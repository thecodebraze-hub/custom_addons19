# -*- coding: utf-8 -*-

from odoo import fields, models


class ShopifySyncLog(models.Model):
    _name = "shopify.sync.log"
    _description = "Shopify Sync Log"
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(string="Reference", required=True, index=True)
    instance_id = fields.Many2one(
        comodel_name="shopify.instance",
        string="Store",
        ondelete="set null",
        index=True,
        help="Shopify store that the request was sent to.",
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        default=lambda self: self.env.company,
        index=True,
    )
    endpoint = fields.Char(string="Endpoint", required=True, help="Full URL of the request.")
    method = fields.Char(string="HTTP Method", required=True)
    request_body = fields.Text(string="Request Body")
    response_body = fields.Text(string="Response Body")
    status_code = fields.Integer(string="Status Code")
    duration_ms = fields.Float(
        string="Duration (ms)",
        digits=(16, 2),
        help="Execution time of the request in milliseconds.",
    )
    success = fields.Boolean(
        string="Success",
        default=False,
        help="True when the request completed with a successful HTTP status.",
    )
    error_message = fields.Text(string="Error Message")
    user_id = fields.Many2one(
        comodel_name="res.users",
        string="Created By",
        default=lambda self: self.env.user,
        index=True,
    )
    log_date = fields.Datetime(
        string="Date",
        default=fields.Datetime.now,
        index=True,
        help="Date and time when the request was executed.",
    )
