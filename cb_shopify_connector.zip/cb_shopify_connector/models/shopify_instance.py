# -*- coding: utf-8 -*-

import re
from typing import Any

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from odoo.addons.base.models.res_partner import _tz_get
from odoo.addons.cb_shopify_connector.services.shopify_connection import ShopifyConnectionService
from odoo.addons.cb_shopify_connector.services.shopify_product_import import ShopifyProductImportService
from odoo.addons.cb_shopify_connector.services.shopify_product_export import ShopifyProductExportService

_SHOPIFY_DOMAIN_RE = re.compile(
    r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.myshopify\.com$",
    re.IGNORECASE,
)

SHOPIFY_API_VERSIONS = [
    "2025-10",
    "2026-01",
    "2026-04",
    "2026-07",
]


class ShopifyInstance(models.Model):
    """Store credentials and Odoo mapping for one Shopify shop."""

    _name = "shopify.instance"
    _description = "Shopify Store"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name, id"
    _check_company_auto = True

    name = fields.Char(
        string="Store Name",
        required=True,
        tracking=True,
        help="Internal label used inside Odoo to identify this Shopify store.",
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
        tracking=True,
        help="Odoo company that owns this Shopify store configuration.",
    )
    warehouse_id = fields.Many2one(
        comodel_name="stock.warehouse",
        string="Warehouse",
        required=True,
        check_company=True,
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        help="Default Odoo warehouse used to fulfill Shopify orders for this store.",
    )
    shop_domain = fields.Char(
        string="Shop Domain",
        required=True,
        tracking=True,
        help=(
            "Shopify myshopify.com domain of the store. "
            "Example: my-brand.myshopify.com"
        ),
    )
    access_token = fields.Char(
        string="Access Token",
        copy=False,
        groups="cb_shopify_connector.group_shopify_administrator,cb_shopify_connector.group_shopify_manager",
        help="Private Admin API access token generated from the Shopify custom app.",
    )
    api_version = fields.Selection(
        selection=[(version, version) for version in SHOPIFY_API_VERSIONS],
        string="API Version",
        required=True,
        default="2026-07",
        tracking=True,
        help="Shopify Admin API version used for REST and GraphQL requests.",
    )
    currency = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.company.currency_id,
        tracking=True,
        help="Primary currency configured on the Shopify store.",
    )
    timezone = fields.Selection(
        selection=_tz_get,
        string="Timezone",
        required=True,
        default=lambda self: self.env.user.tz or "UTC",
        help="Timezone configured on the Shopify store.",
    )
    webhook_secret = fields.Char(
        string="Webhook Secret",
        copy=False,
        groups="cb_shopify_connector.group_shopify_administrator,cb_shopify_connector.group_shopify_manager",
        help="Shared secret used to verify incoming Shopify webhook signatures.",
    )
    active = fields.Boolean(
        string="Active",
        default=True,
        tracking=True,
        help="Inactive stores are hidden from sync operations and selection lists.",
    )
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("connected", "Connected"),
            ("failed", "Failed"),
        ],
        string="Status",
        default="draft",
        required=True,
        tracking=True,
        copy=False,
        help="Connection lifecycle status of the Shopify store configuration.",
    )
    shopify_shop_id = fields.Char(
        string="Shopify Shop ID",
        readonly=True,
        copy=False,
        help="Unique identifier of the shop on Shopify.",
    )
    shopify_shop_name = fields.Char(
        string="Shopify Shop Name",
        readonly=True,
        copy=False,
        help="Display name of the shop returned by Shopify.",
    )
    shopify_shop_email = fields.Char(
        string="Shopify Shop Email",
        readonly=True,
        copy=False,
        help="Primary contact email configured on the Shopify store.",
    )
    shopify_shop_domain = fields.Char(
        string="Shopify Domain",
        readonly=True,
        copy=False,
        help="Public customer-facing domain configured on Shopify.",
    )
    last_connection_test = fields.Datetime(
        string="Last Connection Test",
        readonly=True,
        copy=False,
        help="Date and time when the connection was last tested.",
    )
    last_connection_error = fields.Text(
        string="Last Connection Error",
        readonly=True,
        copy=False,
        help="Error message returned by the most recent failed connection test.",
    )
    sync_log_ids = fields.One2many(
        comodel_name="shopify.sync.log",
        inverse_name="instance_id",
        string="Sync Logs",
    )
    sync_log_count = fields.Integer(compute="_compute_sync_log_count")

    _shop_domain_unique = models.Constraint(
        "unique(company_id, shop_domain)",
        "A Shopify store with this domain already exists for the selected company.",
    )
    _shop_domain_format = models.Constraint(
        "CHECK(shop_domain ~* "
        "'^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\\.myshopify\\.com$')",
        "Shop domain must be a valid myshopify.com address (example: my-brand.myshopify.com).",
    )

    @api.model_create_multi
    def create(self, vals_list: list[dict[str, Any]]):
        """Normalize domains before enforcing uniqueness."""
        for vals in vals_list:
            if vals.get("shop_domain"):
                vals["shop_domain"] = vals["shop_domain"].strip().lower()
        return super().create(vals_list)

    def write(self, vals: dict[str, Any]) -> bool:
        """Normalize a changed domain and reset connection metadata when credentials change."""
        if vals.get("shop_domain"):
            vals["shop_domain"] = vals["shop_domain"].strip().lower()
        credential_fields = {"shop_domain", "access_token", "api_version"}
        if credential_fields.intersection(vals.keys()):
            vals.setdefault("state", "draft")
            vals.setdefault("shopify_shop_id", False)
            vals.setdefault("shopify_shop_name", False)
            vals.setdefault("shopify_shop_email", False)
            vals.setdefault("shopify_shop_domain", False)
            vals.setdefault("last_connection_test", False)
            vals.setdefault("last_connection_error", False)
        return super().write(vals)

    @api.depends("sync_log_ids")
    def _compute_sync_log_count(self) -> None:
        for instance in self:
            instance.sync_log_count = len(instance.sync_log_ids)

    def _validate_connection_credentials(self) -> None:
        """Ensure required credentials exist before calling Shopify."""
        self.ensure_one()
        if not self.shop_domain:
            raise UserError(_("Enter a valid shop domain before testing the connection."))
        if not self.access_token:
            raise UserError(_("Enter the Shopify access token before testing the connection."))

    def _notify_connection_success(self, shop_name: str | None) -> dict[str, Any]:
        """Return a success notification for the UI."""
        self.ensure_one()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Connection Successful"),
                "message": _("Successfully connected to Shopify store '%s'.", shop_name or self.name),
                "type": "success",
                "sticky": False,
            },
        }

    def action_test_connection(self) -> dict[str, Any]:
        """Validate Shopify credentials and update the connection state."""
        self.ensure_one()
        return ShopifyConnectionService(self.env).test_connection(self)

    def action_import_product_wizard(self) -> dict[str, Any]:
        """Open the wizard to import one Shopify product."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Import Shopify Product"),
            "res_model": "shopify.import.product.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_instance_id": self.id,
            },
        }

    def action_import_all_products(self) -> dict[str, Any]:
        """Import all products from the connected Shopify store."""
        self.ensure_one()
        return ShopifyProductImportService(self.env).import_all_products(self)

    def action_export_product_wizard(self) -> dict[str, Any]:
        """Open the wizard to export one Odoo product to Shopify."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Export Product to Shopify"),
            "res_model": "shopify.export.product.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_instance_id": self.id,
            },
        }

    def action_export_all_products(self) -> dict[str, Any]:
        """Export all saleable Odoo products to the connected Shopify store."""
        self.ensure_one()
        return ShopifyProductExportService(self.env).export_all_products(self)

    def action_view_sync_logs(self) -> dict[str, Any]:
        """Open sync logs linked to this store instance."""
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Shopify Sync Logs"),
            "res_model": "shopify.sync.log",
            "view_mode": "list,form",
            "domain": [("instance_id", "=", self.id)],
            "context": {
                "default_instance_id": self.id,
                "default_company_id": self.company_id.id,
            },
        }

    @api.constrains("shop_domain")
    def _check_shop_domain(self) -> None:
        """Ensure the domain uses Shopify's canonical host format."""
        for instance in self:
            domain = (instance.shop_domain or "").strip().lower()
            if domain and not _SHOPIFY_DOMAIN_RE.match(domain):
                raise ValidationError(
                    _(
                        "Enter a valid Shopify domain such as "
                        "'my-brand.myshopify.com'."
                    )
                )

    @api.onchange("company_id")
    def _onchange_company_id(self) -> None:
        """Reset company-dependent values when the company changes."""
        if self.company_id:
            self.currency = self.company_id.currency_id
            if self.warehouse_id and self.warehouse_id.company_id != self.company_id:
                self.warehouse_id = False
