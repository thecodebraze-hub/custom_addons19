# -*- coding: utf-8 -*-

from odoo import fields, models


class ShopifyProductMapping(models.Model):
    """Map one Odoo product variant to one Shopify product variant."""

    _name = "shopify.product.mapping"
    _description = "Shopify Product Mapping"
    _rec_name = "product_id"
    _order = "instance_id, product_id, id"
    _check_company_auto = True

    product_id = fields.Many2one(
        comodel_name="product.product",
        string="Odoo Product",
        required=True,
        ondelete="cascade",
        index=True,
        help="Odoo product variant represented by this Shopify mapping.",
    )
    shopify_product_id = fields.Char(
        string="Shopify Product ID",
        required=True,
        index=True,
        help="Unique identifier of the parent product in Shopify.",
    )
    shopify_variant_id = fields.Char(
        string="Shopify Variant ID",
        required=True,
        index=True,
        help="Unique identifier of the product variant in Shopify.",
    )
    instance_id = fields.Many2one(
        comodel_name="shopify.instance",
        string="Store",
        required=True,
        ondelete="cascade",
        check_company=True,
        index=True,
        help="Shopify store to which this product mapping belongs.",
    )
    company_id = fields.Many2one(
        related="instance_id.company_id",
        string="Company",
        store=True,
        readonly=True,
        index=True,
    )
    last_sync = fields.Datetime(
        string="Last Sync",
        readonly=True,
        copy=False,
        help="Date and time when this mapping was last synchronized successfully.",
    )
    sync_status = fields.Selection(
        selection=[
            ("pending", "Pending"),
            ("synced", "Synced"),
            ("failed", "Failed"),
        ],
        string="Sync Status",
        required=True,
        default="pending",
        readonly=True,
        copy=False,
        index=True,
        help="Current synchronization state of this product mapping.",
    )

    _odoo_product_store_unique = models.Constraint(
        "unique(product_id, instance_id)",
        "An Odoo product can only be mapped once per Shopify store.",
    )
    _shopify_variant_store_unique = models.Constraint(
        "unique(shopify_variant_id, instance_id)",
        "A Shopify variant can only be mapped once per Shopify store.",
    )
