# -*- coding: utf-8 -*-
"""Import Shopify products into Odoo and create product mappings."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from odoo import _, fields
from odoo.exceptions import UserError

from odoo.addons.cb_shopify_connector.services.shopify_api import (
    ShopifyAPIError,
    ShopifyNetworkError,
)
from odoo.addons.cb_shopify_connector.services.shopify_sync_log_service import (
    ShopifySyncLogService,
)

_logger = logging.getLogger(__name__)


@dataclass
class ProductImportResult:
    """Summary counters for a product import operation."""

    imported: int = 0
    updated: int = 0
    skipped: int = 0
    failed: int = 0
    errors: list[str] = field(default_factory=list)

    def merge(self, other: ProductImportResult) -> None:
        self.imported += other.imported
        self.updated += other.updated
        self.skipped += other.skipped
        self.failed += other.failed
        self.errors.extend(other.errors)


class ShopifyProductImportService:
    """Fetch Shopify products and create Odoo products with mappings."""

    def __init__(self, env) -> None:
        self.env = env
        self._log_service = ShopifySyncLogService(env)

    def import_product(self, instance, shopify_product_id: str) -> dict[str, Any]:
        """Import one Shopify product by its product ID."""
        instance.ensure_one()
        self._validate_instance(instance)
        product_id = str(shopify_product_id).strip()
        if not product_id.isdigit():
            raise UserError(_("Enter a valid numeric Shopify product ID."))

        result = ProductImportResult()
        client = self._log_service.get_client(instance)
        try:
            with client:
                payload = client.get(f"products/{product_id}.json")
        except (ShopifyAPIError, ShopifyNetworkError) as exc:
            raise UserError(_("Product import failed: %s", exc)) from exc

        product_data = payload.get("product")
        if not product_data:
            raise UserError(_("Shopify product %s was not found.", product_id))

        self._import_shopify_product(instance, product_data, result)
        if result.failed and not result.imported and not result.updated:
            raise UserError(
                _("Product import failed: %s", result.errors[0] if result.errors else product_id)
            )
        return self._notify_result(instance, result, single=True)

    def import_all_products(self, instance) -> dict[str, Any]:
        """Import all Shopify products for the given store."""
        instance.ensure_one()
        self._validate_instance(instance)

        result = ProductImportResult()
        client = self._log_service.get_client(instance)
        try:
            with client:
                for product_data in client.paginate_resources("products.json", "products"):
                    try:
                        self._import_shopify_product(instance, product_data, result)
                    except Exception as exc:  # pylint: disable=broad-except
                        result.failed += 1
                        message = _("Product %(product)s: %(error)s", product=product_data.get("id"), error=exc)
                        result.errors.append(str(message))
                        _logger.exception(
                            "Failed importing Shopify product %s for instance %s",
                            product_data.get("id"),
                            instance.name,
                        )
        except (ShopifyAPIError, ShopifyNetworkError) as exc:
            raise UserError(_("Product import failed: %s", exc)) from exc

        if result.failed and not result.imported and not result.updated:
            raise UserError(
                _("Product import failed: %s", result.errors[0] if result.errors else _("Unknown error"))
            )
        return self._notify_result(instance, result, single=False)

    def _validate_instance(self, instance) -> None:
        """Ensure the store is ready for product import."""
        if instance.state != "connected":
            raise UserError(_("Connect the Shopify store before importing products."))
        instance._validate_connection_credentials()

    def _import_shopify_product(
        self,
        instance,
        product_data: dict[str, Any],
        result: ProductImportResult,
    ) -> None:
        """Import one Shopify product using its primary variant only."""
        variant_data = self._get_primary_variant(product_data)
        if not variant_data:
            result.skipped += 1
            result.errors.append(
                _("Product %(product)s has no variants.", product=product_data.get("id"))
            )
            return

        shopify_product_id = str(product_data["id"])
        shopify_variant_id = str(variant_data["id"])
        mapping_model = self.env["shopify.product.mapping"].sudo()
        mapping = mapping_model.search([
            ("instance_id", "=", instance.id),
            ("shopify_variant_id", "=", shopify_variant_id),
        ], limit=1)

        product_vals = self._prepare_product_vals(instance, product_data, variant_data)
        if mapping:
            self._apply_product_values(
                mapping.product_id.with_company(instance.company_id),
                product_vals,
            )
            mapping.write({
                "shopify_product_id": shopify_product_id,
                "last_sync": fields.Datetime.now(),
                "sync_status": "synced",
            })
            result.updated += 1
            return

        product = self._create_odoo_product(instance, product_vals)
        mapping_model.create({
            "product_id": product.id,
            "shopify_product_id": shopify_product_id,
            "shopify_variant_id": shopify_variant_id,
            "instance_id": instance.id,
            "last_sync": fields.Datetime.now(),
            "sync_status": "synced",
        })
        result.imported += 1

    def _get_primary_variant(self, product_data: dict[str, Any]) -> dict[str, Any] | None:
        """Return the first Shopify variant and ignore additional variants."""
        variants = product_data.get("variants") or []
        return variants[0] if variants else None

    def _prepare_product_vals(
        self,
        instance,
        product_data: dict[str, Any],
        variant_data: dict[str, Any],
    ) -> dict[str, Any]:
        """Map Shopify product and variant fields to Odoo product values."""
        name = product_data.get("title") or _("Shopify Product %s", product_data.get("id"))
        price = float(variant_data.get("price") or 0.0)
        vals = {
            "name": name,
            "list_price": price,
            "default_code": variant_data.get("sku") or False,
            "barcode": variant_data.get("barcode") or False,
        }
        if instance.company_id:
            vals["company_id"] = instance.company_id.id
        return vals

    def _create_odoo_product(self, instance, product_vals: dict[str, Any]):
        """Create a consumable Odoo product for the imported Shopify item."""
        template_vals = {
            "name": product_vals["name"],
            "list_price": product_vals["list_price"],
            "type": "consu",
            "sale_ok": True,
            "purchase_ok": False,
        }
        if product_vals.get("company_id"):
            template_vals["company_id"] = product_vals["company_id"]

        template = self.env["product.template"].with_company(instance.company_id).create(template_vals)
        product = template.product_variant_id
        self._apply_product_values(product, product_vals)
        return product

    def _apply_product_values(self, product, product_vals: dict[str, Any]) -> None:
        """Write imported values on the product template and variant."""
        product.product_tmpl_id.write({
            "name": product_vals["name"],
            "list_price": product_vals["list_price"],
        })
        product.write({
            "default_code": product_vals.get("default_code"),
            "barcode": product_vals.get("barcode"),
        })

    def _notify_result(
        self,
        instance,
        result: ProductImportResult,
        *,
        single: bool,
    ) -> dict[str, Any]:
        """Return a client notification summarizing the import."""
        if single:
            if result.imported:
                message = _("Product imported successfully from Shopify store '%s'.", instance.name)
            elif result.updated:
                message = _("Product updated successfully from Shopify store '%s'.", instance.name)
            else:
                message = _("Product import completed for Shopify store '%s'.", instance.name)
        else:
            message = _(
                "Imported %(imported)s, updated %(updated)s, skipped %(skipped)s, "
                "failed %(failed)s product(s) from Shopify store '%(store)s'.",
                imported=result.imported,
                updated=result.updated,
                skipped=result.skipped,
                failed=result.failed,
                store=instance.name,
            )
        notification_type = "success" if not result.failed else "warning"
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Product Import"),
                "message": message,
                "type": notification_type,
                "sticky": bool(result.failed),
            },
        }
