# -*- coding: utf-8 -*-
"""Shared helpers for persisting Shopify API sync logs."""

from __future__ import annotations

from odoo.addons.cb_shopify_connector.services.shopify_api import (
    ShopifyAPIClient,
    ShopifyRequestLog,
)


class ShopifySyncLogService:
    """Build logged API clients and persist sync log entries."""

    def __init__(self, env) -> None:
        self.env = env

    def get_client(self, instance) -> ShopifyAPIClient:
        """Return an API client that logs every request for the given store."""
        instance.ensure_one()
        return ShopifyAPIClient.from_credentials(
            shop_domain=instance.shop_domain,
            access_token=instance.access_token,
            api_version=instance.api_version,
            log_callback=self._make_log_callback(instance),
        )

    def _make_log_callback(self, instance):
        log_model = self.env["shopify.sync.log"].sudo()

        def log_callback(log_entry: ShopifyRequestLog) -> None:
            self.create_log(instance, log_model, log_entry)

        return log_callback

    def create_log(self, instance, log_model, log_entry: ShopifyRequestLog) -> None:
        """Persist one sync log entry linked to the store instance."""
        is_success = (
            not log_entry.error_message
            and 200 <= log_entry.status_code < 300
        )
        log_model.create({
            "name": f"{log_entry.method} {log_entry.url}",
            "instance_id": instance.id,
            "company_id": instance.company_id.id,
            "user_id": self.env.user.id,
            "method": log_entry.method,
            "endpoint": log_entry.url,
            "request_body": log_entry.request_body,
            "response_body": log_entry.response_body,
            "status_code": log_entry.status_code,
            "duration_ms": log_entry.duration_ms,
            "success": is_success,
            "error_message": log_entry.error_message,
        })
