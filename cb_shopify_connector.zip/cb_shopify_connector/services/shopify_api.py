# -*- coding: utf-8 -*-
"""Reusable Shopify Admin API HTTP client."""

from __future__ import annotations

import json
import logging
import re
import time
from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

import requests
from requests import Response, Session
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

_logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 3
RETRYABLE_STATUS_CODES = frozenset({429, 500, 502, 503, 504})
MAX_LOG_BODY_LENGTH = 65535


class ShopifyAPIError(Exception):
    """Raised when Shopify returns an application or HTTP error."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: str | None = None,
        errors: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
        self.errors = errors


class ShopifyNetworkError(Exception):
    """Raised when the Shopify API cannot be reached."""

    def __init__(self, message: str, *, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.cause = cause


@dataclass
class ShopifyRequestLog:
    """Structured log payload for one Shopify API request."""

    method: str
    url: str
    status_code: int
    duration_ms: float
    request_body: str = ""
    response_body: str = ""
    error_message: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class ShopifyAPIClient:
    """Low-level client for Shopify REST and GraphQL Admin API requests.

    This class is intentionally independent from Odoo models so it can be reused
    by services, cron jobs, controllers, and queue processors.
    """

    def __init__(
        self,
        shop_domain: str,
        access_token: str,
        api_version: str,
        *,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        session: Session | None = None,
        log_callback: Callable[[ShopifyRequestLog], None] | None = None,
    ) -> None:
        """Initialize the client.

        :param shop_domain: Normalized Shopify domain, e.g. ``my-brand.myshopify.com``.
        :param access_token: Shopify Admin API access token.
        :param api_version: Shopify API version, e.g. ``2026-07``.
        :param timeout: Request timeout in seconds.
        :param max_retries: Number of retries for transient HTTP failures.
        :param session: Optional preconfigured ``requests.Session`` instance.
        :param log_callback: Optional callable invoked with ``ShopifyRequestLog``.
        """
        self.shop_domain = shop_domain.strip().lower()
        self.access_token = access_token
        self.api_version = api_version
        self.timeout = timeout
        self.max_retries = max_retries
        self._session = session or self._build_session(max_retries)
        self._owns_session = session is None
        self._log_callback = log_callback

    @classmethod
    def from_credentials(
        cls,
        shop_domain: str,
        access_token: str,
        api_version: str,
        **kwargs: Any,
    ) -> ShopifyAPIClient:
        """Build a client from plain credential values."""
        return cls(
            shop_domain=shop_domain,
            access_token=access_token,
            api_version=api_version,
            **kwargs,
        )

    @property
    def base_url(self) -> str:
        """REST Admin API base URL."""
        return f"https://{self.shop_domain}/admin/api/{self.api_version}/"

    @property
    def graphql_url(self) -> str:
        """GraphQL Admin API endpoint."""
        return f"https://{self.shop_domain}/admin/api/{self.api_version}/graphql.json"

    def close(self) -> None:
        """Close the underlying HTTP session when owned by the client."""
        if self._owns_session:
            self._session.close()

    def __enter__(self) -> ShopifyAPIClient:
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()

    def get(self, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Perform a GET request against the REST Admin API."""
        return self.request("GET", endpoint, **kwargs)

    def post(self, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Perform a POST request against the REST Admin API."""
        return self.request("POST", endpoint, **kwargs)

    def put(self, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Perform a PUT request against the REST Admin API."""
        return self.request("PUT", endpoint, **kwargs)

    def delete(self, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Perform a DELETE request against the REST Admin API."""
        return self.request("DELETE", endpoint, **kwargs)

    def graphql(
        self,
        query: str,
        variables: Mapping[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute a GraphQL Admin API request."""
        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = dict(variables)
        return self.request(
            "POST",
            self.graphql_url,
            json=payload,
            absolute_url=True,
            validate_graphql=True,
            **kwargs,
        )

    def paginate_resources(
        self,
        endpoint: str,
        resource_key: str,
        *,
        limit: int = 250,
        params: Mapping[str, Any] | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Yield resources from a paginated Shopify REST collection."""
        request_params = dict(params or {})
        request_params["limit"] = limit
        url = endpoint
        absolute_url = False
        while url:
            payload, response = self._perform_request(
                "GET",
                url,
                absolute_url=absolute_url,
                params=request_params if not absolute_url else None,
            )
            for resource in payload.get(resource_key, []):
                yield resource
            next_url = self._parse_next_link(response.headers.get("Link"))
            if not next_url:
                break
            url = next_url
            absolute_url = True
            request_params = {}

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        absolute_url: bool = False,
        validate_graphql: bool = False,
        headers: Mapping[str, str] | None = None,
        log_request: bool = True,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute an HTTP request and return the parsed JSON body."""
        payload, _response = self._perform_request(
            method,
            endpoint,
            absolute_url=absolute_url,
            validate_graphql=validate_graphql,
            headers=headers,
            log_request=log_request,
            **kwargs,
        )
        return payload

    def _perform_request(
        self,
        method: str,
        endpoint: str,
        *,
        absolute_url: bool = False,
        validate_graphql: bool = False,
        headers: Mapping[str, str] | None = None,
        log_request: bool = True,
        **kwargs: Any,
    ) -> tuple[dict[str, Any], Response | None]:
        """Execute an HTTP request and return the parsed body and raw response."""
        url = endpoint if absolute_url else self._build_rest_url(endpoint)
        request_headers = self._build_headers(headers)
        request_body = self._serialize_payload(kwargs.get("json") or kwargs.get("data"))

        start_time = time.perf_counter()
        response: Response | None = None
        error_message: str | None = None
        response_payload: dict[str, Any] = {}

        try:
            response = self._send(method, url, headers=request_headers, **kwargs)
            response_payload = self._parse_json(response)
            if not response.ok:
                error_message = self._extract_error_message(response, response_payload)
                raise ShopifyAPIError(
                    error_message,
                    status_code=response.status_code,
                    response_body=self._truncate(response.text),
                    errors=response_payload.get("errors"),
                )
            if validate_graphql and response_payload.get("errors"):
                error_message = self._format_graphql_errors(response_payload["errors"])
                raise ShopifyAPIError(
                    error_message,
                    status_code=response.status_code,
                    response_body=self._truncate(response.text),
                    errors=response_payload["errors"],
                )
            return response_payload, response
        except ShopifyAPIError:
            raise
        except requests.RequestException as exc:
            error_message = str(exc)
            _logger.exception(
                "Shopify network error [%s %s] domain=%s",
                method,
                url,
                self.shop_domain,
            )
            raise ShopifyNetworkError(
                f"Could not reach Shopify: {error_message}",
                cause=exc,
            ) from exc
        finally:
            if log_request:
                duration_ms = (time.perf_counter() - start_time) * 1000
                self._log_request(
                    ShopifyRequestLog(
                        method=method,
                        url=url,
                        status_code=response.status_code if response is not None else 0,
                        duration_ms=duration_ms,
                        request_body=request_body,
                        response_body=self._truncate(response.text) if response is not None else "",
                        error_message=error_message,
                        metadata={"shop_domain": self.shop_domain},
                    )
                )

    def _build_session(self, max_retries: int) -> Session:
        """Create a configured ``requests.Session`` with retry support."""
        session = requests.Session()
        retry = Retry(
            total=max_retries,
            connect=max_retries,
            read=max_retries,
            status=max_retries,
            status_forcelist=sorted(RETRYABLE_STATUS_CODES),
            allowed_methods=frozenset({"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"}),
            backoff_factor=0.5,
            respect_retry_after_header=True,
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session

    def _build_headers(
        self,
        extra_headers: Mapping[str, str] | None = None,
    ) -> dict[str, str]:
        """Build default Shopify authentication headers."""
        headers: dict[str, str] = {
            "X-Shopify-Access-Token": self.access_token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def _build_rest_url(self, endpoint: str) -> str:
        """Join a REST endpoint with the Admin API base URL."""
        endpoint = endpoint.lstrip("/")
        return f"{self.base_url}{endpoint}"

    def _send(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str],
        **kwargs: Any,
    ) -> Response:
        """Send the HTTP request through the configured session."""
        return self._session.request(
            method=method,
            url=url,
            headers=headers,
            timeout=self.timeout,
            **kwargs,
        )

    def _log_request(self, log_entry: ShopifyRequestLog) -> None:
        """Write request details to Python logging and optional callback."""
        if log_entry.error_message:
            _logger.warning(
                "Shopify API %s %s -> %s (%.2f ms) error=%s",
                log_entry.method,
                log_entry.url,
                log_entry.status_code,
                log_entry.duration_ms,
                log_entry.error_message,
            )
        else:
            _logger.info(
                "Shopify API %s %s -> %s (%.2f ms)",
                log_entry.method,
                log_entry.url,
                log_entry.status_code,
                log_entry.duration_ms,
            )
        if self._log_callback:
            self._log_callback(log_entry)

    @staticmethod
    def _serialize_payload(payload: Any) -> str:
        """Serialize request payload for logging."""
        if payload is None:
            return ""
        if isinstance(payload, (dict, list)):
            text = json.dumps(payload, ensure_ascii=False, default=str)
        else:
            text = str(payload)
        return ShopifyAPIClient._truncate(text)

    @staticmethod
    def _parse_json(response: Response) -> dict[str, Any]:
        """Parse a JSON response body when possible."""
        if not response.content:
            return {}
        try:
            payload = response.json()
        except ValueError:
            return {"raw_response": ShopifyAPIClient._truncate(response.text)}
        return payload if isinstance(payload, dict) else {"data": payload}

    @staticmethod
    def _extract_error_message(response: Response, payload: dict[str, Any]) -> str:
        """Build a readable error message from a Shopify error response."""
        if "errors" in payload:
            return ShopifyAPIClient._format_graphql_errors(payload["errors"])
        if "error" in payload:
            return str(payload["error"])
        return f"Shopify returned HTTP {response.status_code}."

    @staticmethod
    def _format_graphql_errors(errors: Any) -> str:
        """Format REST or GraphQL error payloads into a single message."""
        if isinstance(errors, str):
            return errors
        if isinstance(errors, list):
            messages = []
            for error in errors:
                if isinstance(error, dict):
                    message = error.get("message") or error.get("title") or str(error)
                    messages.append(str(message))
                else:
                    messages.append(str(error))
            return "; ".join(messages)
        if isinstance(errors, dict):
            parts = []
            for key, value in errors.items():
                if isinstance(value, list):
                    parts.append(f"{key}: {', '.join(str(item) for item in value)}")
                else:
                    parts.append(f"{key}: {value}")
            return "; ".join(parts)
        return str(errors)

    @staticmethod
    def _parse_next_link(link_header: str | None) -> str | None:
        """Extract the next page URL from a Shopify Link header."""
        if not link_header:
            return None
        for part in link_header.split(","):
            if 'rel="next"' not in part:
                continue
            match = re.search(r"<([^>]+)>", part)
            if match:
                return match.group(1)
        return None

    @staticmethod
    def _truncate(value: str) -> str:
        """Limit logged payload size."""
        return value[:MAX_LOG_BODY_LENGTH]
