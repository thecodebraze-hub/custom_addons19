# -*- coding: utf-8 -*-
"""Export Odoo products to Shopify and maintain product mappings."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from odoo import _, fields
from odoo.exceptions import UserError

from odoo.addons.cb_shopify_connector.services.shopify_api import (
    ShopifyAPIError,
    ShopifyNetworkError,
)
from odoo.addons.cb_shopify_connector.services.shopify_sync_log_service import (
    ShopifySyncLogService,
)

_logger = logging.getLogger(__name__)


@dataclass
class ProductExportResult:
    """Summary counters for a product export operation."""

    created: int = 0
    updated: int = 0
    skipped: int = 0
    failed: int = 0
    errors: list[str] = field(default_factory=list)


class ShopifyProductExportService:
    """Push Odoo product data to Shopify and create or update mappings."""

    def __init__(self, env) -> None:
        self.env = env
        self._log_service = ShopifySyncLogService(env)

    def export_product(self, instance, product) -> dict[str, Any]:
        """Export one Odoo product to Shopify."""
        instance.ensure_one()
        product.ensure_one()
        self._validate_instance(instance)

        result = ProductExportResult()
        client = self._log_service.get_client(instance)
        with client:
            self._export_odoo_product(instance, product, client, result)

        if result.failed and not result.created and not result.updated:
            raise UserError(
                _("Product export failed: %s", result.errors[0] if result.errors else product.display_name)
            )
        return self._notify_result(instance, result, single=True)

    def export_all_products(self, instance) -> dict[str, Any]:
        """Export all saleable Odoo products for the store company."""
        instance.ensure_one()
        self._validate_instance(instance)

        products = self._get_exportable_products(instance)
        result = ProductExportResult()
        client = self._log_service.get_client(instance)
        with client:
            for product in products:
                self._export_odoo_product(instance, product, client, result)

        if result.failed and not result.created and not result.updated:
            raise UserError(
                _("Product export failed: %s", result.errors[0] if result.errors else _("Unknown error"))
            )
        return self._notify_result(instance, result, single=False)

    def _validate_instance(self, instance) -> None:
        """Ensure the store is ready for product export."""
        if instance.state != "connected":
            raise UserError(_("Connect the Shopify store before exporting products."))
        instance._validate_connection_credentials()

    def _get_exportable_products(self, instance):
        """Return saleable products scoped to the store company."""
        domain = [
            ("sale_ok", "=", True),
            "|",
            ("company_id", "=", False),
            ("company_id", "=", instance.company_id.id),
        ]
        return self.env["product.product"].with_company(instance.company_id).search(domain)

    def _export_odoo_product(
        self,
        instance,
        product,
        client,
        result: ProductExportResult,
    ) -> None:
        """Create or update one Shopify product from an Odoo product."""
        product = product.with_company(instance.company_id)
        mapping_model = self.env["shopify.product.mapping"].sudo()
        mapping = mapping_model.search([
            ("instance_id", "=", instance.id),
            ("product_id", "=", product.id),
        ], limit=1)

        payload = self._prepare_shopify_payload(product, mapping)
        try:
            if mapping:
                response = client.put(
                    f"products/{mapping.shopify_product_id}.json",
                    json={"product": payload},
                )
                self._update_mapping(mapping, response)
                result.updated += 1
                return

            response = client.post("products.json", json={"product": payload})
            self._create_mapping(instance, product, mapping_model, response)
            result.created += 1
        except (ShopifyAPIError, ShopifyNetworkError) as exc:
            if mapping:
                mapping.write({"sync_status": "failed"})
            result.failed += 1
            result.errors.append(
                _("Product %(product)s: %(error)s", product=product.display_name, error=exc)
            )
            _logger.exception(
                "Failed exporting Odoo product %s for instance %s",
                product.display_name,
                instance.name,
            )

    def _prepare_shopify_payload(
        self,
        product,
        mapping,
    ) -> dict[str, Any]:
        """Build the minimal Shopify product payload for export."""
        variant_payload: dict[str, Any] = {
            "sku": product.default_code or "",
            "barcode": product.barcode or "",
            "price": f"{product.list_price:.2f}",
        }
        if mapping:
            variant_payload["id"] = int(mapping.shopify_variant_id)

        payload: dict[str, Any] = {
            "title": product.product_tmpl_id.name,
            "variants": [variant_payload],
        }
        if mapping:
            payload["id"] = int(mapping.shopify_product_id)
        return payload

    def _create_mapping(self, instance, product, mapping_model, response: dict[str, Any]) -> None:
        """Create a mapping from a Shopify create response."""
        product_data = response.get("product") or {}
        variant_data = self._get_primary_variant(product_data)
        if not product_data.get("id") or not variant_data.get("id"):
            raise UserError(_("Shopify did not return product identifiers after export."))

        mapping_model.create({
            "product_id": product.id,
            "shopify_product_id": str(product_data["id"]),
            "shopify_variant_id": str(variant_data["id"]),
            "instance_id": instance.id,
            "last_sync": fields.Datetime.now(),
            "sync_status": "synced",
        })

    def _update_mapping(self, mapping, response: dict[str, Any]) -> None:
        """Refresh mapping metadata after a Shopify update."""
        product_data = response.get("product") or {}
        variant_data = self._get_primary_variant(product_data)
        vals = {
            "last_sync": fields.Datetime.now(),
            "sync_status": "synced",
        }
        if product_data.get("id"):
            vals["shopify_product_id"] = str(product_data["id"])
        if variant_data and variant_data.get("id"):
            vals["shopify_variant_id"] = str(variant_data["id"])
        mapping.write(vals)

    @staticmethod
    def _get_primary_variant(product_data: dict[str, Any]) -> dict[str, Any]:
        """Return the first Shopify variant from a product payload."""
        variants = product_data.get("variants") or []
        return variants[0] if variants else {}

    def _notify_result(
        self,
        instance,
        result: ProductExportResult,
        *,
        single: bool,
    ) -> dict[str, Any]:
        """Return a client notification summarizing the export."""
        if single:
            if result.created:
                message = _("Product exported successfully to Shopify store '%s'.", instance.name)
            elif result.updated:
                message = _("Product updated successfully on Shopify store '%s'.", instance.name)
            else:
                message = _("Product export completed for Shopify store '%s'.", instance.name)
        else:
            message = _(
                "Created %(created)s, updated %(updated)s, skipped %(skipped)s, "
                "failed %(failed)s product(s) on Shopify store '%(store)s'.",
                created=result.created,
                updated=result.updated,
                skipped=result.skipped,
                failed=result.failed,
                store=instance.name,
            )
        notification_type = "success" if not result.failed else "warning"
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Product Export"),
                "message": message,
                "type": notification_type,
                "sticky": bool(result.failed),
            },
        }
