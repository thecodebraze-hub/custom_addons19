# -*- coding: utf-8 -*-
"""Business logic for Shopify store connection management."""

from __future__ import annotations

import logging
from typing import Any

from odoo import _, fields
from odoo.exceptions import UserError

from odoo.addons.base.models.res_partner import _tz_get
from odoo.addons.cb_shopify_connector.services.shopify_api import (
    ShopifyAPIError,
    ShopifyNetworkError,
)
from odoo.addons.cb_shopify_connector.services.shopify_sync_log_service import ShopifySyncLogService

_logger = logging.getLogger(__name__)


class ShopifyConnectionService:
    """Validate Shopify credentials and persist connection metadata."""

    def __init__(self, env) -> None:
        self.env = env

    def test_connection(self, instance) -> dict[str, Any]:
        """Validate credentials against ``GET /shop.json``.

        :param instance: ``shopify.instance`` record to validate.
        :return: Client notification action on success.
        :raise UserError: If credentials are missing or Shopify rejects the request.
        """
        instance.ensure_one()
        instance._validate_connection_credentials()

        client_service = ShopifySyncLogService(self.env)
        client = client_service.get_client(instance)

        try:
            with client:
                payload = client.get("shop.json")
        except ShopifyAPIError as exc:
            self._mark_connection_failed(instance, str(exc))
            raise UserError(_("Connection test failed: %s", exc)) from exc
        except ShopifyNetworkError as exc:
            self._mark_connection_failed(instance, str(exc))
            raise UserError(_("Connection test failed: %s", exc)) from exc

        shop_data = payload.get("shop")
        if not shop_data:
            message = _("Unexpected response from Shopify: shop data was not returned.")
            self._mark_connection_failed(instance, message)
            raise UserError(message)

        self._mark_connection_success(instance, shop_data)
        _logger.info(
            "Shopify connection validated for instance %s (%s)",
            instance.name,
            instance.shop_domain,
        )
        return instance._notify_connection_success(shop_data.get("name"))

    def _mark_connection_failed(self, instance, message: str) -> None:
        """Update the instance after a failed connection test."""
        instance.write({
            "state": "failed",
            "last_connection_test": fields.Datetime.now(),
            "last_connection_error": message,
        })

    def _mark_connection_success(self, instance, shop_data: dict[str, Any]) -> None:
        """Store Shopify shop metadata and mark the instance as connected."""
        vals = {
            "state": "connected",
            "shopify_shop_id": str(shop_data.get("id", "")),
            "shopify_shop_name": shop_data.get("name"),
            "shopify_shop_email": shop_data.get("email"),
            "shopify_shop_domain": shop_data.get("domain"),
            "last_connection_test": fields.Datetime.now(),
            "last_connection_error": False,
        }
        currency = self._find_currency(shop_data.get("currency"))
        if currency:
            vals["currency"] = currency.id
        timezone = shop_data.get("iana_timezone") or shop_data.get("timezone")
        if timezone:
            valid_timezones = {code for code, _ in _tz_get(instance)}
            if timezone in valid_timezones:
                vals["timezone"] = timezone
        instance.write(vals)

    def _find_currency(self, currency_code: str | None):
        """Match a Shopify currency code to an Odoo currency record."""
        if not currency_code:
            return self.env["res.currency"]
        return self.env["res.currency"].search([("name", "=", currency_code.upper())], limit=1)
