# -*- coding: utf-8 -*-

from odoo import _, fields, models
from odoo.exceptions import UserError

from odoo.addons.cb_shopify_connector.services.shopify_product_export import (
    ShopifyProductExportService,
)


class ShopifyExportProductWizard(models.TransientModel):
    _name = "shopify.export.product.wizard"
    _description = "Export Product to Shopify Wizard"

    instance_id = fields.Many2one(
        comodel_name="shopify.instance",
        string="Store",
        required=True,
        readonly=True,
    )
    company_id = fields.Many2one(
        related="instance_id.company_id",
        string="Company",
    )
    product_id = fields.Many2one(
        comodel_name="product.product",
        string="Odoo Product",
        required=True,
        domain="[('sale_ok', '=', True), '|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        help="Odoo product to export to the selected Shopify store.",
    )

    def action_export_product(self):
        """Export the selected Odoo product to Shopify."""
        self.ensure_one()
        if not self.product_id:
            raise UserError(_("Select an Odoo product to export."))
        return ShopifyProductExportService(self.env).export_product(
            self.instance_id,
            self.product_id,
        )
