# -*- coding: utf-8 -*-

from odoo import _, fields, models
from odoo.exceptions import UserError

from odoo.addons.cb_shopify_connector.services.shopify_product_import import (
    ShopifyProductImportService,
)


class ShopifyImportProductWizard(models.TransientModel):
    _name = "shopify.import.product.wizard"
    _description = "Import Shopify Product Wizard"

    instance_id = fields.Many2one(
        comodel_name="shopify.instance",
        string="Store",
        required=True,
        readonly=True,
    )
    shopify_product_id = fields.Char(
        string="Shopify Product ID",
        required=True,
        help="Numeric Shopify product identifier to import from the selected store.",
    )

    def action_import_product(self):
        """Import the selected Shopify product into Odoo."""
        self.ensure_one()
        if not self.shopify_product_id:
            raise UserError(_("Enter the Shopify product ID to import."))
        return ShopifyProductImportService(self.env).import_product(
            self.instance_id,
            self.shopify_product_id,
        )
