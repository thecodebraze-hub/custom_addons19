# -*- coding: utf-8 -*-
{
    "name": "Shopify Connector",
    "version": "19.0.1.0.0",
    "category": "Sales/Sales",
    "summary": "Connect Odoo with Shopify stores",
    "description": """
Shopify Connector for Odoo 19
=============================

Foundation module for integrating Odoo with Shopify.

* Configure Shopify store instances per company and warehouse
* Manage API credentials and connection status
    """,
    "author": "CodeBraze PVT LTD",
    "website": "https://www.codebraze.lk",
    "support": "sales@codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "mail",
        "stock",
    ],
    "data": [
        "security/shopify_security.xml",
        "security/ir.model.access.csv",
        "views/shopify_instance_views.xml",
        "views/shopify_product_mapping_views.xml",
        "views/shopify_sync_log_views.xml",
        "wizard/shopify_import_product_wizard_views.xml",
        "wizard/shopify_export_product_wizard_views.xml",
        "views/shopify_menus.xml",
    ],
    "application": True,
    "installable": True,
    "auto_install": False,
}
