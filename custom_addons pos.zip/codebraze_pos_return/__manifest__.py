# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Return",
    "version": "19.0.1.4.0",
    "category": "Sales/Point of Sale",
    "summary": "Retail return and exchange transactions for Odoo POS",
    "description": """
CodeBraze POS Return & Exchange
===============================
Backend documents for product returns and exchanges, linked to the
CodeBraze Store Credit framework.

Includes a custom POS Refund popup UI (separate from Odoo core Refund).
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "point_of_sale",
        "codebraze_pos_store_credit",
        "codebraze_pos_approval",
    ],
    "data": [
        "security/ir.model.access.csv",
        "data/ir_sequence_data.xml",
        "data/pos_return_reason_data.xml",
    ],
    "assets": {
        "point_of_sale._assets_pos": [
            "codebraze_pos_return/static/src/**/*",
        ],
    },
    "application": False,
    "installable": True,
    "auto_install": False,
}
