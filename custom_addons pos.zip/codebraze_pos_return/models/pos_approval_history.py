# -*- coding: utf-8 -*-
"""Manager / supervisor approval history for returns and credit overrides."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class PosApprovalHistory(models.Model):
    """Approval history for return overrides, cash refunds, voids, etc."""

    _name = "pos.approval.history"
    _description = "POS Approval History"
    _inherit = ["store.credit.uuid.mixin", "store.credit.sync.mixin"]
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
    )
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("requested", "Requested"),
            ("approved", "Approved"),
            ("rejected", "Rejected"),
        ],
        string="Status",
        default="requested",
        required=True,
        index=True,
    )
    approval_type = fields.Selection(
        selection=[
            ("return_override", "Return Override"),
            ("cash_refund", "Cash Refund"),
            ("void_voucher", "Void Voucher"),
            ("credit_adjust", "Credit Adjustment"),
            ("guest_return", "Guest Return"),
            ("expiry_extend", "Expiry Extension"),
        ],
        string="Approval Type",
        required=True,
        index=True,
    )
    requester_id = fields.Many2one(
        comodel_name="res.users",
        string="Requester",
        required=True,
        default=lambda self: self.env.user,
        index=True,
    )
    approver_id = fields.Many2one(
        comodel_name="res.users",
        string="Approver",
        index=True,
    )
    approve_datetime = fields.Datetime(string="Approved On", index=True)
    auth_method = fields.Selection(
        selection=[
            ("pin", "PIN"),
            ("login", "Login"),
            ("badge", "Badge"),
        ],
        string="Auth Method",
        default="pin",
    )
    return_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return",
        index=True,
        ondelete="cascade",
        check_company=True,
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        index=True,
        ondelete="set null",
        check_company=True,
    )
    amount = fields.Monetary(string="Amount", currency_field="currency_id")
    reason = fields.Char(string="Reason")
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.company.currency_id,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )

    _sql_constraints = [
        (
            "pos_approval_uuid_uniq",
            "unique(uuid)",
            "Approval UUID must be unique.",
        ),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
            if vals.get("name", "New") == "New":
                company = self.env["res.company"].browse(
                    vals.get("company_id") or self.env.company.id
                )
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("pos.approval.history")
                )
                vals["name"] = seq or f"APR/{fields.Datetime.now()}"
        return super().create(vals_list)

    @api.model
    def _create_approval(self, vals):
        """Helper used by return / credit workflows to open an approval request."""
        vals = dict(vals or {})
        vals.setdefault("state", "requested")
        vals.setdefault("requester_id", self.env.user.id)
        approval = self.create(vals)
        _logger.info(
            "Created approval %s type=%s",
            approval.name,
            approval.approval_type,
        )
        return approval

    def action_approve(self, approver=None):
        approver = approver or self.env.user
        for approval in self:
            if approval.state != "requested":
                raise UserError(self.env._("Only requested approvals can be approved."))
            approval.write(
                {
                    "state": "approved",
                    "approver_id": approver.id,
                    "approve_datetime": fields.Datetime.now(),
                }
            )
            if approval.credit_id:
                approval.credit_id._log_audit(
                    action="approval",
                    message=self.env._(
                        "Approval %(name)s approved (%(type)s)",
                        name=approval.name,
                        type=approval.approval_type,
                    ),
                    amount=approval.amount,
                    extra={"manager_id": approver.id},
                )
        return True

    def action_reject(self, approver=None):
        approver = approver or self.env.user
        for approval in self:
            if approval.state != "requested":
                raise UserError(self.env._("Only requested approvals can be rejected."))
            approval.write(
                {
                    "state": "rejected",
                    "approver_id": approver.id,
                    "approve_datetime": fields.Datetime.now(),
                }
            )
        return True
