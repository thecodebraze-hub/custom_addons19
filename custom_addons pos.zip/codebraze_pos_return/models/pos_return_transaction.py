# -*- coding: utf-8 -*-
"""Retail return transaction header and business methods."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare, float_is_zero

_logger = logging.getLogger(__name__)


class PosReturnTransaction(models.Model):
    """
    POS return transaction.

    Technical name: pos.return.transaction

    Tracks returned products, original/return POS orders, refund method,
    approval workflow and linkage to store credit / vouchers.
    """

    _name = "pos.return.transaction"
    _description = "POS Return Transaction"
    _inherit = [
        "mail.thread",
        "mail.activity.mixin",
        "store.credit.uuid.mixin",
        "store.credit.sync.mixin",
    ]
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
        tracking=True,
    )
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("waiting_approval", "Waiting Approval"),
            ("approved", "Approved"),
            ("completed", "Completed"),
            ("cancelled", "Cancelled"),
        ],
        string="Status",
        default="draft",
        required=True,
        index=True,
        tracking=True,
        copy=False,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Customer",
        index=True,
        tracking=True,
        check_company=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.company.currency_id,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        required=True,
        check_company=True,
        index=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )
    cashier_id = fields.Many2one(
        comodel_name="res.users",
        string="Cashier",
        default=lambda self: self.env.user,
        index=True,
    )
    manager_id = fields.Many2one(
        comodel_name="res.users",
        string="Manager",
        index=True,
        tracking=True,
    )

    original_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="Original POS Order",
        required=True,
        index=True,
        check_company=True,
        tracking=True,
    )
    return_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="Return POS Order",
        index=True,
        check_company=True,
        copy=False,
        tracking=True,
    )
    original_payment_ids = fields.Many2many(
        comodel_name="pos.payment",
        relation="pos_return_txn_original_payment_rel",
        column1="return_id",
        column2="payment_id",
        string="Original Payments",
        help="Payments from the original sale that may be reversed / referenced.",
    )
    refund_method = fields.Selection(
        selection=[
            ("voucher", "Voucher"),
            ("store_credit", "Store Credit"),
            ("cash", "Cash"),
            ("original_payment", "Original Payment"),
            ("exchange", "Exchange"),
            ("mixed", "Mixed"),
        ],
        string="Refund Method",
        required=True,
        default="voucher",
        index=True,
        tracking=True,
    )
    reason_id = fields.Many2one(
        comodel_name="pos.return.reason",
        string="Reason",
        check_company=True,
        tracking=True,
    )
    approval_required = fields.Boolean(
        string="Approval Required",
        compute="_compute_approval_required",
        store=True,
    )
    approval_ids = fields.One2many(
        comodel_name="pos.approval.history",
        inverse_name="return_id",
        string="Approvals",
        copy=False,
    )
    line_ids = fields.One2many(
        comodel_name="pos.return.transaction.line",
        inverse_name="return_id",
        string="Returned Products",
        copy=True,
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        index=True,
        copy=False,
        check_company=True,
    )
    exchange_id = fields.Many2one(
        comodel_name="pos.exchange.transaction",
        string="Exchange",
        index=True,
        copy=False,
        check_company=True,
    )
    amount_total = fields.Monetary(
        string="Return Total",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
    )
    amount_tax = fields.Monetary(
        string="Tax",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
    )
    has_receipt = fields.Boolean(string="Has Receipt", default=True)
    days_since_sale = fields.Integer(
        string="Days Since Sale",
        compute="_compute_days_since_sale",
        store=True,
    )
    note = fields.Text(string="Notes")

    settlement_state = fields.Selection(
        selection=[
            ("pending", "Pending Settlement"),
            ("settled", "Settled"),
            ("cancelled", "Cancelled"),
        ],
        string="Settlement Status",
        default="pending",
        required=True,
        index=True,
        tracking=True,
        copy=False,
    )
    settlement_method = fields.Selection(
        selection=[
            ("cash", "Cash Refund"),
            ("original_payment", "Original Payment"),
            ("voucher", "Return Voucher"),
        ],
        string="Settlement Method",
        index=True,
        copy=False,
        tracking=True,
    )
    settlement_uuid = fields.Char(
        string="Settlement UUID",
        index=True,
        copy=False,
        help="Client idempotency key for POS settlement.",
    )
    settlement_date = fields.Datetime(string="Settled On", copy=False, index=True)
    settlement_notes = fields.Text(string="Settlement Notes")
    settlement_user_id = fields.Many2one(
        comodel_name="res.users",
        string="Settled By",
        index=True,
        copy=False,
    )
    settlement_payment_id = fields.Many2one(
        comodel_name="pos.payment",
        string="Settlement Payment",
        copy=False,
        index=True,
        help="POS payment line linked to cash settlement when applicable.",
    )

    _sql_constraints = [
        (
            "pos_return_txn_uuid_uniq",
            "unique(uuid)",
            "Return transaction UUID must be unique.",
        ),
        (
            "pos_return_txn_name_company_uniq",
            "unique(company_id, name)",
            "Return transaction reference must be unique per company.",
        ),
    ]

    @api.depends("line_ids.price_subtotal", "line_ids.price_tax")
    def _compute_amounts(self):
        for ret in self:
            ret.amount_total = sum(ret.line_ids.mapped("price_subtotal"))
            ret.amount_tax = sum(ret.line_ids.mapped("price_tax"))

    @api.depends("original_order_id", "original_order_id.date_order")
    def _compute_days_since_sale(self):
        now = fields.Datetime.now()
        for ret in self:
            if not ret.original_order_id or not ret.original_order_id.date_order:
                ret.days_since_sale = 0
                continue
            delta = now - ret.original_order_id.date_order
            ret.days_since_sale = max(delta.days, 0)

    @api.depends(
        "amount_total",
        "reason_id",
        "reason_id.requires_manager",
        "days_since_sale",
        "company_id",
        "config_id",
    )
    def _compute_approval_required(self):
        Settings = self.env["store.credit.settings"]
        for ret in self:
            settings = Settings._get_settings(company=ret.company_id, config=ret.config_id)
            required = False
            if ret.reason_id and ret.reason_id.requires_manager:
                required = True
            if settings:
                if settings.manager_approval:
                    required = True
                if (
                    settings.approval_amount
                    and float_compare(
                        ret.amount_total,
                        settings.approval_amount,
                        precision_rounding=ret.currency_id.rounding,
                    )
                    >= 0
                    and settings.approval_amount > 0
                ):
                    required = True
                if (
                    settings.maximum_refund_days
                    and ret.days_since_sale > settings.maximum_refund_days
                ):
                    required = True
            ret.approval_required = required

    @api.constrains("line_ids")
    def _check_lines(self):
        for ret in self:
            if ret.state == "completed" and not ret.line_ids:
                raise ValidationError(
                    self.env._("A completed return must contain at least one line.")
                )

    @api.constrains("original_order_id", "company_id")
    def _check_company(self):
        for ret in self:
            if ret.original_order_id and ret.original_order_id.company_id != ret.company_id:
                raise ValidationError(
                    self.env._("Original order must belong to the same company as the return.")
                )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            company = self.env["res.company"].browse(
                vals.get("company_id") or self.env.company.id
            )
            if not vals.get("currency_id"):
                vals["currency_id"] = company.currency_id.id
            if vals.get("name", "New") == "New":
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("pos.return.transaction")
                )
                if not seq:
                    raise UserError(
                        self.env._("Sequence 'pos.return.transaction' is not configured.")
                    )
                vals["name"] = seq
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
        records = super().create(vals_list)
        for ret in records:
            _logger.info(
                "Created return transaction %s for order %s",
                ret.name,
                ret.original_order_id.name,
            )
        return records

    def _validate_return(self):
        """Validate return eligibility before approval / completion."""
        Settings = self.env["store.credit.settings"]
        for ret in self:
            if not ret.line_ids:
                raise ValidationError(self.env._("Add at least one returned product."))
            settings = Settings._get_settings(company=ret.company_id, config=ret.config_id)
            if settings and settings.maximum_refund_days:
                if (
                    ret.days_since_sale > settings.maximum_refund_days
                    and ret.state not in ("approved", "completed")
                    and not ret.manager_id
                    and not ret.approval_ids.filtered(lambda a: a.state == "approved")
                ):
                    raise UserError(
                        self.env._(
                            "Return for %(order)s is outside the maximum refund window "
                            "of %(days)s days and requires manager approval.",
                            order=ret.original_order_id.display_name,
                            days=settings.maximum_refund_days,
                        )
                    )
            if ret.refund_method == "cash":
                if settings and not settings.enable_cash_refund:
                    raise UserError(self.env._("Cash refunds are disabled for this company."))
            for line in ret.line_ids:
                line._validate_qty()

    def action_request_approval(self):
        self._validate_return()
        for ret in self:
            if ret.state != "draft":
                raise UserError(self.env._("Only draft returns can request approval."))
            ret.state = "waiting_approval"
            self.env["pos.approval.history"]._create_approval(
                {
                    "return_id": ret.id,
                    "approval_type": "return_override",
                    "amount": ret.amount_total,
                    "company_id": ret.company_id.id,
                    "config_id": ret.config_id.id,
                    "session_id": ret.session_id.id or False,
                    "requester_id": self.env.user.id,
                }
            )
        return True

    def action_approve(self, manager=None):
        manager = manager or self.env.user
        for ret in self:
            if ret.state not in ("draft", "waiting_approval"):
                raise UserError(
                    self.env._(
                        "Return %(name)s cannot be approved from status %(state)s.",
                        name=ret.name,
                        state=ret.state,
                    )
                )
            ret._validate_return()
            ret.write({"state": "approved", "manager_id": manager.id})
            pending = ret.approval_ids.filtered(lambda a: a.state == "requested")
            pending.write(
                {
                    "state": "approved",
                    "approver_id": manager.id,
                    "approve_datetime": fields.Datetime.now(),
                }
            )
            if ret.credit_id:
                ret.credit_id._log_audit(
                    action="approval",
                    message=self.env._("Return %(name)s approved", name=ret.name),
                    amount=ret.amount_total,
                    extra={"manager_id": manager.id},
                )
        return True

    def action_cancel(self):
        for ret in self:
            if ret.state == "completed":
                raise UserError(self.env._("Completed returns cannot be cancelled."))
            ret.state = "cancelled"
        return True

    def action_complete(self):
        """
        Mark return as completed and issue store credit when refund method requires it.

        POS order creation / stock moves are intentionally deferred to POS services.
        """
        for ret in self:
            if ret.state not in ("draft", "approved"):
                raise UserError(
                    self.env._(
                        "Return %(name)s must be draft or approved before completion.",
                        name=ret.name,
                    )
                )
            if ret.approval_required and ret.state != "approved":
                raise UserError(
                    self.env._(
                        "Return %(name)s requires manager approval before completion.",
                        name=ret.name,
                    )
                )
            ret._validate_return()
            if (
                not self.env.context.get("skip_voucher_issue")
                and ret.refund_method in ("store_credit", "voucher")
                and not ret.credit_id
            ):
                credit = ret._issue_store_credit()
                ret.credit_id = credit.id
            ret.state = "completed"
            _logger.info("Completed return transaction %s", ret.name)
        return True

    def _issue_store_credit(self):
        """Create a store.credit from this return (backend only)."""
        self.ensure_one()
        credit_type = "return"
        vals = {
            "credit_type": credit_type,
            "partner_id": self.partner_id.id or False,
            "company_id": self.company_id.id,
            "currency_id": self.currency_id.id,
            "config_id": self.config_id.id,
            "session_id": self.session_id.id or False,
            "cashier_id": self.cashier_id.id or self.env.user.id,
            "manager_id": self.manager_id.id or False,
            "original_order_id": self.return_order_id.id
            or self.original_order_id.id,
            "origin_model": "pos.return.transaction",
            "origin_res_id": self.id,
            "amount": self.amount_total,
            "note": self.env._("Issued from return %(name)s", name=self.name),
            "is_offline": self.is_offline,
            "sync_status": self.sync_status,
            "device_id": self.device_id,
        }
        credit = self.env["store.credit"]._create_credit(vals)
        credit.origin_ref = f"pos.return.transaction,{self.id}"
        return credit
