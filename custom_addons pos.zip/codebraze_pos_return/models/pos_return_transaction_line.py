# -*- coding: utf-8 -*-
"""Return transaction product lines."""

import logging

from odoo import api, fields, models
from odoo.exceptions import ValidationError
from odoo.tools import float_compare

_logger = logging.getLogger(__name__)


class PosReturnTransactionLine(models.Model):
    """Line of a POS return transaction (returned product / qty / value)."""

    _name = "pos.return.transaction.line"
    _description = "POS Return Transaction Line"
    _check_company_auto = True

    return_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return",
        required=True,
        ondelete="cascade",
        index=True,
    )
    active = fields.Boolean(related="return_id.active", store=True)
    state = fields.Selection(related="return_id.state", store=True, index=True)
    company_id = fields.Many2one(
        comodel_name="res.company",
        related="return_id.company_id",
        store=True,
        index=True,
        readonly=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="return_id.currency_id",
        store=True,
        readonly=True,
    )
    original_line_id = fields.Many2one(
        comodel_name="pos.order.line",
        string="Original Order Line",
        required=True,
        index=True,
        ondelete="restrict",
    )
    product_id = fields.Many2one(
        comodel_name="product.product",
        string="Product",
        required=True,
        index=True,
    )
    uom_id = fields.Many2one(
        comodel_name="uom.uom",
        string="Unit of Measure",
        required=True,
    )
    qty_sold = fields.Float(string="Qty Sold", digits="Product Unit of Measure")
    qty_returned_prev = fields.Float(
        string="Qty Already Returned",
        digits="Product Unit of Measure",
        default=0.0,
        help="Quantity previously returned against the original line.",
    )
    qty = fields.Float(
        string="Qty To Return",
        digits="Product Unit of Measure",
        required=True,
        default=1.0,
    )
    price_unit = fields.Float(string="Unit Price", digits="Product Price", required=True)
    discount = fields.Float(string="Discount (%)", default=0.0)
    tax_ids = fields.Many2many(
        comodel_name="account.tax",
        relation="pos_return_line_tax_rel",
        column1="line_id",
        column2="tax_id",
        string="Taxes",
    )
    price_subtotal = fields.Monetary(
        string="Subtotal",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
    )
    price_tax = fields.Monetary(
        string="Tax Amount",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
    )
    reason_id = fields.Many2one(
        comodel_name="pos.return.reason",
        string="Reason",
        check_company=True,
    )
    disposition = fields.Selection(
        selection=[
            ("restock", "Restock"),
            ("scrap", "Scrap"),
            ("quarantine", "Quarantine"),
        ],
        string="Disposition",
        default="restock",
        required=True,
        index=True,
    )
    lot_id = fields.Many2one(
        comodel_name="stock.lot",
        string="Lot/Serial",
        check_company=True,
    )
    move_id = fields.Many2one(
        comodel_name="stock.move",
        string="Stock Move",
        copy=False,
        index=True,
    )

    _sql_constraints = [
        (
            "pos_return_line_qty_positive",
            "CHECK(qty > 0)",
            "Return quantity must be greater than zero.",
        ),
    ]

    @api.depends("qty", "price_unit", "discount", "tax_ids")
    def _compute_amounts(self):
        for line in self:
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            subtotal = price * line.qty
            # Tax computation kept simple for backend scaffold; full fiscal
            # engine can be refined when accounting posting is wired.
            tax_amount = 0.0
            if line.tax_ids:
                taxes = line.tax_ids.compute_all(
                    price,
                    currency=line.currency_id,
                    quantity=line.qty,
                    product=line.product_id,
                    partner=line.return_id.partner_id,
                )
                tax_amount = sum(t.get("amount", 0.0) for t in taxes.get("taxes", []))
                subtotal = taxes.get("total_excluded", subtotal)
            line.price_subtotal = subtotal
            line.price_tax = tax_amount

    @api.onchange("original_line_id")
    def _onchange_original_line_id(self):
        if not self.original_line_id:
            return
        line = self.original_line_id
        self.product_id = line.product_id
        self.uom_id = line.product_uom_id
        self.qty_sold = line.qty
        self.price_unit = line.price_unit
        self.discount = line.discount
        self.tax_ids = line.tax_ids
        # Previously returned qty: sum completed returns on same original line
        prev = self.env["pos.return.transaction.line"].search(
            [
                ("original_line_id", "=", line.id),
                ("return_id.state", "=", "completed"),
                ("id", "!=", self._origin.id if self._origin else 0),
            ]
        )
        self.qty_returned_prev = sum(prev.mapped("qty"))

    def _validate_qty(self):
        """Ensure return qty does not exceed remaining sold quantity."""
        precision = self.env["decimal.precision"].precision_get("Product Unit of Measure")
        for line in self:
            remaining = line.qty_sold - line.qty_returned_prev
            if float_compare(line.qty, remaining, precision_digits=precision) > 0:
                raise ValidationError(
                    self.env._(
                        "Return quantity %(qty)s for %(product)s exceeds remaining "
                        "sold quantity %(remaining)s.",
                        qty=line.qty,
                        product=line.product_id.display_name,
                        remaining=remaining,
                    )
                )
            if float_compare(line.qty, 0.0, precision_digits=precision) <= 0:
                raise ValidationError(self.env._("Return quantity must be positive."))

    @api.constrains("qty", "qty_sold", "qty_returned_prev")
    def _check_qty(self):
        self._validate_qty()
