# -*- coding: utf-8 -*-
"""POS return confirmation — transaction + POS return order creation."""

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare

_logger = logging.getLogger(__name__)


class PosReturnTransactionConfirm(models.Model):
    _inherit = "pos.return.transaction"

    # -------------------------------------------------------------------------
    # POS confirmation RPC
    # -------------------------------------------------------------------------

    @api.model
    def pos_precheck_return(self, payload, config_id, session_id):
        """Validate a return confirmation payload without creating records."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists()
        if not config or not session:
            return {"valid": False, "error": self.env._("POS session not found.")}

        order = self.env["pos.order"].browse(payload.get("order_id")).exists()
        if not order:
            return {"valid": False, "error": self.env._("Invoice not found.")}

        refund_method = self._map_pos_refund_method(payload.get("refund_method"))
        return self._validate_confirm_payload(
            order,
            payload.get("lines") or [],
            config,
            session,
            payload,
            refund_method,
        )

    @api.model
    def pos_confirm_return(self, payload, config_id, session_id):
        """
        Validate and create a return transaction plus POS return order.

        Does not issue vouchers or process customer-facing payments.
        """
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists()
        if not config or not session:
            return {
                "success": False,
                "error_code": "config_missing",
                "error": self.env._("POS session not found."),
            }

        client_uuid = (payload or {}).get("client_uuid")
        if client_uuid:
            existing = self.search([("uuid", "=", client_uuid)], limit=1)
            if existing:
                return self._serialize_confirm_response(existing, duplicate=True)

        lines_payload = (payload or {}).get("lines") or []
        if not lines_payload:
            return {
                "success": False,
                "error_code": "no_lines",
                "error": self.env._("Select at least one product to return."),
            }

        order = self.env["pos.order"].browse(payload.get("order_id")).exists()
        if not order:
            return {
                "success": False,
                "error_code": "invoice_not_found",
                "error": self.env._("Invoice not found."),
            }

        refund_method = self._map_pos_refund_method(payload.get("refund_method"))
        validation = self._validate_confirm_payload(
            order, lines_payload, config, session, payload, refund_method
        )
        if not validation.get("valid"):
            self.env["pos.return.audit"]._log_pos_event(
                "validation_failure",
                message=validation.get("error"),
                success=False,
                config=config,
                session=session,
                order=order,
                payload=validation,
            )
            return {"success": False, **validation}

        if validation.get("approval_required") and not payload.get("manager_approved"):
            return {
                "success": False,
                "error_code": "approval_required",
                "error": self.env._("Manager approval required."),
                "approval_reasons": validation.get("approval_reasons", []),
            }

        ret = self._create_return_transaction(
            order,
            lines_payload,
            config,
            session,
            payload,
            refund_method,
            client_uuid,
        )

        if validation.get("approval_required") and payload.get("manager_approved"):
            manager = self.env["res.users"].browse(payload.get("manager_id")).exists()
            ret.action_approve(manager=manager or self.env.user)
            self.env["pos.return.audit"]._log_pos_event(
                "approval_granted",
                message=self.env._("Manager approved return %(name)s", name=ret.name),
                success=True,
                config=config,
                session=session,
                order=order,
                payload={"return_id": ret.id, "manager_id": manager.id if manager else self.env.user.id},
            )

        return_order = ret._create_pos_return_order()
        ret.return_order_id = return_order.id
        ret._settle_return_order_for_inventory(return_order)
        ret.with_context(skip_voucher_issue=True).action_complete()
        ret.write({"settlement_state": "pending"})

        self.env["pos.return.audit"]._log_pos_event(
            "return_created",
            message=self.env._("Return %(name)s created", name=ret.name),
            success=True,
            config=config,
            session=session,
            order=order,
            payload={
                "return_id": ret.id,
                "return_order_id": return_order.id,
                "refund_amount": ret.amount_total,
                "line_count": len(ret.line_ids),
            },
        )
        return self._serialize_confirm_response(ret)

    # -------------------------------------------------------------------------
    # Creation helpers
    # -------------------------------------------------------------------------

    @api.model
    def _create_return_transaction(
        self, order, lines_payload, config, session, payload, refund_method, client_uuid
    ):
        line_commands = []
        for lp in lines_payload:
            orig_line = self.env["pos.order.line"].browse(lp["order_line_id"]).exists()
            if not orig_line:
                raise ValidationError(self.env._("Original order line not found."))
            qty_info = self._compute_qty_info(orig_line)
            reason = (
                self.env["pos.return.reason"].browse(lp.get("reason_id")).exists()
                if lp.get("reason_id")
                else self.env["pos.return.reason"]
            )
            line_commands.append(
                (
                    0,
                    0,
                    {
                        "original_line_id": orig_line.id,
                        "product_id": orig_line.product_id.id,
                        "uom_id": orig_line.product_uom_id.id,
                        "qty_sold": qty_info["qty_sold"],
                        "qty_returned_prev": qty_info["qty_returned_prev"],
                        "qty": float(lp["return_qty"]),
                        "price_unit": orig_line.price_unit,
                        "discount": orig_line.discount,
                        "tax_ids": [(6, 0, orig_line.tax_ids.ids)],
                        "reason_id": reason.id if reason else False,
                        "disposition": reason.default_disposition if reason else "restock",
                    },
                )
            )

        vals = {
            "original_order_id": order.id,
            "partner_id": payload.get("partner_id") or order.partner_id.id or False,
            "company_id": config.company_id.id,
            "config_id": config.id,
            "session_id": session.id,
            "cashier_id": self.env.user.id,
            "refund_method": refund_method,
            "note": payload.get("notes") or "",
            "uuid": client_uuid or self._generate_uuid(),
            "line_ids": line_commands,
        }
        if payload.get("reason_id"):
            vals["reason_id"] = payload["reason_id"]
        if payload.get("manager_approved"):
            vals["manager_id"] = payload.get("manager_id") or self.env.user.id

        return self.create(vals)

    def _create_pos_return_order(self):
        """Create a POS refund order mirroring standard Odoo return mechanics."""
        self.ensure_one()
        original = self.original_order_id
        session = self.session_id or original.config_id.current_session_id
        if not session:
            raise UserError(
                self.env._(
                    "To return product(s), you need an open POS session at %(branch)s.",
                    branch=original.config_id.display_name,
                )
            )

        refund_order = original.copy(original._prepare_refund_values(session))
        refund_order.write(
            {
                "partner_id": self.partner_id.id or original.partner_id.id,
                "user_id": self.cashier_id.id or self.env.user.id,
                "fiscal_position_id": original.fiscal_position_id.id,
            }
        )

        for ret_line in self.line_ids:
            orig_line = ret_line.original_line_id
            pack_lots = self.env["pos.pack.operation.lot"]
            if orig_line.pack_lot_ids:
                remaining_lots = self._remaining_pack_lots(orig_line, ret_line.qty)
                for lot_name in remaining_lots:
                    pack_lots += self.env["pos.pack.operation.lot"].create(
                        {"lot_name": lot_name}
                    )
            refund_vals = orig_line._prepare_refund_data(refund_order, pack_lots)
            refund_vals["qty"] = -ret_line.qty
            refund_line = orig_line.copy(refund_vals)
            refund_line.write(
                {
                    "price_unit": ret_line.price_unit,
                    "discount": ret_line.discount,
                    "tax_ids": [(6, 0, ret_line.tax_ids.ids)],
                }
            )
            refund_line._onchange_amount_line_all()

        refund_order._compute_prices()
        return refund_order

    def _remaining_pack_lots(self, orig_line, qty):
        """Return lot names not yet refunded, limited to return qty."""
        already = set()
        for refund_line in orig_line.refund_orderline_ids.filtered(
            lambda l: l.order_id.state not in ("draft", "cancel")
        ):
            already.update(refund_line.pack_lot_ids.mapped("lot_name"))
        available = [
            lot.lot_name
            for lot in orig_line.pack_lot_ids
            if lot.lot_name and lot.lot_name not in already
        ]
        count = int(qty) if qty == int(qty) else len(available)
        return available[: max(count, 0)]

    def _settle_return_order_for_inventory(self, refund_order):
        """
        Mark the refund order paid so Odoo creates stock pickings.

        Technical settlement only — no customer payment UI.
        """
        self.ensure_one()
        if refund_order.state == "paid":
            self._link_stock_moves(refund_order)
            return

        payment_method = self._select_settlement_payment_method()
        if not payment_method:
            raise UserError(
                self.env._("No payment method configured to settle the return order.")
            )

        refund_order.add_payment(
            {
                "name": _("Return settlement"),
                "pos_order_id": refund_order.id,
                "amount": refund_order.amount_total,
                "payment_date": fields.Datetime.now(),
                "payment_method_id": payment_method.id,
            }
        )
        refund_order.action_pos_order_paid()
        refund_order._create_order_picking()
        self._link_stock_moves(refund_order)

    def _select_settlement_payment_method(self):
        self.ensure_one()
        if self.refund_method == "original_payment" and self.original_order_id.payment_ids:
            return self.original_order_id.payment_ids[0].payment_method_id
        if self.refund_method == "cash":
            cash = self.config_id.payment_method_ids.filtered("is_cash_count")[:1]
            if cash:
                return cash
        return self.config_id.payment_method_ids[:1]

    def _link_stock_moves(self, refund_order):
        self.ensure_one()
        moves = refund_order.picking_ids.move_ids
        for ret_line in self.line_ids:
            line_moves = moves.filtered(lambda m: m.product_id.id == ret_line.product_id.id)
            if line_moves:
                ret_line.move_id = line_moves[0].id

    # -------------------------------------------------------------------------
    # Validation
    # -------------------------------------------------------------------------

    @api.model
    def _validate_confirm_payload(
        self, order, lines_payload, config, session, payload, refund_method
    ):
        Settings = self.env["store.credit.settings"]
        settings = Settings._get_settings(company=config.company_id, config=config)
        precision = self.env["decimal.precision"].precision_get("Product Unit of Measure")
        approval_reasons = []
        approval_required = False

        if order.state not in ("paid", "done"):
            return {
                "valid": False,
                "error_code": "invoice_not_paid",
                "error": self.env._("Invoice status must be paid before returning."),
            }
        if order.company_id.id != config.company_id.id:
            return {
                "valid": False,
                "error_code": "company_mismatch",
                "error": self.env._("Invoice belongs to another company."),
            }
        branch_specific = getattr(settings, "branch_specific_voucher", True) if settings else True
        if branch_specific and order.config_id.id != config.id:
            return {
                "valid": False,
                "error_code": "branch_mismatch",
                "error": self.env._("Branch mismatch."),
            }

        partner_id = payload.get("partner_id")
        if partner_id and order.partner_id and order.partner_id.id != partner_id:
            return {
                "valid": False,
                "error_code": "customer_mismatch",
                "error": self.env._("Customer mismatch."),
            }

        if refund_method == "cash" and settings and not settings.enable_cash_refund:
            return {
                "valid": False,
                "error_code": "cash_refund_disabled",
                "error": self.env._("Cash refunds are disabled for this branch."),
            }

        total_refund = 0.0
        days_since = 0
        if order.date_order:
            days_since = max((fields.Datetime.now() - order.date_order).days, 0)
        max_days = settings.maximum_refund_days if settings else 14
        period_expired = bool(max_days and days_since > max_days)

        for lp in lines_payload:
            if not lp.get("selected", True):
                continue
            orig_line = self.env["pos.order.line"].browse(lp.get("order_line_id")).exists()
            if not orig_line or orig_line.order_id.id != order.id:
                return {
                    "valid": False,
                    "error_code": "product_not_in_invoice",
                    "error": self.env._("Product does not belong to selected invoice."),
                }
            qty_info = self._compute_qty_info(orig_line)
            return_qty = float(lp.get("return_qty") or 0)
            if qty_info["remaining_qty"] <= 0:
                return {
                    "valid": False,
                    "error_code": "fully_returned",
                    "error": self.env._("Product already fully returned."),
                }
            if float_compare(return_qty, 0, precision_digits=precision) <= 0:
                return {
                    "valid": False,
                    "error_code": "invalid_qty",
                    "error": self.env._("Return quantity must be greater than zero."),
                }
            if float_compare(return_qty, qty_info["remaining_qty"], precision_digits=precision) > 0:
                return {
                    "valid": False,
                    "error_code": "qty_exceeds_remaining",
                    "error": self.env._("Return quantity exceeds remaining quantity."),
                }
            if not lp.get("reason_id"):
                return {
                    "valid": False,
                    "error_code": "reason_required",
                    "error": self.env._("Select a return reason for each product."),
                }
            amounts = self._compute_refund_amounts(orig_line, return_qty)
            total_refund += amounts["net_refund"]

            reason = self.env["pos.return.reason"].browse(lp.get("reason_id")).exists()
            if reason and reason.requires_manager:
                approval_required = True
                approval_reasons.append(
                    self.env._("Manager approval required for %(reason)s.", reason=reason.name)
                )

        if settings:
            if settings.manager_approval:
                approval_required = True
                approval_reasons.append(self.env._("Manager approval required by policy."))
            if (
                settings.approval_amount
                and settings.approval_amount > 0
                and float_compare(
                    total_refund,
                    settings.approval_amount,
                    precision_rounding=order.currency_id.rounding,
                )
                >= 0
            ):
                approval_required = True
                approval_reasons.append(
                    self.env._("Manager approval required for high-value returns.")
                )
        if period_expired:
            approval_required = True
            approval_reasons.append(
                self.env._("Return period has expired. Manager approval required.")
            )
        if payload.get("manual_price_adjustment"):
            approval_required = True
            approval_reasons.append(
                self.env._("Manager approval required for manual price adjustment.")
            )

        return {
            "valid": True,
            "approval_required": approval_required,
            "approval_reasons": approval_reasons,
            "period_expired": period_expired,
            "total_refund": total_refund,
        }

    @api.model
    def _map_pos_refund_method(self, method):
        mapping = {
            "cash": "cash",
            "original_payment": "original_payment",
            "voucher": "voucher",
            "store_credit": "store_credit",
        }
        return mapping.get(method, "voucher")

    @api.model
    def _serialize_confirm_response(self, ret, duplicate=False):
        return {
            "success": True,
            "duplicate": duplicate,
            "return_id": ret.id,
            "return_name": ret.name,
            "original_order_id": ret.original_order_id.id,
            "return_order_id": ret.return_order_id.id,
            "return_order_name": ret.return_order_id.pos_reference or ret.return_order_id.name,
            "state": ret.state,
            "refund_method": ret.refund_method,
            "amount_total": ret.amount_total,
            "amount_tax": ret.amount_tax,
            "line_ids": ret.line_ids.ids,
            "settlement_state": ret.settlement_state,
            "needs_settlement": ret.settlement_state == "pending",
        }
