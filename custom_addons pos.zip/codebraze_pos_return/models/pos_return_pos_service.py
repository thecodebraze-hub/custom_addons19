# -*- coding: utf-8 -*-
"""POS-facing lookup and validation API for the refund popup."""

import logging

from odoo import api, fields, models
from odoo.tools import float_compare, float_round

_logger = logging.getLogger(__name__)

PAID_ORDER_STATES = ("paid", "done")


class PosReturnTransactionPosApi(models.Model):
    _inherit = "pos.return.transaction"

    # -------------------------------------------------------------------------
    # POS RPC entry points
    # -------------------------------------------------------------------------

    @api.model
    def pos_get_return_settings(self, config_id):
        """Expose return policy settings to the POS refund popup."""
        config = self.env["pos.config"].browse(config_id).exists()
        if not config:
            return {}
        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        )
        return {
            "maximum_refund_days": settings.maximum_refund_days if settings else 14,
            "branch_specific_voucher": getattr(settings, "branch_specific_voucher", True),
            "manager_approval": settings.manager_approval if settings else False,
            "approval_amount": settings.approval_amount if settings else 0.0,
            "enable_cash_refund": settings.enable_cash_refund if settings else False,
            "cash_refund_limit": settings.cash_refund_limit if settings else 0.0,
            "require_original_invoice": getattr(settings, "require_original_invoice", True),
            "allow_return_without_invoice": getattr(
                settings, "allow_return_without_invoice", False
            ),
            "enable_audit_logs": getattr(settings, "enable_audit_logs", True),
        }

    @api.model
    def pos_lookup_invoice(self, barcode, config_id, session_id=False):
        """
        Resolve an original sale by invoice / receipt barcode or reference.

        Returns a JSON-serializable dict consumed by the Refund popup.
        """
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        code = (barcode or "").strip()
        if not config:
            return self._lookup_error(
                "config_missing",
                self.env._("POS configuration not found."),
                config=config,
                session=session,
                event="invoice_lookup",
            )
        if not code:
            return self._lookup_error(
                "barcode_invalid",
                self.env._("Barcode is required."),
                config=config,
                session=session,
                event="invoice_lookup",
            )

        order = self._find_order_by_reference(code, config)
        if not order:
            self.env["pos.return.audit"]._log_pos_event(
                "invoice_lookup",
                message=self.env._("Invoice not found for barcode %(code)s", code=code),
                success=False,
                config=config,
                session=session,
                payload={"barcode": code},
            )
            return {"success": False, "error_code": "invoice_not_found", "error": self.env._("Invoice not found.")}

        invoice_data = self._serialize_invoice(order, config)
        self.env["pos.return.audit"]._log_pos_event(
            "invoice_lookup",
            message=self.env._("Invoice %(ref)s found", ref=invoice_data["invoice_number"]),
            success=True,
            config=config,
            session=session,
            order=order,
            payload={"barcode": code, "order_id": order.id},
        )
        return {
            "success": True,
            "invoice": invoice_data,
            "products": invoice_data["products"],
        }

    @api.model
    def pos_lookup_product_invoices(
        self,
        config_id,
        session_id=False,
        barcode=None,
        product_id=None,
        partner_id=False,
        search_term=None,
    ):
        """
        Identify a product and list paid invoices containing it.
        """
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        product = self._resolve_product(barcode=barcode, product_id=product_id)
        if not config:
            return self._lookup_error(
                "config_missing",
                self.env._("POS configuration not found."),
                config=config,
                session=session,
                event="product_lookup",
            )
        if not product:
            self.env["pos.return.audit"]._log_pos_event(
                "product_lookup",
                message=self.env._("Product not found."),
                success=False,
                config=config,
                session=session,
                payload={"barcode": barcode, "product_id": product_id},
            )
            return {
                "success": False,
                "error_code": "product_not_found",
                "error": self.env._("Product not found."),
            }

        invoices = self._find_invoices_for_product(
            product,
            config,
            partner_id=partner_id,
            search_term=search_term,
        )
        product_data = self._serialize_product(product)
        self.env["pos.return.audit"]._log_pos_event(
            "product_lookup",
            message=self.env._(
                "Product %(product)s — %(count)s invoice(s) found",
                product=product.display_name,
                count=len(invoices),
            ),
            success=bool(invoices),
            config=config,
            session=session,
            product=product,
            payload={
                "barcode": barcode,
                "product_id": product.id,
                "invoice_count": len(invoices),
            },
        )
        if not invoices:
            return {
                "success": False,
                "error_code": "invoice_not_found",
                "error": self.env._("Invoice not found."),
                "product": product_data,
            }
        return {
            "success": True,
            "product": product_data,
            "invoices": invoices,
        }

    @api.model
    def pos_validate_return(
        self,
        config_id,
        session_id,
        order_id,
        product_id,
        order_line_id,
        return_qty,
        reason_id=False,
        refund_method="voucher",
        partner_id=False,
    ):
        """Validate return eligibility and compute refund amounts."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        order = self.env["pos.order"].browse(order_id).exists()
        product = self.env["product.product"].browse(product_id).exists()
        line = self.env["pos.order.line"].browse(order_line_id).exists()
        reason = self.env["pos.return.reason"].browse(reason_id).exists() if reason_id else False
        qty = float(return_qty or 0)

        result = self._validate_return_context(
            config=config,
            session=session,
            order=order,
            product=product,
            line=line,
            return_qty=qty,
            reason=reason,
            refund_method=refund_method,
            partner_id=partner_id,
        )
        event = "validation_failure" if not result.get("valid") else "product_selected"
        if result.get("valid"):
            event = "invoice_selected" if not product else "product_selected"
        self.env["pos.return.audit"]._log_pos_event(
            event if result.get("valid") else "validation_failure",
            message=result.get("error") or self.env._("Return validation passed."),
            success=result.get("valid", False),
            config=config,
            session=session,
            order=order,
            product=product,
            payload=result,
        )
        return result

    # -------------------------------------------------------------------------
    # Lookup helpers
    # -------------------------------------------------------------------------

    @api.model
    def _find_order_by_reference(self, code, config):
        """Search paid POS orders by receipt / invoice reference."""
        company = config.company_id
        base_domain = [
            ("state", "in", list(PAID_ORDER_STATES)),
            ("company_id", "=", company.id),
            ("amount_total", ">=", 0),
        ]
        exact_domain = base_domain + [
            "|",
            "|",
            "|",
            ("pos_reference", "=", code),
            ("name", "=", code),
            ("tracking_number", "=", code),
            ("account_move.name", "=", code),
        ]
        order = self.env["pos.order"].search(exact_domain, limit=1, order="date_order desc")
        if order:
            return order

        fuzzy = f"%{code}%"
        fuzzy_domain = base_domain + [
            "|",
            "|",
            "|",
            ("pos_reference", "ilike", fuzzy),
            ("name", "ilike", fuzzy),
            ("tracking_number", "ilike", fuzzy),
            ("account_move.name", "ilike", fuzzy),
        ]
        return self.env["pos.order"].search(fuzzy_domain, limit=1, order="date_order desc")

    @api.model
    def _resolve_product(self, barcode=None, product_id=None):
        Product = self.env["product.product"]
        if product_id:
            product = Product.browse(product_id).exists()
            if product:
                return product
        code = (barcode or "").strip()
        if not code:
            return Product.browse()
        product = Product.search([("barcode", "=", code)], limit=1)
        if not product:
            product = Product.search([("default_code", "=", code)], limit=1)
        if not product:
            stripped = code.lstrip("0")
            if stripped and stripped != code:
                product = Product.search([("barcode", "=", stripped)], limit=1)
        return product

    @api.model
    def _find_invoices_for_product(self, product, config, partner_id=False, search_term=None):
        """Return invoice summaries containing the product, newest first."""
        domain = [
            ("state", "in", list(PAID_ORDER_STATES)),
            ("company_id", "=", config.company_id.id),
            ("lines.product_id", "=", product.id),
            ("amount_total", ">=", 0),
        ]
        if partner_id:
            domain.append(("partner_id", "=", partner_id))
        term = (search_term or "").strip()
        if term:
            domain += [
                "|",
                "|",
                ("pos_reference", "ilike", f"%{term}%"),
                ("name", "ilike", f"%{term}%"),
                ("partner_id.name", "ilike", f"%{term}%"),
            ]
        orders = self.env["pos.order"].search(domain, order="date_order desc", limit=50)
        results = []
        for order in orders:
            line = order.lines.filtered(lambda l: l.product_id.id == product.id and l.qty > 0)[:1]
            if not line:
                continue
            line = line[0]
            qty_info = self._compute_qty_info(line)
            if qty_info["remaining_qty"] <= 0:
                continue
            summary = self._serialize_invoice_summary(order, line, qty_info, config)
            results.append(summary)
        return results

    # -------------------------------------------------------------------------
    # Serialization
    # -------------------------------------------------------------------------

    @api.model
    def _serialize_invoice(self, order, config):
        payments = order.payment_ids
        payment_methods = ", ".join(payments.mapped("payment_method_id.name")) or "-"
        cashier = order.user_id.name if order.user_id else "-"
        partner = order.partner_id
        products = []
        for line in order.lines.filtered(lambda l: l.qty > 0):
            qty_info = self._compute_qty_info(line)
            products.append(
                {
                    **self._serialize_product(line.product_id),
                    "order_line_id": line.id,
                    "qty_sold": qty_info["qty_sold"],
                    "qty_returned_prev": qty_info["qty_returned_prev"],
                    "remaining_qty": qty_info["remaining_qty"],
                    "sold_price": line.price_unit,
                    "discount": line.discount,
                    "line_subtotal": line.price_subtotal_incl,
                }
            )
        return {
            "order_id": order.id,
            "invoice_number": order.pos_reference or order.name,
            "invoice_date": fields.Datetime.to_string(order.date_order),
            "customer": self._serialize_partner(partner),
            "cashier": cashier,
            "branch": order.config_id.name or config.name,
            "branch_id": order.config_id.id,
            "company_id": order.company_id.id,
            "state": order.state,
            "paid_amount": order.amount_paid,
            "total_amount": order.amount_total,
            "payment_method": payment_methods,
            "products": products,
        }

    @api.model
    def _serialize_invoice_summary(self, order, line, qty_info, config):
        return {
            "order_id": order.id,
            "order_line_id": line.id,
            "invoice_number": order.pos_reference or order.name,
            "invoice_date": fields.Datetime.to_string(order.date_order),
            "customer": order.partner_id.name or self.env._("Walk-in Customer"),
            "customer_id": order.partner_id.id or False,
            "branch": order.config_id.name or config.name,
            "branch_id": order.config_id.id,
            "cashier": order.user_id.name if order.user_id else "-",
            "qty_sold": qty_info["qty_sold"],
            "qty_returned_prev": qty_info["qty_returned_prev"],
            "remaining_qty": qty_info["remaining_qty"],
            "total_amount": order.amount_total,
            "line_amount": line.price_subtotal_incl,
            "product_id": line.product_id.id,
        }

    @api.model
    def _serialize_product(self, product):
        variant_parts = []
        size = color = False
        for ptav in product.product_template_attribute_value_ids:
            attr_name = (ptav.attribute_id.name or "").lower()
            label = f"{ptav.attribute_id.name}: {ptav.name}"
            variant_parts.append(label)
            if "size" in attr_name:
                size = ptav.name
            if "colour" in attr_name or "color" in attr_name:
                color = ptav.name
        return {
            "id": product.id,
            "name": product.display_name,
            "default_code": product.default_code or "",
            "barcode": product.barcode or "",
            "size": size or "",
            "color": color or "",
            "variant": ", ".join(variant_parts) if variant_parts else product.display_name,
        }

    @api.model
    def _serialize_partner(self, partner):
        if not partner:
            return {
                "id": False,
                "name": self.env._("Walk-in Customer"),
                "ref": "",
                "mobile": "",
                "loyalty_number": "",
                "store_credit_balance": 0.0,
            }
        balance = 0.0
        credits = self.env["store.credit"].search(
            [
                ("partner_id", "=", partner.id),
                ("state", "in", ("issued", "partially_used")),
                ("company_id", "=", partner.company_id.id or self.env.company.id),
            ]
        )
        if credits:
            balance = sum(credits.mapped("amount_remaining"))
        return {
            "id": partner.id,
            "name": partner.name,
            "ref": partner.ref or "",
            "mobile": partner.mobile or partner.phone or "",
            "loyalty_number": "",
            "store_credit_balance": balance,
        }

    # -------------------------------------------------------------------------
    # Quantity & history
    # -------------------------------------------------------------------------

    @api.model
    def _compute_qty_info(self, line):
        precision = self.env["decimal.precision"].precision_get("Product Unit of Measure")
        qty_sold = abs(line.qty)
        prev_lines = self.env["pos.return.transaction.line"].search(
            [
                ("original_line_id", "=", line.id),
                ("return_id.state", "=", "completed"),
            ]
        )
        qty_returned_prev = sum(prev_lines.mapped("qty"))
        # Include native POS refund orders not yet in return transactions
        refund_orders = self.env["pos.order"].search(
            [
                ("refunded_order_id", "=", line.order_id.id),
                ("state", "in", list(PAID_ORDER_STATES)),
            ]
        )
        for refund in refund_orders:
            for rline in refund.lines.filtered(
                lambda l: l.product_id.id == line.product_id.id
            ):
                qty_returned_prev += abs(rline.qty)
        remaining = max(qty_sold - qty_returned_prev, 0.0)
        remaining = float_round(remaining, precision_digits=precision)
        return {
            "qty_sold": qty_sold,
            "qty_returned_prev": qty_returned_prev,
            "remaining_qty": remaining,
        }

    @api.model
    def _get_return_history(self, line):
        returns = []
        exchanges = []
        vouchers = []
        prev_lines = self.env["pos.return.transaction.line"].search(
            [
                ("original_line_id", "=", line.id),
                ("return_id.state", "in", ("approved", "completed", "waiting_approval")),
            ],
            order="create_date desc",
        )
        for rline in prev_lines:
            ret = rline.return_id
            returns.append(
                {
                    "reference": ret.name,
                    "date": fields.Datetime.to_string(ret.create_date),
                    "qty": rline.qty,
                    "amount": rline.price_subtotal + rline.price_tax,
                    "state": ret.state,
                    "refund_method": ret.refund_method,
                }
            )
            if ret.credit_id:
                vouchers.append(
                    {
                        "reference": ret.credit_id.name,
                        "amount": ret.credit_id.amount,
                        "balance": ret.credit_id.amount_remaining,
                        "barcode": ret.credit_id.barcode or "",
                    }
                )
            if ret.exchange_id:
                exchanges.append(
                    {
                        "reference": ret.exchange_id.name,
                        "date": fields.Datetime.to_string(ret.exchange_id.create_date),
                        "state": ret.exchange_id.state,
                    }
                )
        qty_info = self._compute_qty_info(line)
        return {
            "returns": returns,
            "exchanges": exchanges,
            "vouchers": vouchers,
            "remaining_qty": qty_info["remaining_qty"],
            "qty_sold": qty_info["qty_sold"],
            "qty_returned_prev": qty_info["qty_returned_prev"],
        }

    # -------------------------------------------------------------------------
    # Validation
    # -------------------------------------------------------------------------

    @api.model
    def _validate_return_context(
        self,
        config,
        session,
        order,
        product,
        line,
        return_qty,
        reason,
        refund_method,
        partner_id,
    ):
        Settings = self.env["store.credit.settings"]
        settings = Settings._get_settings(company=config.company_id, config=config) if config else None
        precision = self.env["decimal.precision"].precision_get("Product Unit of Measure")

        def fail(code, message, **extra):
            return {
                "valid": False,
                "error_code": code,
                "error": message,
                **extra,
            }

        if not config:
            return fail("config_missing", self.env._("POS configuration not found."))
        if not order:
            return fail("invoice_not_found", self.env._("Invoice not found."))
        if not product:
            return fail("product_not_found", self.env._("Product not found."))
        if not line or line.order_id.id != order.id:
            return fail(
                "product_not_in_invoice",
                self.env._("Product does not belong to selected invoice."),
            )
        if line.product_id.id != product.id:
            return fail(
                "product_not_in_invoice",
                self.env._("Product does not belong to selected invoice."),
            )
        if order.state not in PAID_ORDER_STATES:
            return fail(
                "invoice_not_paid",
                self.env._("Invoice status must be paid before returning."),
            )
        if order.company_id.id != config.company_id.id:
            return fail(
                "company_mismatch",
                self.env._("Invoice belongs to another company."),
            )

        branch_specific = getattr(settings, "branch_specific_voucher", True) if settings else True
        if branch_specific and order.config_id.id != config.id:
            return fail("branch_mismatch", self.env._("Branch mismatch."))

        if partner_id and order.partner_id and order.partner_id.id != partner_id:
            return fail("customer_mismatch", self.env._("Customer mismatch."))

        qty_info = self._compute_qty_info(line)
        if qty_info["remaining_qty"] <= 0:
            return fail(
                "fully_returned",
                self.env._("Product already fully returned."),
            )
        if float_compare(return_qty, 0, precision_digits=precision) <= 0:
            return fail("invalid_qty", self.env._("Return quantity must be greater than zero."))
        if float_compare(return_qty, qty_info["remaining_qty"], precision_digits=precision) > 0:
            return fail(
                "qty_exceeds_remaining",
                self.env._(
                    "Return quantity exceeds remaining quantity (%(remaining)s).",
                    remaining=qty_info["remaining_qty"],
                ),
            )

        days_since = 0
        if order.date_order:
            days_since = max((fields.Datetime.now() - order.date_order).days, 0)
        max_days = settings.maximum_refund_days if settings else 14
        period_expired = bool(max_days and days_since > max_days)

        approval_required = False
        approval_reasons = []
        if reason and reason.requires_manager:
            approval_required = True
            approval_reasons.append(self.env._("Manager approval required for this reason."))
        if settings:
            if settings.manager_approval:
                approval_required = True
                approval_reasons.append(self.env._("Manager approval required by policy."))
            if (
                settings.approval_amount
                and settings.approval_amount > 0
            ):
                amounts = self._compute_refund_amounts(line, return_qty)
                if float_compare(
                    amounts["net_refund"],
                    settings.approval_amount,
                    precision_rounding=order.currency_id.rounding,
                ) >= 0:
                    approval_required = True
                    approval_reasons.append(
                        self.env._("Manager approval required for high-value returns.")
                    )
            if period_expired:
                approval_required = True
                approval_reasons.append(
                    self.env._("Return period has expired. Manager approval required.")
                )
            if refund_method == "cash" and not settings.enable_cash_refund:
                return fail(
                    "cash_refund_disabled",
                    self.env._("Cash refunds are disabled for this branch."),
                )

        amounts = self._compute_refund_amounts(line, return_qty)
        history = self._get_return_history(line)
        can_edit_amount = self.env.user.has_group("point_of_sale.group_pos_manager")

        return {
            "valid": True,
            "approval_required": approval_required,
            "approval_reasons": approval_reasons,
            "period_expired": period_expired,
            "days_since_sale": days_since,
            "max_return_days": max_days,
            "invoice": self._serialize_invoice(order, config),
            "product": self._serialize_product(product),
            "customer": self._serialize_partner(order.partner_id),
            "order_line_id": line.id,
            "qty_sold": qty_info["qty_sold"],
            "qty_returned_prev": qty_info["qty_returned_prev"],
            "remaining_qty": qty_info["remaining_qty"],
            "history": history,
            "amounts": amounts,
            "can_edit_refund_amount": can_edit_amount,
        }

    @api.model
    def _compute_refund_amounts(self, line, return_qty):
        currency = line.currency_id or line.order_id.currency_id
        price_unit = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
        gross = line.price_unit * return_qty
        discount_amount = gross - (price_unit * return_qty)
        tax_amount = 0.0
        subtotal = price_unit * return_qty
        net_refund = subtotal
        if line.tax_ids:
            taxes = line.tax_ids.compute_all(
                price_unit,
                currency=currency,
                quantity=return_qty,
                product=line.product_id,
                partner=line.order_id.partner_id,
            )
            subtotal = taxes.get("total_excluded", subtotal)
            tax_amount = taxes.get("total_included", subtotal) - subtotal
            net_refund = taxes.get("total_included", subtotal + tax_amount)
        else:
            line_total = line.price_subtotal_incl
            unit_incl = line_total / abs(line.qty) if line.qty else line.price_unit
            net_refund = unit_incl * return_qty
            tax_amount = max(net_refund - subtotal, 0.0)
        return {
            "refund_amount": subtotal + tax_amount,
            "subtotal": subtotal,
            "tax": tax_amount,
            "discount": discount_amount,
            "net_refund": net_refund,
        }

    @api.model
    def _lookup_error(self, code, message, config=None, session=None, event="invoice_lookup"):
        self.env["pos.return.audit"]._log_pos_event(
            event,
            message=message,
            success=False,
            config=config,
            session=session,
            payload={"error_code": code},
        )
        return {"success": False, "error_code": code, "error": message}
