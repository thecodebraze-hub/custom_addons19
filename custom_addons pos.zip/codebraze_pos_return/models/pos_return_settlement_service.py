# -*- coding: utf-8 -*-
"""POS refund settlement — customer-facing refund disbursement."""

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.tools import float_compare

_logger = logging.getLogger(__name__)


class PosReturnTransactionSettlement(models.Model):
    _inherit = "pos.return.transaction"

    # -------------------------------------------------------------------------
    # POS settlement RPC
    # -------------------------------------------------------------------------

    @api.model
    def pos_get_settlement_context(self, return_id, config_id, session_id=False):
        """Return header data for the Refund Settlement popup."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        ret = self.browse(return_id).exists()
        if not ret:
            return {"success": False, "error": self.env._("Return not found.")}
        if not config:
            return {"success": False, "error": self.env._("POS configuration not found.")}

        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        )
        original = ret.original_order_id
        return {
            "success": True,
            "return_id": ret.id,
            "return_name": ret.name,
            "settlement_state": ret.settlement_state,
            "refund_method": ret.refund_method,
            "invoice_number": original.pos_reference or original.name,
            "original_order_id": original.id,
            "customer": ret.partner_id.name or self.env._("Walk-in Customer"),
            "partner_id": ret.partner_id.id or False,
            "cashier": ret.cashier_id.name or self.env.user.name,
            "branch": ret.config_id.name or config.name,
            "refund_amount": ret.amount_total,
            "amount_tax": ret.amount_tax,
            "enable_cash_refund": settings.enable_cash_refund if settings else False,
            "cash_refund_limit": settings.cash_refund_limit if settings else 0.0,
            "approval_amount": settings.approval_amount if settings else 0.0,
            "default_refund_method": "voucher",
            "can_settle": ret.settlement_state == "pending",
        }

    @api.model
    def pos_precheck_settlement(self, payload, config_id, session_id=False):
        """Validate settlement eligibility without persisting."""
        return self._validate_settlement_payload(payload, config_id, session_id)

    @api.model
    def pos_settle_return(self, payload, config_id, session_id=False):
        """Execute refund settlement for a completed return."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        validation = self._validate_settlement_payload(payload, config_id, session_id)
        if not validation.get("valid"):
            self.env["pos.return.audit"]._log_pos_event(
                "validation_failure",
                message=validation.get("error"),
                success=False,
                config=config,
                session=session,
                payload=validation,
            )
            return {"success": False, **validation}

        if validation.get("approval_required") and not payload.get("manager_approved"):
            return {
                "success": False,
                "error_code": "approval_required",
                "error": self.env._("Manager approval required."),
                "approval_reasons": validation.get("approval_reasons", []),
            }

        ret = self.browse(payload.get("return_id")).exists()
        settlement_uuid = (payload or {}).get("settlement_uuid")
        if settlement_uuid:
            existing = self.search([("settlement_uuid", "=", settlement_uuid)], limit=1)
            if existing and existing.settlement_state == "settled":
                return self._serialize_settlement_response(existing, duplicate=True)

        if ret.settlement_state == "settled":
            return {
                "success": False,
                "error_code": "already_settled",
                "error": self.env._("This return has already been settled."),
            }

        method = self._map_pos_refund_method(payload.get("refund_method", "voucher"))
        self.env["pos.return.audit"]._log_pos_event(
            "settlement_started",
            message=self.env._("Settlement started for %(name)s", name=ret.name),
            success=True,
            config=config,
            session=session,
            order=ret.original_order_id,
            payload={"return_id": ret.id, "refund_method": method},
        )
        self.env["pos.return.audit"]._log_pos_event(
            "refund_method_selected",
            message=self.env._("Refund method: %(method)s", method=method),
            success=True,
            config=config,
            session=session,
            order=ret.original_order_id,
            payload={"return_id": ret.id, "refund_method": method},
        )

        if validation.get("approval_required") and payload.get("manager_approved"):
            manager = self.env["res.users"].browse(payload.get("manager_id")).exists()
            ret.write({"manager_id": (manager or self.env.user).id})

        result_extra = {}
        if method == "cash":
            result_extra = ret._execute_cash_settlement()
        elif method == "original_payment":
            result_extra = ret._execute_original_payment_settlement()
        else:
            result_extra = ret._execute_voucher_settlement()

        ret.write(
            {
                "settlement_state": "settled",
                "settlement_method": method,
                "settlement_uuid": settlement_uuid or ret.settlement_uuid,
                "settlement_date": fields.Datetime.now(),
                "settlement_notes": payload.get("notes") or "",
                "settlement_user_id": self.env.user.id,
                "refund_method": method,
            }
        )

        self.env["pos.return.audit"]._log_pos_event(
            "settlement_confirmed",
            message=self.env._("Settlement completed for %(name)s", name=ret.name),
            success=True,
            config=config,
            session=session,
            order=ret.original_order_id,
            payload={
                "return_id": ret.id,
                "refund_method": method,
                "refund_amount": ret.amount_total,
                **result_extra,
            },
        )
        return self._serialize_settlement_response(ret, extra=result_extra)

    def _execute_cash_settlement(self):
        """Record cash refund settlement without duplicating inventory payments."""
        self.ensure_one()
        order = self.return_order_id
        if not order:
            raise UserError(self.env._("Return POS order is missing."))
        cash_method = self.config_id.payment_method_ids.filtered("is_cash_count")[:1]
        if not cash_method:
            raise UserError(self.env._("No cash payment method configured for this POS."))

        existing = order.payment_ids.filtered(
            lambda p: p.payment_method_id.is_cash_count
        )[:1]
        if existing:
            self.settlement_payment_id = existing.id
            return {"payment_id": existing.id, "cash_settled": True}

        payment = self.env["pos.payment"].create(
            {
                "name": _("Customer cash refund"),
                "pos_order_id": order.id,
                "amount": order.amount_total,
                "payment_date": fields.Datetime.now(),
                "payment_method_id": cash_method.id,
            }
        )
        self.settlement_payment_id = payment.id
        return {"payment_id": payment.id, "cash_settled": True}

    def _execute_original_payment_settlement(self):
        """Link settlement to original sale payment methods."""
        self.ensure_one()
        original_payments = self.original_order_id.payment_ids
        if not original_payments:
            raise UserError(
                self.env._("Original invoice has no payment lines to reference.")
            )
        self.original_payment_ids = [(6, 0, original_payments.ids)]
        methods = ", ".join(original_payments.mapped("payment_method_id.name"))
        return {
            "original_payment_ids": original_payments.ids,
            "payment_methods": methods,
        }

    def _execute_voucher_settlement(self):
        """Delegate to Voucher Service — issuance deferred to Prompt 16."""
        self.ensure_one()
        Voucher = self.env.get("pos.return.voucher")
        if Voucher is not None and hasattr(Voucher, "request_settlement"):
            return Voucher.request_settlement(self)
        return {
            "status": "deferred",
            "voucher_pending": True,
            "message": self.env._(
                "Voucher issuance is deferred to the voucher service."
            ),
        }

    # -------------------------------------------------------------------------
    # Validation & permissions
    # -------------------------------------------------------------------------

    @api.model
    def _validate_settlement_payload(self, payload, config_id, session_id):
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        ret = self.browse((payload or {}).get("return_id")).exists()

        if not ret:
            return {
                "valid": False,
                "error_code": "return_not_found",
                "error": self.env._("Return not found."),
            }
        if ret.settlement_state == "settled":
            return {
                "valid": False,
                "error_code": "already_settled",
                "error": self.env._("This return has already been settled."),
            }
        if ret.settlement_state == "cancelled":
            return {
                "valid": False,
                "error_code": "settlement_cancelled",
                "error": self.env._("Settlement was cancelled for this return."),
            }
        if ret.state != "completed":
            return {
                "valid": False,
                "error_code": "return_not_completed",
                "error": self.env._("Return must be completed before settlement."),
            }
        if float_compare(ret.amount_total, 0.0, precision_rounding=ret.currency_id.rounding) <= 0:
            return {
                "valid": False,
                "error_code": "invalid_amount",
                "error": self.env._("Refund amount must be greater than zero."),
            }

        role = payload.get("cashier_role") or "cashier"
        if role == "minimal":
            return {
                "valid": False,
                "error_code": "permission_denied",
                "error": self.env._("Permission denied."),
            }

        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        ) if config else None
        method = self._map_pos_refund_method(payload.get("refund_method", "voucher"))
        approval_reasons = []
        approval_required = False

        if method == "cash":
            if settings and not settings.enable_cash_refund:
                return {
                    "valid": False,
                    "error_code": "cash_refund_disabled",
                    "error": self.env._("Cash refunds are disabled for this branch."),
                }
            if (
                settings
                and settings.cash_refund_limit > 0
                and float_compare(
                    ret.amount_total,
                    settings.cash_refund_limit,
                    precision_rounding=ret.currency_id.rounding,
                )
                > 0
                and role not in ("manager", "supervisor")
            ):
                approval_required = True
                approval_reasons.append(
                    self.env._(
                        "Cash refund exceeds cashier limit (%(limit)s).",
                        limit=settings.cash_refund_limit,
                    )
                )

        if (
            settings
            and settings.approval_amount > 0
            and float_compare(
                ret.amount_total,
                settings.approval_amount,
                precision_rounding=ret.currency_id.rounding,
            )
            >= 0
            and role == "cashier"
            and not payload.get("manager_approved")
        ):
            approval_required = True
            approval_reasons.append(
                self.env._("Manager approval required for high-value refunds.")
            )

        if ret.approval_required and not ret.manager_id and not payload.get("manager_approved"):
            approval_required = True
            approval_reasons.append(
                self.env._("Manager approval required for this return.")
            )

        return {
            "valid": True,
            "approval_required": approval_required,
            "approval_reasons": approval_reasons,
            "return_id": ret.id,
            "refund_amount": ret.amount_total,
        }

    @api.model
    def _serialize_settlement_response(self, ret, duplicate=False, extra=None):
        data = {
            "success": True,
            "duplicate": duplicate,
            "return_id": ret.id,
            "return_name": ret.name,
            "settlement_state": ret.settlement_state,
            "settlement_method": ret.settlement_method,
            "refund_method": ret.refund_method,
            "refund_amount": ret.amount_total,
            "settlement_date": fields.Datetime.to_string(ret.settlement_date)
            if ret.settlement_date
            else False,
        }
        if extra:
            data.update(extra)
        return data

    @api.model
    def pos_log_settlement_cancelled(self, return_id, config_id, session_id=False):
        """Audit hook when cashier closes settlement without confirming."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        ret = self.browse(return_id).exists()
        if not ret:
            return {"success": False}
        self.env["pos.return.audit"]._log_pos_event(
            "settlement_cancelled",
            message=self.env._("Settlement cancelled for %(name)s", name=ret.name),
            success=False,
            config=config,
            session=session,
            order=ret.original_order_id,
            payload={"return_id": ret.id},
        )
        return {"success": True}
