# -*- coding: utf-8 -*-
"""Audit trail for POS return lookup and validation events."""

import json
import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class PosReturnAudit(models.Model):
    """Structured audit log for return workflow POS events."""

    _name = "pos.return.audit"
    _description = "POS Return Audit"
    _inherit = ["store.credit.uuid.mixin"]
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(default="New", readonly=True, index=True)
    event_type = fields.Selection(
        selection=[
            ("invoice_lookup", "Invoice Lookup"),
            ("product_lookup", "Product Lookup"),
            ("validation_failure", "Validation Failure"),
            ("invoice_selected", "Invoice Selected"),
            ("product_selected", "Product Selected"),
            ("return_created", "Return Created"),
            ("approval_granted", "Approval Granted"),
            ("settlement_started", "Settlement Started"),
            ("settlement_confirmed", "Settlement Confirmed"),
            ("settlement_cancelled", "Settlement Cancelled"),
            ("refund_method_selected", "Refund Method Selected"),
        ],
        required=True,
        index=True,
    )
    message = fields.Text()
    success = fields.Boolean(default=True, index=True)
    company_id = fields.Many2one(
        comodel_name="res.company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )
    cashier_id = fields.Many2one(
        comodel_name="res.users",
        string="Cashier",
        default=lambda self: self.env.user,
        index=True,
    )
    pos_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="POS Order",
        index=True,
        check_company=True,
    )
    product_id = fields.Many2one(
        comodel_name="product.product",
        string="Product",
        index=True,
    )
    payload = fields.Text(
        string="Payload",
        help="JSON snapshot of lookup / validation context.",
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
            if vals.get("name", "New") == "New":
                vals["name"] = fields.Datetime.now().strftime("RAUD/%Y%m%d/%H%M%S")
        records = super().create(vals_list)
        for audit in records:
            _logger.info(
                "Return audit %s event=%s success=%s",
                audit.name,
                audit.event_type,
                audit.success,
            )
        return records

    @api.model
    def _log_pos_event(
        self,
        event_type,
        *,
        message="",
        success=True,
        config=None,
        session=None,
        order=None,
        product=None,
        payload=None,
    ):
        """Create an audit entry when audit logging is enabled."""
        Settings = self.env["store.credit.settings"]
        company = config.company_id if config else self.env.company
        settings = Settings._get_settings(company=company, config=config)
        if settings and not getattr(settings, "enable_audit_logs", True):
            return self.env["pos.return.audit"]

        payload_text = ""
        if payload is not None:
            try:
                payload_text = json.dumps(payload, default=str)
            except (TypeError, ValueError):
                payload_text = str(payload)

        return self.sudo().create(
            {
                "event_type": event_type,
                "message": message,
                "success": success,
                "company_id": company.id,
                "config_id": config.id if config else False,
                "session_id": session.id if session else False,
                "cashier_id": self.env.user.id,
                "pos_order_id": order.id if order else False,
                "product_id": product.id if product else False,
                "payload": payload_text,
            }
        )
