# -*- coding: utf-8 -*-
"""Exchange replacement product lines."""

from odoo import api, fields, models


class PosExchangeTransactionLine(models.Model):
    """Replacement product line on an exchange transaction."""

    _name = "pos.exchange.transaction.line"
    _description = "POS Exchange Transaction Line"
    _check_company_auto = True

    exchange_id = fields.Many2one(
        comodel_name="pos.exchange.transaction",
        string="Exchange",
        required=True,
        ondelete="cascade",
        index=True,
    )
    active = fields.Boolean(related="exchange_id.active", store=True)
    state = fields.Selection(related="exchange_id.state", store=True, index=True)
    company_id = fields.Many2one(
        comodel_name="res.company",
        related="exchange_id.company_id",
        store=True,
        index=True,
        readonly=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="exchange_id.currency_id",
        store=True,
        readonly=True,
    )
    product_id = fields.Many2one(
        comodel_name="product.product",
        string="Product",
        required=True,
        index=True,
    )
    uom_id = fields.Many2one(
        comodel_name="uom.uom",
        string="Unit of Measure",
        required=True,
    )
    qty = fields.Float(
        string="Quantity",
        digits="Product Unit of Measure",
        required=True,
        default=1.0,
    )
    price_unit = fields.Float(string="Unit Price", digits="Product Price", required=True)
    discount = fields.Float(string="Discount (%)", default=0.0)
    price_subtotal = fields.Monetary(
        string="Subtotal",
        currency_field="currency_id",
        compute="_compute_price_subtotal",
        store=True,
    )
    order_line_id = fields.Many2one(
        comodel_name="pos.order.line",
        string="POS Order Line",
        index=True,
        copy=False,
    )

    _sql_constraints = [
        (
            "pos_exchange_line_qty_positive",
            "CHECK(qty > 0)",
            "Exchange quantity must be greater than zero.",
        ),
    ]

    @api.depends("qty", "price_unit", "discount")
    def _compute_price_subtotal(self):
        for line in self:
            price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            line.price_subtotal = price * line.qty

    @api.onchange("product_id")
    def _onchange_product_id(self):
        if self.product_id:
            self.uom_id = self.product_id.uom_id
            self.price_unit = self.product_id.lst_price
