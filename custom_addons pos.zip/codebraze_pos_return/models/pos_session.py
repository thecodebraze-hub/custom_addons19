# -*- coding: utf-8 -*-

from odoo import api, models


class PosSession(models.Model):
    _inherit = "pos.session"

    @api.model
    def _load_pos_data_models(self, config):
        models_list = super()._load_pos_data_models(config)
        if "pos.return.reason" not in models_list:
            models_list.append("pos.return.reason")
        return models_list
