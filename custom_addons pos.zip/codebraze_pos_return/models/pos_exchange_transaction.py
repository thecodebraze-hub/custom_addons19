# -*- coding: utf-8 -*-
"""Exchange transaction header."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class PosExchangeTransaction(models.Model):
    """
    POS exchange transaction.

    Technical name: pos.exchange.transaction

    Tracks returned products (via linked return), replacement products,
    net difference, voucher usage and customer payment.
    """

    _name = "pos.exchange.transaction"
    _description = "POS Exchange Transaction"
    _inherit = [
        "mail.thread",
        "mail.activity.mixin",
        "store.credit.uuid.mixin",
        "store.credit.sync.mixin",
    ]
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
        tracking=True,
    )
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("completed", "Completed"),
            ("cancelled", "Cancelled"),
        ],
        string="Status",
        default="draft",
        required=True,
        index=True,
        tracking=True,
        copy=False,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Customer",
        index=True,
        tracking=True,
        check_company=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.company.currency_id,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        required=True,
        check_company=True,
        index=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )
    cashier_id = fields.Many2one(
        comodel_name="res.users",
        string="Cashier",
        default=lambda self: self.env.user,
        index=True,
    )
    manager_id = fields.Many2one(
        comodel_name="res.users",
        string="Manager",
        index=True,
    )

    return_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return Transaction",
        required=True,
        index=True,
        check_company=True,
        tracking=True,
        help="Return leg of the exchange.",
    )
    replacement_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="Replacement POS Order",
        index=True,
        check_company=True,
        copy=False,
    )
    line_ids = fields.One2many(
        comodel_name="pos.exchange.transaction.line",
        inverse_name="exchange_id",
        string="New Products",
        copy=True,
    )
    amount_return = fields.Monetary(
        string="Return Amount",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
        help="Total value of returned products.",
    )
    amount_replacement = fields.Monetary(
        string="Replacement Amount",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
        help="Total value of new products.",
    )
    difference_amount = fields.Monetary(
        string="Difference Amount",
        currency_field="currency_id",
        compute="_compute_amounts",
        store=True,
        help="Positive: customer pays. Negative: store owes (credit/voucher).",
    )
    voucher_used = fields.Boolean(
        string="Voucher Used",
        default=False,
        help="Set when an existing voucher/credit is applied on the exchange.",
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit Used / Issued",
        index=True,
        check_company=True,
        copy=False,
    )
    customer_payment = fields.Monetary(
        string="Customer Payment",
        currency_field="currency_id",
        default=0.0,
        help="Amount collected from the customer for a positive difference.",
    )
    settlement_mode = fields.Selection(
        selection=[
            ("customer_payment", "Customer Payment"),
            ("store_credit", "Store Credit"),
            ("voucher", "Voucher"),
            ("balanced", "Balanced"),
        ],
        string="Settlement Mode",
        compute="_compute_settlement_mode",
        store=True,
    )
    note = fields.Text(string="Notes")

    _sql_constraints = [
        (
            "pos_exchange_txn_uuid_uniq",
            "unique(uuid)",
            "Exchange transaction UUID must be unique.",
        ),
        (
            "pos_exchange_txn_name_company_uniq",
            "unique(company_id, name)",
            "Exchange transaction reference must be unique per company.",
        ),
        (
            "pos_exchange_customer_payment_positive",
            "CHECK(customer_payment >= 0)",
            "Customer payment cannot be negative.",
        ),
    ]

    @api.depends(
        "return_id",
        "return_id.amount_total",
        "line_ids",
        "line_ids.price_subtotal",
    )
    def _compute_amounts(self):
        for exchange in self:
            amount_return = exchange.return_id.amount_total if exchange.return_id else 0.0
            amount_replacement = sum(exchange.line_ids.mapped("price_subtotal"))
            exchange.amount_return = amount_return
            exchange.amount_replacement = amount_replacement
            exchange.difference_amount = amount_replacement - amount_return

    @api.depends("difference_amount", "voucher_used", "customer_payment")
    def _compute_settlement_mode(self):
        for exchange in self:
            diff = exchange.difference_amount
            rounding = exchange.currency_id.rounding or 0.01
            if abs(diff) < rounding:
                exchange.settlement_mode = "balanced"
            elif diff > 0:
                exchange.settlement_mode = "customer_payment"
            elif exchange.voucher_used:
                exchange.settlement_mode = "voucher"
            else:
                exchange.settlement_mode = "store_credit"

    @api.constrains("return_id", "company_id")
    def _check_return_company(self):
        for exchange in self:
            if exchange.return_id.company_id != exchange.company_id:
                raise ValidationError(
                    self.env._("Return and exchange must belong to the same company.")
                )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            company = self.env["res.company"].browse(
                vals.get("company_id") or self.env.company.id
            )
            if not vals.get("currency_id"):
                vals["currency_id"] = company.currency_id.id
            if vals.get("name", "New") == "New":
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("pos.exchange.transaction")
                )
                if not seq:
                    raise UserError(
                        self.env._("Sequence 'pos.exchange.transaction' is not configured.")
                    )
                vals["name"] = seq
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
        records = super().create(vals_list)
        for exchange in records:
            if exchange.return_id and not exchange.return_id.exchange_id:
                exchange.return_id.exchange_id = exchange.id
            _logger.info("Created exchange transaction %s", exchange.name)
        return records

    def action_cancel(self):
        for exchange in self:
            if exchange.state == "completed":
                raise UserError(self.env._("Completed exchanges cannot be cancelled."))
            exchange.state = "cancelled"
        return True

    def action_complete(self):
        """Complete exchange document (POS order wiring deferred)."""
        for exchange in self:
            if exchange.state != "draft":
                raise UserError(
                    self.env._(
                        "Exchange %(name)s must be draft to complete.",
                        name=exchange.name,
                    )
                )
            if not exchange.line_ids:
                raise ValidationError(
                    self.env._("Add at least one replacement product to the exchange.")
                )
            if exchange.return_id.state not in ("approved", "completed"):
                # Auto-complete linked return when settlement is exchange
                if exchange.return_id.state in ("draft", "approved"):
                    if exchange.return_id.refund_method != "exchange":
                        exchange.return_id.refund_method = "exchange"
                    exchange.return_id.action_complete()
                else:
                    raise UserError(
                        self.env._(
                            "Linked return %(name)s must be approved or completed.",
                            name=exchange.return_id.name,
                        )
                    )
            # Store owes customer → issue credit if not already linked
            if (
                exchange.difference_amount < 0
                and not exchange.credit_id
                and exchange.settlement_mode in ("store_credit", "voucher")
            ):
                credit = self.env["store.credit"]._create_credit(
                    {
                        "credit_type": "return",
                        "partner_id": exchange.partner_id.id or False,
                        "company_id": exchange.company_id.id,
                        "currency_id": exchange.currency_id.id,
                        "config_id": exchange.config_id.id,
                        "session_id": exchange.session_id.id or False,
                        "cashier_id": exchange.cashier_id.id,
                        "amount": abs(exchange.difference_amount),
                        "original_order_id": exchange.replacement_order_id.id
                        or exchange.return_id.original_order_id.id,
                        "origin_model": "pos.exchange.transaction",
                        "origin_res_id": exchange.id,
                        "note": self.env._(
                            "Exchange difference from %(name)s", name=exchange.name
                        ),
                    }
                )
                exchange.credit_id = credit.id
            exchange.state = "completed"
            _logger.info("Completed exchange transaction %s", exchange.name)
        return True
