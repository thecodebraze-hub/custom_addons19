# -*- coding: utf-8 -*-
"""Return reason master data."""

from odoo import api, fields, models


class PosReturnReason(models.Model):
    """Reason codes for retail returns (wrong size, defect, etc.)."""

    _name = "pos.return.reason"
    _description = "POS Return Reason"
    _inherit = ["pos.load.mixin"]
    _order = "sequence, name"
    _check_company_auto = True

    name = fields.Char(required=True, translate=True)
    code = fields.Char(required=True, index=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("active", "Active"),
            ("archived", "Archived"),
        ],
        default="active",
        required=True,
        index=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="company_id.currency_id",
        store=True,
        readonly=True,
    )
    requires_manager = fields.Boolean(
        string="Requires Manager",
        default=False,
        help="Selecting this reason forces manager approval on the return.",
    )
    default_disposition = fields.Selection(
        selection=[
            ("restock", "Restock"),
            ("scrap", "Scrap"),
            ("quarantine", "Quarantine"),
        ],
        string="Default Disposition",
        default="restock",
        required=True,
    )

    _sql_constraints = [
        (
            "pos_return_reason_code_company_uniq",
            "unique(company_id, code)",
            "Return reason code must be unique per company.",
        ),
    ]

    @api.model
    def _load_pos_data_domain(self, data, config):
        return [
            ("company_id", "=", config.company_id.id),
            ("active", "=", True),
            ("state", "=", "active"),
        ]

    @api.model
    def _load_pos_data_fields(self, config):
        return [
            "id",
            "name",
            "code",
            "sequence",
            "requires_manager",
            "default_disposition",
        ]
