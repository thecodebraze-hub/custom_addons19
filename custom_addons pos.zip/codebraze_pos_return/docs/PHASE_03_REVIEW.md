# Phase 03 — Return & Exchange Production Readiness Review

**Date:** 2026-07-09  
**Scope:** `codebraze_pos_return`, `codebraze_pos_return_voucher`, `codebraze_pos_store_credit` (Phase 03 integration)  
**Verdict:** **Conditionally production-ready** — core return/refund/voucher/redemption flows are implemented; mandatory gates below must close before Phase 04.

---

## 1. QA Review Report

### Workflows reviewed

| Workflow | Status | Notes |
|----------|--------|-------|
| Return Product | ✅ Implemented | Refund popup → invoice/product lookup → validation → confirmation → inventory |
| Exchange Product | ⚠️ Partial | Backend `pos.exchange.transaction` exists; **no POS UI workflow** |
| Refund Settlement | ✅ Implemented | Settlement popup; cash / original payment / voucher paths |
| Store Credit Issue | ✅ Implemented | Via return completion + `pos.return.voucher._create_from_return` |
| Store Credit Redemption | ✅ Implemented | Payment screen popup; server-side on order paid |
| Voucher Printing | ✅ Implemented | `_register_print`; hook for `pos.voucher.print.service` |
| Remaining Balance | ✅ Implemented | `update_existing` / `issue_new` strategies |
| Multiple Voucher | ✅ Implemented | Allocation + auto-apply in payment popup |
| Offline Flow | ⚠️ Partial | Queues exist; conflict resolver not fully wired |
| Manager Approval | ✅ Implemented | Return confirm + settlement + partial redemption |

### End-to-end flow (happy path)

```
Refund Button → Refund Popup (scan/search)
  → Invoice Selection / Product grid
  → Return Confirmation (reasons, qty, approval)
  → pos_confirm_return (UUID idempotency)
  → Return POS order + stock picking
  → Settlement Popup (method selection)
  → pos_settle_return (settlement_uuid idempotency)
  → Voucher issued (on action_complete when refund_method=voucher)
```

### Gaps / edge cases identified

| # | Gap | Severity | Recommendation |
|---|-----|----------|----------------|
| 1 | `allow_return_without_invoice` / `require_original_invoice` exposed in settings but **not enforced** in `pos_validate_return` or confirm | Medium | Wire settings into validation (Phase 04 or hotfix) |
| 2 | `expired_voucher_allowed` / `cancelled_voucher_allowed` config **not wired** to redemption validators | Medium | Honor flags in `_pos_validate_credit_for_redemption` |
| 3 | Exchange workflow has **no POS screens** | High | Phase 04 or document as backend-only |
| 4 | `_execute_voucher_settlement` returns deferred stub; voucher actually created at `action_complete` | Low | Document; consolidate settlement + issuance audit |
| 5 | Voucher **reprint** (manager permission, reprint count, reason) not found in codebase | Medium | Confirm voucher print framework coverage |
| 6 | Offline return queue does not check `client_uuid` duplicate before re-sync | Low | Compare UUID on queue drain |
| 7 | Fuzzy invoice lookup (`ilike %code%`) may return wrong invoice | Low | Prefer exact match; fuzzy only as fallback with warning |
| 8 | `_compute_qty_info` may double-count if both return txn and native refund exist | Medium | UAT with mixed return paths |

### Duplicate prevention (verified)

| Scenario | Mechanism | Location |
|----------|-----------|----------|
| Duplicate return | `client_uuid` → `uuid` unique | `pos_confirm_return` |
| Duplicate settlement | `settlement_uuid` unique | `pos_settle_return` |
| Duplicate redemption | `redemption_uuid` on `store.credit.payment` | `_pos_execute_redemption` |
| Duplicate voucher issue | `credit_id` unique per return via search-before-create | `_create_from_return` |

---

## 2. Code Review Report

### Strengths

- Clear separation: lookup (`pos_return_pos_service`), confirm (`pos_return_confirm_service`), settlement (`pos_return_settlement_service`)
- POS services mirror backend RPC (`PosRefundUiService`, `PosSettlementUiService`, `PosStoreCreditRedemptionService`)
- Ledger-first store credit with idempotent UUIDs throughout
- Audit hooks on lookup, validation, return created, settlement, redemption
- Tax-aware refund amount computation in `_compute_refund_amounts`

### Issues found & addressed in this review

| Issue | Action |
|-------|--------|
| Duplicate `approval_amount` key in `pos_get_return_settings` | **Fixed** |
| Missing `ir.model.access.csv` on store credit + return voucher | **Fixed** |
| POS user read-only on `pos.return.transaction` (could not create returns) | **Fixed** — grant create/write to `group_pos_user` |
| Missing ACL for return lines, exchange, approval history | **Fixed** |

### Remaining code quality items

| Area | Finding | Priority |
|------|---------|----------|
| God-object | `store.credit` ~1100 lines; consider service extraction in Phase 04 | Low |
| Duplication | Barcode/UUID generation on model + identification services | Low |
| Dead code | `_execute_voucher_settlement` deferred stub vs `action_complete` voucher hook | Low |
| Settings UI | `res.config.settings` fields exist; **no XML views** | Medium |
| Tests | `codebraze_pos_return` has **zero unit tests** | High |
| `_sort_credits_for_allocation` defined on both redemption + partial services | Low |

### SOLID assessment

| Principle | Score | Comment |
|-----------|-------|---------|
| SRP | B | Return services well split; store credit engine concentrated |
| OCP | A | Credit types, refund methods, strategies are configurable |
| LSP | A | Voucher delegates to store.credit via `_inherits` |
| ISP | B | POS settings payloads are wide but acceptable |
| DIP | B | Some direct `env.get()` for optional modules (voucher, print) |

---

## 3. Performance Recommendations

| Area | Current | Recommendation |
|------|---------|----------------|
| Invoice lookup | Exact + fuzzy `ilike` search, limit 1 | Add composite index on `(company_id, state, pos_reference)` if slow |
| Product-invoice search | Up to 50 orders × line filter | Acceptable for retail; add `limit` config for high-volume |
| Partner credit balance | `search` all credits per customer lookup | Cache per session or use `read_group` |
| `_compute_amounts` on store credit | Walks all posted txns | OK for POS volume; monitor >500 txns/credit |
| `_compute_qty_info` | Per-line search + refund order search | Batch prefetch return lines for multi-product returns |
| POS product search | `getAll().filter()` client-side | OK for <10k products; server search if catalog grows |
| Offline queues | localStorage JSON arrays | Cap queue size per `offline_queue_size` setting |
| Audit writes | Every lookup logs a row | Gate verbose events behind `enable_audit_logs` (already done) |

---

## 4. Security Review

### Permissions model

| Role | Return | Settlement | Redemption | Backend |
|------|--------|------------|------------|---------|
| Cashier (`group_pos_user`) | Create/read/write | Via RPC | Via RPC | Read store credit |
| Supervisor | Same + cash limit bypass in settlement validation | | | |
| Manager (`group_pos_manager`) | Full + unlink | Full | Full | Full settings |
| Minimal role | **Blocked** in payment + settlement popups | Blocked | Blocked | — |

### Fixed in this review

- Added ACL for all `store.credit*` models
- Added ACL for `pos.return.voucher`
- Granted POS user create/write on return transaction models

### Still required before production

| Item | Status |
|------|--------|
| Company-scoped **record rules** on store credit + return models | ❌ Missing |
| `permission_cashier/supervisor/manager` config flags vs actual ACL enforcement | ⚠️ Config only |
| Manager approval popup credential verification | ⚠️ Verify PIN/password in UAT |
| Cross-company redemption blocked by default | ✅ `allow_cross_company_redemption=False` |

---

## 5. Functional Test Cases

### Preconditions

- Odoo 19 Enterprise POS with `codebraze_pos_return`, `codebraze_pos_return_voucher`, `codebraze_pos_store_credit` installed
- Open POS session; test customer with prior sale
- Settings documented per scenario

---

### TC-01 — Full Return with Return Voucher

| Step | Action | Expected |
|------|--------|----------|
| 1 | Scan invoice barcode | Invoice loads with all products |
| 2 | Select product, qty = sold qty | Remaining qty = 0 after return |
| 3 | Select reason, confirm return | `pos.return.transaction` completed; return order paid |
| 4 | Settlement → Voucher | Voucher issued; `pos.return.voucher` linked |
| 5 | Check audit | `return_created`, `settlement_confirmed`, `issue` audit rows |

---

### TC-02 — Partial Return

| Step | Action | Expected |
|------|--------|----------|
| 1 | Select product, return qty < sold | Validation passes |
| 2 | Confirm | Return total = partial amount |
| 3 | Re-open same invoice | `remaining_qty` reduced |

---

### TC-03 — Multiple Product Return

| Step | Action | Expected |
|------|--------|----------|
| 1 | Invoice with 3+ products | All shown in grid |
| 2 | Select 2 products with different reasons | Both lines created |
| 3 | Confirm | Single return txn, multiple lines, correct total |

---

### TC-04 — Return Without Invoice (if enabled)

| Step | Action | Expected |
|------|--------|----------|
| 1 | Set `allow_return_without_invoice=True` | — |
| 2 | Attempt return without invoice scan | **Currently fails** — config not wired; document as known gap |

---

### TC-05 — Return Requiring Manager Approval

| Step | Action | Expected |
|------|--------|----------|
| 1 | Return exceeding `approval_amount` OR expired period | `approval_required=True` |
| 2 | Confirm without approval | Blocked |
| 3 | Manager approves | Return completes; `approval_granted` audit |

---

### TC-06 — Voucher Redemption (Full)

| Step | Action | Expected |
|------|--------|----------|
| 1 | Sale Rs.3000; voucher Rs.3000 | — |
| 2 | Apply store credit on payment | Order fully paid |
| 3 | Check credit | Status `used`, remaining = 0 |

---

### TC-07 — Voucher Redemption (Partial)

| Step | Action | Expected |
|------|--------|----------|
| 1 | Voucher Rs.5000; bill Rs.3500 | — |
| 2 | Apply credit | Rs.3500 redeemed |
| 3 | Check remainder per strategy | `partially_used` (update) OR new voucher (issue_new) |

---

### TC-08 — Multiple Voucher Redemption

| Step | Action | Expected |
|------|--------|----------|
| 1 | Customer with 2+ credits | Listed in payment popup |
| 2 | Apply All (Auto) | Allocated per `credit_redemption_order` |
| 3 | Order paid | Both redemptions posted; no duplicate UUID |

---

### TC-09 — Remaining Balance: Update Existing

| Setting | `remaining_credit_strategy=update_existing` |
| Step | Action | Expected |
| 1 | Partial redeem | Same barcode, `partially_used`, balance retained |

---

### TC-10 — Remaining Balance: Issue New

| Setting | `remaining_credit_strategy=issue_new`, `auto_print_remainder_voucher=True` |
| Step | Action | Expected |
| 1 | Partial redeem | Original `used`; new credit + voucher; print audit |

---

### TC-11 — Offline Return

| Step | Action | Expected |
|------|--------|----------|
| 1 | Disconnect network | Offline banner in popup |
| 2 | Confirm return | Queued in localStorage |
| 3 | Reconnect | `processOfflineReturnQueue` syncs; no duplicate if UUID matches |

---

### TC-12 — Offline Voucher Redemption

| Step | Action | Expected |
|------|--------|----------|
| 1 | Cache credit via prior online lookup | — |
| 2 | Apply offline | Queued with `redemption_uuid` |
| 3 | Online | Server validates; idempotent if already redeemed |

---

### TC-13 — Duplicate Voucher Scan

| Step | Action | Expected |
|------|--------|----------|
| 1 | Apply same credit twice on one order | Blocked if `allow_multiple_voucher=False` |
| 2 | Re-scan same UUID on second order after full use | `not_found` or validation failure |

---

### TC-14 — Expired Voucher

| Step | Action | Expected |
|------|--------|----------|
| 1 | Credit past `expiry_date` | Redemption blocked (`_is_expired`) |
| 2 | `expired_voucher_allowed=True` | **Currently still blocked** — flag not wired |

---

### TC-15 — Cancelled Voucher

| Step | Action | Expected |
|------|--------|----------|
| 1 | Cancel credit in backend | Redemption blocked |
| 2 | `cancelled_voucher_allowed=True` | **Currently still blocked** — flag not wired |

---

### TC-16 — Cross Branch Redemption

| Setting | `cross_branch_usage=False` |
| Step | Action | Expected |
| 1 | Redeem credit issued at Branch A at Branch B | Validation error |

---

### TC-17 — Cross Company Redemption

| Setting | `allow_cross_company_redemption=False` (default) |
| Step | Action | Expected |
| 1 | Redeem credit from Company A at Company B POS | Blocked |

---

### TC-18 — Refund to Cash

| Setting | `enable_cash_refund=True` |
| Step | Action | Expected |
| 1 | Settlement → Cash | Cash payment on return order; drawer updated |

---

### TC-19 — Refund to Original Payment Method

| Step | Action | Expected |
|------|--------|----------|
| 1 | Settlement → Original Payment | `original_payment_ids` linked; audit logged |

---

### TC-20 — Exchange Workflow

| Step | Action | Expected |
|------|--------|----------|
| 1 | Initiate exchange from POS | **Not available** — backend model only |
| 2 | Manual backend exchange | `pos.exchange.transaction` completes; credit issued if difference < 0 |

---

## 6. Edge Case Checklist

- [ ] Return qty = 0 → blocked (`invalid_qty`)
- [ ] Return qty > remaining → blocked (`qty_exceeds_remaining`)
- [ ] Fully returned line → blocked (`fully_returned`)
- [ ] Unpaid invoice → blocked (`invoice_not_paid`)
- [ ] Branch mismatch → blocked when `branch_specific_voucher=True`
- [ ] Customer mismatch → blocked when partner enforced
- [ ] Company mismatch → blocked
- [ ] Cash refund disabled → blocked at validation + settlement
- [ ] Cash over limit → manager approval required
- [ ] Completed return cancel → blocked
- [ ] Settle already-settled return → blocked (`already_settled`)
- [ ] Redeem more than remaining → blocked
- [ ] Partial redemption disabled → must redeem full balance
- [ ] Negative credit balance → SQL constraint prevents
- [ ] Concurrent redemption same UUID → idempotent return existing payment
- [ ] Return order without open session → UserError
- [ ] No cash payment method for cash settlement → UserError
- [ ] Offline duplicate return UUID on sync → should return `duplicate=True` (verify UAT)

---

## 7. Refactoring Recommendations (non-breaking)

1. **Wire dormant config flags** — `require_original_invoice`, `expired_voucher_allowed`, `cancelled_voucher_allowed`
2. **Add `codebraze_pos_return/tests/`** — mirror store credit test patterns for confirm/settlement/qty
3. **Add settings XML views** — operators cannot configure ICP params without technical menu
4. **Add company record rules** — multi-company data isolation
5. **Consolidate voucher settlement** — remove deferred stub; link settlement audit to voucher print
6. **Exchange POS UI** — Phase 04 scope
7. **Route barcode/UUID creation** through `IdentificationFacadeService` exclusively
8. **Cap offline queues** — enforce `offline_queue_size` in JS drain loops

---

## 8. Production Readiness Checklist

### Mandatory (blockers)

- [x] Core return workflow (lookup → confirm → inventory → settlement)
- [x] Store credit issuance on voucher returns
- [x] Store credit redemption on POS payment
- [x] Partial redemption + remainder strategies
- [x] Manager approval gates
- [x] UUID idempotency (return, settlement, redemption)
- [x] Audit logging framework
- [x] ACL for POS user on transactional models (**fixed this review**)
- [ ] **UAT on cashier-only account** (not manager)
- [ ] **Unit tests for return module**
- [ ] **Company record rules**
- [ ] **Settings UI for branch operators**

### Recommended

- [ ] Wire `allow_return_without_invoice` validation
- [ ] Wire expired/cancelled voucher override flags
- [ ] Exchange POS workflow
- [ ] Voucher reprint with manager gate
- [ ] Full offline conflict resolution (`conflict_resolution_strategy`)
- [ ] Performance test with 50+ concurrent POS terminals

### Sign-off criteria for Phase 04

All **Mandatory** items checked + TC-01 through TC-19 pass on staging + security review signed off.

---

## 9. Phase 03 Completion Report

### Delivered

| Component | Module | Status |
|-----------|--------|--------|
| Refund Button & Popup | `codebraze_pos_return` | ✅ |
| Invoice / Product / Customer Lookup | `codebraze_pos_return` | ✅ |
| Return Validation & Reasons | `codebraze_pos_return` | ✅ |
| Return Order + Inventory | `codebraze_pos_return` | ✅ |
| Refund Settlement | `codebraze_pos_return` | ✅ |
| Return Voucher | `codebraze_pos_return_voucher` | ✅ |
| Store Credit Engine | `codebraze_pos_store_credit` | ✅ |
| Redemption + Partial Engine | `codebraze_pos_store_credit` | ✅ |
| Voucher Printing Hooks | `codebraze_pos_return_voucher` | ✅ |
| Offline Queues | All POS services | ⚠️ Partial |
| Exchange | `codebraze_pos_return` | ⚠️ Backend only |
| Security ACL | All modules | ✅ Fixed |

### Certification status

**Phase 03 is certified for staged production pilot** subject to:

1. UAT execution of test cases TC-01–TC-19
2. Record rules + settings UI before multi-company rollout
3. Exchange workflow deferred to Phase 04

### Changes applied during finalization

1. Removed duplicate `approval_amount` in `pos_get_return_settings`
2. Added `security/ir.model.access.csv` to `codebraze_pos_store_credit`
3. Added `security/ir.model.access.csv` to `codebraze_pos_return_voucher`
4. Extended return ACL for lines, exchange, approval + POS user create/write

---

*Review conducted against codebase at `codebraze_pos_return` v19.0.1.4.0, `codebraze_pos_store_credit` v19.0.1.2.0.*
