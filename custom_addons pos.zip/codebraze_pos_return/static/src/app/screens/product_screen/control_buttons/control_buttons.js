/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { ControlButtons } from "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";
import { _t } from "@web/core/l10n/translation";

patch(ControlButtons.prototype, {
    /**
     * Custom CodeBraze Refund — distinct from Odoo core clickRefund().
     */
    async clickCodebrazeRefund() {
        await this.pos.openCodebrazeRefundPopup();
        this.props.close?.();
    },

    get showCodebrazeRefundButton() {
        return this.pos.cashier?._role !== "minimal";
    },

    get codebrazeRefundLabel() {
        return _t("Refund");
    },
});
