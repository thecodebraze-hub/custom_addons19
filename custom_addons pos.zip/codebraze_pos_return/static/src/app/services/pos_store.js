/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { makeAwaitable } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { RefundPopup } from "../components/popups/refund_popup/refund_popup";
import { ReturnConfirmationPopup } from "../components/popups/return_confirmation_popup/return_confirmation_popup";
import { SettlementPopup } from "../components/popups/settlement_popup/settlement_popup";
import { PosRefundUiService } from "./pos_refund_ui_service";
import { PosSettlementUiService } from "./pos_settlement_ui_service";
import { _t } from "@web/core/l10n/translation";

patch(PosStore.prototype, {
    async setup(...args) {
        await super.setup(...args);
        this.refundUi = new PosRefundUiService(this);
        this.settlementUi = new PosSettlementUiService(this);
    },

    async openCodebrazeRefundPopup() {
        if (this.cashier?._role === "minimal") {
            this.notification.add(_t("Permission Denied"), { type: "danger" });
            return;
        }
        const lookupResult = await makeAwaitable(this.dialog, RefundPopup, {
            pos: this,
        });
        if (!lookupResult || lookupResult.action !== "open_confirmation") {
            return;
        }
        await this.openReturnConfirmation(lookupResult);
    },

    async openReturnConfirmation({ invoice, order_id, partner_id }) {
        const confirmResult = await makeAwaitable(this.dialog, ReturnConfirmationPopup, {
            pos: this,
            invoice,
            orderId: order_id,
            partnerId: partner_id,
        });
        if (!confirmResult || confirmResult.action !== "return_confirmed") {
            return;
        }
        const { result } = confirmResult;
        if (result.offline || result.queued) {
            this.notification.add(_t("Return queued for synchronization."), { type: "info" });
            return;
        }
        if (result.duplicate) {
            this.notification.add(
                _t("Return already processed (%s).", result.return_name),
                { type: "warning" }
            );
            if (result.needs_settlement && result.return_id) {
                await this.openRefundSettlement(result.return_id);
            }
            return;
        }
        this.notification.add(
            _t("Return %(name)s created.", { name: result.return_name }),
            { type: "success" }
        );
        await this.refundUi.refreshOrdersAfterReturn(result);
        if (result.needs_settlement !== false && result.return_id) {
            await this.openRefundSettlement(result.return_id);
        }
    },

    async openRefundSettlement(returnId) {
        const settlementResult = await makeAwaitable(this.dialog, SettlementPopup, {
            pos: this,
            returnId,
        });
        if (!settlementResult || settlementResult.action !== "settlement_confirmed") {
            return;
        }
        const { result } = settlementResult;
        if (result.offline || result.queued) {
            this.notification.add(_t("Settlement queued for synchronization."), {
                type: "info",
            });
            return;
        }
        if (result.duplicate) {
            this.notification.add(_t("Settlement already completed."), { type: "warning" });
            return;
        }
        if (result.voucher_pending) {
            this.notification.add(
                _t("Settlement complete. Voucher will be issued in the next step."),
                { type: "success" }
            );
            return;
        }
        this.notification.add(_t("Refund settlement completed."), { type: "success" });
    },

    async posBackOnline() {
        await super.posBackOnline(...arguments);
        await this.onCodebrazeRefundNetworkReconnect();
    },

    async onCodebrazeRefundNetworkReconnect() {
        await this.refundUi?.processOfflineReturnQueue();
        await this.settlementUi?.processOfflineSettlementQueue();
    },
});
