/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { formatCurrency } from "@point_of_sale/app/models/utils/currency";

const OFFLINE_QUEUE_KEY_PREFIX = "codebraze.refund.queue.";
const SETTINGS_CACHE_KEY_PREFIX = "codebraze.refund.settings.";

/**
 * Refund popup lookup, validation, and offline queue service.
 */
export class PosRefundUiService {
    constructor(pos) {
        this.pos = pos;
        this._settings = null;
    }

    get isOffline() {
        const network = this.pos.data?.network?.unsyncData;
        if (network && typeof network.hasConnection === "function") {
            return !network.hasConnection();
        }
        return typeof navigator !== "undefined" ? !navigator.onLine : false;
    }

    get canEditRefundAmount() {
        return this.pos.cashier?._role === "manager";
    }

    async getReturnSettings() {
        if (this._settings) {
            return this._settings;
        }
        const cacheKey = `${SETTINGS_CACHE_KEY_PREFIX}${this.pos.config.id}`;
        try {
            const cached = localStorage.getItem(cacheKey);
            if (cached) {
                this._settings = JSON.parse(cached);
            }
        } catch {
            // ignore cache parse errors
        }
        if (!this.isOffline) {
            try {
                const settings = await this.pos.data.call(
                    "pos.return.transaction",
                    "pos_get_return_settings",
                    [this.pos.config.id]
                );
                this._settings = settings || this._defaultSettings();
                localStorage.setItem(cacheKey, JSON.stringify(this._settings));
            } catch {
                this._settings = this._settings || this._defaultSettings();
            }
        } else {
            this._settings = this._settings || this._defaultSettings();
        }
        return this._settings;
    }

    _defaultSettings() {
        return {
            maximum_refund_days: 14,
            branch_specific_voucher: true,
            manager_approval: false,
            approval_amount: 0,
            enable_cash_refund: false,
            require_original_invoice: true,
        };
    }

    async lookupInvoiceByBarcode(barcode) {
        const code = (barcode || "").trim();
        if (!code) {
            return { success: false, error_code: "barcode_invalid", error: _t("Barcode Invalid") };
        }
        if (!this.isOffline) {
            try {
                const result = await this.pos.data.call(
                    "pos.return.transaction",
                    "pos_lookup_invoice",
                    [code, this.pos.config.id, this.pos.session?.id || false]
                );
                if (result?.success) {
                    return result;
                }
            } catch {
                // fall through to local lookup
            }
        }
        return this._lookupInvoiceLocal(code);
    }

    async lookupProductInvoices({ barcode, productId, partnerId, searchTerm } = {}) {
        if (!this.isOffline) {
            try {
                const result = await this.pos.data.call(
                    "pos.return.transaction",
                    "pos_lookup_product_invoices",
                    [
                        this.pos.config.id,
                        this.pos.session?.id || false,
                        barcode || false,
                        productId || false,
                        partnerId || false,
                        searchTerm || false,
                    ]
                );
                if (result?.success || result?.product) {
                    return result;
                }
            } catch {
                // fall through
            }
        }
        return this._lookupProductInvoicesLocal({ barcode, productId, partnerId, searchTerm });
    }

    async validateReturn(context) {
        const {
            orderId,
            productId,
            orderLineId,
            returnQty,
            reasonId,
            refundMethod,
            partnerId,
        } = context;
        if (!this.isOffline) {
            try {
                const result = await this.pos.data.call(
                    "pos.return.transaction",
                    "pos_validate_return",
                    [
                        this.pos.config.id,
                        this.pos.session?.id || false,
                        orderId,
                        productId,
                        orderLineId,
                        returnQty,
                        reasonId || false,
                        refundMethod || "voucher",
                        partnerId || false,
                    ]
                );
                return result;
            } catch (error) {
                return {
                    valid: false,
                    error_code: "validation_error",
                    error: error?.message || _t("Validation failed."),
                };
            }
        }
        return this._validateReturnLocal(context);
    }

    async findProductByBarcode(barcode) {
        const code = (barcode || "").trim();
        if (!code) {
            return null;
        }
        const Product = this.pos.models["product.product"];
        let product =
            Product.getBy("barcode", code) ||
            Product.getAll().find(
                (p) =>
                    (p.barcode && p.barcode === code) ||
                    (p.default_code && p.default_code === code)
            ) ||
            null;
        if (!product) {
            const stripped = code.replace(/^0+/, "");
            if (stripped && stripped !== code) {
                product = Product.getBy("barcode", stripped);
            }
        }
        if (!product && !this.isOffline) {
            try {
                const results = await this.pos.data.searchRead(
                    "product.product",
                    [["barcode", "=", code]],
                    { limit: 1 }
                );
                product = results?.[0] ? Product.get(results[0].id) : null;
            } catch {
                // local only
            }
        }
        return product;
    }

    searchProducts(term, limit = 30) {
        const needle = (term || "").trim().toLowerCase();
        if (!needle) {
            return [];
        }
        return this.pos.models["product.product"]
            .getAll()
            .filter((p) => {
                const name = (p.display_name || p.name || "").toLowerCase();
                const barcode = (p.barcode || "").toLowerCase();
                const code = (p.default_code || "").toLowerCase();
                return (
                    name.includes(needle) ||
                    barcode.includes(needle) ||
                    code.includes(needle)
                );
            })
            .slice(0, limit);
    }

    formatMoney(amount) {
        return formatCurrency(amount || 0, this.pos.currency);
    }

    getReturnReasons() {
        const Reason = this.pos.models["pos.return.reason"];
        if (!Reason) {
            return [];
        }
        return (Reason.getAll?.() || [])
            .filter((r) => r.active !== false)
            .slice()
            .sort((a, b) => (a.sequence || 0) - (b.sequence || 0));
    }

    validateRefundPayload(payload) {
        if (!payload?.lines?.length && !payload?.product_id) {
            return { valid: false, error: _t("Select at least one product to return.") };
        }
        if (this.pos.cashier?._role === "minimal") {
            return { valid: false, error: _t("Permission Denied") };
        }
        if (payload.approval_required && !payload.manager_approved) {
            return { valid: false, error: _t("Manager approval required.") };
        }
        return { valid: true, error: null };
    }

    computeLineRefundAmounts(line) {
        const qty = Number(line.return_qty) || 0;
        const unit = line.unit_price || 0;
        const gross = unit * qty;
        const discount = gross * ((line.discount || 0) / 100);
        const subtotal = gross - discount;
        const unitIncl = line.line_subtotal
            ? line.line_subtotal / (line.qty_sold || 1)
            : subtotal / (qty || 1);
        const net = unitIncl * qty;
        const tax = Math.max(net - subtotal, 0);
        return { subtotal, tax, discount, net_refund: net };
    }

    async precheckReturnConfirmation(payload) {
        if (this.isOffline) {
            return this._precheckReturnLocal(payload);
        }
        try {
            return await this.pos.data.call(
                "pos.return.transaction",
                "pos_precheck_return",
                [payload, this.pos.config.id, this.pos.session?.id || false]
            );
        } catch (error) {
            return {
                valid: false,
                error: error?.message || _t("Validation failed."),
            };
        }
    }

    async confirmReturn(payload) {
        if (this.isOffline) {
            return this.queueOfflineReturnConfirmation(payload);
        }
        try {
            return await this.pos.data.call(
                "pos.return.transaction",
                "pos_confirm_return",
                [payload, this.pos.config.id, this.pos.session?.id || false]
            );
        } catch (error) {
            return {
                success: false,
                error: error?.message || _t("Return confirmation failed."),
            };
        }
    }

    queueOfflineReturnConfirmation(payload) {
        const entry = {
            ...payload,
            offline: true,
            queued_at: new Date().toISOString(),
            sync_status: "pending",
        };
        this.queueOfflineRefundAction(entry);
        return {
            success: true,
            offline: true,
            return_name: payload.client_uuid,
            queued: true,
        };
    }

    async refreshOrdersAfterReturn(result) {
        if (!result?.return_order_id || this.isOffline) {
            return;
        }
        try {
            const data = await this.pos.data.call("pos.order", "read_pos_orders", [
                [["id", "in", [result.return_order_id, result.original_order_id].filter(Boolean)]],
            ]);
            if (data?.["pos.order"]) {
                this.pos.models.loadConnectedData(data, []);
            }
        } catch {
            // Non-blocking refresh
        }
    }

    async processOfflineReturnQueue() {
        if (this.isOffline) {
            return;
        }
        const storageKey = `${OFFLINE_QUEUE_KEY_PREFIX}${this.pos.config.id}`;
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(storageKey) || "[]");
        } catch {
            return;
        }
        const remaining = [];
        for (const entry of queue) {
            if (!entry.lines?.length) {
                continue;
            }
            try {
                const result = await this.pos.data.call(
                    "pos.return.transaction",
                    "pos_confirm_return",
                    [entry, this.pos.config.id, this.pos.session?.id || false]
                );
                if (!result?.success) {
                    remaining.push(entry);
                }
            } catch {
                remaining.push(entry);
            }
        }
        localStorage.setItem(storageKey, JSON.stringify(remaining));
    }

    _precheckReturnLocal(payload) {
        const order = this.pos.models["pos.order"].get(payload.order_id);
        if (!order) {
            return { valid: false, error: _t("Invoice not found.") };
        }
        for (const line of payload.lines || []) {
            const orig = order.lines?.find((l) => l.id === line.order_line_id);
            if (!orig) {
                return {
                    valid: false,
                    error: _t("Product does not belong to selected invoice."),
                };
            }
            const qtyInfo = this._computeLocalQtyInfo(order, orig);
            if (line.return_qty > qtyInfo.remaining_qty) {
                return {
                    valid: false,
                    error: _t("Return quantity exceeds remaining quantity."),
                };
            }
        }
        return { valid: true, approval_required: false, approval_reasons: [] };
    }

    queueOfflineRefundAction(payload) {
        const entry = {
            ...payload,
            uuid: payload.client_uuid || crypto.randomUUID(),
            queued_at: new Date().toISOString(),
            sync_status: "pending",
        };
        this.pos._codebrazeOfflineRefundQueue = this.pos._codebrazeOfflineRefundQueue || [];
        this.pos._codebrazeOfflineRefundQueue.push(entry);
        const storageKey = `${OFFLINE_QUEUE_KEY_PREFIX}${this.pos.config.id}`;
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(storageKey) || "[]");
        } catch {
            queue = [];
        }
        queue.push(entry);
        localStorage.setItem(storageKey, JSON.stringify(queue));
        return queue.length;
    }

    // -------------------------------------------------------------------------
    // Local / offline fallbacks
    // -------------------------------------------------------------------------

    _lookupInvoiceLocal(code) {
        const order = this._findLocalOrderByReference(code);
        if (!order) {
            return { success: false, error_code: "invoice_not_found", error: _t("Invoice not found.") };
        }
        if (!["paid", "done"].includes(order.state)) {
            return {
                success: false,
                error_code: "invoice_not_paid",
                error: _t("Invoice status must be paid before returning."),
            };
        }
        return {
            success: true,
            invoice: this._serializeLocalInvoice(order),
            products: this._serializeLocalInvoice(order).products,
        };
    }

    async _lookupProductInvoicesLocal({ barcode, productId, partnerId, searchTerm }) {
        let product = productId
            ? this.pos.models["product.product"].get(productId)
            : await this.findProductByBarcode(barcode);
        if (!product) {
            return {
                success: false,
                error_code: "product_not_found",
                error: _t("Product not found."),
            };
        }
        const partner = partnerId ? this.pos.models["res.partner"]?.get(partnerId) : null;
        const orders = this._searchLocalOrders({ product, partner, searchTerm });
        const invoices = orders
            .map((order) => {
                const line = this._findLocalOrderLine(order, product);
                if (!line) {
                    return null;
                }
                const qtyInfo = this._computeLocalQtyInfo(order, line);
                if (qtyInfo.remaining_qty <= 0) {
                    return null;
                }
                return {
                    order_id: order.id,
                    order_line_id: line.id,
                    invoice_number: order.pos_reference || order.name,
                    invoice_date: order.date_order,
                    customer: order.getPartner?.()?.name || _t("Walk-in Customer"),
                    customer_id: order.getPartner?.()?.id || false,
                    branch: order.config_id?.name || this.pos.config.name,
                    branch_id: order.config_id?.id || this.pos.config.id,
                    cashier: order.user_id?.name || "-",
                    qty_sold: qtyInfo.qty_sold,
                    qty_returned_prev: qtyInfo.qty_returned_prev,
                    remaining_qty: qtyInfo.remaining_qty,
                    total_amount: order.amount_total,
                    line_amount: this._lineAmountIncl(line),
                    product_id: product.id,
                };
            })
            .filter(Boolean);
        if (!invoices.length) {
            return {
                success: false,
                error_code: "invoice_not_found",
                error: _t("Invoice not found."),
                product: this._serializeLocalProduct(product),
            };
        }
        return {
            success: true,
            product: this._serializeLocalProduct(product),
            invoices,
        };
    }

    async _validateReturnLocal(context) {
        const settings = await this.getReturnSettings();
        const order = this.pos.models["pos.order"].get(context.orderId);
        const product = this.pos.models["product.product"].get(context.productId);
        const line = order?.lines?.find((l) => l.id === context.orderLineId);
        const returnQty = Number(context.returnQty) || 0;

        if (!order) {
            return { valid: false, error_code: "invoice_not_found", error: _t("Invoice not found.") };
        }
        if (!product) {
            return { valid: false, error_code: "product_not_found", error: _t("Product not found.") };
        }
        if (!line || line.product_id?.id !== product.id) {
            return {
                valid: false,
                error_code: "product_not_in_invoice",
                error: _t("Product does not belong to selected invoice."),
            };
        }
        if (!["paid", "done"].includes(order.state)) {
            return {
                valid: false,
                error_code: "invoice_not_paid",
                error: _t("Invoice status must be paid before returning."),
            };
        }
        if (settings.branch_specific_voucher && order.config_id?.id !== this.pos.config.id) {
            return { valid: false, error_code: "branch_mismatch", error: _t("Branch mismatch.") };
        }
        const qtyInfo = this._computeLocalQtyInfo(order, line);
        if (qtyInfo.remaining_qty <= 0) {
            return {
                valid: false,
                error_code: "fully_returned",
                error: _t("Product already fully returned."),
            };
        }
        if (returnQty <= 0) {
            return { valid: false, error_code: "invalid_qty", error: _t("Nothing to Return") };
        }
        if (returnQty > qtyInfo.remaining_qty) {
            return {
                valid: false,
                error_code: "qty_exceeds_remaining",
                error: _t("Return quantity exceeds remaining quantity."),
            };
        }
        const amounts = this._computeLocalRefundAmounts(line, returnQty);
        const daysSince = this._daysSinceSale(order);
        const periodExpired =
            settings.maximum_refund_days > 0 && daysSince > settings.maximum_refund_days;
        const reason = context.reasonId
            ? this.pos.models["pos.return.reason"]?.get(context.reasonId)
            : null;
        let approvalRequired = Boolean(reason?.requires_manager || settings.manager_approval);
        if (periodExpired) {
            approvalRequired = true;
        }
        if (settings.approval_amount > 0 && amounts.net_refund >= settings.approval_amount) {
            approvalRequired = true;
        }
        return {
            valid: true,
            approval_required: approvalRequired,
            approval_reasons: approvalRequired ? [_t("Manager approval required.")] : [],
            period_expired: periodExpired,
            days_since_sale: daysSince,
            max_return_days: settings.maximum_refund_days,
            invoice: this._serializeLocalInvoice(order),
            product: this._serializeLocalProduct(product),
            customer: this._serializeLocalPartner(order.getPartner?.()),
            order_line_id: line.id,
            qty_sold: qtyInfo.qty_sold,
            qty_returned_prev: qtyInfo.qty_returned_prev,
            remaining_qty: qtyInfo.remaining_qty,
            history: this._localReturnHistory(order, line),
            amounts,
            can_edit_refund_amount: this.canEditRefundAmount,
        };
    }

    _findLocalOrderByReference(code) {
        const needle = code.toLowerCase();
        const orders = this.pos.models["pos.order"]?.getAll?.() || [];
        return (
            orders.find((order) => {
                if (!["paid", "done"].includes(order.state)) {
                    return false;
                }
                const refs = [
                    order.pos_reference,
                    order.name,
                    order.tracking_number,
                ]
                    .filter(Boolean)
                    .map((v) => String(v).toLowerCase());
                return refs.some((ref) => ref === needle || ref.includes(needle));
            }) || null
        );
    }

    _searchLocalOrders({ product, partner, searchTerm }) {
        const term = (searchTerm || "").trim().toLowerCase();
        return (this.pos.models["pos.order"]?.getAll?.() || [])
            .filter((order) => {
                if (!["paid", "done"].includes(order.state) || order.amount_total < 0) {
                    return false;
                }
                if (partner && order.getPartner?.()?.id !== partner.id) {
                    return false;
                }
                if (term) {
                    const hay = [
                        order.pos_reference,
                        order.name,
                        order.getPartner?.()?.name,
                    ]
                        .filter(Boolean)
                        .join(" ")
                        .toLowerCase();
                    if (!hay.includes(term)) {
                        return false;
                    }
                }
                return Boolean(this._findLocalOrderLine(order, product));
            })
            .sort((a, b) => {
                const da = a.date_order?.toMillis?.() || 0;
                const db = b.date_order?.toMillis?.() || 0;
                return db - da;
            });
    }

    _findLocalOrderLine(order, product) {
        return (
            order.lines?.find(
                (line) => line.product_id?.id === product.id && (line.qty || 0) > 0
            ) || null
        );
    }

    _computeLocalQtyInfo(order, line) {
        const qtySold = Math.abs(line.qty || 0);
        let qtyReturnedPrev = 0;
        const orders = this.pos.models["pos.order"]?.getAll?.() || [];
        for (const refundOrder of orders) {
            if (refundOrder.refunded_order_id?.id !== order.id) {
                continue;
            }
            for (const rline of refundOrder.lines || []) {
                if (rline.product_id?.id === line.product_id?.id) {
                    qtyReturnedPrev += Math.abs(rline.qty || 0);
                }
            }
        }
        const remaining = Math.max(qtySold - qtyReturnedPrev, 0);
        return { qty_sold: qtySold, qty_returned_prev: qtyReturnedPrev, remaining_qty: remaining };
    }

    _computeLocalRefundAmounts(line, returnQty) {
        const qty = Math.abs(line.qty || 1);
        const unitIncl = this._lineAmountIncl(line) / qty;
        const unitExcl = (line.price_subtotal || line.price_unit * qty) / qty;
        const discount = (line.discount || 0) * (line.price_unit * returnQty) / 100;
        const netRefund = unitIncl * returnQty;
        const subtotal = unitExcl * returnQty;
        const tax = Math.max(netRefund - subtotal, 0);
        return {
            refund_amount: netRefund,
            subtotal,
            tax,
            discount,
            net_refund: netRefund,
        };
    }

    _lineAmountIncl(line) {
        if (line.priceIncl != null) {
            return line.priceIncl;
        }
        return (line.price_unit || 0) * Math.abs(line.qty || 1);
    }

    _serializeLocalInvoice(order) {
        const partner = order.getPartner?.();
        const products = (order.lines || [])
            .filter((line) => (line.qty || 0) > 0)
            .map((line) => {
                const qtyInfo = this._computeLocalQtyInfo(order, line);
                return {
                    ...this._serializeLocalProduct(line.product_id),
                    order_line_id: line.id,
                    qty_sold: qtyInfo.qty_sold,
                    qty_returned_prev: qtyInfo.qty_returned_prev,
                    remaining_qty: qtyInfo.remaining_qty,
                    sold_price: line.price_unit,
                    discount: line.discount || 0,
                    line_subtotal: this._lineAmountIncl(line),
                };
            });
        return {
            order_id: order.id,
            invoice_number: order.pos_reference || order.name,
            invoice_date: order.date_order,
            customer: this._serializeLocalPartner(partner),
            cashier: order.user_id?.name || "-",
            branch: order.config_id?.name || this.pos.config.name,
            branch_id: order.config_id?.id || this.pos.config.id,
            company_id: this.pos.company?.id,
            state: order.state,
            paid_amount: order.amount_paid,
            total_amount: order.amount_total,
            payment_method: (order.payment_ids || [])
                .map((p) => p.payment_method_id?.name)
                .filter(Boolean)
                .join(", ") || "-",
            products,
        };
    }

    _serializeLocalProduct(product) {
        if (!product) {
            return {};
        }
        return {
            id: product.id,
            name: product.display_name || product.name,
            default_code: product.default_code || "",
            barcode: product.barcode || "",
            size: "",
            color: "",
            variant: product.display_name || product.name,
        };
    }

    _serializeLocalPartner(partner) {
        if (!partner) {
            return { id: false, name: _t("Walk-in Customer"), ref: "", mobile: "", store_credit_balance: 0 };
        }
        return {
            id: partner.id,
            name: partner.name,
            ref: partner.ref || "",
            mobile: partner.mobile || partner.phone || "",
            loyalty_number: "",
            store_credit_balance: 0,
        };
    }

    _localReturnHistory(order, line) {
        const returns = [];
        const orders = this.pos.models["pos.order"]?.getAll?.() || [];
        for (const refundOrder of orders) {
            if (refundOrder.refunded_order_id?.id !== order.id) {
                continue;
            }
            for (const rline of refundOrder.lines || []) {
                if (rline.product_id?.id === line.product_id?.id) {
                    returns.push({
                        reference: refundOrder.pos_reference || refundOrder.name,
                        date: refundOrder.date_order,
                        qty: Math.abs(rline.qty || 0),
                        amount: this._lineAmountIncl(rline),
                        state: refundOrder.state,
                        refund_method: "pos_refund",
                    });
                }
            }
        }
        const qtyInfo = this._computeLocalQtyInfo(order, line);
        return {
            returns,
            exchanges: [],
            vouchers: [],
            ...qtyInfo,
        };
    }

    _daysSinceSale(order) {
        const date = order.date_order;
        if (!date) {
            return 0;
        }
        const ms = date.toMillis ? date.toMillis() : new Date(date).getTime();
        return Math.max(Math.floor((Date.now() - ms) / 86400000), 0);
    }
}
