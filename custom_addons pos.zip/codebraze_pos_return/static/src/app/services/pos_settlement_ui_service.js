/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { formatCurrency } from "@point_of_sale/app/models/utils/currency";

const OFFLINE_SETTLEMENT_KEY_PREFIX = "codebraze.settlement.queue.";

/**
 * Refund settlement service — separate from return confirmation.
 */
export class PosSettlementUiService {
    constructor(pos) {
        this.pos = pos;
    }

    get isOffline() {
        const network = this.pos.data?.network?.unsyncData;
        if (network && typeof network.hasConnection === "function") {
            return !network.hasConnection();
        }
        return typeof navigator !== "undefined" ? !navigator.onLine : false;
    }

    get cashierRole() {
        const role = this.pos.cashier?._role;
        if (role === "manager") {
            return "manager";
        }
        if (role === "supervisor") {
            return "supervisor";
        }
        return role === "minimal" ? "minimal" : "cashier";
    }

    formatMoney(amount) {
        return formatCurrency(amount || 0, this.pos.currency);
    }

    async getSettlementContext(returnId) {
        if (this.isOffline) {
            return this._getSettlementContextLocal(returnId);
        }
        try {
            return await this.pos.data.call(
                "pos.return.transaction",
                "pos_get_settlement_context",
                [returnId, this.pos.config.id, this.pos.session?.id || false]
            );
        } catch (error) {
            return { success: false, error: error?.message || _t("Unable to load settlement.") };
        }
    }

    buildSettlementPayload(state, returnId) {
        return {
            settlement_uuid: state.settlementUuid,
            return_id: returnId,
            refund_method: state.refundMethod,
            notes: state.notes,
            cashier_role: this.cashierRole,
            manager_approved: state.managerApproved,
            manager_id: state.managerId || false,
            approval_uuid: state.approvalUuid || false,
        };
    }

    async precheckSettlement(payload) {
        if (this.isOffline) {
            return this._precheckSettlementLocal(payload);
        }
        try {
            return await this.pos.data.call(
                "pos.return.transaction",
                "pos_precheck_settlement",
                [payload, this.pos.config.id, this.pos.session?.id || false]
            );
        } catch (error) {
            return { valid: false, error: error?.message || _t("Validation failed.") };
        }
    }

    async settleReturn(payload) {
        if (this.isOffline) {
            return this.queueOfflineSettlement(payload);
        }
        try {
            return await this.pos.data.call(
                "pos.return.transaction",
                "pos_settle_return",
                [payload, this.pos.config.id, this.pos.session?.id || false]
            );
        } catch (error) {
            return {
                success: false,
                error: error?.message || _t("Settlement failed."),
            };
        }
    }

    queueOfflineSettlement(payload) {
        const entry = {
            ...payload,
            offline: true,
            queued_at: new Date().toISOString(),
            sync_status: "pending",
        };
        const storageKey = `${OFFLINE_SETTLEMENT_KEY_PREFIX}${this.pos.config.id}`;
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(storageKey) || "[]");
        } catch {
            queue = [];
        }
        queue.push(entry);
        localStorage.setItem(storageKey, JSON.stringify(queue));
        return {
            success: true,
            offline: true,
            queued: true,
            settlement_state: "pending",
        };
    }

    async processOfflineSettlementQueue() {
        if (this.isOffline) {
            return;
        }
        const storageKey = `${OFFLINE_SETTLEMENT_KEY_PREFIX}${this.pos.config.id}`;
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(storageKey) || "[]");
        } catch {
            return;
        }
        const remaining = [];
        for (const entry of queue) {
            try {
                const result = await this.pos.data.call(
                    "pos.return.transaction",
                    "pos_settle_return",
                    [entry, this.pos.config.id, this.pos.session?.id || false]
                );
                if (
                    result?.success ||
                    result?.error_code === "already_settled" ||
                    result?.duplicate
                ) {
                    continue;
                }
                remaining.push(entry);
            } catch {
                remaining.push(entry);
            }
        }
        localStorage.setItem(storageKey, JSON.stringify(remaining));
    }

    _getSettlementContextLocal(returnId) {
        return {
            success: true,
            return_id: returnId,
            settlement_state: "pending",
            can_settle: true,
            default_refund_method: "voucher",
            enable_cash_refund: true,
            cash_refund_limit: 0,
        };
    }

    _precheckSettlementLocal(payload) {
        if (this.cashierRole === "minimal") {
            return { valid: false, error: _t("Permission denied.") };
        }
        return { valid: true, approval_required: false, approval_reasons: [] };
    }

    logSettlementCancelled(returnId) {
        if (this.isOffline) {
            return;
        }
        this.pos.data
            .call("pos.return.transaction", "pos_log_settlement_cancelled", [
                returnId,
                this.pos.config.id,
                this.pos.session?.id || false,
            ])
            .catch(() => {});
    }
}
