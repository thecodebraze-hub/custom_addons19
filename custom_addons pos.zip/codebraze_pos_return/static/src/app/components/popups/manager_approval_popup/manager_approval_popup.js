/** @odoo-module **/

export { ManagerApprovalPopup } from "@codebraze_pos_approval/app/components/popups/manager_approval_popup/manager_approval_popup";
