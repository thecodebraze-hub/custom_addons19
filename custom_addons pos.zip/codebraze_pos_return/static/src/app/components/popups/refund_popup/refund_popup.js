/** @odoo-module **/

import { Component, useState, useRef, onMounted } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";
import { makeAwaitable } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { useBarcodeReader } from "@point_of_sale/app/hooks/barcode_reader_hook";
import { InvoiceSelectionPopup } from "../invoice_selection_popup/invoice_selection_popup";

export class RefundPopup extends Component {
    static template = "codebraze_pos_return.RefundPopup";
    static components = { Dialog };
    static props = {
        pos: { type: Object },
        getPayload: { type: Function },
        close: { type: Function },
    };

    setup() {
        this.pos = this.props.pos;
        this.refundUi = this.pos.refundUi;
        this.barcodeInputRef = useRef("barcodeInput");
        this.state = useState({
            searchMode: "product",
            barcodeInput: "",
            loading: false,
            error: "",
            isOffline: this.refundUi.isOffline,
        });

        useBarcodeReader(
            {
                product: (parsed) => this.onHardwareBarcode(parsed),
                weight: (parsed) => this.onHardwareBarcode(parsed),
                quantity: (parsed) => this.onHardwareBarcode(parsed),
                price: (parsed) => this.onHardwareBarcode(parsed),
            },
            true
        );

        onMounted(async () => {
            this.barcodeInputRef.el?.focus();
            await this.refundUi.getReturnSettings();
        });
    }

    setSearchMode(mode) {
        this.state.searchMode = mode;
        this.state.error = "";
        this.state.barcodeInput = "";
        this.barcodeInputRef.el?.focus();
    }

    async onHardwareBarcode(parsed) {
        const code = parsed?.base_code || parsed?.code || "";
        this.state.barcodeInput = code;
        await this.applyBarcode(code);
    }

    async onBarcodeKeydown(ev) {
        if (ev.key !== "Enter") {
            return;
        }
        ev.preventDefault();
        await this.applyBarcode(this.state.barcodeInput);
    }

    async applyBarcode(raw) {
        this.state.error = "";
        const code = (raw || "").trim();
        if (!code) {
            this.state.error = _t("Barcode Invalid");
            return;
        }
        this.state.loading = true;
        try {
            if (this.state.searchMode === "invoice") {
                await this.lookupInvoice(code);
            } else {
                await this.lookupProduct(code);
            }
        } finally {
            this.state.loading = false;
        }
    }

    async lookupInvoice(code) {
        const result = await this.refundUi.lookupInvoiceByBarcode(code);
        if (!result?.success) {
            this.state.error = result?.error || _t("Invoice not found.");
            return;
        }
        const returnable = (result.products || []).filter((p) => (p.remaining_qty || 0) > 0);
        if (!returnable.length) {
            this.state.error = _t("Product already fully returned.");
            return;
        }
        this.proceedToConfirmation({ ...result.invoice, products: returnable });
    }

    async lookupProduct(code) {
        const product = await this.refundUi.findProductByBarcode(code);
        if (!product) {
            this.state.error = _t("Product not found.");
            return;
        }
        const result = await this.refundUi.lookupProductInvoices({
            barcode: code,
            productId: product.id,
        });
        if (!result?.success) {
            this.state.error = result?.error || _t("Invoice not found.");
            return;
        }
        const invoices = result.invoices || [];
        if (!invoices.length) {
            this.state.error = _t("Invoice not found.");
            return;
        }
        let invoiceRow = invoices[0];
        if (invoices.length > 1) {
            const selected = await makeAwaitable(this.pos.dialog, InvoiceSelectionPopup, {
                invoices,
                currency: this.pos.currency,
            });
            if (!selected) {
                this.state.error = _t("Invoice not found.");
                return;
            }
            invoiceRow = selected;
        }
        const lookup = await this.refundUi.lookupInvoiceByBarcode(invoiceRow.invoice_number);
        if (lookup?.success) {
            this.proceedToConfirmation(lookup.invoice);
            return;
        }
        this.state.error = _t("Invoice not found.");
    }

    proceedToConfirmation(invoice) {
        this.props.getPayload({
            action: "open_confirmation",
            invoice,
            order_id: invoice.order_id,
            partner_id: invoice.customer?.id || false,
        });
        this.props.close();
    }

    cancel() {
        this.props.close();
    }
}
