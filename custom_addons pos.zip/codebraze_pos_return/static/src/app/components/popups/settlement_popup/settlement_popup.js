/** @odoo-module **/

import { Component, useState, onMounted } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";
import { makeAwaitable } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { ManagerApprovalPopup } from "@codebraze_pos_approval/app/components/popups/manager_approval_popup/manager_approval_popup";

export class SettlementPopup extends Component {
    static template = "codebraze_pos_return.SettlementPopup";
    static components = { Dialog };
    static props = {
        pos: { type: Object },
        returnId: { type: Number },
        getPayload: { type: Function },
        close: { type: Function },
    };

    setup() {
        this.pos = this.props.pos;
        this.settlementUi = this.pos.settlementUi;
        this.state = useState({
            loading: true,
            error: "",
            context: null,
            refundMethod: "voucher",
            notes: "",
            managerApproved: false,
            managerId: false,
            approvalUuid: false,
            settlementUuid: crypto.randomUUID(),
            approvalRequired: false,
        });

        onMounted(() => this.loadContext());
    }

    get canShowCash() {
        return this.state.context?.enable_cash_refund !== false;
    }

    get formattedRefundAmount() {
        const amount = this.state.context?.refund_amount || 0;
        return this.settlementUi.formatMoney(amount);
    }

    get canConfirm() {
        return (
            this.state.context?.can_settle &&
            !this.state.loading &&
            !this.state.error &&
            (!this.state.approvalRequired || this.state.managerApproved)
        );
    }

    async loadContext() {
        this.state.loading = true;
        this.state.error = "";
        const ctx = await this.settlementUi.getSettlementContext(this.props.returnId);
        this.state.loading = false;
        if (!ctx?.success) {
            this.state.error = ctx?.error || _t("Unable to load settlement.");
            return;
        }
        if (!ctx.can_settle) {
            this.state.error = _t("This return has already been settled.");
            return;
        }
        this.state.context = ctx;
        this.state.refundMethod = ctx.default_refund_method || "voucher";
        if (!ctx.enable_cash_refund && this.state.refundMethod === "cash") {
            this.state.refundMethod = "voucher";
        }
    }

    async requestManagerApproval(reasons) {
        const result = await makeAwaitable(this.pos.dialog, ManagerApprovalPopup, {
            reasons,
            pos: this.pos,
            approvalType: "refund_approval",
            requiredLevel: "supervisor",
        });
        if (result?.approved) {
            this.state.managerApproved = true;
            this.state.managerId = result.manager_id;
            this.state.approvalUuid = result.approval_uuid || false;
            this.state.error = "";
            return true;
        }
        this.state.error = _t("Manager approval required.");
        return false;
    }

    cancel() {
        this.settlementUi.logSettlementCancelled(this.props.returnId);
        this.props.close();
    }

    async confirm() {
        if (this.pos.cashier?._role === "minimal") {
            this.state.error = _t("Permission Denied");
            return;
        }
        this.state.loading = true;
        this.state.error = "";
        try {
            const payload = this.settlementUi.buildSettlementPayload(
                this.state,
                this.props.returnId
            );
            const precheck = await this.settlementUi.precheckSettlement(payload);
            if (!precheck?.valid) {
                this.state.error = precheck?.error || _t("Validation failed.");
                return;
            }
            this.state.approvalRequired = Boolean(precheck.approval_required);
            if (this.state.approvalRequired && !this.state.managerApproved) {
                const approved = await this.requestManagerApproval(
                    precheck.approval_reasons || []
                );
                if (!approved) {
                    return;
                }
                payload.manager_approved = true;
                payload.manager_id = this.state.managerId;
                payload.approval_uuid = this.state.approvalUuid || false;
            }
            const result = await this.settlementUi.settleReturn(payload);
            if (!result?.success) {
                if (result?.error_code === "approval_required") {
                    await this.requestManagerApproval(result.approval_reasons || []);
                    return;
                }
                this.state.error = result?.error || _t("Settlement failed.");
                return;
            }
            this.props.getPayload({ action: "settlement_confirmed", result, payload });
            this.props.close();
        } finally {
            this.state.loading = false;
        }
    }
}
