/** @odoo-module **/

import { Component, useState, onMounted } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";
import { formatDateTime } from "@web/core/l10n/dates";
import { makeAwaitable } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { ManagerApprovalPopup } from "@codebraze_pos_approval/app/components/popups/manager_approval_popup/manager_approval_popup";

export class ReturnConfirmationPopup extends Component {
    static template = "codebraze_pos_return.ReturnConfirmationPopup";
    static components = { Dialog };
    static props = {
        pos: { type: Object },
        invoice: { type: Object },
        orderId: { type: Number },
        partnerId: { type: [Number, { value: false }], optional: true },
        getPayload: { type: Function },
        close: { type: Function },
    };

    setup() {
        this.pos = this.props.pos;
        this.refundUi = this.pos.refundUi;
        const reasons = this.refundUi.getReturnReasons();
        const defaultReasonId = reasons.length ? reasons[0].id : false;

        const lines = (this.props.invoice?.products || [])
            .filter((p) => (p.remaining_qty || 0) > 0)
            .map((p) => ({
                selected: false,
                order_line_id: p.order_line_id,
                product_id: p.id,
                name: p.name,
                variant: p.variant || p.name,
                barcode: p.barcode || "",
                qty_sold: p.qty_sold || 0,
                qty_returned_prev: p.qty_returned_prev || 0,
                remaining_qty: p.remaining_qty || 0,
                return_qty: p.remaining_qty || 1,
                unit_price: p.sold_price || 0,
                discount: p.discount || 0,
                line_subtotal: p.line_subtotal || 0,
                reason_id: defaultReasonId,
                note: "",
                refund_amount: 0,
            }));

        this.state = useState({
            lines,
            notes: "",
            error: "",
            warning: "",
            loading: false,
            approvalRequired: false,
            approvalReasons: [],
            managerApproved: false,
            managerId: false,
            approvalUuid: false,
            manualPriceAdjustment: false,
            clientUuid: crypto.randomUUID(),
        });

        onMounted(() => {
            this.recalculateSummary();
        });
    }

    get reasons() {
        return this.refundUi.getReturnReasons();
    }

    get selectedLines() {
        return this.state.lines.filter((l) => l.selected);
    }

    get summary() {
        let items = 0;
        let subtotal = 0;
        let tax = 0;
        let discount = 0;
        let net = 0;
        for (const line of this.selectedLines) {
            const amounts = this.refundUi.computeLineRefundAmounts(line);
            items += Number(line.return_qty) || 0;
            subtotal += amounts.subtotal;
            tax += amounts.tax;
            discount += amounts.discount;
            net += amounts.net_refund;
            line.refund_amount = amounts.net_refund;
        }
        return { items, subtotal, tax, discount, net };
    }

    formatDate(value) {
        if (!value) {
            return "—";
        }
        try {
            return formatDateTime(value, { format: "short" });
        } catch {
            return value;
        }
    }

    get canConfirm() {
        return (
            this.selectedLines.length > 0 &&
            !this.state.error &&
            !this.state.loading &&
            (!this.state.approvalRequired || this.state.managerApproved)
        );
    }

    clearMessages() {
        this.state.error = "";
        this.state.warning = "";
    }

    toggleLine(line) {
        line.selected = !line.selected;
        if (line.selected && !line.return_qty) {
            line.return_qty = line.remaining_qty || 1;
        }
        this.recalculateSummary();
    }

    toggleAll(ev) {
        const checked = ev.target.checked;
        for (const line of this.state.lines) {
            line.selected = checked;
            if (checked) {
                line.return_qty = line.remaining_qty || 1;
            }
        }
        this.recalculateSummary();
    }

    onReturnQtyChange(line, ev) {
        this.clearMessages();
        let qty = Number(ev.target.value);
        if (!Number.isFinite(qty) || qty <= 0) {
            qty = 1;
        }
        if (qty > line.remaining_qty) {
            qty = line.remaining_qty;
            this.state.error = _t("Return quantity exceeds remaining quantity.");
        }
        line.return_qty = qty;
        line.selected = qty > 0;
        this.recalculateSummary();
    }

    onReasonChange(line, ev) {
        line.reason_id = Number(ev.target.value) || false;
        this.recalculateSummary();
    }

    recalculateSummary() {
        // Trigger reactive summary getter
        this.summary;
    }

    buildPayload() {
        const summary = this.summary;
        return {
            client_uuid: this.state.clientUuid,
            order_id: this.props.orderId,
            partner_id: this.props.partnerId || this.props.invoice?.customer?.id || false,
            notes: this.state.notes,
            manager_approved: this.state.managerApproved,
            manager_id: this.state.managerId || false,
            approval_uuid: this.state.approvalUuid || false,
            manual_price_adjustment: this.state.manualPriceAdjustment,
            totals: summary,
            lines: this.selectedLines.map((line) => ({
                selected: true,
                order_line_id: line.order_line_id,
                product_id: line.product_id,
                return_qty: Number(line.return_qty),
                reason_id: line.reason_id,
                note: line.note,
            })),
        };
    }

    async requestManagerApproval(reasons) {
        const result = await makeAwaitable(this.pos.dialog, ManagerApprovalPopup, {
            reasons,
            pos: this.pos,
            approvalType: "return_approval",
            requiredLevel: "supervisor",
        });
        if (result?.approved) {
            this.state.managerApproved = true;
            this.state.managerId = result.manager_id;
            this.state.approvalUuid = result.approval_uuid || false;
            this.clearMessages();
            return true;
        }
        this.state.error = _t("Manager approval required.");
        return false;
    }

    async confirm() {
        if (this.pos.cashier?._role === "minimal") {
            this.state.error = _t("Permission Denied");
            return;
        }
        if (!this.selectedLines.length) {
            this.state.error = _t("Select at least one product to return.");
            return;
        }
        for (const line of this.selectedLines) {
            if (!line.reason_id) {
                this.state.error = _t("Select a return reason for each product.");
                return;
            }
        }

        this.state.loading = true;
        this.clearMessages();
        try {
            const payload = this.buildPayload();
            const precheck = await this.refundUi.precheckReturnConfirmation(payload);
            if (!precheck?.valid && precheck?.error_code !== "approval_required") {
                this.state.error = precheck?.error || _t("Validation failed.");
                return;
            }
            this.state.approvalRequired = Boolean(precheck?.approval_required);
            this.state.approvalReasons = precheck?.approval_reasons || [];

            if (this.state.approvalRequired && !this.state.managerApproved) {
                const approved = await this.requestManagerApproval(this.state.approvalReasons);
                if (!approved) {
                    return;
                }
                payload.manager_approved = true;
                payload.manager_id = this.state.managerId;
            }

            const result = await this.refundUi.confirmReturn(payload);
            if (!result?.success) {
                if (result?.error_code === "approval_required") {
                    this.state.approvalRequired = true;
                    this.state.approvalReasons = result.approval_reasons || [];
                    await this.requestManagerApproval(this.state.approvalReasons);
                    return;
                }
                this.state.error = result?.error || _t("Return confirmation failed.");
                return;
            }
            this.props.getPayload({ action: "return_confirmed", result, payload });
            this.props.close();
        } finally {
            this.state.loading = false;
        }
    }

    cancel() {
        this.props.close();
    }
}
