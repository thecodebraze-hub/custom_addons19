/** @odoo-module **/

import { Component, useState } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";
import { formatDateTime } from "@web/core/l10n/dates";
import { formatCurrency } from "@point_of_sale/app/models/utils/currency";

export class InvoiceSelectionPopup extends Component {
    static template = "codebraze_pos_return.InvoiceSelectionPopup";
    static components = { Dialog };
    static props = {
        invoices: { type: Array },
        currency: { type: Object, optional: true },
        getPayload: { type: Function },
        close: { type: Function },
    };

    setup() {
        this.state = useState({
            search: "",
        });
    }

    get filteredInvoices() {
        const needle = (this.state.search || "").trim().toLowerCase();
        let rows = [...(this.props.invoices || [])];
        if (needle) {
            rows = rows.filter(
                (row) =>
                    (row.invoice_number || "").toLowerCase().includes(needle) ||
                    (row.customer || "").toLowerCase().includes(needle)
            );
        }
        return rows.sort((a, b) => {
            const da = a.invoice_date || "";
            const db = b.invoice_date || "";
            return db > da ? 1 : db < da ? -1 : 0;
        });
    }

    formatDate(value) {
        if (!value) {
            return "";
        }
        try {
            return formatDateTime(value, { format: "short" });
        } catch {
            return value;
        }
    }

    formatMoney(amount) {
        if (!this.props.currency) {
            return amount;
        }
        return formatCurrency(amount || 0, this.props.currency);
    }

    selectInvoice(invoice) {
        this.props.getPayload(invoice);
        this.props.close();
    }
}
