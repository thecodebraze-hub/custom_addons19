# -*- coding: utf-8 -*-

def post_init_hook(env):
    """Create reporting performance indexes (idempotent)."""
    cr = env.cr
    statements = [
        """
        CREATE INDEX IF NOT EXISTS store_credit_remaining_active_idx
          ON store_credit (company_id, state, amount_remaining)
          WHERE amount_remaining > 0
        """,
        """
        CREATE INDEX IF NOT EXISTS store_credit_partner_issue_idx
          ON store_credit (partner_id, issue_date)
        """,
        """
        CREATE INDEX IF NOT EXISTS store_credit_payment_create_idx
          ON store_credit_payment (credit_id, create_date)
        """,
        """
        CREATE INDEX IF NOT EXISTS pos_return_txn_return_date_idx
          ON pos_return_transaction (company_id, return_date)
        """,
    ]
    for stmt in statements:
        cr.execute(stmt)
