# CodeBraze POS — Reporting & Analytics Framework Design

**Version:** 1.0  
**Target:** Odoo 19 Enterprise  
**Scope:** Return & Store Credit ecosystem  
**Status:** Design only — no implementation in this phase  

---

## 1. Purpose & Constraints

### 1.1 Objective

Define a **reusable reporting and analytics framework** for the entire Return & Store Credit ecosystem. The framework must support interactive backend reports, pivot/graph views, dashboards, PDF/Excel/CSV exports, and scheduled email delivery.

### 1.2 Hard Constraints

| Constraint | Implication |
|------------|-------------|
| Business logic is complete | Reports are **read-only consumers** of existing models and services |
| Do not modify workflows | No changes to `store.credit`, return confirm/settlement, approval engine, or accounting posting |
| No POS UI | Backend + optional spreadsheet dashboard only |
| Large datasets | Design for aggregation-first, drill-down-second |

### 1.3 Recommended Module

**`codebraze_pos_reporting`** — new installable module depending on:

```
codebraze_pos_administration  (umbrella — implies full stack)
```

Optional direct depends for lighter installs: `codebraze_pos_store_credit`, `codebraze_pos_return`, `codebraze_pos_approval`, `codebraze_pos_store_credit_accounting`.

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        Presentation Layer                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ │
│  │ Tree / Pivot │  │ Graph / Cal  │  │  Dashboard   │  │   Wizards   │ │
│  │   / Search   │  │    Views     │  │   (Spread)   │  │  (filters)  │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬──────┘ │
└─────────┼─────────────────┼─────────────────┼─────────────────┼─────────┘
          │                 │                 │                 │
┌─────────▼─────────────────▼─────────────────▼─────────────────▼─────────┐
│                     Report Orchestration Layer                             │
│  ┌─────────────────────────────────────────────────────────────────────┐ │
│  │              pos.report.service  (AbstractModel)                     │ │
│  │  resolve_context() · build_domain() · read_group() · get_kpi()       │ │
│  └─────────────────────────────────────────────────────────────────────┘ │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │ pos.report   │  │ pos.report   │  │ pos.report   │  │ pos.report   │ │
│  │ .filter      │  │ .export      │  │ .print       │  │ .dashboard   │ │
│  │ .service     │  │ .service     │  │ .service     │  │ .service     │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘ │
└─────────┬─────────────────┬─────────────────┬─────────────────┬─────────┘
          │                 │                 │                 │
┌─────────▼─────────────────▼─────────────────▼─────────────────▼─────────┐
│                       Data Provider Layer                                  │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  Source models (existing — never duplicated)                        │  │
│  │  store.credit · store.credit.transaction · store.credit.payment      │  │
│  │  store.credit.audit · pos.return.transaction · pos.exchange.*      │  │
│  │  pos.return.voucher · pos.approval.history · account.move           │  │
│  └────────────────────────────────────────────────────────────────────┘  │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  Optional SQL views (read-only, reporting-only)                     │  │
│  │  pos.report.return.summary · pos.report.credit.liability · …        │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
          │
┌─────────▼─────────────────────────────────────────────────────────────────┐
│  Security: record rules + report groups mapped to SC admin tiers           │
│  Scheduling: ir.cron → pos.report.schedule → mail + attachment           │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Framework Components

### 3.1 Report Base Classes

#### `pos.report.mixin` (AbstractModel)

Shared behaviour for all report wizards and services.

| Method | Responsibility |
|--------|----------------|
| `_report_company_ids()` | Resolve allowed companies from user + role |
| `_report_branch_ids()` | Resolve allowed `pos.config` IDs |
| `_report_date_range(preset)` | Map daily/weekly/monthly presets to datetimes |
| `_report_base_domain(model)` | Apply security domain before user filters |
| `_report_read_group(model, domain, fields, groupby)` | Wrapper with limits and caching hook |
| `_report_format_currency(amount, currency)` | Consistent monetary display |

#### `pos.report.definition` (Model — configuration registry)

Lightweight registry row per report (not business data).

| Field | Purpose |
|-------|---------|
| `code` | Stable identifier, e.g. `returns.summary` |
| `name` | Display name |
| `category` | Selection matching report groups (§4) |
| `source_model` | Primary Odoo model |
| `sql_view_model` | Optional denormalized model |
| `default_groupby` | e.g. `config_id`, `cashier_id` |
| `allowed_view_modes` | tree, pivot, graph, calendar |
| `export_formats` | pdf, xlsx, csv |
| `min_group` | Minimum security group |
| `active` | Enable/disable |

Individual reports inherit behaviour via **report-specific provider classes** (AbstractModels), not by overriding business models.

#### Report Provider Pattern

```text
pos.report.provider.returns        → pos.return.transaction
pos.report.provider.exchanges      → pos.exchange.transaction
pos.report.provider.store_credit   → store.credit
pos.report.provider.redemptions    → store.credit.payment
pos.report.provider.outstanding    → store.credit (filtered)
pos.report.provider.expired        → store.credit (filtered)
pos.report.provider.accounting     → account.move
pos.report.provider.cashier        → cross-model aggregation
pos.report.provider.branch         → cross-model aggregation
pos.report.provider.customer       → res.partner + store.credit
pos.report.provider.approvals      → pos.approval.history
```

Each provider implements:

- `get_domain(filters)` → Odoo domain list  
- `get_measures()` → pivot measures (sum, count, avg)  
- `get_dimensions()` → groupby fields  
- `get_tree_fields()` → list view columns  
- `get_graph_config()` → graph type + axes  
- `get_kpis(filters)` → dashboard widget values  

---

### 3.2 Shared Filters

#### `pos.report.filter` (TransientModel — wizard base)

Single filter wizard reused across reports; persisted in `ir.actions.act_window` context.

| Field | Type | Maps to |
|-------|------|---------|
| `company_ids` | Many2many `res.company` | `company_id` |
| `config_ids` | Many2many `pos.config` | `config_id` (branch) |
| `session_ids` | Many2many `pos.session` | `session_id` (POS) |
| `cashier_ids` | Many2many `res.users` | `cashier_id` / `user_id` |
| `partner_ids` | Many2many `res.partner` | `partner_id` |
| `date_from` / `date_to` | Datetime | context-dependent date field |
| `date_preset` | Selection | today, yesterday, this_week, last_week, this_month, last_month, this_quarter, this_year, custom |
| `state_ids` | Char (serialized) | model-specific states |
| `credit_type` | Selection | `store.credit.credit_type` |
| `voucher_type` | Selection | voucher / credit classification |
| `return_reason_ids` | Many2many `pos.return.reason` | line-level join for returns |
| `refund_method` | Selection | return settlement |
| `settlement_state` | Selection | return settlement |
| `approval_state` | Selection | approval reports |
| `include_archived` | Boolean | `active` test |

#### Filter Service — `pos.report.filter.service`

| Method | Purpose |
|--------|---------|
| `apply(model, filters, date_field='create_date')` | Returns merged domain |
| `validate(filters)` | Enforce branch/company scope per user role |
| `to_context(filters)` | Serialize for scheduled jobs |
| `from_context(ctx)` | Deserialize cron payload |

#### Date Field Resolution (per report category)

| Category | Primary date field |
|----------|-------------------|
| Returns | `pos.return.transaction.create_date` or `settlement_date` |
| Exchanges | `pos.exchange.transaction.create_date` |
| Store Credits | `store.credit.issue_date` |
| Redemptions | `store.credit.payment.create_date` |
| Outstanding / Expired | `store.credit.issue_date` + `expiry_date` |
| Accounting | `account.move.date` |
| Approvals | `pos.approval.history.create_date` / `approve_datetime` |
| Cashier / Branch KPIs | configurable per widget |

---

### 3.3 Export Services

#### `pos.report.export.service` (AbstractModel)

| Method | Output |
|--------|--------|
| `export_csv(provider, filters, fields)` | `ir.attachment` + download URL |
| `export_xlsx(provider, filters, fields)` | openpyxl / xlsxwriter workbook |
| `export_pdf(provider, filters, template)` | QWeb → PDF via `ir.actions.report` |
| `export_from_read_group(...)` | Aggregated pivot data → flat table |

**Design rules:**

- Export always runs through the same `build_domain()` + security layer as on-screen reports  
- Row limit: configurable via `store.credit.settings` / `pos.report.config` (default 50 000 detail rows)  
- Aggregated exports have no row cap  
- File naming: `{report_code}_{branch}_{date_from}_{date_to}.{ext}`  

#### `pos.report.print.service` (AbstractModel)

Thin wrapper over `ir.actions.report` for PDF.

| Report code | Template type |
|-------------|---------------|
| `customer.statement` | QWeb PDF — partner summary + credit lines |
| `store.credit.liability` | QWeb PDF — outstanding summary |
| `returns.summary` | QWeb PDF — optional; pivot preferred |
| `voucher.register` | QWeb PDF — voucher listing |

Registers reports in XML; templates live under `codebraze_pos_reporting/report/`.

---

### 3.4 Dashboard Services

#### `pos.report.dashboard.service` (AbstractModel)

| Method | Purpose |
|--------|---------|
| `get_widget(code, filters)` | Return `{value, comparison, trend, sparkline}` |
| `get_all_widgets(board_code, filters)` | Batch KPI fetch for dashboard load |
| `compare_period(filters, metric)` | Prior-period delta for KPI cards |

#### KPI Widget Registry

| Widget code | Data source | Aggregation |
|-------------|-------------|-------------|
| `kpi.returns.today` | `pos.return.transaction` | count, sum `amount_total` |
| `kpi.refund.today` | `pos.return.transaction` | sum where `settlement_state=done` |
| `kpi.credit.outstanding` | `store.credit` | sum `amount_remaining` where active states |
| `kpi.credit.expired` | `store.credit` | sum `amount_remaining` where `state=expired` |
| `kpi.approvals.pending` | `pos.approval.history` | count `state in (pending, requested)` |
| `kpi.liability.total` | `store.credit` or `account.move` | liability account balance via accounting module |
| `kpi.top.cashiers` | multi-model | read_group by `cashier_id` limit 10 |
| `kpi.top.branches` | multi-model | read_group by `config_id` limit 10 |
| `kpi.returns.trend.monthly` | `pos.return.transaction` | read_group by month, 12 periods |
| `kpi.redemptions.today` | `store.credit.payment` | count + sum |

#### Dashboard Delivery Options (Odoo 19)

1. **Spreadsheet dashboard** — Odoo Enterprise `spreadsheet.dashboard` boards per role  
2. **Backend kanban home** — `pos.report.dashboard` model with embedded JSON metrics (fallback)  
3. **Client action** — OWL dashboard consuming `pos.report.dashboard.service` JSON-RPC  

**Recommendation:** Primary = Spreadsheet dashboards for managers; secondary = backend menu dashboards for supervisors.

---

### 3.5 Data Providers

#### Tier 1 — Direct Model Queries (default)

Use existing models with `read_group`, `search_read`, and list/pivot/graph views. No data duplication.

#### Tier 2 — SQL Views (performance-critical reports only)

Read-only models (`_auto = False`) for heavy cross joins:

| SQL View Model | Purpose | Key joins |
|----------------|---------|-----------|
| `pos.report.return.summary` | Return + settlement + credit | `pos.return.transaction` LEFT JOIN `store.credit` |
| `pos.report.credit.liability` | Outstanding snapshot | `store.credit` WHERE `amount_remaining > 0` |
| `pos.report.redemption.summary` | Payment + order + credit | `store.credit.payment` JOIN `pos.order` |
| `pos.report.cashier.performance` | Unified cashier metrics | UNION of return + redeem + issue counts |
| `pos.report.branch.performance` | Branch-level rollup | GROUP BY `config_id` across sources |

**Refresh strategy:** Views are live SQL (no materialization) unless row counts exceed threshold; then optional nightly materialized table via cron.

#### Tier 3 — Existing Timeline (drill-down only)

`store.credit.timeline` — use for **single-credit drill-down**, not aggregate reporting.

---

## 4. Report Categories & Catalog

### 4.1 Menu Structure

```text
Point of Sale
└── Return Management
    └── Reports & Analytics          [group_sc_supervisor+]
        ├── Dashboard
        ├── Returns
        ├── Exchanges
        ├── Store Credits
        ├── Voucher Redemptions
        ├── Outstanding Credits
        ├── Expired Credits
        ├── Accounting
        ├── Cashier Performance
        ├── Branch Performance
        ├── Customer Statements
        └── Scheduled Reports
```

### 4.2 Report Catalog

| # | Report Group | Report Code | Source | Primary Views | Export |
|---|--------------|-------------|--------|---------------|--------|
| R01 | Returns | `returns.detail` | `pos.return.transaction` | tree, pivot, graph | xlsx, csv, pdf |
| R02 | Returns | `returns.by_reason` | `pos.return.transaction.line` | pivot, graph | xlsx, csv |
| R03 | Returns | `returns.settlement` | `pos.return.transaction` | tree, pivot | xlsx, csv |
| R04 | Exchanges | `exchanges.detail` | `pos.exchange.transaction` | tree, pivot, graph | xlsx, csv |
| R05 | Exchanges | `exchanges.difference` | `pos.exchange.transaction` | pivot | xlsx |
| R06 | Store Credits | `credits.issued` | `store.credit` | tree, pivot, graph, calendar | xlsx, csv, pdf |
| R07 | Store Credits | `credits.adjustments` | `store.credit.audit` | tree, pivot | xlsx, csv |
| R08 | Voucher Redemptions | `redemptions.detail` | `store.credit.payment` | tree, pivot, graph | xlsx, csv |
| R09 | Voucher Redemptions | `redemptions.by_voucher` | `store.credit.payment` + voucher | pivot | xlsx |
| O01 | Outstanding Credits | `credits.outstanding` | `store.credit` | tree, pivot | xlsx, csv, pdf |
| O02 | Outstanding Credits | `credits.outstanding.by_branch` | SQL view or read_group | pivot, graph | xlsx, pdf |
| E01 | Expired Credits | `credits.expired` | `store.credit` | tree, pivot, calendar | xlsx, csv |
| E02 | Expired Credits | `credits.expiry.forecast` | `store.credit` | graph (by expiry_date) | xlsx |
| A01 | Accounting | `accounting.credit_moves` | `account.move` | tree, pivot | xlsx, csv |
| A02 | Accounting | `accounting.liability` | `account.move` + liability account | pivot, graph | xlsx, pdf |
| A03 | Accounting | `accounting.unreconciled` | `pos.payment` + `accounting_state` | tree | xlsx |
| C01 | Cashier Performance | `cashier.summary` | SQL view / multi read_group | pivot, graph | xlsx, pdf |
| C02 | Cashier Performance | `cashier.returns` | `pos.return.transaction` | pivot | xlsx |
| C03 | Cashier Performance | `cashier.redemptions` | `store.credit.payment` | pivot | xlsx |
| B01 | Branch Performance | `branch.summary` | SQL view / multi read_group | pivot, graph | xlsx, pdf |
| B02 | Branch Performance | `branch.liability` | `store.credit` | pivot | xlsx, pdf |
| S01 | Customer Statements | `customer.statement` | `res.partner` + credits + payments | form + pdf | pdf, xlsx |
| S02 | Customer Statements | `customer.credit.history` | `store.credit` + timeline | tree | xlsx, pdf |
| P01 | Approvals | `approvals.pending` | `pos.approval.history` | tree, pivot | xlsx, csv |

---

## 5. Common Outputs

### 5.1 View Mode Strategy

| View | Use case | Implementation |
|------|----------|----------------|
| **Tree** | Detail drill-down, export source | `ir.ui.view` list on source or SQL model |
| **Pivot** | Branch/cashier/product analysis | Native Odoo pivot on source model |
| **Graph** | Trends, comparisons | bar (counts), line (trends), pie (share) |
| **Calendar** | Issue/expiry/settlement dates | `store.credit.issue_date`, `expiry_date`, `settlement_date` |
| **Form** | Customer statement single partner | `res.partner` profile extension |

### 5.2 Action Pattern

Each report = `ir.actions.act_window` with:

```python
{
    "type": "ir.actions.act_window",
    "res_model": "<source_model>",
    "view_mode": "pivot,graph,tree",
    "domain": "<from filter service>",
    "context": {
        "report_code": "returns.detail",
        "search_default_<filter>": 1,
        "pivot_measures": ["amount_total"],
        "pivot_row_groupby": ["config_id"],
    },
}
```

Plus bound server actions: **Export Excel**, **Export CSV**, **Print PDF**.

---

## 6. Dashboard Architecture

### 6.1 Role-Based Boards

| Board | Audience | Widgets |
|-------|----------|---------|
| `dashboard.supervisor` | Supervisor | today returns, pending approvals, branch outstanding |
| `dashboard.manager` | Manager | all KPIs + top cashiers/branches + monthly trend |
| `dashboard.administrator` | Administrator | multi-company liability, accounting reconciliation, expired forecast |
| `dashboard.cashier` | Cashier | own returns today, own redemptions (read-only) |

### 6.2 Widget Data Contract

```json
{
  "code": "kpi.returns.today",
  "title": "Today's Returns",
  "value": 42,
  "formatted_value": "42",
  "sub_value": 125000.00,
  "formatted_sub_value": "₹ 125,000.00",
  "comparison": {
    "period": "yesterday",
    "delta": 5,
    "delta_pct": 13.5,
    "direction": "up"
  },
  "sparkline": [12, 15, 8, 22, 42],
  "drilldown_action": "ir.actions.act_window,...",
  "last_refresh": "2026-07-09T08:00:00Z"
}
```

### 6.3 Layout

```text
┌────────────────────────────────────────────────────────────┐
│  [Filter bar: Company | Branch | Date preset | Apply]      │
├────────────┬────────────┬────────────┬─────────────────────┤
│  Returns   │  Refunds   │ Outstanding│  Pending Approvals  │
│  Today     │  Today     │  Credit    │                     │
├────────────┴────────────┴────────────┴─────────────────────┤
│  Monthly Return Trend (line chart)                          │
├────────────────────────────┬───────────────────────────────┤
│  Top Cashiers (bar)        │  Top Branches (bar)           │
├────────────────────────────┴───────────────────────────────┤
│  Store Credit Liability (gauge / KPI + pivot link)         │
└────────────────────────────────────────────────────────────┘
```

---

## 7. Data Flow

### 7.1 Interactive Report Flow

```text
User opens report menu
        │
        ▼
Filter wizard (optional) / search view defaults
        │
        ▼
pos.report.filter.service.validate()
  ├── merges role-based domain (company, branch, cashier)
  └── merges user-selected filters
        │
        ▼
pos.report.provider.<category>.get_domain()
        │
        ├──► Tree/Pivot/Graph view (Odoo ORM read_group / search_read)
        │
        └──► Export/Print service (same domain, no bypass)
```

### 7.2 Dashboard Flow

```text
Dashboard load
        │
        ▼
pos.report.dashboard.service.get_all_widgets(board, filters)
        │
        ├── parallel read_group calls (batched by model)
        └── optional @ormcache per (widget, filters_hash, company) TTL 5 min
        │
        ▼
JSON → Spreadsheet dashboard / OWL client action
```

### 7.3 Scheduled Report Flow

```text
ir.cron (daily/weekly/monthly/…)
        │
        ▼
pos.report.schedule (model)
  ├── report_code
  ├── filters (JSON)
  ├── format (pdf | xlsx | csv)
  ├── recipient_partner_ids / group_ids
  └── last_run / next_run
        │
        ▼
pos.report.export.service.export_*()
        │
        ▼
mail.mail + ir.attachment
  ├── subject: "[Report] Returns Summary — Branch X — Jul 2026"
  └── body: summary KPIs + attachment
```

### 7.4 Accounting Report Flow

```text
pos.report.provider.accounting
        │
        ├── domain on account.move (store_credit_id != False)
        ├── join store.credit.settings for liability account
        └── reconcile with pos.payment.accounting_state for unreconciled report
        │
        ▼
Never calls posting services — read-only account.move queries
```

---

## 8. Security Design

### 8.1 Report Groups (new — map to existing SC groups)

| Report Group XML ID | Implies | Data scope |
|---------------------|---------|------------|
| `group_report_cashier` | `group_sc_cashier` | Own `cashier_id` only |
| `group_report_supervisor` | `group_sc_supervisor` | Own branch (`config_id` in user's allowed branches) |
| `group_report_manager` | `group_sc_manager` | All branches in user's companies |
| `group_report_administrator` | `group_sc_administrator` | All companies in `company_ids` |

### 8.2 Domain Injection (mandatory)

Every report action must prepend domains from `pos.report.filter.service._report_base_domain()`:

| Role | Domain fragment |
|------|-----------------|
| Cashier | `[('cashier_id', '=', uid)]` |
| Supervisor | `[('config_id', 'in', user_branch_ids)]` |
| Manager | `[('company_id', 'in', company_ids)]` |
| Administrator | `[('company_id', 'in', company_ids)]` (all assigned companies) |

**Branch resolution:** user's `pos.config` access via existing config records; fallback to session history if needed.

### 8.3 Record Rules

Extend `codebraze_pos_administration/security/ir_rule.xml` with parallel rules on:

- SQL view models (same domains as source tables)
- `pos.report.schedule` (managers create schedules for own branch; admins for all)

### 8.4 Export & Schedule Permissions

| Action | Minimum group |
|--------|---------------|
| View reports | `group_report_cashier` |
| Pivot / graph | `group_report_supervisor` |
| Export CSV | `group_report_supervisor` |
| Export Excel / PDF | `group_report_manager` |
| Schedule reports | `group_report_manager` |
| Cross-company dashboard | `group_report_administrator` |
| Customer statements (any customer) | `group_report_manager` |
| Customer statements (own branch customers) | `group_report_supervisor` |

### 8.5 Multi-Company

- All report models include `company_id` in domain  
- Pivot `company_id` groupby only visible with `base.group_multi_company`  
- Scheduled reports run as `report_scheduler_user` (dedicated system user per company or sudo with domain)

---

## 9. Performance Strategy

### 9.1 Principles

1. **Aggregate first** — dashboards and summary reports use `read_group` only  
2. **Detail on demand** — tree views paginated (Odoo default 80/page)  
3. **No N+1** — batch `read_group` for dashboard widgets  
4. **Index-backed filters** — rely on existing indexed fields (`company_id`, `config_id`, `state`, `create_date`, `cashier_id`, `partner_id`)  
5. **SQL views only when** cross-model joins exceed 3 tables or p95 latency > 2s  

### 9.2 Existing Indexes (leverage)

| Model | Indexed fields |
|-------|----------------|
| `store.credit` | `company_id`, `config_id`, `partner_id`, `state`, `issue_date`, `expiry_date`, `cashier_id`, `barcode` |
| `pos.return.transaction` | `company_id`, `config_id`, `state`, `settlement_state`, `cashier_id`, `create_date` |
| `store.credit.payment` | `credit_id`, `pos_order_id`, `cashier_id`, `config_id`, `create_date` |
| `pos.approval.history` | `state`, `approval_type`, `config_id`, `create_date` |

### 9.3 Recommended Additional Indexes (reporting module migration)

```sql
-- Only if explain analyze shows seq scans at scale
CREATE INDEX IF NOT EXISTS store_credit_remaining_active_idx
  ON store_credit (company_id, state, amount_remaining)
  WHERE amount_remaining > 0;

CREATE INDEX IF NOT EXISTS pos_return_settlement_date_idx
  ON pos_return_transaction (settlement_date, settlement_state)
  WHERE settlement_state = 'done';
```

### 9.4 Query Limits

| Operation | Limit |
|-----------|-------|
| `search_read` detail export | 50 000 rows (configurable) |
| Dashboard `read_group` | 10 000 source rows implicit via date filter |
| `read_group` groups | max 500 groups; warn if exceeded |
| Cron report | aggregated preferred; detail max 100 000 |

### 9.5 Caching

| Layer | TTL | Key |
|-------|-----|-----|
| `@ormcache` on KPI widgets | 5 min | `(widget_code, company_id, date_preset)` |
| Dashboard board snapshot | 15 min | optional for spreadsheet |
| Invalidation | on write | **none** (reports are read-only; stale 5 min acceptable) |

### 9.6 Lazy Loading

- Dashboard: load KPI cards first, charts async via second RPC  
- Tree reports: standard Odoo pagination  
- Customer statement: load summary header, lines on tab click  

---

## 10. Export Strategy

### 10.1 Format Selection Guide

| Format | Engine | Best for |
|--------|--------|----------|
| **CSV** | `csv` module | Large detail exports, integrations |
| **Excel** | `xlsxwriter` | Formatted pivot exports, customer statements |
| **PDF** | QWeb + wkhtmltopdf / Odoo 19 report engine | Statements, liability summaries, scheduled mgmt reports |

### 10.2 Export Pipeline

```text
export_request(report_code, format, filters)
    → validate permissions
    → build_domain (same as screen)
    → if pivot_export: read_group → flatten
    → if detail_export: search_read (batched 1000)
    → generate file
    → ir.attachment (optional mail)
    → return download action
```

### 10.3 Excel Structure (standard)

- Sheet 1: **Summary** — filters applied, KPI totals, generation timestamp  
- Sheet 2: **Data** — column headers + rows  
- Sheet 3: **Pivot** (optional) — pre-built pivot for manager reports  

### 10.4 PDF Structure (standard)

- Header: company logo, branch, date range  
- Footer: page number, generated by, timestamp  
- Body: provider-specific QWeb template  

### 10.5 Scheduled Export Attachment Limits

- Max attachment size: 10 MB (configurable)  
- If exceeded: send link to stored `ir.attachment` + email summary only  
- Retention: auto-delete attachments older than 90 days via cron  

---

## 11. Scheduled Reports

### 11.1 Model — `pos.report.schedule`

| Field | Type | Notes |
|-------|------|-------|
| `name` | Char | e.g. "Daily Outstanding Credits — Main Store" |
| `report_code` | Char | links to `pos.report.definition` |
| `interval` | Selection | daily, weekly, monthly, quarterly, yearly |
| `interval_count` | Integer | default 1 |
| `next_run` | Datetime | computed |
| `filter_json` | Text | serialized `pos.report.filter` |
| `export_format` | Selection | pdf, xlsx, csv |
| `recipient_user_ids` | Many2many | direct recipients |
| `recipient_group_id` | Many2one | optional group expansion |
| `company_id` | Many2one | required |
| `config_id` | Many2one | optional branch scope |
| `active` | Boolean | |
| `last_run` | Datetime | |
| `last_status` | Selection | success, failed, skipped |

### 11.2 Cron Matrix

| Interval | Typical cron | Example reports |
|----------|--------------|-----------------|
| Daily | 06:00 local | outstanding credits, pending approvals, yesterday returns |
| Weekly | Monday 07:00 | branch performance, cashier summary |
| Monthly | 1st 08:00 | liability PDF, expired forecast, accounting reconciliation |
| Quarterly | 1st Jan/Apr/Jul/Oct | management pack |
| Yearly | Jan 1 | annual return + credit summary |

### 11.3 Email Template

- `mail.template` per report category  
- Placeholders: `{{ summary_kpis }}`, `{{ date_range }}`, `{{ branch_name }}`  
- Attachment via `report_schedule_id.generate_attachment()`  

---

## 12. Implementation Phases (for future prompts)

| Phase | Deliverable | Depends on |
|-------|-------------|------------|
| **R-01** | Module skeleton, filter wizard, security groups, menu | This design |
| **R-02** | Returns + Exchanges reports (tree/pivot/graph) | R-01 |
| **R-03** | Store credit + redemption + outstanding + expired | R-01 |
| **R-04** | Accounting + liability reports | R-01, accounting module |
| **R-05** | Cashier + branch performance (SQL view) | R-01 |
| **R-06** | Customer statement PDF + Excel | R-01 |
| **R-07** | Export services (CSV, XLSX, PDF) | R-02–R-06 |
| **R-08** | Dashboard boards + KPI widgets | R-02–R-06 |
| **R-09** | Scheduled reports + email | R-07 |
| **R-10** | Performance indexes + SQL views | R-05, R-08 |

---

## 13. Integration Points (read-only)

| Existing component | Reporting usage |
|--------------------|-----------------|
| `store.credit.settings._get_settings()` | Report config: export limits, default date presets |
| `store.credit.timeline` | Customer statement drill-down only |
| `pos.approval.history` | Pending approvals KPI + report |
| `account.move` (accounting extension) | Liability and journal reports |
| `codebraze_pos_administration` menus | Parent menu "Reports & Analytics" |
| Administration security groups | Mapped to report groups (§8.1) |

**Do not call:** `_create_credit`, `_redeem_credit`, `action_complete`, `pos.approval.service.create_request`, `store.credit.account.move.service.post_*`.

---

## 14. Glossary

| Term | Definition |
|------|------------|
| Provider | Report-specific AbstractModel that builds domains and measures |
| Filter service | Central security-aware domain builder |
| Board | Collection of KPI widgets for a role |
| Schedule | Cron-driven export + email job |
| Liability | Sum of `amount_remaining` on active store credits (or GL balance) |

---

*End of design document. Implementation prompts should reference report codes from §4.2 and services from §3.*
