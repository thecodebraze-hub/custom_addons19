# -*- coding: utf-8 -*-
"""Customer statement reporting on partners."""

from odoo import _, models


class ResPartnerReport(models.Model):
    _inherit = "res.partner"

    def action_open_customer_statement(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Customer Store Credit Statement"),
            "res_model": "pos.customer.statement.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_partner_id": self.id},
        }
