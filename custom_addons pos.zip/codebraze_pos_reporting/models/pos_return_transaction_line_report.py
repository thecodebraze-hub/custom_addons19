# -*- coding: utf-8 -*-
"""Reporting extensions on return transaction lines."""

from odoo import api, fields, models


class PosReturnTransactionLineReport(models.Model):
    _inherit = "pos.return.transaction.line"

    return_date = fields.Datetime(
        related="return_id.create_date",
        store=True,
        index=True,
        string="Return Date",
    )
    partner_id = fields.Many2one(
        related="return_id.partner_id",
        store=True,
        index=True,
        string="Customer",
    )
    cashier_id = fields.Many2one(
        related="return_id.cashier_id",
        store=True,
        index=True,
    )
    config_id = fields.Many2one(
        related="return_id.config_id",
        store=True,
        index=True,
        string="Branch",
    )
    session_id = fields.Many2one(
        related="return_id.session_id",
        store=True,
        index=True,
        string="POS Session",
    )
    refund_method = fields.Selection(
        related="return_id.refund_method",
        store=True,
        index=True,
    )
    return_name = fields.Char(
        related="return_id.name",
        store=True,
        string="Return Number",
    )
    product_barcode = fields.Char(
        related="product_id.barcode",
        store=True,
        index=True,
        string="Barcode",
    )
    product_categ_id = fields.Many2one(
        related="product_id.categ_id",
        store=True,
        index=True,
        string="Category",
    )
    product_variant = fields.Char(
        string="Variant",
        compute="_compute_product_variant",
    )
    refund_amount = fields.Monetary(
        related="price_subtotal",
        store=True,
        string="Refund Amount",
    )
    qty_returned = fields.Float(
        related="qty",
        store=True,
        string="Returned Qty",
    )

    @api.depends("product_id", "product_id.product_template_attribute_value_ids")
    def _compute_product_variant(self):
        for line in self:
            product = line.product_id
            if not product:
                line.product_variant = ""
                continue
            attrs = product.product_template_attribute_value_ids
            if attrs:
                line.product_variant = ", ".join(attrs.mapped("display_name"))
            else:
                line.product_variant = product.display_name

    def action_report_open_return(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Return"),
            "res_model": "pos.return.transaction",
            "view_mode": "form",
            "res_id": self.return_id.id,
        }

    def action_report_open_product(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Product"),
            "res_model": "product.product",
            "view_mode": "form",
            "res_id": self.product_id.id,
        }

    def action_report_open_customer(self):
        self.ensure_one()
        if not self.partner_id:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Customer"),
            "res_model": "res.partner",
            "view_mode": "form",
            "res_id": self.partner_id.id,
        }

    def action_report_open_pos_order(self):
        self.ensure_one()
        order = self.return_id.original_order_id
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("POS Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": order.id,
        }
