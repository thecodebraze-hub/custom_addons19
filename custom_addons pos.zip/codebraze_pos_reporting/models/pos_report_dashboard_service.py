# -*- coding: utf-8 -*-
"""Executive dashboard KPI and chart data (read-only aggregates)."""

from datetime import timedelta

from odoo import api, fields, models


class PosReportDashboardService(models.AbstractModel):
    _name = "pos.report.dashboard.service"
    _description = "POS Report Dashboard Service"
    _inherit = "pos.report.mixin"

    ACTIVE_CREDIT_STATES = ("issued", "partially_used")
    PENDING_RETURN_STATES = ("draft", "waiting_approval", "approved")
    PENDING_APPROVAL_STATES = ("pending", "requested")

    @api.model
    def _filters(self, filters=None):
        filters = dict(filters or {})
        today = fields.Date.context_today(self)
        date_from = filters.get("date_from") or today.replace(day=1)
        date_to = filters.get("date_to") or today
        if isinstance(date_from, str):
            date_from = fields.Date.from_string(date_from)
        if isinstance(date_to, str):
            date_to = fields.Date.from_string(date_to)
        dt_from = fields.Datetime.to_datetime(date_from)
        dt_to = fields.Datetime.to_datetime(date_to) + timedelta(days=1, seconds=-1)
        return {
            "date_from": date_from,
            "date_to": date_to,
            "dt_from": dt_from,
            "dt_to": dt_to,
            "company_id": filters.get("company_id") or self.env.company.id,
            "config_id": filters.get("config_id"),
            "board_code": filters.get("board_code") or "executive",
        }

    @api.model
    def _extra_domain(self, model_name, config_id):
        domain = []
        if config_id:
            branch_field = self.env["pos.report.filter.service"]._branch_field(model_name)
            if branch_field:
                domain.append((branch_field, "=", config_id))
        return domain

    @api.model
    def _date_domain(self, field_name, dt_from, dt_to):
        return [(field_name, ">=", dt_from), (field_name, "<=", dt_to)]

    @api.model
    def get_all_widgets(self, filters=None):
        f = self._filters(filters)
        filter_svc = self.env["pos.report.filter.service"]
        today = fields.Date.context_today(self)
        today_start = fields.Datetime.to_datetime(today)
        today_end = today_start + timedelta(days=1, seconds=-1)

        return_domain = filter_svc.merge_domain(
            "pos.return.transaction",
            self._extra_domain("pos.return.transaction", f["config_id"]),
        )
        credit_domain = filter_svc.merge_domain(
            "store.credit",
            self._extra_domain("store.credit", f["config_id"]),
        )
        payment_domain = filter_svc.merge_domain(
            "store.credit.payment",
            self._extra_domain("store.credit.payment", f["config_id"]),
        )

        Return = self.env["pos.return.transaction"]
        Credit = self.env["store.credit"]
        Payment = self.env["store.credit.payment"]
        Approval = self.env["pos.approval.history"]
        Order = self.env["pos.order"]

        today_return_domain = return_domain + self._date_domain(
            "return_date", today_start, today_end
        )
        period_return_domain = return_domain + self._date_domain(
            "return_date", f["dt_from"], f["dt_to"]
        )

        returns_today = Return.search_count(today_return_domain)
        refund_today_data = Return.read_group(
            today_return_domain,
            ["refund_amount:sum"],
            [],
            lazy=False,
        )
        refund_today = refund_today_data[0]["refund_amount"] if refund_today_data else 0.0

        outstanding_domain = credit_domain + [
            ("state", "in", self.ACTIVE_CREDIT_STATES),
            ("amount_remaining", ">", 0),
        ]
        outstanding_data = Credit.read_group(
            outstanding_domain,
            ["amount_remaining:sum"],
            [],
            lazy=False,
        )
        outstanding_credits = (
            outstanding_data[0]["amount_remaining"] if outstanding_data else 0.0
        )

        issued_today_domain = credit_domain + self._date_domain(
            "issue_date", today_start, today_end
        ) + [("state", "not in", ("draft", "cancelled"))]
        issued_today_data = Credit.read_group(
            issued_today_domain,
            ["amount:sum"],
            [],
            lazy=False,
        )
        credits_issued_today = issued_today_data[0]["amount"] if issued_today_data else 0.0

        redeemed_today_domain = payment_domain + self._date_domain(
            "create_date", today_start, today_end
        ) + [("state", "=", "posted")]
        redeemed_today_data = Payment.read_group(
            redeemed_today_domain,
            ["amount:sum"],
            [],
            lazy=False,
        )
        credits_redeemed_today = (
            redeemed_today_data[0]["amount"] if redeemed_today_data else 0.0
        )

        pending_returns = Return.search_count(
            return_domain
            + [
                ("state", "!=", "cancelled"),
                "|",
                ("state", "in", self.PENDING_RETURN_STATES),
                ("settlement_state", "=", "pending"),
            ]
        )

        expired_domain = credit_domain + [("state", "=", "expired")]
        expired_data = Credit.read_group(
            expired_domain,
            ["amount_remaining:sum"],
            [],
            lazy=False,
        )
        expired_credits = expired_data[0]["amount_remaining"] if expired_data else 0.0

        period_returns = Return.read_group(
            period_return_domain,
            ["refund_amount:sum", "unit_count:sum"],
            [],
            lazy=False,
        )
        return_count = int(period_returns[0]["unit_count"]) if period_returns else 0
        return_amount = period_returns[0]["refund_amount"] if period_returns else 0.0
        avg_return_value = return_amount / return_count if return_count else 0.0

        period_payment_domain = payment_domain + self._date_domain(
            "create_date", f["dt_from"], f["dt_to"]
        ) + [("state", "=", "posted")]
        redemption_data = Payment.read_group(
            period_payment_domain,
            ["amount:sum"],
            [],
            lazy=False,
        )
        redemption_count = Payment.search_count(period_payment_domain)
        redemption_amount = redemption_data[0]["amount"] if redemption_data else 0.0
        avg_redemption_value = (
            redemption_amount / redemption_count if redemption_count else 0.0
        )

        order_domain = [
            ("company_id", "=", f["company_id"]),
            ("date_order", ">=", f["dt_from"]),
            ("date_order", "<=", f["dt_to"]),
            ("state", "in", ("paid", "done", "invoiced")),
        ]
        if f["config_id"]:
            order_domain.append(("config_id", "=", f["config_id"]))
        order_data = Order.read_group(order_domain, ["amount_total:sum"], [], lazy=False)
        sales_total = order_data[0]["amount_total"] if order_data else 0.0
        return_pct = (return_amount / sales_total * 100.0) if sales_total else 0.0

        period_issued_domain = credit_domain + self._date_domain(
            "issue_date", f["dt_from"], f["dt_to"]
        ) + [("state", "not in", ("draft", "cancelled"))]
        issued_period = Credit.read_group(
            period_issued_domain,
            ["amount:sum", "amount_used:sum"],
            [],
            lazy=False,
        )
        issued_sum = issued_period[0]["amount"] if issued_period else 0.0
        used_sum = issued_period[0]["amount_used"] if issued_period else 0.0
        voucher_util_pct = (used_sum / issued_sum * 100.0) if issued_sum else 0.0

        expired_period = Credit.read_group(
            credit_domain
            + self._date_domain("expiry_date", f["dt_from"], f["dt_to"])
            + [("state", "=", "expired")],
            ["amount:sum"],
            [],
            lazy=False,
        )
        expired_period_sum = expired_period[0]["amount"] if expired_period else 0.0
        expiry_pct = (expired_period_sum / issued_sum * 100.0) if issued_sum else 0.0

        approval_domain = [
            ("company_id", "=", f["company_id"]),
            ("state", "in", self.PENDING_APPROVAL_STATES),
        ]
        if f["config_id"]:
            approval_domain.append(("config_id", "=", f["config_id"]))
        pending_approvals = Approval.search_count(approval_domain)

        return {
            "cards": {
                "returns_today": returns_today,
                "refund_today": refund_today,
                "outstanding_liability": outstanding_credits,
                "credits_issued_today": credits_issued_today,
                "credits_redeemed_today": credits_redeemed_today,
                "pending_returns": pending_returns,
                "expired_credits": expired_credits,
                "outstanding_credits": outstanding_credits,
                "pending_approvals": pending_approvals,
            },
            "kpis": {
                "avg_return_value": avg_return_value,
                "avg_redemption_value": avg_redemption_value,
                "return_pct": return_pct,
                "outstanding_liability": outstanding_credits,
                "voucher_util_pct": voucher_util_pct,
                "expiry_pct": expiry_pct,
            },
            "charts": {
                "return_trend": self._return_trend(return_domain, f),
                "liability_trend": self._liability_trend(credit_domain, f),
                "voucher_usage": self._voucher_usage(payment_domain, f),
                "top_branches": self._top_branches(return_domain, payment_domain, f),
                "top_cashiers": self._top_cashiers(return_domain, payment_domain, f),
                "top_customers": self._top_customers(return_domain, credit_domain, f),
            },
        }

    @api.model
    def _return_trend(self, base_domain, f):
        domain = base_domain + self._date_domain("return_date", f["dt_from"], f["dt_to"])
        groups = self.env["pos.return.transaction"].read_group(
            domain,
            ["refund_amount:sum", "unit_count:sum"],
            ["return_date:day"],
            lazy=False,
        )
        return [
            {
                "label": g["return_date:day"],
                "count": int(g["unit_count"]),
                "amount": g["refund_amount"],
            }
            for g in groups
        ]

    @api.model
    def _liability_trend(self, base_domain, f):
        domain = base_domain + [
            ("issue_date", "<=", f["dt_to"]),
            ("state", "not in", ("draft", "cancelled")),
        ]
        groups = self.env["store.credit"].read_group(
            domain,
            ["amount_remaining:sum"],
            ["issue_date:month"],
            lazy=False,
        )
        return [
            {
                "label": g["issue_date:month"],
                "amount": g["amount_remaining"],
            }
            for g in groups
        ]

    @api.model
    def _voucher_usage(self, base_domain, f):
        domain = base_domain + self._date_domain(
            "create_date", f["dt_from"], f["dt_to"]
        ) + [("state", "=", "posted")]
        groups = self.env["store.credit.payment"].read_group(
            domain,
            ["amount:sum"],
            ["create_date:week"],
            lazy=False,
        )
        return [
            {
                "label": g["create_date:week"],
                "amount": g["amount"],
            }
            for g in groups
        ]

    @api.model
    def _top_branches(self, return_domain, payment_domain, f):
        period_return = return_domain + self._date_domain(
            "return_date", f["dt_from"], f["dt_to"]
        )
        return_groups = self.env["pos.return.transaction"].read_group(
            period_return,
            ["refund_amount:sum"],
            ["config_id"],
            lazy=False,
            limit=10,
        )
        redeem_groups = self.env["store.credit.payment"].read_group(
            payment_domain
            + self._date_domain("create_date", f["dt_from"], f["dt_to"])
            + [("state", "=", "posted")],
            ["amount:sum"],
            ["config_id"],
            lazy=False,
            limit=10,
        )
        scores = {}
        for g in return_groups:
            bid = g["config_id"][0] if g["config_id"] else 0
            scores[bid] = scores.get(bid, 0.0) + g["refund_amount"]
        for g in redeem_groups:
            bid = g["config_id"][0] if g["config_id"] else 0
            scores[bid] = scores.get(bid, 0.0) + g["amount"]
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:10]
        Config = self.env["pos.config"]
        return [
            {
                "label": Config.browse(bid).name if bid else self.env._("N/A"),
                "amount": amount,
            }
            for bid, amount in ranked
        ]

    @api.model
    def _top_cashiers(self, return_domain, payment_domain, f):
        period_return = return_domain + self._date_domain(
            "return_date", f["dt_from"], f["dt_to"]
        )
        return_groups = self.env["pos.return.transaction"].read_group(
            period_return,
            ["refund_amount:sum"],
            ["cashier_id"],
            lazy=False,
            limit=10,
        )
        redeem_groups = self.env["store.credit.payment"].read_group(
            payment_domain
            + self._date_domain("create_date", f["dt_from"], f["dt_to"])
            + [("state", "=", "posted")],
            ["amount:sum"],
            ["cashier_id"],
            lazy=False,
            limit=10,
        )
        scores = {}
        for g in return_groups:
            uid = g["cashier_id"][0] if g["cashier_id"] else 0
            scores[uid] = scores.get(uid, 0.0) + g["refund_amount"]
        for g in redeem_groups:
            uid = g["cashier_id"][0] if g["cashier_id"] else 0
            scores[uid] = scores.get(uid, 0.0) + g["amount"]
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:10]
        Users = self.env["res.users"]
        return [
            {
                "label": Users.browse(uid).name if uid else self.env._("N/A"),
                "amount": amount,
            }
            for uid, amount in ranked
        ]

    @api.model
    def _top_customers(self, return_domain, credit_domain, f):
        period_return = return_domain + self._date_domain(
            "return_date", f["dt_from"], f["dt_to"]
        )
        return_groups = self.env["pos.return.transaction"].read_group(
            period_return,
            ["refund_amount:sum"],
            ["partner_id"],
            lazy=False,
            limit=10,
        )
        issued_groups = self.env["store.credit"].read_group(
            credit_domain
            + self._date_domain("issue_date", f["dt_from"], f["dt_to"])
            + [("state", "not in", ("draft", "cancelled"))],
            ["amount:sum"],
            ["partner_id"],
            lazy=False,
            limit=10,
        )
        scores = {}
        for g in return_groups:
            pid = g["partner_id"][0] if g["partner_id"] else 0
            scores[pid] = scores.get(pid, 0.0) + g["refund_amount"]
        for g in issued_groups:
            pid = g["partner_id"][0] if g["partner_id"] else 0
            scores[pid] = scores.get(pid, 0.0) + g["amount"]
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:10]
        Partner = self.env["res.partner"]
        return [
            {
                "label": Partner.browse(pid).name if pid else self.env._("Walk-in"),
                "amount": amount,
            }
            for pid, amount in ranked
        ]
