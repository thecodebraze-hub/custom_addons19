# -*- coding: utf-8 -*-
"""Security-aware report domain builder."""

from odoo import api, models


class PosReportFilterService(models.AbstractModel):
    _name = "pos.report.filter.service"
    _description = "POS Report Filter Service"
    _inherit = "pos.report.mixin"

    @api.model
    def get_security_domain(self, model_name):
        """Return role-based domain fragment for reporting models."""
        user = self.env.user
        base = [("company_id", "in", self._report_company_ids())]

        if model_name == "store.credit.audit":
            if user.has_group("codebraze_pos_reporting.group_report_administrator"):
                return base
            if user.has_group("codebraze_pos_reporting.group_report_manager"):
                return base
            if user.has_group("codebraze_pos_reporting.group_report_supervisor"):
                branch_ids = self._report_branch_ids()
                return base + [("credit_id.config_id", "in", branch_ids)]
            if user.has_group("codebraze_pos_reporting.group_report_cashier"):
                return base + [("cashier_id", "=", user.id)]
            return base + [("id", "=", 0)]

        if user.has_group("codebraze_pos_reporting.group_report_administrator"):
            return base
        if user.has_group("codebraze_pos_reporting.group_report_manager"):
            return base
        if user.has_group("codebraze_pos_reporting.group_report_supervisor"):
            branch_ids = self._report_branch_ids()
            branch_field = self._branch_field(model_name)
            if branch_field:
                return base + [(branch_field, "in", branch_ids)]
            return base
        if user.has_group("codebraze_pos_reporting.group_report_cashier"):
            cashier_field = self._cashier_field(model_name)
            if cashier_field:
                return base + [(cashier_field, "=", user.id)]
            return base + [("id", "=", 0)]
        return base + [("id", "=", 0)]

    @api.model
    def _branch_field(self, model_name):
        mapping = {
            "pos.return.transaction": "config_id",
            "pos.return.transaction.line": "config_id",
            "pos.exchange.transaction": "config_id",
            "pos.report.return.reason.analysis": "config_id",
            "store.credit": "config_id",
            "store.credit.payment": "config_id",
            "store.credit.audit": "credit_id.config_id",
        }
        return mapping.get(model_name, "config_id")

    @api.model
    def _cashier_field(self, model_name):
        mapping = {
            "pos.return.transaction": "cashier_id",
            "pos.return.transaction.line": "cashier_id",
            "pos.exchange.transaction": "cashier_id",
            "pos.report.return.reason.analysis": "cashier_id",
            "store.credit.payment": "cashier_id",
        }
        return mapping.get(model_name, "cashier_id")

    @api.model
    def merge_domain(self, model_name, extra_domain=None):
        domain = self.get_security_domain(model_name)
        if extra_domain:
            domain = domain + list(extra_domain)
        return domain
