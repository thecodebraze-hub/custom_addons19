# -*- coding: utf-8 -*-
"""Customer store credit statement builder."""

from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import AccessError, UserError


class PosCustomerStatementService(models.AbstractModel):
    _name = "pos.customer.statement.service"
    _description = "Customer Store Credit Statement Service"
    _inherit = "pos.report.mixin"

    @api.model
    def check_statement_access(self, partner):
        user = self.env.user
        if user.has_group("codebraze_pos_reporting.group_report_manager"):
            return True
        if user.has_group("codebraze_pos_reporting.group_report_supervisor"):
            branch_ids = self._report_branch_ids()
            credit_count = self.env["store.credit"].search_count(
                [
                    ("partner_id", "=", partner.id),
                    ("config_id", "in", branch_ids),
                ]
            )
            if credit_count:
                return True
            raise AccessError(
                _("You can only view statements for customers at your branch.")
            )
        raise AccessError(_("You do not have permission to view customer statements."))

    @api.model
    def build_statement(self, partner, date_from, date_to):
        self.check_statement_access(partner)
        if date_from > date_to:
            raise UserError(_("Statement start date must be before end date."))

        dt_from = fields.Datetime.to_datetime(date_from)
        dt_to = fields.Datetime.to_datetime(date_to) + timedelta(days=1, seconds=-1)
        credit_ids = partner.store_credit_ids.ids

        Credit = self.env["store.credit"]
        Payment = self.env["store.credit.payment"]
        Return = self.env["pos.return.transaction"]
        Audit = self.env["store.credit.audit"]

        currency = (
            partner.store_credit_ids[:1].currency_id
            if partner.store_credit_ids
            else partner.company_id.currency_id or self.env.company.currency_id
        )

        issued = Credit.search(
            [
                ("partner_id", "=", partner.id),
                ("issue_date", ">=", dt_from),
                ("issue_date", "<=", dt_to),
                ("state", "not in", ("draft", "cancelled")),
            ],
            order="issue_date asc",
        )
        redeemed = Payment.search(
            [
                ("credit_id", "in", credit_ids or [0]),
                ("create_date", ">=", dt_from),
                ("create_date", "<=", dt_to),
                ("state", "=", "posted"),
            ],
            order="create_date asc",
        )
        returns = Return.search(
            [
                ("partner_id", "=", partner.id),
                ("return_date", ">=", dt_from),
                ("return_date", "<=", dt_to),
            ],
            order="return_date asc",
        )
        adjustments = Audit.search(
            [
                ("credit_id", "in", credit_ids or [0]),
                ("action", "=", "adjustment"),
                ("create_date", ">=", dt_from),
                ("create_date", "<=", dt_to),
            ],
            order="create_date asc",
        )
        expired = Credit.search(
            [
                ("partner_id", "=", partner.id),
                ("state", "=", "expired"),
                ("expiry_date", ">=", dt_from),
                ("expiry_date", "<=", dt_to),
            ],
            order="expiry_date asc",
        )
        cancelled = Credit.search(
            [
                ("partner_id", "=", partner.id),
                ("state", "=", "cancelled"),
                ("write_date", ">=", dt_from),
                ("write_date", "<=", dt_to),
            ],
            order="write_date asc",
        )

        opening_balance = self._balance_before(partner, dt_from)
        period_issued = sum(issued.mapped("amount"))
        period_redeemed = sum(redeemed.mapped("amount"))
        period_expired = sum(expired.mapped("amount_remaining"))
        period_cancelled = sum(cancelled.mapped("amount_remaining"))
        closing_balance = partner.sc_available_balance

        return {
            "partner": partner,
            "date_from": date_from,
            "date_to": date_to,
            "currency": currency,
            "opening_balance": opening_balance,
            "closing_balance": closing_balance,
            "totals": {
                "issued": period_issued,
                "redeemed": period_redeemed,
                "returns": sum(returns.mapped("refund_amount")),
                "adjustments": sum(adjustments.mapped("amount")),
                "expired": period_expired,
                "cancelled": period_cancelled,
            },
            "issued_lines": self._credit_lines(issued),
            "redeemed_lines": self._payment_lines(redeemed),
            "return_lines": self._return_lines(returns),
            "adjustment_lines": self._audit_lines(adjustments),
            "expired_lines": self._credit_lines(expired, use_remaining=True),
            "cancelled_lines": self._credit_lines(cancelled, use_remaining=True),
        }

    @api.model
    def _balance_before(self, partner, dt_from):
        credits = partner.store_credit_ids.filtered(
            lambda c: c.state in ("issued", "partially_used", "used", "expired")
            and (not c.issue_date or c.issue_date < dt_from)
        )
        active = credits.filtered(
            lambda c: c.state in ("issued", "partially_used")
            and c.amount_remaining > 0
        )
        return sum(active.mapped("amount_remaining"))

    @api.model
    def _credit_lines(self, credits, use_remaining=False):
        return [
            {
                "date": c.issue_date or c.create_date,
                "reference": c.name,
                "barcode": c.barcode,
                "branch": c.config_id.name,
                "amount": c.amount_remaining if use_remaining else c.amount,
                "state": c.state,
            }
            for c in credits
        ]

    @api.model
    def _payment_lines(self, payments):
        return [
            {
                "date": p.create_date,
                "reference": p.name,
                "credit": p.credit_id.name,
                "order": p.pos_order_id.name,
                "branch": p.config_id.name,
                "amount": p.amount,
            }
            for p in payments
        ]

    @api.model
    def _return_lines(self, returns):
        return [
            {
                "date": r.return_date or r.create_date,
                "reference": r.name,
                "branch": r.config_id.name,
                "method": r.refund_method,
                "amount": r.refund_amount,
                "state": r.state,
            }
            for r in returns
        ]

    @api.model
    def _audit_lines(self, audits):
        return [
            {
                "date": a.create_date,
                "reference": a.credit_id.name,
                "message": a.message,
                "amount": a.amount,
                "user": a.cashier_id.name or a.manager_id.name,
            }
            for a in audits
        ]
