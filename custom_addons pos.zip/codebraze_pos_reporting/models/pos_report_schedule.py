# -*- coding: utf-8 -*-
"""Scheduled POS report email delivery."""

import logging
import base64
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class PosReportSchedule(models.Model):
    _name = "pos.report.schedule"
    _description = "POS Report Schedule"
    _order = "name"
    _check_company_auto = True

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)
    report_code = fields.Selection(
        selection=[
            ("returns.detail", "Return Summary"),
            ("returns.items", "Return Item Report"),
            ("exchanges.detail", "Exchange Report"),
            ("reason.analysis", "Return Reason Analysis"),
            ("customer.statement", "Customer Statement"),
        ],
        required=True,
        default="returns.detail",
    )
    interval_type = fields.Selection(
        selection=[
            ("daily", "Daily"),
            ("weekly", "Weekly"),
            ("monthly", "Monthly"),
        ],
        required=True,
        default="weekly",
    )
    weekday = fields.Selection(
        selection=[
            ("0", "Monday"),
            ("1", "Tuesday"),
            ("2", "Wednesday"),
            ("3", "Thursday"),
            ("4", "Friday"),
            ("5", "Saturday"),
            ("6", "Sunday"),
        ],
        default="0",
    )
    month_day = fields.Integer(string="Day of Month", default=1)
    next_run = fields.Datetime(string="Next Run", index=True)
    last_run = fields.Datetime(readonly=True)
    export_format = fields.Selection(
        selection=[
            ("csv", "CSV"),
            ("xlsx", "Excel"),
            ("pdf", "PDF"),
        ],
        required=True,
        default="xlsx",
    )
    date_preset = fields.Selection(
        selection=[
            ("today", "Today"),
            ("yesterday", "Yesterday"),
            ("this_week", "This Week"),
            ("last_week", "Last Week"),
            ("this_month", "This Month"),
            ("last_month", "Last Month"),
        ],
        default="last_week",
        required=True,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Statement Customer",
        help="Required for customer statement schedules.",
    )
    recipient_partner_ids = fields.Many2many(
        comodel_name="res.partner",
        relation="pos_report_schedule_partner_rel",
        column1="schedule_id",
        column2="partner_id",
        string="Email Recipients",
    )
    group_ids = fields.Many2many(
        comodel_name="res.groups",
        relation="pos_report_schedule_group_rel",
        column1="schedule_id",
        column2="group_id",
        string="Recipient Groups",
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        default=lambda self: self.env.company,
        required=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch Filter",
        domain="[('company_id', '=', company_id)]",
    )
    user_id = fields.Many2one(
        comodel_name="res.users",
        string="Created By",
        default=lambda self: self.env.user,
        readonly=True,
    )

    REPORT_REGISTRY = {
        "returns.detail": {
            "model": "pos.return.transaction",
            "fields": [
                "name",
                "invoice_name",
                "partner_id",
                "cashier_id",
                "config_id",
                "return_date",
                "refund_method",
                "refund_amount",
                "state",
            ],
            "title": "Return_Summary",
            "date_field": "return_date",
        },
        "returns.items": {
            "model": "pos.return.transaction.line",
            "fields": [
                "return_id",
                "product_id",
                "qty",
                "price_subtotal",
                "reason_id",
                "cashier_id",
                "config_id",
            ],
            "title": "Return_Items",
            "date_field": "create_date",
        },
        "exchanges.detail": {
            "model": "pos.exchange.transaction",
            "fields": [
                "name",
                "partner_id",
                "cashier_id",
                "config_id",
                "exchange_date",
                "difference_amount",
                "store_credit_used",
                "state",
            ],
            "title": "Exchange_Report",
            "date_field": "exchange_date",
        },
        "reason.analysis": {
            "model": "pos.report.return.reason.analysis",
            "fields": [
                "reason_id",
                "config_id",
                "return_count",
                "return_amount",
                "percentage",
            ],
            "title": "Return_Reason_Analysis",
            "date_field": "return_date",
        },
    }

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        records._ensure_next_run()
        return records

    def write(self, vals):
        res = super().write(vals)
        if any(
            f in vals
            for f in ("interval_type", "weekday", "month_day", "active", "next_run")
        ):
            self._ensure_next_run()
        return res

    def _ensure_next_run(self):
        for sched in self.filtered(lambda s: s.active and not s.next_run):
            sched.next_run = sched._compute_next_run(fields.Datetime.now())

    @api.model
    def _cron_run_scheduled_reports(self):
        due = self.search(
            [
                ("active", "=", True),
                ("next_run", "!=", False),
                ("next_run", "<=", fields.Datetime.now()),
            ]
        )
        for sched in due:
            try:
                sched.with_user(sched.user_id or self.env.user)._run_once()
            except Exception:
                _logger.exception("Scheduled report failed: %s", sched.name)

    def _run_once(self):
        self.ensure_one()
        if self.report_code == "customer.statement":
            if not self.partner_id:
                raise UserError(_("Customer is required for statement schedules."))
            attachment = self._generate_statement_attachment()
        else:
            attachment = self._generate_tabular_attachment()
        recipients = self._resolve_recipients()
        if not recipients:
            raise UserError(_("No email recipients configured for schedule %s.") % self.name)
        template = self.env.ref(
            "codebraze_pos_reporting.mail_template_pos_report_schedule",
            raise_if_not_found=False,
        )
        for partner in recipients:
            if not partner.email:
                continue
            email_values = {
                "email_to": partner.email,
                "recipient_ids": [(4, partner.id)],
                "attachment_ids": [(4, attachment.id)],
            }
            if template:
                template.send_mail(
                    self.id,
                    email_values=email_values,
                    force_send=True,
                )
            else:
                self.env["mail.mail"].sudo().create(
                    {
                        "subject": "[Report] %s" % self.name,
                        "body_html": "<p>Please find the attached report.</p>",
                        "email_to": partner.email,
                        "attachment_ids": [(4, attachment.id)],
                    }
                ).send()
        self.write(
            {
                "last_run": fields.Datetime.now(),
                "next_run": self._compute_next_run(fields.Datetime.now()),
            }
        )

    def _resolve_recipients(self):
        partners = self.recipient_partner_ids
        if self.group_ids:
            users = self.env["res.users"].search(
                [("groups_id", "in", self.group_ids.ids), ("active", "=", True)]
            )
            partners |= users.mapped("partner_id")
        return partners.filtered(lambda p: p.email)

    def _date_range(self):
        mixin = self.env["pos.report.mixin"]
        start, end = mixin._report_date_range(self.date_preset)
        if not start:
            today = fields.Date.context_today(self)
            start = fields.Datetime.to_datetime(today.replace(day=1))
            end = fields.Datetime.to_datetime(today) + timedelta(days=1, seconds=-1)
        return start, end

    def _schedule_domain(self, model_name, date_field):
        filter_svc = self.env["pos.report.filter.service"]
        domain = filter_svc.merge_domain(model_name)
        if self.config_id:
            branch_field = filter_svc._branch_field(model_name)
            if branch_field:
                domain.append((branch_field, "=", self.config_id.id))
        start, end = self._date_range()
        return domain + [(date_field, ">=", start), (date_field, "<=", end)]

    def _generate_tabular_attachment(self):
        meta = self.REPORT_REGISTRY.get(self.report_code)
        if not meta:
            raise UserError(_("Unknown report code: %s") % self.report_code)
        domain = self._schedule_domain(meta["model"], meta["date_field"])
        export = self.env["pos.report.export.service"]
        title = "%s_%s" % (meta["title"], self.date_preset)
        if self.export_format == "pdf":
            return self._generate_tabular_pdf(meta, domain, title)
        if self.export_format == "xlsx":
            action = export.export_xlsx(
                meta["model"], domain, meta["fields"], title=title
            )
        else:
            action = export.export_csv(
                meta["model"], domain, meta["fields"], title=title
            )
        attachment_id = int(action["url"].split("/web/content/")[1].split("?")[0])
        return self.env["ir.attachment"].browse(attachment_id)

    def _generate_tabular_pdf(self, meta, domain, title):
        report_refs = {
            "returns.detail": "codebraze_pos_reporting.action_report_return_summary_pdf",
            "returns.items": "codebraze_pos_reporting.action_report_return_item_pdf",
            "exchanges.detail": "codebraze_pos_reporting.action_report_exchange_pdf",
            "reason.analysis": "codebraze_pos_reporting.action_report_reason_analysis_pdf",
        }
        report_xmlid = report_refs.get(self.report_code)
        if not report_xmlid:
            raise UserError(_("PDF export is not available for this report."))
        records = self.env[meta["model"]].search(domain, limit=500)
        report = self.env.ref(report_xmlid)
        pdf_content, _ = report._render_qweb_pdf(records.ids)
        return self.env["ir.attachment"].create(
            {
                "name": "%s.pdf" % title,
                "type": "binary",
                "datas": base64.b64encode(pdf_content),
                "mimetype": "application/pdf",
            }
        )

    def _generate_statement_attachment(self):
        start, end = self._date_range()
        date_from = start.date() if hasattr(start, "date") else start
        date_to = end.date() if hasattr(end, "date") else end
        if self.export_format == "pdf":
            wizard = self.env["pos.customer.statement.wizard"].create(
                {
                    "partner_id": self.partner_id.id,
                    "date_from": date_from,
                    "date_to": date_to,
                }
            )
            return wizard._create_pdf_attachment()
        action = self.env["pos.report.export.service"].export_customer_statement(
            self.partner_id,
            date_from,
            date_to,
            export_format=self.export_format,
        )
        attachment_id = int(action["url"].split("/web/content/")[1].split("?")[0])
        return self.env["ir.attachment"].browse(attachment_id)

    def _compute_next_run(self, from_dt):
        self.ensure_one()
        base = from_dt or fields.Datetime.now()
        if self.interval_type == "daily":
            return base + timedelta(days=1)
        if self.interval_type == "weekly":
            return base + timedelta(weeks=1)
        return base + timedelta(days=30)

    def action_run_now(self):
        self.ensure_one()
        self._run_once()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Report Sent"),
                "message": _("Scheduled report has been generated and emailed."),
                "type": "success",
                "sticky": False,
            },
        }
