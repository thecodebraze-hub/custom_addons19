# -*- coding: utf-8 -*-
"""CSV, Excel and PDF export helpers for POS reports."""

import base64
import csv
import io
from datetime import datetime

from odoo import _, api, models
from odoo.exceptions import UserError


class PosReportExportService(models.AbstractModel):
    _name = "pos.report.export.service"
    _description = "POS Report Export Service"
    _inherit = "pos.report.mixin"

    MAX_ROWS = 50000

    @api.model
    def export_csv(self, model_name, domain, field_names, title="report"):
        records = self.env[model_name].search(domain, limit=self.MAX_ROWS + 1)
        if len(records) > self.MAX_ROWS:
            raise UserError(
                _("Export exceeds the maximum of %(max)s rows.", max=self.MAX_ROWS)
            )
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        fields_meta = self.env[model_name].fields_get(field_names)
        headers = [fields_meta[f].get("string", f) for f in field_names]
        writer.writerow(headers)
        for rec in records:
            row = []
            for fname in field_names:
                val = rec[fname]
                if hasattr(val, "display_name"):
                    val = val.display_name
                elif isinstance(val, (list, tuple)):
                    val = ",".join(str(v) for v in val)
                row.append(val or "")
            writer.writerow(row)
        return self._attachment(
            buffer.getvalue().encode("utf-8"),
            "%s_%s.csv" % (title, datetime.now().strftime("%Y%m%d_%H%M%S")),
            "text/csv",
        )

    @api.model
    def export_xlsx(self, model_name, domain, field_names, title="report"):
        try:
            import xlsxwriter
        except ImportError:
            raise UserError(_("xlsxwriter is required for Excel export.")) from None

        records = self.env[model_name].search(domain, limit=self.MAX_ROWS + 1)
        if len(records) > self.MAX_ROWS:
            raise UserError(
                _("Export exceeds the maximum of %(max)s rows.", max=self.MAX_ROWS)
            )
        buffer = io.BytesIO()
        workbook = xlsxwriter.Workbook(buffer, {"in_memory": True})
        sheet = workbook.add_worksheet(title[:31])
        header_fmt = workbook.add_format({"bold": True})
        fields_meta = self.env[model_name].fields_get(field_names)
        for col, fname in enumerate(field_names):
            sheet.write(0, col, fields_meta[fname].get("string", fname), header_fmt)
        for row_idx, rec in enumerate(records, start=1):
            for col, fname in enumerate(field_names):
                val = rec[fname]
                if hasattr(val, "display_name"):
                    val = val.display_name
                elif isinstance(val, (list, tuple)):
                    val = ",".join(str(v) for v in val)
                sheet.write(row_idx, col, val or "")
        workbook.close()
        return self._attachment(
            buffer.getvalue(),
            "%s_%s.xlsx" % (title, datetime.now().strftime("%Y%m%d_%H%M%S")),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    @api.model
    def _attachment(self, data, filename, mimetype):
        attachment = self.env["ir.attachment"].create(
            {
                "name": filename,
                "type": "binary",
                "datas": base64.b64encode(data),
                "mimetype": mimetype,
            }
        )
        return {
            "type": "ir.actions.act_url",
            "url": "/web/content/%s?download=true" % attachment.id,
            "target": "self",
        }

    @api.model
    def export_customer_statement(self, partner, date_from, date_to, export_format="csv"):
        statement = self.env["pos.customer.statement.service"].build_statement(
            partner, date_from, date_to
        )
        title = "Customer_Statement_%s" % partner.name.replace(" ", "_")[:40]
        if export_format == "xlsx":
            return self._export_statement_xlsx(statement, title)
        return self._export_statement_csv(statement, title)

    @api.model
    def _export_statement_csv(self, statement, title):
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        partner = statement["partner"]
        writer.writerow(["Customer Store Credit Statement"])
        writer.writerow(["Customer", partner.name])
        writer.writerow(["Period", "%s to %s" % (statement["date_from"], statement["date_to"])])
        writer.writerow(["Opening Balance", statement["opening_balance"]])
        writer.writerow(["Closing Balance", statement["closing_balance"]])
        writer.writerow([])
        for section, key in [
            ("Store Credits Issued", "issued_lines"),
            ("Store Credits Redeemed", "redeemed_lines"),
            ("Returns", "return_lines"),
            ("Manual Adjustments", "adjustment_lines"),
            ("Expired Credits", "expired_lines"),
            ("Cancelled Credits", "cancelled_lines"),
        ]:
            writer.writerow([section])
            rows = statement[key]
            if not rows:
                writer.writerow(["No records"])
                continue
            writer.writerow(list(rows[0].keys()))
            for row in rows:
                writer.writerow(list(row.values()))
            writer.writerow([])
        return self._attachment(
            buffer.getvalue().encode("utf-8"),
            "%s_%s.csv" % (title, datetime.now().strftime("%Y%m%d_%H%M%S")),
            "text/csv",
        )

    @api.model
    def _export_statement_xlsx(self, statement, title):
        try:
            import xlsxwriter
        except ImportError:
            raise UserError(_("xlsxwriter is required for Excel export.")) from None

        buffer = io.BytesIO()
        workbook = xlsxwriter.Workbook(buffer, {"in_memory": True})
        sheet = workbook.add_worksheet("Statement")
        header_fmt = workbook.add_format({"bold": True})
        partner = statement["partner"]
        row = 0
        sheet.write(row, 0, "Customer Store Credit Statement", header_fmt)
        row += 1
        sheet.write(row, 0, "Customer")
        sheet.write(row, 1, partner.name)
        row += 1
        sheet.write(row, 0, "Period")
        sheet.write(
            row,
            1,
            "%s to %s" % (statement["date_from"], statement["date_to"]),
        )
        row += 1
        sheet.write(row, 0, "Opening Balance")
        sheet.write(row, 1, statement["opening_balance"])
        row += 1
        sheet.write(row, 0, "Closing Balance")
        sheet.write(row, 1, statement["closing_balance"])
        row += 2
        for section, key in [
            ("Store Credits Issued", "issued_lines"),
            ("Store Credits Redeemed", "redeemed_lines"),
            ("Returns", "return_lines"),
            ("Manual Adjustments", "adjustment_lines"),
            ("Expired Credits", "expired_lines"),
            ("Cancelled Credits", "cancelled_lines"),
        ]:
            sheet.write(row, 0, section, header_fmt)
            row += 1
            rows = statement[key]
            if not rows:
                sheet.write(row, 0, "No records")
                row += 2
                continue
            headers = list(rows[0].keys())
            for col, h in enumerate(headers):
                sheet.write(row, col, h, header_fmt)
            row += 1
            for data_row in rows:
                for col, h in enumerate(headers):
                    val = data_row[h]
                    if hasattr(val, "display_name"):
                        val = val.display_name
                    sheet.write(row, col, val or "")
                row += 1
            row += 1
        workbook.close()
        return self._attachment(
            buffer.getvalue(),
            "%s_%s.xlsx" % (title, datetime.now().strftime("%Y%m%d_%H%M%S")),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    @api.model
    def action_export_from_context(self, export_format="csv"):
        ctx = self.env.context
        model_name = ctx.get("report_model") or ctx.get("active_model")
        field_names = ctx.get("report_fields") or []
        title = ctx.get("report_title") or model_name or "report"
        active_ids = ctx.get("active_ids")
        if not model_name or not field_names:
            raise UserError(_("Report export is not configured for this action."))
        filter_service = self.env["pos.report.filter.service"]
        domain = filter_service.merge_domain(model_name)
        if active_ids:
            domain = domain + [("id", "in", active_ids)]
        if export_format == "xlsx":
            return self.export_xlsx(model_name, domain, field_names, title=title)
        return self.export_csv(model_name, domain, field_names, title=title)
