# -*- coding: utf-8 -*-
"""Reporting extensions on exchange transactions."""

from odoo import api, fields, models


class PosExchangeTransactionReport(models.Model):
    _inherit = "pos.exchange.transaction"

    exchange_date = fields.Datetime(
        related="create_date",
        store=True,
        index=True,
        string="Exchange Date",
    )
    returned_product_summary = fields.Char(
        string="Returned Products",
        compute="_compute_product_summaries",
        store=True,
    )
    new_product_summary = fields.Char(
        string="New Products",
        compute="_compute_product_summaries",
        store=True,
    )
    original_product_summary = fields.Char(
        string="Original Invoice Products",
        compute="_compute_product_summaries",
        store=True,
    )
    store_credit_used = fields.Monetary(
        string="Store Credit Used",
        compute="_compute_store_credit_used",
        store=True,
        currency_field="currency_id",
    )
    cash_received = fields.Monetary(
        related="customer_payment",
        store=True,
        string="Cash Received",
    )

    @api.depends(
        "return_id",
        "return_id.line_ids",
        "return_id.line_ids.product_id",
        "line_ids",
        "line_ids.product_id",
        "return_id.original_order_id",
        "return_id.original_order_id.lines",
        "return_id.original_order_id.lines.product_id",
    )
    def _compute_product_summaries(self):
        for exchange in self:
            returned = exchange.return_id.line_ids.mapped("product_id.display_name")
            exchange.returned_product_summary = "; ".join(returned) if returned else ""
            new_products = exchange.line_ids.mapped("product_id.display_name")
            exchange.new_product_summary = "; ".join(new_products) if new_products else ""
            original = []
            if exchange.return_id and exchange.return_id.original_order_id:
                original = exchange.return_id.original_order_id.lines.mapped(
                    "product_id.display_name"
                )
            exchange.original_product_summary = "; ".join(original) if original else ""

    @api.depends("credit_id", "voucher_used", "difference_amount")
    def _compute_store_credit_used(self):
        for exchange in self:
            amount = 0.0
            if exchange.credit_id and exchange.difference_amount < 0:
                amount = abs(exchange.difference_amount)
            elif exchange.voucher_used and exchange.return_id.credit_id:
                amount = exchange.return_id.amount_total
            exchange.store_credit_used = amount

    def action_report_open_return(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Return"),
            "res_model": "pos.return.transaction",
            "view_mode": "form",
            "res_id": self.return_id.id,
        }

    def action_report_open_store_credit(self):
        self.ensure_one()
        credit = self.credit_id or self.return_id.credit_id
        if not credit:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Store Credit"),
            "res_model": "store.credit",
            "view_mode": "form",
            "res_id": credit.id,
        }

    def action_report_open_customer(self):
        self.ensure_one()
        if not self.partner_id:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Customer"),
            "res_model": "res.partner",
            "view_mode": "form",
            "res_id": self.partner_id.id,
        }
