# -*- coding: utf-8 -*-
"""Reporting extensions and drill-down on return transactions."""

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class PosReturnTransactionReport(models.Model):
    _inherit = "pos.return.transaction"

    return_date = fields.Datetime(
        string="Return Date",
        related="create_date",
        store=True,
        index=True,
    )
    invoice_name = fields.Char(
        string="Invoice",
        related="original_order_id.name",
        store=True,
        index=True,
    )
    refund_amount = fields.Monetary(
        string="Refund Amount",
        related="amount_total",
        store=True,
    )
    report_line_count = fields.Integer(
        string="Items Returned",
        compute="_compute_report_line_count",
    )
    unit_count = fields.Integer(
        string="Return Count",
        default=1,
        store=True,
        help="Technical field for pivot row counting.",
    )

    @api.depends("line_ids")
    def _compute_report_line_count(self):
        for ret in self:
            ret.report_line_count = len(ret.line_ids)

    def action_report_open_original_order(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("POS Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": self.original_order_id.id,
        }

    def action_report_open_return_order(self):
        self.ensure_one()
        if not self.return_order_id:
            raise UserError(_("No return POS order linked."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Return Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": self.return_order_id.id,
        }

    def action_report_open_customer(self):
        self.ensure_one()
        if not self.partner_id:
            raise UserError(_("No customer on this return."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Customer"),
            "res_model": "res.partner",
            "view_mode": "form",
            "res_id": self.partner_id.id,
        }

    def action_report_open_store_credit(self):
        self.ensure_one()
        if not self.credit_id:
            raise UserError(_("No store credit linked."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Store Credit"),
            "res_model": "store.credit",
            "view_mode": "form",
            "res_id": self.credit_id.id,
        }

    def action_report_open_accounting(self):
        self.ensure_one()
        move_ids = []
        if hasattr(self, "refund_move_id") and self.refund_move_id:
            move_ids.append(self.refund_move_id.id)
        if hasattr(self, "accounting_move_ids"):
            move_ids.extend(self.accounting_move_ids.ids)
        if not move_ids:
            raise UserError(_("No accounting entries linked."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Accounting Entries"),
            "res_model": "account.move",
            "view_mode": "list,form",
            "domain": [("id", "in", move_ids)],
        }
