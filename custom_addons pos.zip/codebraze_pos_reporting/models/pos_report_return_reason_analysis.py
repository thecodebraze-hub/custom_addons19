# -*- coding: utf-8 -*-
"""Aggregated return reason analysis (SQL view)."""

from odoo import fields, models, tools


class PosReportReturnReasonAnalysis(models.Model):
    _name = "pos.report.return.reason.analysis"
    _description = "Return Reason Analysis"
    _auto = False
    _order = "refund_value desc"
    _check_company_auto = True

    reason_id = fields.Many2one(
        comodel_name="pos.return.reason",
        string="Reason",
        readonly=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        readonly=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        readonly=True,
    )
    cashier_id = fields.Many2one(
        comodel_name="res.users",
        readonly=True,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        readonly=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS",
        readonly=True,
    )
    refund_method = fields.Selection(
        selection=[
            ("voucher", "Voucher"),
            ("store_credit", "Store Credit"),
            ("cash", "Cash"),
            ("original_payment", "Original Payment"),
            ("exchange", "Exchange"),
            ("mixed", "Mixed"),
        ],
        readonly=True,
    )
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("waiting_approval", "Waiting Approval"),
            ("approved", "Approved"),
            ("completed", "Completed"),
            ("cancelled", "Cancelled"),
        ],
        readonly=True,
    )
    return_date = fields.Date(string="Return Date", readonly=True)
    return_month = fields.Date(string="Month", readonly=True)
    return_week = fields.Date(string="Week", readonly=True)
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        readonly=True,
    )
    return_count = fields.Integer(string="Count", readonly=True)
    returned_qty = fields.Float(string="Returned Qty", readonly=True)
    refund_value = fields.Monetary(string="Refund Value", readonly=True)
    percentage = fields.Float(string="Percentage (%)", readonly=True, digits=(16, 2))

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute(
            """
            CREATE OR REPLACE VIEW %(table)s AS (
                WITH base AS (
                    SELECT
                        l.reason_id,
                        r.company_id,
                        r.config_id,
                        r.cashier_id,
                        r.partner_id,
                        r.session_id,
                        r.refund_method,
                        r.state,
                        r.currency_id,
                        DATE(r.create_date) AS return_date,
                        DATE_TRUNC('month', r.create_date)::date AS return_month,
                        DATE_TRUNC('week', r.create_date)::date AS return_week,
                        r.id AS return_id,
                        l.qty,
                        l.price_subtotal
                    FROM pos_return_transaction_line l
                    JOIN pos_return_transaction r ON r.id = l.return_id
                    WHERE l.reason_id IS NOT NULL
                      AND r.active = TRUE
                ),
                agg AS (
                    SELECT
                        reason_id,
                        company_id,
                        config_id,
                        cashier_id,
                        partner_id,
                        session_id,
                        refund_method,
                        state,
                        currency_id,
                        return_date,
                        return_month,
                        return_week,
                        COUNT(DISTINCT return_id) AS return_count,
                        COALESCE(SUM(qty), 0) AS returned_qty,
                        COALESCE(SUM(price_subtotal), 0) AS refund_value
                    FROM base
                    GROUP BY
                        reason_id,
                        company_id,
                        config_id,
                        cashier_id,
                        partner_id,
                        session_id,
                        refund_method,
                        state,
                        currency_id,
                        return_date,
                        return_month,
                        return_week
                )
                SELECT
                    ROW_NUMBER() OVER (ORDER BY reason_id, company_id, return_date) AS id,
                    reason_id,
                    company_id,
                    config_id,
                    cashier_id,
                    partner_id,
                    session_id,
                    refund_method,
                    state,
                    currency_id,
                    return_date,
                    return_month,
                    return_week,
                    return_count,
                    returned_qty,
                    refund_value,
                    CASE
                        WHEN SUM(refund_value) OVER (
                            PARTITION BY company_id, return_month
                        ) > 0
                        THEN refund_value * 100.0 / SUM(refund_value) OVER (
                            PARTITION BY company_id, return_month
                        )
                        ELSE 0
                    END AS percentage
                FROM agg
            )
            """
            % {"table": self._table}
        )
