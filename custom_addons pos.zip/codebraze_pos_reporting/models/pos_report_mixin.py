# -*- coding: utf-8 -*-
"""Shared reporting helpers."""

from datetime import timedelta

from odoo import api, fields, models


class PosReportMixin(models.AbstractModel):
    _name = "pos.report.mixin"
    _description = "POS Report Mixin"

    @api.model
    def _report_company_ids(self):
        return self.env.companies.ids

    @api.model
    def _report_branch_ids(self):
        configs = self.env["pos.config"].search(
            [("company_id", "in", self._report_company_ids())]
        )
        return configs.ids

    @api.model
    def _report_date_range(self, preset):
        today = fields.Date.context_today(self)
        if preset == "today":
            start = today
            end = today
        elif preset == "yesterday":
            start = today - timedelta(days=1)
            end = start
        elif preset == "this_week":
            start = today - timedelta(days=today.weekday())
            end = today
        elif preset == "last_week":
            end = today - timedelta(days=today.weekday() + 1)
            start = end - timedelta(days=6)
        elif preset == "this_month":
            start = today.replace(day=1)
            end = today
        elif preset == "last_month":
            first_this = today.replace(day=1)
            end = first_this - timedelta(days=1)
            start = end.replace(day=1)
        else:
            return False, False
        return (
            fields.Datetime.to_datetime(start),
            fields.Datetime.to_datetime(end) + timedelta(days=1, seconds=-1),
        )

    @api.model
    def _report_read_group(self, model, domain, aggregates, groupby, limit=500):
        return self.env[model].read_group(
            domain,
            aggregates,
            groupby,
            limit=limit,
            lazy=False,
        )
