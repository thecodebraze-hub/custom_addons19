# -*- coding: utf-8 -*-
"""Interactive executive dashboard (transient)."""

from datetime import timedelta

from odoo import api, fields, models


class PosReportDashboardLine(models.TransientModel):
    _name = "pos.report.dashboard.line"
    _description = "POS Dashboard Chart Line"
    _order = "sequence, id"

    dashboard_id = fields.Many2one(
        comodel_name="pos.report.dashboard",
        required=True,
        ondelete="cascade",
    )
    sequence = fields.Integer(default=10)
    chart_type = fields.Selection(
        selection=[
            ("return_trend", "Return Trend"),
            ("liability_trend", "Liability Trend"),
            ("voucher_usage", "Voucher Usage"),
            ("top_branch", "Top Branch"),
            ("top_cashier", "Top Cashier"),
            ("top_customer", "Top Customer"),
        ],
        required=True,
    )
    label = fields.Char(string="Period / Name", required=True)
    count_value = fields.Integer(string="Count")
    amount = fields.Monetary(currency_field="currency_id")
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="dashboard_id.currency_id",
    )


class PosReportDashboard(models.TransientModel):
    _name = "pos.report.dashboard"
    _description = "POS Executive Dashboard"

    date_preset = fields.Selection(
        selection=[
            ("today", "Today"),
            ("yesterday", "Yesterday"),
            ("this_week", "This Week"),
            ("last_week", "Last Week"),
            ("this_month", "This Month"),
            ("last_month", "Last Month"),
            ("custom", "Custom"),
        ],
        default="this_month",
    )
    date_from = fields.Date(required=True)
    date_to = fields.Date(required=True)
    company_id = fields.Many2one(
        comodel_name="res.company",
        default=lambda self: self.env.company,
        required=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        domain="[('company_id', '=', company_id)]",
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="company_id.currency_id",
    )

    returns_today = fields.Integer(readonly=True)
    refund_today = fields.Monetary(currency_field="currency_id", readonly=True)
    outstanding_liability = fields.Monetary(currency_field="currency_id", readonly=True)
    credits_issued_today = fields.Monetary(currency_field="currency_id", readonly=True)
    credits_redeemed_today = fields.Monetary(
        currency_field="currency_id", readonly=True
    )
    pending_returns = fields.Integer(readonly=True)
    expired_credits = fields.Monetary(currency_field="currency_id", readonly=True)
    outstanding_credits = fields.Monetary(currency_field="currency_id", readonly=True)

    avg_return_value = fields.Monetary(currency_field="currency_id", readonly=True)
    avg_redemption_value = fields.Monetary(currency_field="currency_id", readonly=True)
    return_pct = fields.Float(string="Return %", digits=(16, 2), readonly=True)
    voucher_util_pct = fields.Float(string="Voucher Utilization %", digits=(16, 2))
    expiry_pct = fields.Float(string="Expiry %", digits=(16, 2))

    line_ids = fields.One2many(
        comodel_name="pos.report.dashboard.line",
        inverse_name="dashboard_id",
        readonly=True,
    )

    @api.model
    def default_get(self, fields_list):
        vals = super().default_get(fields_list)
        today = fields.Date.context_today(self)
        vals.setdefault("date_preset", "this_month")
        vals.setdefault("date_from", today.replace(day=1))
        vals.setdefault("date_to", today)
        return vals

    @api.model
    def action_open_dashboard(self):
        dashboard = self.create({})
        dashboard._load_metrics()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Executive Dashboard"),
            "res_model": "pos.report.dashboard",
            "view_mode": "form",
            "res_id": dashboard.id,
            "target": "current",
        }

    @api.onchange("date_preset")
    def _onchange_date_preset(self):
        if self.date_preset == "custom":
            return
        start, end = self.env["pos.report.mixin"]._report_date_range(self.date_preset)
        if start and end:
            self.date_from = start.date()
            self.date_to = end.date()

    def action_apply_filters(self):
        self.ensure_one()
        self._load_metrics()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Executive Dashboard"),
            "res_model": "pos.report.dashboard",
            "view_mode": "form",
            "res_id": self.id,
            "target": "current",
        }

    def _filter_payload(self):
        self.ensure_one()
        return {
            "date_from": self.date_from,
            "date_to": self.date_to,
            "company_id": self.company_id.id,
            "config_id": self.config_id.id if self.config_id else False,
            "board_code": "executive",
        }

    def _load_metrics(self):
        self.ensure_one()
        data = self.env["pos.report.dashboard.service"].get_all_widgets(
            self._filter_payload()
        )
        cards = data["cards"]
        kpis = data["kpis"]
        self.write(
            {
                "returns_today": cards["returns_today"],
                "refund_today": cards["refund_today"],
                "outstanding_liability": cards["outstanding_liability"],
                "credits_issued_today": cards["credits_issued_today"],
                "credits_redeemed_today": cards["credits_redeemed_today"],
                "pending_returns": cards["pending_returns"],
                "expired_credits": cards["expired_credits"],
                "outstanding_credits": cards["outstanding_credits"],
                "avg_return_value": kpis["avg_return_value"],
                "avg_redemption_value": kpis["avg_redemption_value"],
                "return_pct": kpis["return_pct"],
                "voucher_util_pct": kpis["voucher_util_pct"],
                "expiry_pct": kpis["expiry_pct"],
            }
        )
        self.line_ids.unlink()
        lines = []
        seq = 10

        def _add_lines(chart_key, chart_type, rows):
            nonlocal seq
            for row in rows:
                lines.append(
                    {
                        "dashboard_id": self.id,
                        "sequence": seq,
                        "chart_type": chart_type,
                        "label": str(row.get("label") or ""),
                        "count_value": int(row.get("count") or 0),
                        "amount": row.get("amount") or 0.0,
                    }
                )
                seq += 10

        charts = data["charts"]
        _add_lines("return_trend", "return_trend", charts["return_trend"])
        _add_lines("liability_trend", "liability_trend", charts["liability_trend"])
        _add_lines("voucher_usage", "voucher_usage", charts["voucher_usage"])
        _add_lines("top_branch", "top_branch", charts["top_branches"])
        _add_lines("top_cashier", "top_cashier", charts["top_cashiers"])
        _add_lines("top_customer", "top_customer", charts["top_customers"])
        if lines:
            self.env["pos.report.dashboard.line"].create(lines)

    def _drill_domain(self, model_name, date_field="create_date"):
        filter_svc = self.env["pos.report.filter.service"]
        domain = filter_svc.merge_domain(
            model_name,
            self.env["pos.report.dashboard.service"]._extra_domain(
                model_name, self.config_id.id if self.config_id else False
            ),
        )
        dt_from = fields.Datetime.to_datetime(self.date_from)
        dt_to = fields.Datetime.to_datetime(self.date_to) + timedelta(
            days=1, seconds=-1
        )
        return domain + [
            (date_field, ">=", dt_from),
            (date_field, "<=", dt_to),
        ]

    def action_open_returns_today(self):
        today = fields.Date.context_today(self)
        dt_start = fields.Datetime.to_datetime(today)
        dt_end = dt_start + timedelta(days=1, seconds=-1)
        domain = self.env["pos.report.filter.service"].merge_domain(
            "pos.return.transaction",
            self.env["pos.report.dashboard.service"]._extra_domain(
                "pos.return.transaction",
                self.config_id.id if self.config_id else False,
            ),
        ) + [("return_date", ">=", dt_start), ("return_date", "<=", dt_end)]
        return self._window("pos.return.transaction", _("Today's Returns"), domain)

    def action_open_refunds_today(self):
        return self.action_open_returns_today()

    def action_open_outstanding_credits(self):
        domain = self.env["pos.report.filter.service"].merge_domain(
            "store.credit",
            self.env["pos.report.dashboard.service"]._extra_domain(
                "store.credit", self.config_id.id if self.config_id else False
            ),
        ) + [
            ("state", "in", ("issued", "partially_used")),
            ("amount_remaining", ">", 0),
        ]
        return self._window("store.credit", _("Outstanding Credits"), domain)

    def action_open_pending_returns(self):
        domain = self.env["pos.report.filter.service"].merge_domain(
            "pos.return.transaction",
            self.env["pos.report.dashboard.service"]._extra_domain(
                "pos.return.transaction",
                self.config_id.id if self.config_id else False,
            ),
        ) + [
            ("state", "!=", "cancelled"),
            "|",
            ("state", "in", ("draft", "waiting_approval", "approved")),
            ("settlement_state", "=", "pending"),
        ]
        return self._window("pos.return.transaction", _("Pending Returns"), domain)

    def action_open_expired_credits(self):
        domain = self.env["pos.report.filter.service"].merge_domain(
            "store.credit",
            self.env["pos.report.dashboard.service"]._extra_domain(
                "store.credit", self.config_id.id if self.config_id else False
            ),
        ) + [("state", "=", "expired")]
        return self._window("store.credit", _("Expired Credits"), domain)

    def action_open_return_trend_chart(self):
        return self._chart_action(
            "pos.return.transaction",
            _("Return Trend"),
            "return_date",
            "refund_amount",
        )

    def action_open_liability_chart(self):
        return self._chart_action(
            "store.credit",
            _("Liability Trend"),
            "issue_date:month",
            "amount_remaining",
            extra=[("amount_remaining", ">", 0)],
        )

    def action_open_voucher_chart(self):
        return self._chart_action(
            "store.credit.payment",
            _("Voucher Usage"),
            "create_date:week",
            "amount",
            extra=[("state", "=", "posted")],
        )

    def _chart_action(self, model, title, groupby, measure, extra=None):
        domain = self._drill_domain(
            model,
            "return_date" if model == "pos.return.transaction" else "create_date",
        )
        if extra:
            domain = domain + list(extra)
        return {
            "type": "ir.actions.act_window",
            "name": title,
            "res_model": model,
            "view_mode": "graph,pivot,list",
            "domain": domain,
            "context": {
                "graph_measure": measure,
                "graph_groupbys": [groupby],
            },
        }

    def _window(self, model, title, domain):
        return {
            "type": "ir.actions.act_window",
            "name": title,
            "res_model": model,
            "view_mode": "list,form",
            "domain": domain,
        }
