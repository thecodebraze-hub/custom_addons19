# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Reporting",
    "version": "19.0.2.0.0",
    "category": "Sales/Point of Sale",
    "summary": "Return, exchange and store credit reporting for retail POS",
    "description": """
CodeBraze POS Reporting
=======================
Interactive backend reports with pivot, graph, executive dashboard,
customer statements, PDF/Excel/CSV export and scheduled email delivery.
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "codebraze_pos_administration",
    ],
    "data": [
        "security/reporting_security.xml",
        "security/ir.model.access.csv",
        "security/ir_rule.xml",
        "views/return_summary_views.xml",
        "views/return_item_views.xml",
        "views/exchange_report_views.xml",
        "views/return_reason_analysis_views.xml",
        "views/dashboard_views.xml",
        "views/customer_statement_views.xml",
        "views/schedule_views.xml",
        "report/return_reports.xml",
        "report/customer_statement_reports.xml",
        "data/server_actions.xml",
        "data/cron.xml",
        "data/mail_templates.xml",
        "wizards/pos_report_export_wizard_views.xml",
        "views/reporting_menus.xml",
    ],
    "post_init_hook": "post_init_hook",
    "application": False,
    "installable": True,
    "auto_install": False,
}
