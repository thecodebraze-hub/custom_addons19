# -*- coding: utf-8 -*-
"""Customer store credit statement wizard."""

import base64
from datetime import timedelta

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class PosCustomerStatementWizard(models.TransientModel):
    _name = "pos.customer.statement.wizard"
    _description = "Customer Store Credit Statement Wizard"

    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Customer",
        required=True,
    )
    date_from = fields.Date(required=True)
    date_to = fields.Date(required=True, default=fields.Date.context_today)
    company_id = fields.Many2one(
        comodel_name="res.company",
        default=lambda self: self.env.company,
    )

    @api.model
    def default_get(self, fields_list):
        vals = super().default_get(fields_list)
        today = fields.Date.context_today(self)
        vals.setdefault("date_from", today.replace(day=1))
        vals.setdefault("date_to", today)
        partner_id = self.env.context.get("default_partner_id")
        if partner_id:
            vals.setdefault("partner_id", partner_id)
        return vals

    def _statement_data(self):
        self.ensure_one()
        return self.env["pos.customer.statement.service"].build_statement(
            self.partner_id, self.date_from, self.date_to
        )

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref(
            "codebraze_pos_reporting.action_report_customer_statement_pdf"
        ).report_action(self)

    def action_export_csv(self):
        self.ensure_one()
        return self.env["pos.report.export.service"].export_customer_statement(
            self.partner_id,
            self.date_from,
            self.date_to,
            export_format="csv",
        )

    def action_export_xlsx(self):
        self.ensure_one()
        return self.env["pos.report.export.service"].export_customer_statement(
            self.partner_id,
            self.date_from,
            self.date_to,
            export_format="xlsx",
        )

    def _create_pdf_attachment(self):
        self.ensure_one()
        pdf_content, _ = self.env["ir.actions.report"]._render_qweb_pdf(
            "codebraze_pos_reporting.report_customer_statement_document",
            self.ids,
        )
        filename = "Customer_Statement_%s_%s.pdf" % (
            self.partner_id.name.replace(" ", "_")[:40],
            fields.Date.to_string(self.date_to),
        )
        return self.env["ir.attachment"].create(
            {
                "name": filename,
                "type": "binary",
                "datas": base64.b64encode(pdf_content),
                "mimetype": "application/pdf",
                "res_model": self._name,
                "res_id": self.id,
            }
        )


class ReportCustomerStatement(models.AbstractModel):
    _name = "report.codebraze_pos_reporting.report_customer_statement_document"
    _description = "Customer Store Credit Statement QWeb Report"

    @api.model
    def _get_report_values(self, docids, data=None):
        wizard = self.env["pos.customer.statement.wizard"].browse(docids)
        wizard.ensure_one()
        statement = self.env["pos.customer.statement.service"].build_statement(
            wizard.partner_id, wizard.date_from, wizard.date_to
        )
        return {
            "doc_ids": docids,
            "doc_model": "pos.customer.statement.wizard",
            "docs": wizard,
            "statement": statement,
        }
