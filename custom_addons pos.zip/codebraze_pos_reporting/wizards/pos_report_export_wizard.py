# -*- coding: utf-8 -*-

from odoo import fields, models


class PosReportExportWizard(models.TransientModel):
    _name = "pos.report.export.wizard"
    _description = "POS Report Export Wizard"

    export_format = fields.Selection(
        selection=[
            ("csv", "CSV"),
            ("xlsx", "Excel"),
        ],
        required=True,
        default="csv",
    )

    def action_export(self):
        self.ensure_one()
        return self.env["pos.report.export.service"].with_context(
            self.env.context
        ).action_export_from_context(self.export_format)
