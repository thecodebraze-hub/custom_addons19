# -*- coding: utf-8 -*-

from odoo import fields, models


class PosConfig(models.Model):
    _inherit = "pos.config"

    approval_override_level = fields.Selection(
        selection=[
            ("", "Use Rules"),
            ("supervisor", "Supervisor"),
            ("store_manager", "Store Manager"),
            ("regional_manager", "Regional Manager"),
            ("administrator", "Administrator"),
        ],
        string="Minimum Approval Level Override",
        help="Optional branch-level minimum approval level override.",
    )
