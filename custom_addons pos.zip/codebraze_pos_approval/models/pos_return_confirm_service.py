# -*- coding: utf-8 -*-
"""Wire return confirmation into the generic approval engine."""

from odoo import api, fields, models


class PosReturnConfirmServiceApproval(models.Model):
    _inherit = "pos.return.transaction"

    @api.model
    def _validate_confirm_payload(
        self, order, lines_payload, config, session, payload, refund_method
    ):
        result = super()._validate_confirm_payload(
            order, lines_payload, config, session, payload, refund_method
        )
        if not result.get("valid"):
            return result

        exception_codes = []
        if result.get("period_expired"):
            exception_codes.append("return_outside_days")
        if payload.get("manual_price_adjustment"):
            exception_codes.append("price_difference")
        if not order:
            exception_codes.append("return_without_invoice")

        customer_type = "guest"
        if order.partner_id:
            customer_type = (
                "b2b"
                if order.partner_id.is_company
                else "registered"
            )

        eval_ctx = {
            "approval_type": "return_approval",
            "amount": result.get("total_refund", 0.0),
            "currency_id": order.currency_id.id,
            "config_id": config.id,
            "company_id": config.company_id.id,
            "return_days": (
                max((fields.Datetime.now() - order.date_order).days, 0)
                if order.date_order
                else 0
            ),
            "return_days_exceeded": result.get("period_expired"),
            "return_without_invoice": not bool(order),
            "customer_type": customer_type,
            "price_override": payload.get("manual_price_adjustment"),
            "exception_codes": exception_codes,
        }
        evaluation = self.env["pos.approval.service"].evaluate(eval_ctx)
        if evaluation.get("required"):
            result["approval_required"] = True
            reasons = list(result.get("approval_reasons") or [])
            for reason in evaluation.get("reasons", []):
                if reason not in reasons:
                    reasons.append(reason)
            result["approval_reasons"] = reasons
            result["approval_min_level"] = evaluation.get("min_level")
        return result
