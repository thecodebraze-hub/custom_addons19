# -*- coding: utf-8 -*-
"""Central approval orchestration service."""

import json
import logging
from datetime import timedelta

from odoo import api, fields, models
from odoo.exceptions import AccessError, UserError
from odoo.tools import float_compare

from .pos_approval_rule import APPROVAL_LEVEL_RANK, LEGACY_TYPE_MAP

_logger = logging.getLogger(__name__)

PENDING_STATES = ("pending", "requested")


class PosApprovalService(models.AbstractModel):
    _name = "pos.approval.service"
    _description = "POS Approval Service"

    # -------------------------------------------------------------------------
    # Level helpers
    # -------------------------------------------------------------------------

    @api.model
    def _get_user_approval_level(self, user=None):
        user = user or self.env.user
        if user.has_group("codebraze_pos_approval.group_approval_administrator"):
            return "administrator"
        if user.has_group("codebraze_pos_administration.group_sc_administrator"):
            return "administrator"
        if user.has_group("codebraze_pos_approval.group_approval_regional_manager"):
            return "regional_manager"
        if user.has_group("codebraze_pos_approval.group_approval_manager"):
            return "store_manager"
        if user.has_group("codebraze_pos_administration.group_sc_manager"):
            return "store_manager"
        if user.has_group("point_of_sale.group_pos_manager"):
            return "store_manager"
        if user.has_group("codebraze_pos_approval.group_approval_supervisor"):
            return "supervisor"
        if user.has_group("codebraze_pos_administration.group_sc_supervisor"):
            return "supervisor"
        return "cashier"

    @api.model
    def _check_user_level(self, user, required_level):
        user_level = self._get_user_approval_level(user)
        if APPROVAL_LEVEL_RANK.get(user_level, 0) < APPROVAL_LEVEL_RANK.get(
            required_level, 99
        ):
            raise AccessError(
                self.env._(
                    "User does not meet the required approval level (%(level)s).",
                    level=required_level,
                )
            )
        return True

    # -------------------------------------------------------------------------
    # Evaluation
    # -------------------------------------------------------------------------

    @api.model
    def evaluate(self, context):
        """Return whether approval is required and why."""
        context = dict(context or {})
        company_id = context.get("company_id") or self.env.company.id
        config = self.env["pos.config"].browse(context.get("config_id")).exists()
        settings = self.env["store.credit.settings"]._get_settings(
            company=self.env["res.company"].browse(company_id),
            config=config,
        )
        reasons = []
        exception_codes = list(context.get("exception_codes") or [])
        min_level = "supervisor"
        matched_rules = self.env["pos.approval.rule"].find_matching_rules(context)

        for rule in matched_rules:
            if APPROVAL_LEVEL_RANK.get(rule.required_level, 0) > APPROVAL_LEVEL_RANK.get(
                min_level, 0
            ):
                min_level = rule.required_level
            reasons.append(
                self.env._("Rule %(name)s requires %(level)s approval.", name=rule.name, level=rule.required_level)
            )
            if rule.exception_code:
                exception_codes.append(rule.exception_code)

        legacy = self._evaluate_legacy_settings(context, settings)
        if legacy.get("required"):
            reasons.extend(legacy.get("reasons", []))
            legacy_level = legacy.get("min_level")
            if legacy_level and APPROVAL_LEVEL_RANK.get(legacy_level, 0) > APPROVAL_LEVEL_RANK.get(
                min_level, 0
            ):
                min_level = legacy_level
            exception_codes.extend(legacy.get("exception_codes", []))

        required = bool(matched_rules) or legacy.get("required", False)
        auto_approve = matched_rules and all(rule.auto_approve for rule in matched_rules)

        return {
            "required": required and not auto_approve,
            "auto_approve": auto_approve,
            "reasons": reasons,
            "rule_ids": matched_rules.ids,
            "min_level": min_level,
            "exception_codes": list(dict.fromkeys(exception_codes)),
        }

    @api.model
    def _evaluate_legacy_settings(self, context, settings):
        """Bridge existing store credit / return settings into the engine."""
        if not settings:
            return {"required": False, "reasons": [], "exception_codes": []}

        approval_type = self.env["pos.approval.rule"]._normalize_approval_type(
            context.get("approval_type")
        )
        amount = float(context.get("amount") or 0.0)
        currency = self.env["res.currency"].browse(
            context.get("currency_id") or settings.currency_id.id
        )
        reasons = []
        exception_codes = []
        required = False
        min_level = "supervisor"

        def _above_threshold(threshold):
            if not threshold:
                return False
            return (
                float_compare(
                    amount,
                    threshold,
                    precision_rounding=currency.rounding,
                )
                >= 0
            )

        if approval_type == "return_approval":
            if getattr(settings, "manager_approval", False) or getattr(
                settings, "manager_approval_required", False
            ):
                required = True
                reasons.append(self.env._("Manager approval required by policy."))
            limit = getattr(settings, "approval_amount", 0.0) or getattr(
                settings, "approval_amount_limit", 0.0
            )
            if _above_threshold(limit):
                required = True
                reasons.append(self.env._("Manager approval required for high-value returns."))
                exception_codes.append("high_value")
            if context.get("return_days_exceeded"):
                required = True
                reasons.append(
                    self.env._("Return period has expired. Manager approval required.")
                )
                exception_codes.append("return_outside_days")
            if context.get("return_without_invoice") and getattr(
                settings, "approval_for_return_without_invoice", False
            ):
                required = True
                reasons.append(self.env._("Return without invoice requires approval."))
                exception_codes.append("return_without_invoice")

        elif approval_type == "refund_approval":
            limit = getattr(settings, "approval_amount", 0.0) or getattr(
                settings, "approval_amount_limit", 0.0
            )
            if _above_threshold(limit):
                required = True
                reasons.append(self.env._("Manager approval required for high-value refunds."))
                exception_codes.append("high_value")

        elif approval_type == "manual_adjustment":
            if getattr(settings, "approval_for_manual_adjustment", False):
                required = True
                reasons.append(self.env._("Manual adjustment requires manager approval."))
            if amount < 0:
                exception_codes.append("negative_adjustment")
                required = True
                reasons.append(self.env._("Negative adjustment requires approval."))

        elif approval_type == "voucher_cancellation":
            if context.get("voucher_cancelled") and getattr(
                settings, "approval_for_cancel_voucher", False
            ):
                required = True
                reasons.append(self.env._("Cancelled voucher override requires approval."))
                exception_codes.append("voucher_cancelled")

        elif approval_type in ("voucher_approval", "voucher_extension"):
            if context.get("voucher_expired") and getattr(
                settings, "approval_for_expired_voucher", False
            ):
                required = True
                reasons.append(self.env._("Expired voucher requires manager approval."))
                exception_codes.append("voucher_expired")

        if context.get("price_override"):
            required = True
            reasons.append(self.env._("Price override requires manager approval."))
            exception_codes.append("price_difference")
            min_level = "store_manager"

        if context.get("discount_override"):
            required = True
            reasons.append(self.env._("Discount override requires manager approval."))
            min_level = "supervisor"

        if context.get("duplicate_redemption"):
            required = True
            reasons.append(self.env._("Duplicate redemption detected."))
            exception_codes.append("duplicate_redemption")

        return {
            "required": required,
            "reasons": reasons,
            "exception_codes": exception_codes,
            "min_level": min_level,
        }

    # -------------------------------------------------------------------------
    # Request lifecycle
    # -------------------------------------------------------------------------

    @api.model
    def create_request(self, vals):
        evaluation = self.evaluate(vals)
        vals = dict(vals or {})
        vals.setdefault("required_level", evaluation.get("min_level", "supervisor"))
        vals.setdefault("exception_codes", evaluation.get("exception_codes"))
        if evaluation.get("rule_ids"):
            vals.setdefault("reason", "; ".join(evaluation.get("reasons", [])))
        expiry_hours = vals.pop("expiry_hours", 24)
        if expiry_hours and not vals.get("expiry_datetime"):
            vals["expiry_datetime"] = fields.Datetime.now() + timedelta(hours=expiry_hours)
        return self.env["pos.approval.history"]._create_approval(vals)

    @api.model
    def ensure_approved(self, context, payload=None):
        """Validate that approval exists or payload carries manager authorization."""
        payload = payload or {}
        evaluation = self.evaluate(context)
        if not evaluation.get("required"):
            return {"valid": True, "approval_required": False}

        if payload.get("manager_approved") and payload.get("manager_id"):
            manager = self.env["res.users"].browse(payload["manager_id"]).exists()
            if manager:
                self._check_user_level(manager, evaluation.get("min_level", "supervisor"))
                return {
                    "valid": True,
                    "approval_required": True,
                    "manager_id": manager.id,
                }

        approval_uuid = payload.get("approval_uuid")
        if approval_uuid:
            approval = self.env["pos.approval.history"].search(
                [("uuid", "=", approval_uuid), ("state", "=", "approved")],
                limit=1,
            )
            if approval:
                return {
                    "valid": True,
                    "approval_required": True,
                    "approval_id": approval.id,
                    "manager_id": approval.approver_id.id,
                }

        return {
            "valid": False,
            "approval_required": True,
            "approval_reasons": evaluation.get("reasons", []),
            "min_level": evaluation.get("min_level"),
            "error_code": "approval_required",
            "error": self.env._("Manager approval required."),
        }

    # -------------------------------------------------------------------------
    # POS RPC
    # -------------------------------------------------------------------------

    @api.model
    def pos_evaluate(self, context, config_id=False):
        config = self.env["pos.config"].browse(config_id).exists()
        context = dict(context or {})
        if config:
            context.setdefault("config_id", config.id)
            context.setdefault("company_id", config.company_id.id)
        return self.evaluate(context)

    @api.model
    def pos_authenticate_and_approve(self, payload, config_id=False, session_id=False):
        """Authenticate a manager and optionally approve a pending request."""
        payload = dict(payload or {})
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        auth_service = self.env["pos.approval.auth.service"]
        auth = auth_service.authenticate(
            method=payload.get("auth_method", "pin"),
            credentials=payload.get("credentials") or {},
            config=config,
            required_level=payload.get("required_level", "supervisor"),
        )
        if not auth.get("success"):
            self.env["pos.approval.audit"]._log_event(
                action="manager_login_failed",
                user_id=self.env.user.id,
                auth_method=payload.get("auth_method"),
                reason=auth.get("error"),
                metadata={"config_id": config.id if config else False},
            )
            return auth

        manager = self.env["res.users"].browse(auth["manager_id"]).exists()
        approval_uuid = payload.get("approval_uuid")
        approval = False
        if approval_uuid:
            approval = self.env["pos.approval.history"].search(
                [("uuid", "=", approval_uuid)],
                limit=1,
            )
        elif payload.get("create_request"):
            approval = self.create_request(
                {
                    **(payload.get("request_vals") or {}),
                    "config_id": config.id if config else False,
                    "session_id": session.id if session else False,
                    "company_id": config.company_id.id if config else self.env.company.id,
                }
            )

        if payload.get("action") == "reject" and approval:
            approval.action_reject(approver=manager, notes=payload.get("notes"))
        elif approval and approval._is_pending_state(approval.state):
            approval.action_approve(
                approver=manager,
                auth_method=payload.get("auth_method"),
                notes=payload.get("notes"),
            )
        elif payload.get("action") == "approve" and not approval:
            pass

        self.env["pos.approval.audit"]._log_event(
            action="manager_login",
            user_id=self.env.user.id,
            manager_id=manager.id,
            auth_method=payload.get("auth_method"),
            approval_id=approval.id if approval else False,
            metadata={"session_id": session.id if session else False},
        )

        return {
            "success": True,
            "manager_id": manager.id,
            "manager_name": manager.name,
            "approval_uuid": approval.uuid if approval else False,
            "approval_id": approval.id if approval else False,
            "auth_method": payload.get("auth_method"),
        }

    @api.model
    def pos_get_auth_config(self, config_id):
        config = self.env["pos.config"].browse(config_id).exists()
        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id if config else self.env.company,
            config=config,
        )
        methods = []
        if settings:
            if settings.approval_auth_pin:
                methods.append("pin")
            if settings.approval_auth_password:
                methods.append("password")
            if settings.approval_auth_barcode:
                methods.append("badge")
            if settings.approval_auth_employee_card:
                methods.append("employee_card")
        if not methods:
            methods = ["pin", "badge"]
        return {
            "auth_methods": methods,
            "default_method": methods[0],
            "manager_notification": getattr(settings, "manager_notification", False),
        }
