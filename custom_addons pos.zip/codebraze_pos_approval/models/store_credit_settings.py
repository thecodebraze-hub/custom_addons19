# -*- coding: utf-8 -*-

from odoo import fields, models


class StoreCreditSettings(models.Model):
    _inherit = "store.credit.settings"

    approval_auth_pin = fields.Boolean(string="PIN Authentication", default=True)
    approval_auth_password = fields.Boolean(string="Password Authentication", default=False)
    approval_auth_barcode = fields.Boolean(string="Barcode Authentication", default=True)
    approval_auth_employee_card = fields.Boolean(
        string="Employee Card Authentication",
        default=True,
    )
    approval_request_expiry_hours = fields.Integer(
        string="Approval Request Expiry (Hours)",
        default=24,
    )
    manager_notification = fields.Boolean(
        string="Manager Notification",
        default=False,
    )

    def _to_pos_approval_dict(self):
        data = super()._to_pos_dict() if hasattr(super(), "_to_pos_dict") else {}
        data.update(
            {
                "approval_auth_pin": self.approval_auth_pin,
                "approval_auth_password": self.approval_auth_password,
                "approval_auth_barcode": self.approval_auth_barcode,
                "approval_auth_employee_card": self.approval_auth_employee_card,
                "approval_request_expiry_hours": self.approval_request_expiry_hours,
                "manager_notification": self.manager_notification,
            }
        )
        return data
