# -*- coding: utf-8 -*-
"""Exception log linked to approval requests."""

from odoo import api, fields, models

from .pos_approval_rule import EXCEPTION_CODE_SELECTION


class PosExceptionLog(models.Model):
    _name = "pos.exception.log"
    _description = "POS Exception Log"
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
    )
    exception_code = fields.Selection(
        selection=EXCEPTION_CODE_SELECTION,
        required=True,
        index=True,
    )
    description = fields.Text(string="Description")
    state = fields.Selection(
        selection=[
            ("open", "Open"),
            ("resolved", "Resolved"),
            ("ignored", "Ignored"),
        ],
        default="open",
        required=True,
        index=True,
    )
    approval_id = fields.Many2one(
        comodel_name="pos.approval.history",
        string="Approval Request",
        index=True,
        ondelete="set null",
    )
    return_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        index=True,
        ondelete="set null",
        check_company=True,
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        index=True,
        ondelete="set null",
        check_company=True,
    )
    voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        index=True,
        ondelete="set null",
        check_company=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
    )
    resolved_by_id = fields.Many2one(comodel_name="res.users", string="Resolved By")
    resolved_datetime = fields.Datetime(string="Resolved On")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "New") == "New":
                vals["name"] = (
                    self.env["ir.sequence"].next_by_code("pos.exception.log")
                    or f"EXC/{fields.Datetime.now()}"
                )
        return super().create(vals_list)

    def action_resolve(self):
        for rec in self:
            rec.write(
                {
                    "state": "resolved",
                    "resolved_by_id": self.env.user.id,
                    "resolved_datetime": fields.Datetime.now(),
                }
            )
        return True
