# -*- coding: utf-8 -*-
"""Dedicated audit log for approval workflow events."""

import json
import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class PosApprovalAudit(models.Model):
    _name = "pos.approval.audit"
    _description = "POS Approval Audit"
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
    )
    approval_id = fields.Many2one(
        comodel_name="pos.approval.history",
        string="Approval Request",
        index=True,
        ondelete="cascade",
    )
    action = fields.Selection(
        selection=[
            ("request_created", "Request Created"),
            ("approved", "Approved"),
            ("rejected", "Rejected"),
            ("cancelled", "Cancelled"),
            ("expired", "Expired"),
            ("override", "Override"),
            ("manager_login", "Manager Login"),
            ("manager_login_failed", "Manager Login Failed"),
            ("modified", "Modified"),
            ("force_complete", "Force Complete"),
        ],
        required=True,
        index=True,
    )
    user_id = fields.Many2one(comodel_name="res.users", string="User", index=True)
    manager_id = fields.Many2one(comodel_name="res.users", string="Manager", index=True)
    auth_method = fields.Char(string="Auth Method")
    reason = fields.Char(string="Reason")
    notes = fields.Text(string="Notes")
    metadata = fields.Text(string="Metadata (JSON)")
    company_id = fields.Many2one(
        comodel_name="res.company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "New") == "New":
                vals["name"] = (
                    self.env["ir.sequence"].next_by_code("pos.approval.audit")
                    or f"AUD/{fields.Datetime.now()}"
                )
            metadata = vals.get("metadata")
            if isinstance(metadata, dict):
                vals["metadata"] = json.dumps(metadata)
        return super().create(vals_list)

    @api.model
    def _log_event(self, action, **kwargs):
        approval = self.env["pos.approval.history"].browse(kwargs.get("approval_id")).exists()
        vals = {
            "action": action,
            "approval_id": approval.id if approval else False,
            "user_id": kwargs.get("user_id") or self.env.user.id,
            "manager_id": kwargs.get("manager_id"),
            "auth_method": kwargs.get("auth_method"),
            "reason": kwargs.get("reason"),
            "notes": kwargs.get("notes"),
            "metadata": kwargs.get("metadata"),
            "company_id": approval.company_id.id
            if approval
            else kwargs.get("company_id") or self.env.company.id,
            "config_id": approval.config_id.id if approval else kwargs.get("config_id"),
        }
        return self.create(vals)
