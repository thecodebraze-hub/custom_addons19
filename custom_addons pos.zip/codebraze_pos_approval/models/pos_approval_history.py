# -*- coding: utf-8 -*-
"""Extended approval request model — generic across POS workflows."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

from .pos_approval_rule import (
    APPROVAL_LEVEL_RANK,
    APPROVAL_LEVEL_SELECTION,
    APPROVAL_TYPE_SELECTION,
    EXCEPTION_CODE_SELECTION,
)

_logger = logging.getLogger(__name__)

PENDING_STATES = ("pending", "requested")


class PosApprovalHistory(models.Model):
    _inherit = ["pos.approval.history", "mail.thread", "mail.activity.mixin"]

    state = fields.Selection(
        selection=[
            ("pending", "Pending"),
            ("approved", "Approved"),
            ("rejected", "Rejected"),
            ("cancelled", "Cancelled"),
            ("expired", "Expired"),
        ],
        string="Status",
        default="pending",
        required=True,
        tracking=True,
        index=True,
    )
    approval_type = fields.Selection(
        selection=APPROVAL_TYPE_SELECTION,
        required=True,
        index=True,
    )
    required_level = fields.Selection(
        selection=APPROVAL_LEVEL_SELECTION,
        string="Required Level",
        default="supervisor",
        index=True,
    )
    exception_codes = fields.Char(
        string="Exceptions",
        help="Comma-separated exception codes linked to this request.",
    )
    manager_notes = fields.Text(string="Manager Notes", tracking=True)
    modified_payload = fields.Text(
        string="Modified Payload",
        help="JSON payload when a manager modifies the original request.",
    )
    force_completed = fields.Boolean(string="Force Completed", default=False)
    expiry_datetime = fields.Datetime(string="Expires On", index=True)
    voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Voucher",
        index=True,
        ondelete="set null",
        check_company=True,
    )
    audit_ids = fields.One2many(
        comodel_name="pos.approval.audit",
        inverse_name="approval_id",
        string="Audit Trail",
    )
    exception_ids = fields.One2many(
        comodel_name="pos.exception.log",
        inverse_name="approval_id",
        string="Exceptions",
    )
    exception_count = fields.Integer(compute="_compute_exception_count")

    @api.depends("exception_ids")
    def _compute_exception_count(self):
        for approval in self:
            approval.exception_count = len(approval.exception_ids)

    auth_method = fields.Selection(
        selection_add=[
            ("password", "Password"),
            ("employee_card", "Employee Card"),
        ],
    )

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    @api.model
    def _is_pending_state(self, state):
        return state in PENDING_STATES

    def _log_approval_audit(self, action, **kwargs):
        Audit = self.env["pos.approval.audit"]
        for approval in self:
            Audit._log_event(
                approval_id=approval.id,
                action=action,
                user_id=kwargs.get("user_id", self.env.user.id),
                manager_id=kwargs.get("manager_id"),
                auth_method=kwargs.get("auth_method") or approval.auth_method,
                reason=kwargs.get("reason") or approval.reason,
                notes=kwargs.get("notes") or approval.manager_notes,
                metadata=kwargs.get("metadata"),
            )

    def _notify_managers(self, event):
        settings = self.env["store.credit.settings"]._get_settings(
            company=self.company_id,
            config=self.config_id,
        )
        if not settings or not getattr(settings, "manager_notification", False):
            return
        subtype = self.env.ref(
            "codebraze_pos_approval.mt_approval_pending",
            raise_if_not_found=False,
        )
        for approval in self:
            partners = approval._get_manager_partner_ids()
            if not partners:
                continue
            body = self.env._(
                "Approval %(name)s (%(type)s) is %(event)s.",
                name=approval.name,
                type=dict(approval._fields["approval_type"].selection).get(
                    approval.approval_type, approval.approval_type
                ),
                event=event,
            )
            approval.message_post(
                body=body,
                partner_ids=partners,
                subtype_id=subtype.id if subtype else False,
            )
            approval.notification_sent = True

    def _get_manager_partner_ids(self):
        self.ensure_one()
        group_xmlids = [
            "codebraze_pos_administration.group_sc_manager",
            "codebraze_pos_administration.group_sc_supervisor",
            "codebraze_pos_approval.group_approval_regional_manager",
        ]
        partner_ids = []
        for xmlid in group_xmlids:
            group = self.env.ref(xmlid, raise_if_not_found=False)
            if group:
                partner_ids.extend(group.users.partner_id.ids)
        return list(set(partner_ids))

    # -------------------------------------------------------------------------
    # Workflow actions
    # -------------------------------------------------------------------------

    @api.model
    def _create_approval(self, vals):
        vals = dict(vals or {})
        vals.setdefault("state", "pending")
        if vals.get("state") == "requested":
            vals["state"] = "pending"
        vals.setdefault("requester_id", self.env.user.id)
        exception_codes = vals.pop("exception_codes", None)
        if isinstance(exception_codes, (list, tuple, set)):
            vals["exception_codes"] = ",".join(exception_codes)
        approval = super()._create_approval(vals)
        if exception_codes:
            approval._sync_exception_logs(exception_codes)
        approval._log_approval_audit("request_created")
        approval._notify_managers("pending")
        return approval

    def _sync_exception_logs(self, codes):
        ExceptionLog = self.env["pos.exception.log"]
        for approval in self:
            for code in codes:
                if not code:
                    continue
                ExceptionLog.create(
                    {
                        "approval_id": approval.id,
                        "exception_code": code,
                        "description": approval.reason,
                        "company_id": approval.company_id.id,
                        "config_id": approval.config_id.id,
                        "return_id": approval.return_id.id,
                        "credit_id": approval.credit_id.id,
                        "voucher_id": approval.voucher_id.id,
                    }
                )

    def action_approve(self, approver=None, auth_method=None, notes=None):
        approver = approver or self.env.user
        service = self.env["pos.approval.service"]
        for approval in self:
            if not approval._is_pending_state(approval.state):
                raise UserError(self.env._("Only pending approvals can be approved."))
            service._check_user_level(approver, approval.required_level)
            approval.write(
                {
                    "state": "approved",
                    "approver_id": approver.id,
                    "approve_datetime": fields.Datetime.now(),
                    "auth_method": auth_method or approval.auth_method,
                    "manager_notes": notes or approval.manager_notes,
                }
            )
            if approval.credit_id:
                approval.credit_id._log_audit(
                    action="approval",
                    message=self.env._(
                        "Approval %(name)s approved (%(type)s)",
                        name=approval.name,
                        type=approval.approval_type,
                    ),
                    amount=approval.amount,
                    extra={"manager_id": approver.id},
                )
            approval._log_approval_audit(
                "approved",
                manager_id=approver.id,
                auth_method=auth_method,
                notes=notes,
            )
            approval._notify_managers("approved")
        return True

    def action_reject(self, approver=None, notes=None):
        approver = approver or self.env.user
        for approval in self:
            if not approval._is_pending_state(approval.state):
                raise UserError(self.env._("Only pending approvals can be rejected."))
            approval.write(
                {
                    "state": "rejected",
                    "approver_id": approver.id,
                    "approve_datetime": fields.Datetime.now(),
                    "manager_notes": notes or approval.manager_notes,
                }
            )
            approval._log_approval_audit(
                "rejected",
                manager_id=approver.id,
                notes=notes,
            )
            approval._notify_managers("rejected")
        return True

    def action_cancel(self, notes=None):
        for approval in self:
            if approval.state not in ("pending", "requested", "approved"):
                raise UserError(
                    self.env._("Only pending or approved requests can be cancelled.")
                )
            approval.write(
                {
                    "state": "cancelled",
                    "manager_notes": notes or approval.manager_notes,
                }
            )
            approval._log_approval_audit("cancelled", notes=notes)
        return True

    def action_force_complete(self, approver=None, notes=None):
        approver = approver or self.env.user
        service = self.env["pos.approval.service"]
        for approval in self:
            service._check_user_level(approver, approval.required_level)
            approval.write(
                {
                    "state": "approved",
                    "force_completed": True,
                    "approver_id": approver.id,
                    "approve_datetime": fields.Datetime.now(),
                    "manager_notes": notes or approval.manager_notes,
                }
            )
            approval._log_approval_audit(
                "force_complete",
                manager_id=approver.id,
                notes=notes,
            )
        return True

    def action_modify(self, modified_payload=None, notes=None):
        for approval in self:
            if not approval._is_pending_state(approval.state):
                raise UserError(self.env._("Only pending approvals can be modified."))
            approval.write(
                {
                    "modified_payload": modified_payload or approval.modified_payload,
                    "manager_notes": notes or approval.manager_notes,
                }
            )
            approval._log_approval_audit(
                "modified",
                notes=notes,
                metadata={"modified_payload": modified_payload},
            )
        return True

    @api.model
    def _cron_expire_pending_approvals(self):
        now = fields.Datetime.now()
        pending = self.search(
            [
                ("state", "in", list(PENDING_STATES)),
                ("expiry_datetime", "!=", False),
                ("expiry_datetime", "<", now),
            ]
        )
        for approval in pending:
            approval.write({"state": "expired"})
            approval._log_approval_audit("expired")
        return True
