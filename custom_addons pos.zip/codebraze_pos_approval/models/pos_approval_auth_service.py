# -*- coding: utf-8 -*-
"""Manager authentication for POS approval popups."""

import logging

from odoo import api, models
from odoo.exceptions import AccessError

_logger = logging.getLogger(__name__)


class PosApprovalAuthService(models.AbstractModel):
    _name = "pos.approval.auth.service"
    _description = "POS Approval Authentication Service"

    @api.model
    def authenticate(self, method, credentials, config=None, required_level="supervisor"):
        credentials = credentials or {}
        method = method or "pin"
        approval_service = self.env["pos.approval.service"]

        if method == "pin":
            user = self._authenticate_pin(credentials.get("pin"), config)
        elif method == "password":
            user = self._authenticate_password(
                credentials.get("login"),
                credentials.get("password"),
            )
        elif method in ("badge", "employee_card"):
            user = self._authenticate_barcode(
                credentials.get("barcode"),
                config,
            )
        else:
            return {
                "success": False,
                "error": self.env._("Unsupported authentication method."),
            }

        if not user:
            return {
                "success": False,
                "error": self.env._("Manager authentication failed."),
            }

        try:
            approval_service._check_user_level(user, required_level)
        except AccessError as exc:
            return {"success": False, "error": str(exc)}

        return {"success": True, "manager_id": user.id, "manager_name": user.name}

    @api.model
    def _authenticate_pin(self, pin, config=None):
        pin = (pin or "").strip()
        if not pin:
            return False
        domain = [
            ("pin", "=", pin),
            ("active", "=", True),
        ]
        if config:
            domain.append(("company_id", "in", [config.company_id.id, False]))
        employee = self.env["hr.employee"].sudo().search(domain, limit=1)
        if not employee or not employee.user_id:
            return False
        return employee.user_id

    @api.model
    def _authenticate_password(self, login, password):
        login = (login or "").strip()
        password = password or ""
        if not login or not password:
            return False
        try:
            auth_info = self.env["res.users"].sudo().authenticate(
                {
                    "type": "password",
                    "login": login,
                    "password": password,
                },
                {},
            )
            uid = auth_info.get("uid")
        except Exception:
            _logger.info("Manager password authentication failed for %s", login)
            return False
        return self.env["res.users"].browse(uid).exists() if uid else False

    @api.model
    def _authenticate_barcode(self, barcode, config=None):
        barcode = (barcode or "").strip()
        if not barcode:
            return False
        domain = [
            ("barcode", "=", barcode),
            ("active", "=", True),
        ]
        if config:
            domain.append(("company_id", "in", [config.company_id.id, False]))
        employee = self.env["hr.employee"].sudo().search(domain, limit=1)
        if not employee or not employee.user_id:
            return False
        return employee.user_id
