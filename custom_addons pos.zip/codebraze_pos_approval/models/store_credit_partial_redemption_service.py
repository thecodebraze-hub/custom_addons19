# -*- coding: utf-8 -*-
"""Partial redemption approval integration."""

from odoo import api, models
from odoo.tools import float_compare


class StoreCreditPartialRedemptionApproval(models.Model):
    _inherit = "store.credit"

    @api.model
    def _validate_partial_redemption_policy(
        self, credit, amount, settings, payload, balance_before=None
    ):
        result = super()._validate_partial_redemption_policy(
            credit, amount, settings, payload, balance_before=balance_before
        )
        if not result.get("valid"):
            return result

        precision = credit.currency_id.rounding
        balance_before = (
            balance_before if balance_before is not None else credit.amount_remaining
        )
        is_partial = float_compare(amount, balance_before, precision_rounding=precision) < 0
        if not is_partial:
            return result

        exception_codes = []
        if credit.state == "expired":
            exception_codes.append("voucher_expired")
        if credit.state == "cancelled":
            exception_codes.append("voucher_cancelled")

        eval_ctx = {
            "approval_type": "voucher_approval",
            "amount": amount,
            "currency_id": credit.currency_id.id,
            "company_id": credit.company_id.id,
            "voucher_expired": credit.state == "expired",
            "voucher_cancelled": credit.state == "cancelled",
            "exception_codes": exception_codes,
        }
        evaluation = self.env["pos.approval.service"].evaluate(eval_ctx)
        if evaluation.get("required") and not payload.get("manager_approved"):
            return {
                "valid": False,
                "error": self.env._("Manager approval is required for this redemption."),
                "error_code": "approval_required",
                "approval_reasons": evaluation.get("reasons", []),
            }
        return result
