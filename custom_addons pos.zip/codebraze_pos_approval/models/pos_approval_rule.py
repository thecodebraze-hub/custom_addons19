# -*- coding: utf-8 -*-
"""Configurable approval rules for the POS approval engine."""

from odoo import api, fields, models


APPROVAL_TYPE_SELECTION = [
    ("return_approval", "Return Approval"),
    ("voucher_approval", "Voucher Approval"),
    ("manual_credit", "Manual Credit"),
    ("manual_debit", "Manual Debit"),
    ("refund_approval", "Refund Approval"),
    ("price_override", "Price Override"),
    ("discount_override", "Discount Override"),
    ("voucher_reprint", "Voucher Reprint"),
    ("voucher_cancellation", "Voucher Cancellation"),
    ("voucher_extension", "Voucher Extension"),
    ("manual_adjustment", "Manual Adjustment"),
    # Legacy aliases kept for backward compatibility
    ("return_override", "Return Override (Legacy)"),
    ("cash_refund", "Cash Refund (Legacy)"),
    ("void_voucher", "Void Voucher (Legacy)"),
    ("credit_adjust", "Credit Adjustment (Legacy)"),
    ("guest_return", "Guest Return (Legacy)"),
    ("expiry_extend", "Expiry Extension (Legacy)"),
]

APPROVAL_LEVEL_SELECTION = [
    ("cashier", "Cashier"),
    ("supervisor", "Supervisor"),
    ("store_manager", "Store Manager"),
    ("regional_manager", "Regional Manager"),
    ("administrator", "Administrator"),
]

CUSTOMER_TYPE_SELECTION = [
    ("all", "All Customers"),
    ("registered", "Registered Customer"),
    ("guest", "Guest / Walk-in"),
    ("b2b", "B2B Customer"),
]

EXCEPTION_CODE_SELECTION = [
    ("return_outside_days", "Return Outside Allowed Days"),
    ("return_without_invoice", "Return Without Invoice"),
    ("voucher_expired", "Voucher Expired"),
    ("voucher_already_used", "Voucher Already Used"),
    ("voucher_cancelled", "Voucher Cancelled"),
    ("negative_adjustment", "Negative Adjustment"),
    ("price_difference", "Price Difference"),
    ("duplicate_redemption", "Duplicate Redemption"),
    ("high_value", "High Value Transaction"),
    ("policy_override", "Policy Override"),
]

APPROVAL_LEVEL_RANK = {
    "cashier": 1,
    "supervisor": 2,
    "store_manager": 3,
    "regional_manager": 4,
    "administrator": 5,
}

LEGACY_TYPE_MAP = {
    "return_override": "return_approval",
    "guest_return": "return_approval",
    "cash_refund": "refund_approval",
    "void_voucher": "voucher_cancellation",
    "credit_adjust": "manual_adjustment",
    "expiry_extend": "voucher_extension",
}


class PosApprovalRule(models.Model):
    _name = "pos.approval.rule"
    _description = "POS Approval Rule"
    _order = "sequence, id"
    _check_company_auto = True

    name = fields.Char(required=True)
    active = fields.Boolean(default=True)
    sequence = fields.Integer(default=10)
    company_id = fields.Many2one(
        comodel_name="res.company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
        help="Leave empty to apply company-wide.",
    )
    approval_type = fields.Selection(
        selection=APPROVAL_TYPE_SELECTION,
        string="Approval Type",
        required=True,
        index=True,
    )
    required_level = fields.Selection(
        selection=APPROVAL_LEVEL_SELECTION,
        string="Minimum Approval Level",
        required=True,
        default="supervisor",
    )
    amount_threshold = fields.Monetary(
        string="Amount Threshold",
        currency_field="currency_id",
        default=0.0,
        help="Trigger when amount is at or above this value. 0 means any amount.",
    )
    return_days_threshold = fields.Integer(
        string="Return Days Threshold",
        default=0,
        help="Trigger when return age exceeds this many days. 0 disables.",
    )
    require_expired_voucher = fields.Boolean(
        string="Expired Voucher",
        default=False,
        help="Trigger when the voucher is expired.",
    )
    customer_type = fields.Selection(
        selection=CUSTOMER_TYPE_SELECTION,
        default="all",
        required=True,
    )
    exception_code = fields.Selection(
        selection=EXCEPTION_CODE_SELECTION,
        string="Exception",
        help="Optional exception that must be present to match this rule.",
    )
    auto_approve = fields.Boolean(
        string="Auto Approve",
        default=False,
        help="When matched, automatically approve without manager action.",
    )
    notes = fields.Text(string="Notes")
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="company_id.currency_id",
        store=True,
    )

    @api.model
    def _normalize_approval_type(self, approval_type):
        return LEGACY_TYPE_MAP.get(approval_type, approval_type)

    @api.model
    def _compatible_types(self, approval_type):
        normalized = self._normalize_approval_type(approval_type)
        legacy = {k for k, v in LEGACY_TYPE_MAP.items() if v == normalized}
        return {normalized, approval_type, *legacy}

    def _matches_context(self, context):
        self.ensure_one()
        ctx_type = self._normalize_approval_type(context.get("approval_type"))
        rule_type = self._normalize_approval_type(self.approval_type)
        if rule_type != ctx_type:
            return False

        company_id = context.get("company_id") or self.env.company.id
        if self.company_id.id != company_id:
            return False

        config_id = context.get("config_id")
        if self.config_id and config_id and self.config_id.id != config_id:
            return False
        if self.config_id and not config_id:
            return False

        amount = float(context.get("amount") or 0.0)
        if self.amount_threshold and amount < self.amount_threshold:
            return False

        return_days = int(context.get("return_days") or 0)
        if self.return_days_threshold and return_days < self.return_days_threshold:
            return False

        if self.require_expired_voucher and not context.get("voucher_expired"):
            return False

        customer_type = context.get("customer_type") or "all"
        if self.customer_type != "all" and self.customer_type != customer_type:
            return False

        exception_codes = set(context.get("exception_codes") or [])
        if self.exception_code and self.exception_code not in exception_codes:
            return False

        return True

    @api.model
    def find_matching_rules(self, context):
        company_id = context.get("company_id") or self.env.company.id
        config_id = context.get("config_id")
        domain = [
            ("active", "=", True),
            ("company_id", "=", company_id),
            "|",
            ("config_id", "=", False),
            ("config_id", "=", config_id or False),
        ]
        approval_type = context.get("approval_type")
        if approval_type:
            domain.append(
                ("approval_type", "in", list(self._compatible_types(approval_type)))
            )
        rules = self.search(domain, order="sequence, id")
        return rules.filtered(lambda rule: rule._matches_context(context))
