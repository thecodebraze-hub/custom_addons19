# -*- coding: utf-8 -*-

from odoo import fields, models

from .pos_approval_rule import APPROVAL_LEVEL_SELECTION


class ResUsers(models.Model):
    _inherit = "res.users"

    pos_approval_level = fields.Selection(
        selection=APPROVAL_LEVEL_SELECTION,
        string="POS Approval Level",
        help="Optional explicit approval level override for this user.",
    )
