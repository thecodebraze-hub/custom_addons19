# -*- coding: utf-8 -*-
"""Return transaction approval state helpers."""

from odoo import models
from odoo.exceptions import UserError

PENDING_STATES = ("pending", "requested")


class PosReturnTransactionApproval(models.Model):
    _inherit = "pos.return.transaction"

    def action_approve(self, manager=None):
        res = super().action_approve(manager=manager)
        for ret in self:
            pending = ret.approval_ids.filtered(lambda a: a.state in PENDING_STATES)
            if pending:
                pending.action_approve(approver=manager or self.env.user)
        return res

    def action_request_approval(self):
        for ret in self:
            if ret.state != "draft":
                raise UserError(self.env._("Only draft returns can request approval."))
            ret.state = "waiting_approval"
            self.env["pos.approval.service"].create_request(
                {
                    "approval_type": "return_approval",
                    "return_id": ret.id,
                    "amount": ret.amount_total,
                    "currency_id": ret.currency_id.id,
                    "company_id": ret.company_id.id,
                    "config_id": ret.config_id.id,
                    "reason": ret.reason_id.name if ret.reason_id else False,
                }
            )
        return True
