# -*- coding: utf-8 -*-
"""Wire settlement into the generic approval engine."""

from odoo import api, models
from odoo.tools import float_compare


class PosReturnSettlementServiceApproval(models.Model):
    _inherit = "pos.return.transaction"

    @api.model
    def _validate_settlement_payload(self, ret, config, session, payload):
        result = super()._validate_settlement_payload(ret, config, session, payload)
        if not result.get("valid"):
            return result

        method = self._map_pos_refund_method(payload.get("refund_method", "voucher"))
        exception_codes = []
        if method == "cash":
            exception_codes.append("high_value")

        eval_ctx = {
            "approval_type": "refund_approval",
            "amount": ret.amount_total,
            "currency_id": ret.currency_id.id,
            "config_id": config.id if config else False,
            "company_id": ret.company_id.id,
            "exception_codes": exception_codes,
        }
        evaluation = self.env["pos.approval.service"].evaluate(eval_ctx)
        if evaluation.get("required"):
            role = payload.get("cashier_role") or "cashier"
            if role == "cashier" and not payload.get("manager_approved"):
                result["approval_required"] = True
                reasons = list(result.get("approval_reasons") or [])
                for reason in evaluation.get("reasons", []):
                    if reason not in reasons:
                        reasons.append(reason)
                result["approval_reasons"] = reasons
                result["approval_min_level"] = evaluation.get("min_level")
        return result
