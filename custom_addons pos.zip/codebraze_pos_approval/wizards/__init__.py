# -*- coding: utf-8 -*-

from . import pos_approval_bulk_wizard
