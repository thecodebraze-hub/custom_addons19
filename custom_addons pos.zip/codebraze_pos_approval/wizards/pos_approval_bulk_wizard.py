# -*- coding: utf-8 -*-

from odoo import fields, models
from odoo.exceptions import UserError


class PosApprovalBulkWizard(models.TransientModel):
    _name = "pos.approval.bulk.wizard"
    _description = "Bulk Approval Actions"

    approval_ids = fields.Many2many(
        comodel_name="pos.approval.history",
        string="Approval Requests",
        required=True,
    )
    action = fields.Selection(
        selection=[
            ("approve", "Approve"),
            ("reject", "Reject"),
        ],
        required=True,
        default="approve",
    )
    notes = fields.Text(string="Notes")

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        active_ids = self.env.context.get("active_ids") or self.env.context.get(
            "default_approval_ids"
        )
        if active_ids:
            res["approval_ids"] = [(6, 0, active_ids)]
        return res

    def action_apply(self):
        approvals = self.approval_ids.filtered(
            lambda a: a.state in ("pending", "requested")
        )
        if not approvals:
            raise UserError(self.env._("No pending approval requests selected."))
        if self.action == "approve":
            approvals.action_approve(notes=self.notes)
        else:
            approvals.action_reject(notes=self.notes)
        return {"type": "ir.actions.act_window_close"}
