# -*- coding: utf-8 -*-

def migrate(cr, version):
    cr.execute(
        """
        UPDATE pos_approval_history
        SET state = 'pending'
        WHERE state = 'requested'
        """
    )
