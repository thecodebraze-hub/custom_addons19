/** @odoo-module **/

import { Component, useState, onWillStart } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";

const AUTH_LABELS = {
    pin: _t("PIN"),
    password: _t("Password"),
    badge: _t("Barcode"),
    employee_card: _t("Employee Card"),
};

export class ManagerApprovalPopup extends Component {
    static template = "codebraze_pos_approval.ManagerApprovalPopup";
    static components = { Dialog };
    static AUTH_LABELS = AUTH_LABELS;
    static props = {
        pos: { type: Object },
        reasons: { type: Array, optional: true },
        approvalType: { type: String, optional: true },
        requiredLevel: { type: String, optional: true },
        requestVals: { type: Object, optional: true },
        getPayload: { type: Function, optional: true },
        close: { type: Function },
    };

    setup() {
        this.state = useState({
            authMethod: "pin",
            pin: "",
            login: "",
            password: "",
            barcode: "",
            notes: "",
            error: "",
            loading: false,
            authMethods: ["pin", "badge"],
        });
        onWillStart(async () => {
            const approvalUi = this.props.pos.approvalUi;
            if (approvalUi) {
                const config = await approvalUi.getAuthConfig();
                this.state.authMethods = config.auth_methods || ["pin", "badge"];
                this.state.authMethod = config.default_method || this.state.authMethods[0];
            }
        });
    }

    get authMethodLabel() {
        return AUTH_LABELS[this.state.authMethod] || this.state.authMethod;
    }

    buildCredentials() {
        if (this.state.authMethod === "pin") {
            return { pin: this.state.pin };
        }
        if (this.state.authMethod === "password") {
            return { login: this.state.login, password: this.state.password };
        }
        return { barcode: this.state.barcode };
    }

    authLabel(method) {
        return AUTH_LABELS[method] || method;
    }

    async approve() {
        this.state.loading = true;
        this.state.error = "";
        try {
            const approvalUi = this.props.pos.approvalUi;
            const payload = {
                action: "approve",
                auth_method: this.state.authMethod,
                credentials: this.buildCredentials(),
                required_level: this.props.requiredLevel || "supervisor",
                notes: this.state.notes,
                create_request: Boolean(this.props.requestVals),
                request_vals: {
                    approval_type: this.props.approvalType || "return_approval",
                    ...(this.props.requestVals || {}),
                },
            };
            const result = approvalUi
                ? await approvalUi.authenticateAndApprove(payload)
                : { success: false, error: _t("Approval service unavailable.") };

            if (!result?.success) {
                this.state.error = result?.error || _t("Manager authentication failed.");
                return;
            }
            const response = {
                approved: true,
                manager_id: result.manager_id,
                manager_name: result.manager_name,
                auth_method: result.auth_method,
                approval_uuid: result.approval_uuid,
            };
            if (this.props.getPayload) {
                this.props.getPayload(response);
            }
            this.props.close(response);
        } finally {
            this.state.loading = false;
        }
    }

    deny() {
        const response = { approved: false };
        if (this.props.getPayload) {
            this.props.getPayload(response);
        }
        this.props.close(response);
    }
}
