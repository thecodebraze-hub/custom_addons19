/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";

/**
 * POS-facing approval RPC helpers.
 */
export class PosApprovalUiService {
    constructor(pos) {
        this.pos = pos;
        this._authConfig = null;
    }

    async getAuthConfig() {
        if (this._authConfig) {
            return this._authConfig;
        }
        try {
            this._authConfig = await this.pos.data.call(
                "pos.approval.service",
                "pos_get_auth_config",
                [this.pos.config.id]
            );
        } catch (_error) {
            this._authConfig = {
                auth_methods: ["pin", "badge"],
                default_method: "pin",
            };
        }
        return this._authConfig;
    }

    async evaluate(context) {
        return this.pos.data.call("pos.approval.service", "pos_evaluate", [
            context,
            this.pos.config.id,
        ]);
    }

    async authenticateAndApprove(payload) {
        return this.pos.data.call("pos.approval.service", "pos_authenticate_and_approve", [
            payload,
            this.pos.config.id,
            this.pos.session?.id || false,
        ]);
    }
}
