/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { PosApprovalUiService } from "./pos_approval_ui_service";

patch(PosStore.prototype, {
    async setup() {
        await super.setup(...arguments);
        this.approvalUi = new PosApprovalUiService(this);
    },
});
