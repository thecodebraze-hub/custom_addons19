# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Approval Framework",
    "version": "19.0.1.0.0",
    "category": "Sales/Point of Sale",
    "summary": "Generic manager approval and exception management for retail POS",
    "description": """
POS Manager Approval & Exception Framework
==========================================
Reusable approval engine with configurable rules, multi-level authorization,
POS manager authentication, audit trail and exception tracking.
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "point_of_sale",
        "mail",
        "hr",
        "codebraze_pos_store_credit",
        "codebraze_pos_return",
        "codebraze_pos_return_voucher",
    ],
    "data": [
        "security/approval_security.xml",
        "security/ir.model.access.csv",
        "security/ir_rule.xml",
        "data/ir_sequence_data.xml",
        "data/pos_approval_rule_data.xml",
        "data/ir_cron_data.xml",
        "views/pos_approval_rule_views.xml",
        "views/pos_approval_history_views.xml",
        "views/pos_approval_audit_views.xml",
        "views/pos_exception_log_views.xml",
        "views/approval_menus.xml",
        "wizards/pos_approval_bulk_wizard_views.xml",
    ],
    "assets": {
        "point_of_sale._assets_pos": [
            "codebraze_pos_approval/static/src/**/*",
        ],
    },
    "application": False,
    "installable": True,
    "auto_install": False,
}
