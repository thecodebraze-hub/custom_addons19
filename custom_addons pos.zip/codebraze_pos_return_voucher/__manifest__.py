# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Return Voucher",
    "version": "19.0.1.0.0",
    "category": "Sales/Point of Sale",
    "summary": "Return voucher instrument extending the Store Credit framework",
    "description": """
CodeBraze POS Return Voucher
============================
Barcode / printable return vouchers delegating to store.credit.
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "codebraze_pos_return",
        "barcodes",
    ],
    "data": [
        "security/ir.model.access.csv",
        "data/ir_sequence_data.xml",
    ],
    "application": False,
    "installable": True,
    "auto_install": False,
}
