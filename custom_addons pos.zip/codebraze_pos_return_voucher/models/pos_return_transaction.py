# -*- coding: utf-8 -*-
"""Extend return transaction with voucher link and completion hook."""

import logging

from odoo import fields, models

_logger = logging.getLogger(__name__)


class PosReturnTransaction(models.Model):
    _inherit = "pos.return.transaction"

    voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Return Voucher",
        index=True,
        copy=False,
        check_company=True,
        help="Voucher issued when refund method is Voucher.",
    )

    def action_complete(self):
        res = super().action_complete()
        for ret in self.filtered(lambda r: r.state == "completed"):
            if ret.refund_method == "voucher" and not ret.voucher_id:
                voucher = self.env["pos.return.voucher"]._create_from_return(ret)
                ret.voucher_id = voucher.id
                _logger.info(
                    "Issued voucher %s for return %s",
                    voucher.voucher_number,
                    ret.name,
                )
        return res
