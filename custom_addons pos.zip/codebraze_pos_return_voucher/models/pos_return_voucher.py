# -*- coding: utf-8 -*-
"""
Return voucher specializing store.credit via delegation (_inherits).

pos.return.voucher is the customer-facing barcode instrument; the monetary
ledger remains on store.credit / store.credit.transaction.
"""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

# Fields that belong only to the voucher (not delegated to store.credit)
_VOUCHER_ONLY_KEYS = {
    "credit_id",
    "voucher_number",
    "barcode_image",
    "print_count",
    "last_printed",
    "printed_by",
    "return_id",
    "exchange_id",
    "parent_voucher_id",
    "child_voucher_ids",
}


class PosReturnVoucher(models.Model):
    """
    Return voucher.

    Technical name: pos.return.voucher

    Extends store.credit through delegation so Gift Cards / Wallets can reuse
    the same credit engine without voucher-specific coupling.
    """

    _name = "pos.return.voucher"
    _description = "POS Return Voucher"
    _inherits = {"store.credit": "credit_id"}
    _order = "create_date desc, id desc"
    _check_company_auto = True

    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        required=True,
        ondelete="cascade",
        index=True,
        auto_join=True,
    )
    voucher_number = fields.Char(
        string="Voucher Number",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
        help="Dedicated voucher number (may differ from store credit reference).",
    )
    barcode_image = fields.Binary(
        string="Barcode Image",
        attachment=True,
        help="Rendered barcode image for printing (populated by print services).",
    )
    print_count = fields.Integer(
        string="Print Count",
        default=0,
        readonly=True,
        copy=False,
    )
    last_printed = fields.Datetime(
        string="Last Printed",
        readonly=True,
        copy=False,
        index=True,
    )
    printed_by = fields.Many2one(
        comodel_name="res.users",
        string="Printed By",
        readonly=True,
        copy=False,
        index=True,
    )
    return_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return Transaction",
        index=True,
        check_company=True,
        ondelete="set null",
    )
    exchange_id = fields.Many2one(
        comodel_name="pos.exchange.transaction",
        string="Exchange Transaction",
        index=True,
        check_company=True,
        ondelete="set null",
    )
    parent_voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Parent Voucher",
        index=True,
        help="Original voucher when this is a remainder voucher.",
    )
    child_voucher_ids = fields.One2many(
        comodel_name="pos.return.voucher",
        inverse_name="parent_voucher_id",
        string="Remainder Vouchers",
    )

    _sql_constraints = [
        (
            "pos_return_voucher_number_uniq",
            "unique(voucher_number)",
            "Voucher number must be unique.",
        ),
    ]

    @api.constrains("voucher_number", "credit_id")
    def _check_voucher_number_company(self):
        for voucher in self:
            if not voucher.voucher_number or voucher.voucher_number == "New":
                continue
            domain = [
                ("voucher_number", "=", voucher.voucher_number),
                ("id", "!=", voucher.id),
                ("company_id", "=", voucher.company_id.id),
            ]
            if self.search_count(domain):
                raise ValidationError(
                    self.env._(
                        "Voucher number %(number)s already exists for company %(company)s.",
                        number=voucher.voucher_number,
                        company=voucher.company_id.display_name,
                    )
                )

    @api.model_create_multi
    def create(self, vals_list):
        """
        Create voucher rows.

        When ``credit_id`` is omitted and an amount is provided, the store
        credit is issued through ``store.credit._create_credit`` first so the
        ledger stays consistent. Otherwise standard ``_inherits`` creation is
        used (e.g. draft shells or explicit credit_id link).
        """
        Credit = self.env["store.credit"]
        for vals in vals_list:
            company = self.env["res.company"].browse(
                vals.get("company_id") or self.env.company.id
            )
            vals.setdefault("company_id", company.id)
            vals.setdefault("currency_id", company.currency_id.id)
            vals.setdefault("credit_type", "return")
            if vals.get("voucher_number", "New") == "New":
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("pos.return.voucher")
                )
                if not seq:
                    raise UserError(
                        self.env._("Sequence 'pos.return.voucher' is not configured.")
                    )
                vals["voucher_number"] = seq

            if vals.get("credit_id"):
                continue

            amount = vals.get("amount")
            state = vals.get("state", "issued")
            if amount and state != "draft":
                credit_vals = {
                    key: vals[key]
                    for key in list(vals)
                    if key in Credit._fields and key not in _VOUCHER_ONLY_KEYS
                }
                credit = Credit._create_credit(credit_vals)
                for key in list(vals):
                    if key in Credit._fields and key not in _VOUCHER_ONLY_KEYS:
                        vals.pop(key)
                vals["credit_id"] = credit.id

        vouchers = super().create(vals_list)
        for voucher in vouchers:
            _logger.info(
                "Created return voucher %s credit=%s barcode=%s",
                voucher.voucher_number,
                voucher.credit_id.name,
                voucher.barcode,
            )
        return vouchers

    def _register_print(self, user=None):
        """Update print audit fields and emit audit log."""
        user = user or self.env.user
        for voucher in self:
            voucher.write(
                {
                    "print_count": voucher.print_count + 1,
                    "last_printed": fields.Datetime.now(),
                    "printed_by": user.id,
                }
            )
            self.env["store.credit.audit"].create(
                {
                    "credit_id": voucher.credit_id.id,
                    "voucher_id": voucher.id,
                    "action": "print",
                    "message": self.env._(
                        "Printed voucher %(voucher)s (count=%(count)s)",
                        voucher=voucher.voucher_number,
                        count=voucher.print_count,
                    ),
                    "amount": voucher.amount_remaining,
                    "company_id": voucher.company_id.id,
                    "currency_id": voucher.currency_id.id,
                    "config_id": voucher.config_id.id or False,
                    "session_id": voucher.session_id.id or False,
                    "cashier_id": user.id,
                    "state": "done",
                }
            )
        return True

    def _redeem_voucher(self, amount, pos_order=None, payment=None, user=None):
        """Redeem via underlying store credit and create payment link."""
        self.ensure_one()
        if not pos_order:
            raise ValidationError(
                self.env._("A POS order is required to record voucher redemption.")
            )
        self.credit_id._validate_credit(amount=amount, for_redeem=True)
        settings = self.credit_id._get_settings()
        if settings and not settings.cross_branch_usage:
            if (
                self.config_id
                and pos_order.config_id
                and self.config_id != pos_order.config_id
            ):
                raise UserError(
                    self.env._(
                        "Voucher %(voucher)s cannot be redeemed at another branch.",
                        voucher=self.voucher_number,
                    )
                )
        if settings and not settings.allow_multiple_voucher:
            existing = self.env["store.credit.payment"].search_count(
                [
                    ("pos_order_id", "=", pos_order.id),
                    ("state", "=", "posted"),
                    ("credit_id", "!=", self.credit_id.id),
                ]
            )
            if existing:
                raise UserError(
                    self.env._("Multiple vouchers on one order are not allowed.")
                )

        txn = self.credit_id._redeem_credit(
            amount=amount,
            pos_order=pos_order,
            user=user,
            reference=self.voucher_number,
        )
        return self.env["store.credit.payment"].create(
            {
                "credit_id": self.credit_id.id,
                "voucher_id": self.id,
                "pos_order_id": pos_order.id,
                "payment_id": payment.id if payment else False,
                "amount": amount,
                "company_id": self.company_id.id,
                "currency_id": self.currency_id.id,
                "config_id": self.config_id.id or False,
                "session_id": self.session_id.id or False,
                "transaction_id": txn.id,
                "cashier_id": (user or self.env.user).id,
            }
        )

    def _cancel_voucher(self, reason=None, user=None):
        self.ensure_one()
        return self.credit_id._cancel_credit(reason=reason, user=user)

    @api.model
    def _create_remainder_voucher(
        self, parent_voucher, credit, pos_order=None, session=None, user=None
    ):
        """Create a child voucher for remainder credit after partial redemption."""
        user = user or self.env.user
        vals = {
            "credit_id": credit.id,
            "parent_voucher_id": parent_voucher.id if parent_voucher else False,
        }
        if parent_voucher and parent_voucher.return_id:
            vals["return_id"] = parent_voucher.return_id.id
        if session:
            credit.session_id = session.id
        return self.create(vals)

    def _expire_voucher(self, user=None):
        self.ensure_one()
        return self.credit_id._expire_credit(user=user)

    def _is_redeemable(self):
        self.ensure_one()
        return self.credit_id._is_redeemable()

    @api.model
    def _create_from_return(self, return_txn):
        """Issue a voucher from a return transaction."""
        return_txn.ensure_one()
        if not return_txn.credit_id:
            credit = return_txn._issue_store_credit()
            return_txn.credit_id = credit.id
        else:
            credit = return_txn.credit_id

        voucher = self.search([("credit_id", "=", credit.id)], limit=1)
        if not voucher:
            voucher = self.create(
                {
                    "credit_id": credit.id,
                    "return_id": return_txn.id,
                }
            )
        elif not voucher.return_id:
            voucher.return_id = return_txn.id

        if not return_txn.voucher_id:
            return_txn.voucher_id = voucher.id

        settings = credit._get_settings()
        if settings and settings.auto_print:
            voucher._register_print(user=return_txn.cashier_id or self.env.user)
        return voucher

    @api.model
    def request_settlement(self, return_txn):
        """
        Voucher Service entry point for refund settlement.

        Voucher creation is deferred to the dedicated issuance step (Prompt 16).
        """
        return_txn.ensure_one()
        return {
            "status": "deferred",
            "voucher_pending": True,
            "return_id": return_txn.id,
            "amount": return_txn.amount_total,
            "message": self.env._(
                "Voucher issuance will be completed in the voucher issuance step."
            ),
        }
