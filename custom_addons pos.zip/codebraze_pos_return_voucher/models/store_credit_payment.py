# -*- coding: utf-8 -*-
"""Extend store.credit.payment with voucher link."""

from odoo import fields, models


class StoreCreditPayment(models.Model):
    _inherit = "store.credit.payment"

    voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Voucher",
        index=True,
        check_company=True,
        ondelete="set null",
        help="Return voucher instrument when redemption goes through a voucher.",
    )
