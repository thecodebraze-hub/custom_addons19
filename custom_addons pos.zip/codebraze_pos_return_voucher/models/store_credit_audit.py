# -*- coding: utf-8 -*-
"""Extend store.credit.audit with voucher link."""

from odoo import fields, models


class StoreCreditAudit(models.Model):
    _inherit = "store.credit.audit"

    voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Voucher",
        index=True,
        ondelete="set null",
    )
