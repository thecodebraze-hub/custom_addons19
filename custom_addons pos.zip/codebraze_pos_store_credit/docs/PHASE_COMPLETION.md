# Phase 02 Completion Report — Store Credit Core

## Status

**Conditionally Ready for Phase 03**, after mandatory blockers below.

Phase 02 delivered the reusable Store Credit core used by future Return Voucher,
Gift, Wallet and Loyalty modules.

## Completed in Phase 02

| Area | Status |
|------|--------|
| Backend ORM models | Done |
| Store Credit lifecycle engine | Done (issue/redeem/cancel/expire/adjust/transfer/reverse/reissue) |
| Transactions + audit writes | Done on model layer |
| Configuration via ICP + res.config.settings fields | Done (UI XML pending) |
| Barcode / UUID / Sequence / QR framework | Done |
| Unit tests | Added |
| Critical bug fixes from review | Done |

## Unit tests added

Module: `codebraze_pos_store_credit/tests`

| File | Coverage |
|------|----------|
| `test_identification_utils.py` | barcode format, QR payload, validators |
| `test_store_credit_engine.py` | issue, redeem, cancel, expire, adjust, transfer, reverse, reissue |
| `test_store_credit_config.py` | ICP utils + settings resolution + partial redeem flag |
| `test_identification_services.py` | facade: UUID, barcode, sequence, QR, duplicates |

Run (example):

```bash
odoo-bin -c odoo19.conf -d <db> --test-enable --stop-after-init -i codebraze_pos_store_credit --test-tags=codebraze_store_credit
```

## Developer notes

- Public entry points for money moves live on `store.credit`:
  `_create_credit`, `_redeem_credit`, `_cancel_credit`, `_expire_credit`,
  `_adjust_credit`, `_transfer_credit_to`, `_reverse_transaction`, `_reissue_credit`.
- Prefer `IdentificationFacadeService(env)` for barcodes/UUIDs/sequences/QR in new code.
- Settings runtime API: `env['store.credit.settings']._get_settings(company=, config=)`.
- Residual is ledger-derived from posted `signed_amount` values.

## Technical notes

- Transfer out uses `transfer_sign=-1`; transfer in uses `transfer_sign=+1`.
- Positive adjustments / inbound transfers increase face `amount` so SQL constraints hold.
- Sequences are still globally scoped (`company_id=False`) in data XML.

## Known limitations

1. Security ACL files missing.
2. Settings Python fields without XML views (admins cannot edit via UI yet).
3. Identification facade not yet the sole path for model barcode/UUID create.
4. Dedicated AuditService / Event registry incomplete (audit rows are created).
5. Offline sync queue / conflict resolver not fully implemented.
6. No production UAT yet on multi-company Sri Lankan clothing POS data.

## Mandatory before Phase 03

1. Security groups + access rights for `store.credit*` models.
2. Store Credit settings form/view under POS or Settings app.
3. Route create-time barcode/UUID through identification services.
4. Smoke-run unit tests on a real Odoo 19 database.

## Optional before Phase 03 (recommended)

- balance_before on transactions
- company-scoped sequences
- enforce manager approval flags for adjust/cancel
- domain event hooks for accounting/notifications

## Phase 03 entry criteria met when

- Mandatory list above closed
- Tests green on CI/local DB
- License decision documented (LGPL-3 vs OEEL-1)

Until then, treat Phase 02 as **code complete with known gates**, not “deploy to production”.
