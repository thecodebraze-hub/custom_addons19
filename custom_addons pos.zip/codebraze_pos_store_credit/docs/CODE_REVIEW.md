# -*- coding: utf-8 -*-
"""
Phase 02 Store Credit Core — Code Review Report
================================================

Scope reviewed
--------------
- models/store_credit*.py (engine, ledger, audit, settings, mixins)
- models/store_credit_config_*.py (res.config.settings + ICP utils)
- services/identification/* (barcode, UUID, sequence, QR, validators)
- utils/identification/* (formatters, exceptions, QR payload)
- sibling modules that depend on this core (return / voucher / accounting)

Verdict (after fixes applied during this review)
------------------------------------------------
Store Credit Core is **conditionally production-ready** for Phase 03 start
*after* the mandatory items listed in PHASE_COMPLETION.md are accepted.

Architecture
------------
Strengths:
- Generic store.credit parent supports multiple credit types.
- Ledger-first design via store.credit.transaction.
- Configuration resolved through ir.config_parameter + store.credit.settings bridge.
- Identification services are package-level and reusable.

Gaps / risks:
- Dedicated AuditService / TransactionService / EventBus packages were NOT fully
  built as separate service classes; orchestration currently lives on store.credit.
- store.credit still uses internal barcode/UUID generation instead of always
  routing through IdentificationFacadeService (duplication risk).
- No security/ACL files yet → non-admin access is unsafe.
- No settings XML views → configuration UI exists only as Python fields.

Duplication
-----------
| Area | Status |
|------|--------|
| Barcode generation | DUPLICATE: model helpers AND BarcodeService |
| UUID generation | PARTIAL: mixin + UUIDService |
| Validation rules | MOSTLY centralized on store.credit |
| Audit write | Central _log_audit; no separate AuditService |
| Transfer/adjust signed amount | Fixed during review |

Circular dependencies
---------------------
No hard Python circular imports detected among models / services / utils.
uuid_service previously imported missing uid_validators — **fixed**.

Hardcoded values
----------------
Remaining defaults (acceptable if configurable, but should stay sourced from settings):
- barcode prefix fallback "CBRV" / padding 10 when settings object missing fields
- credit types encoded as Selection on the model
- sequence codes ("store.credit", "store.credit.barcode", ...)

SOLID
-----
- SRP: identification services are good; store.credit still too large (god-object risk).
- OCP: credit_type selection + settings flags support extension.
- DIP: business layer not fully inverted to services yet.

Security
--------
- No ir.model.access.csv / record rules in this module.
- Guest credit, adjustments, cancel/reissue have weak/no ACL checks.

Performance
-----------
Strengths:
- Indexed barcode, uuid, state, company_id, partner_id.
- Stored computed amount_used / amount_remaining.

Watch items:
- _compute_amounts walks all posted transactions per credit (OK for POS volume;
  consider running balance table if txn volume explodes).
- Duplicate barcode uniqueness loops can burn sequences under collision.
- Cron expiry searches due credits then loops one-by-one (OK initially).

Refactors applied in this phase-completion pass
-----------------------------------------------
1. Fixed UUIDService import (uuid_validators).
2. Fixed transfer signed amount (inbound/outbound).
3. Rebuilt residual compute from signed ledger movements.
4. Face amount increases on inbound transfer / positive adjust to satisfy SQL checks.
5. Removed unused OfflineError import in barcode_service.
6. Barcode duplicate search uses active_test=False.
"""
