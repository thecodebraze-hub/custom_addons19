# -*- coding: utf-8 -*-
"""
Phase 02 — Improvement Report
=============================

Improvements applied during Phase Completion
--------------------------------------------
1. Critical bug: UUIDService imported `.validators.uid_validators` (missing module).
   → Fixed to `uuid_validators`.
2. Critical bug: transfer_txns always signed positive → source residual never decreased.
   → Added `transfer_sign` context and transfer handling in `_compute_signed_amount`.
3. Residual math updated to use `signed_amount` net total (covers adjust/transfer/reverse).
4. Positive residual growth (adjust+/transfer in) increases face amount so
   `amount_used >= 0` SQL constraint remains valid.
5. Unused import cleanup in barcode service; barcode validators search inactive rows too.
6. Unit tests added under `tests/` for utils, engine, config, services.

Recommended improvements BEFORE Phase 03 (Return / Voucher UI)
--------------------------------------------------------------
Mandatory
1. Add `security/` (groups + ir.model.access.csv + company record rules).
2. Add settings XML views for `res.config.settings` Store Credit section.
3. Wire `store.credit` barcode/UUID generation to IdentificationFacadeService
   (remove duplicate helper paths carefully).
4. Add dedicated AuditService + lightweight domain event hooks
   (CreditIssued/Redeemed/Cancelled/Expired/Transferred/Adjusted).
5. Capture balance_before on transactions (currently only remaining after).
6. Confirm OEEL vs LGPL license with stakeholders.

High priority
7. Company-scoped ir.sequence records (current sequences have company_id=False).
8. Approval enforcement helpers (manager_approval_required flags exist, not enforced on adjust/cancel).
9. Sync queue models / conflict resolver (offline flags exist; queue engine incomplete).
10. Install smoke test on a real DB with POS + multi-company demo data.

Medium
11. Split store.credit into thinner orchestrator + services (SRP).
12. Prefetch partners/credits for POS load path preparation.
13. Logging standards: unify logger names codebraze.pos.credit.*.
14. Migration script strategy for amount residual recompute if live data exists.

Low / future
15. QR rendering (payload only today).
16. Report views (history by customer/cashier/branch) — Phase reports.
17. I18n .pot extraction.

Dead / unused code to watch
---------------------------
- OfflineError currently unused (kept for planned offline strategy).
- permission_* settings are configuration only until ACL phase.
- validate_uuid_for_offline_barcode is thin wrapper — acceptable.

Known limitations
-----------------
- No POS UI / receipt / accounting wiring in Phase 02 (by design).
- Audit capture of IP / old-new JSON snapshots is partial (fields exist; writers sparse).
- Event notification system is method-local; not a registry yet.
- Cross-company redemption flag exists but engine currently forbids other-company ops.
"""
