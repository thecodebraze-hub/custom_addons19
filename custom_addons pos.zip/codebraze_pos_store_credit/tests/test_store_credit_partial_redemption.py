# -*- coding: utf-8 -*-
"""Unit tests for the partial redemption engine."""

from datetime import timedelta

from odoo import fields
from odoo.tests import tagged
from odoo.tests.common import TransactionCase


@tagged("post_install", "-at_install", "codebraze_store_credit")
class TestStoreCreditPartialRedemption(TransactionCase):
    """Validate remaining balance strategies and allocation."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.Credit = cls.env["store.credit"]
        cls.Audit = cls.env["store.credit.audit"]
        cls.partner = cls.env["res.partner"].create(
            {"name": "Partial Redemption Customer", "company_id": cls.company.id}
        )
        cls.pos_config = cls.env["pos.config"].create(
            {
                "name": "Partial Redemption POS",
                "company_id": cls.company.id,
            }
        )
        cls.ICP = cls.env["ir.config_parameter"].sudo()
        from odoo.addons.codebraze_pos_store_credit.models.store_credit_config_utils import (
            company_param_key,
        )

        cls._company_param_key = company_param_key

    def _set_strategy(self, strategy):
        key = self._company_param_key(self.company.id, "remaining_credit_strategy")
        self.ICP.set_param(key, strategy)

    def _issue(self, amount=5000.0, **extra):
        vals = {
            "credit_type": "manual",
            "partner_id": self.partner.id,
            "company_id": self.company.id,
            "currency_id": self.company.currency_id.id,
            "amount": amount,
        }
        vals.update(extra)
        return self.Credit._create_credit(vals)

    def test_update_existing_keeps_same_credit(self):
        self._set_strategy("update_existing")
        credit = self._issue(5000.0)
        original_barcode = credit.barcode
        credit._redeem_credit(3500.0)
        result = credit._handle_partial_redemption_remainder(
            redeemed_amount=3500.0,
            pos_order=False,
            config=False,
            session=False,
        )
        self.assertEqual(result["strategy"], "update_existing")
        self.assertAlmostEqual(credit.amount_remaining, 1500.0)
        self.assertEqual(credit.state, "partially_used")
        self.assertEqual(credit.barcode, original_barcode)
        audits = self.Audit.search(
            [("credit_id", "=", credit.id), ("action", "=", "partial_redeem")]
        )
        self.assertTrue(audits)

    def test_issue_new_creates_remainder_credit(self):
        self._set_strategy("issue_new")
        credit = self._issue(5000.0)
        original_id = credit.id
        credit._redeem_credit(3500.0)
        result = credit._handle_partial_redemption_remainder(
            redeemed_amount=3500.0,
            pos_order=False,
            config=False,
            session=False,
        )
        self.assertEqual(result["strategy"], "issue_new")
        self.assertEqual(credit.state, "used")
        self.assertAlmostEqual(credit.amount_remaining, 0.0)
        new_credit = self.Credit.browse(result["new_credit_id"])
        self.assertAlmostEqual(new_credit.amount_remaining, 1500.0)
        self.assertNotEqual(new_credit.id, original_id)
        self.assertNotEqual(new_credit.barcode, credit.barcode)
        remainder_audits = self.Audit.search([("action", "=", "remainder_issue")])
        self.assertTrue(remainder_audits)

    def test_full_redemption_skips_remainder_handling(self):
        self._set_strategy("issue_new")
        credit = self._issue(3000.0)
        credit._redeem_credit(3000.0)
        result = credit._handle_partial_redemption_remainder(
            redeemed_amount=3000.0,
            pos_order=False,
            config=False,
            session=False,
        )
        self.assertEqual(result["strategy"], "none")
        self.assertEqual(credit.state, "used")

    def test_allocate_multiple_credits_oldest_first(self):
        older = self._issue(
            1000.0, issue_date=fields.Datetime.now() - timedelta(days=5)
        )
        newer = self._issue(1000.0)
        settings = self.env["store.credit.settings"]._get_settings(company=self.company)
        allocations = self.Credit._allocate_credits_to_due(
            older | newer, 1500.0, settings
        )
        self.assertEqual(len(allocations), 2)
        self.assertEqual(allocations[0]["credit_id"], older.id)
        self.assertAlmostEqual(allocations[0]["amount"], 1000.0)
        self.assertAlmostEqual(allocations[1]["amount"], 500.0)

    def test_calculate_breakdown_customer_payment(self):
        credit = self._issue(3000.0)
        breakdown = self.Credit.pos_calculate_redemption_breakdown(
            {
                "due_amount": 4500.0,
                "credit_ids": [credit.id],
            },
            config_id=self.pos_config.id,
        )
        self.assertTrue(breakdown.get("success"))
        self.assertAlmostEqual(breakdown["credit_used"], 3000.0)
        self.assertAlmostEqual(breakdown["customer_payment"], 1500.0)

    def test_manager_approval_required_for_partial(self):
        key = self._company_param_key(
            self.company.id, "require_manager_approval_partial"
        )
        self.ICP.set_param(key, "True")
        credit = self._issue(5000.0)
        settings = credit._get_settings()
        check = self.Credit._validate_partial_redemption_policy(
            credit, 3500.0, settings, {}
        )
        self.assertFalse(check["valid"])
        check_ok = self.Credit._validate_partial_redemption_policy(
            credit, 3500.0, settings, {"manager_approved": True}
        )
        self.assertTrue(check_ok["valid"])

    def test_manager_approval_not_required_for_full(self):
        key = self._company_param_key(
            self.company.id, "require_manager_approval_partial"
        )
        self.ICP.set_param(key, "True")
        credit = self._issue(3000.0)
        settings = credit._get_settings()
        check = self.Credit._validate_partial_redemption_policy(
            credit, 3000.0, settings, {}
        )
        self.assertTrue(check["valid"])

    def test_highest_amount_first_sort(self):
        low = self._issue(500.0)
        high = self._issue(2000.0)
        sorted_credits = self.Credit._sort_credits_for_allocation(
            low | high, "highest_amount_first"
        )
        self.assertEqual(sorted_credits[0].id, high.id)
