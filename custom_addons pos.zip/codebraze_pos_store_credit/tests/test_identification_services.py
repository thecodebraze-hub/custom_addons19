# -*- coding: utf-8 -*-
"""Service-layer tests for barcode / UUID / sequence / QR facade."""

import uuid

from odoo.exceptions import UserError
from odoo.tests import tagged
from odoo.tests.common import TransactionCase

from odoo.addons.codebraze_pos_store_credit.services.identification.identification_facade import (
    IdentificationFacadeService,
)
from odoo.addons.codebraze_pos_store_credit.utils.identification.exceptions import (
    DuplicateError,
    IdentificationValidationError,
)


@tagged("post_install", "-at_install", "codebraze_store_credit")
class TestIdentificationServices(TransactionCase):
    """Validate shared identification framework services."""

    def setUp(self):
        super().setUp()
        self.facade = IdentificationFacadeService(self.env)

    def test_generate_and_validate_uuid(self):
        value = self.facade.generate_uuid()
        self.assertTrue(self.facade.validate_uuid(value))
        with self.assertRaises(IdentificationValidationError):
            self.facade.validate_uuid("bad")

    def test_generate_barcode_uses_sequence(self):
        barcode = self.facade.generate_barcode(
            company_id=self.env.company.id,
            prefix="SC",
            padding=8,
            check_duplicate=False,
        )
        self.assertTrue(barcode.startswith("SC"))
        self.assertTrue(self.facade.validate_barcode(barcode, expected_prefix="SC"))

    def test_generate_offline_barcode(self):
        offline_uuid = str(uuid.uuid4())
        barcode = self.facade.generate_barcode(
            company_id=self.env.company.id,
            prefix="SC",
            padding=10,
            offline=True,
            uuid_str=offline_uuid,
            check_duplicate=False,
        )
        self.assertTrue(barcode.startswith("SC"))
        parsed = self.facade.parse_barcode(barcode, expected_prefix="SC")
        self.assertTrue(parsed["numeric_body"])

    def test_duplicate_barcode_detection(self):
        partner = self.env["res.partner"].create({"name": "Dup barcode partner"})
        credit = self.env["store.credit"]._create_credit(
            {
                "credit_type": "manual",
                "partner_id": partner.id,
                "company_id": self.env.company.id,
                "currency_id": self.env.company.currency_id.id,
                "amount": 10.0,
            }
        )
        with self.assertRaises(DuplicateError):
            self.facade.validate_barcode(
                credit.barcode,
                check_duplicate=True,
            )

    def test_sequence_service_raises_for_missing_code(self):
        with self.assertRaises(UserError):
            self.facade.generate_sequence("codebraze.missing.sequence")

    def test_qr_payload_service(self):
        payload = self.facade.build_qr_payload(
            voucher_number="RV001",
            uuid=str(uuid.uuid4()),
            verification_url="https://verify.example/rv001",
        )
        self.assertIn("RV001", payload)
        self.assertIn("https://verify.example/rv001", payload)
