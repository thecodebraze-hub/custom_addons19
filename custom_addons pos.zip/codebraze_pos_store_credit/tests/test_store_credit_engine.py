# -*- coding: utf-8 -*-
"""ORM unit tests for Store Credit business engine."""

from datetime import timedelta

from odoo import fields
from odoo.exceptions import UserError, ValidationError
from odoo.tests import tagged
from odoo.tests.common import TransactionCase


@tagged("post_install", "-at_install", "codebraze_store_credit")
class TestStoreCreditEngine(TransactionCase):
    """Validate issue / redeem / cancel / expire / adjust / transfer / reverse."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.Credit = cls.env["store.credit"]
        cls.Txn = cls.env["store.credit.transaction"]
        cls.Audit = cls.env["store.credit.audit"]
        cls.partner = cls.env["res.partner"].create(
            {
                "name": "Store Credit Test Customer",
                "company_id": cls.company.id,
            }
        )

    def _issue(self, amount=1000.0, **extra):
        vals = {
            "credit_type": "manual",
            "partner_id": self.partner.id,
            "company_id": self.company.id,
            "currency_id": self.company.currency_id.id,
            "amount": amount,
        }
        vals.update(extra)
        return self.Credit._create_credit(vals)

    def test_issue_creates_transaction_and_audit(self):
        credit = self._issue(1500.0)
        self.assertEqual(credit.state, "issued")
        self.assertEqual(credit.amount_remaining, 1500.0)
        self.assertEqual(credit.amount_used, 0.0)
        self.assertTrue(credit.barcode)
        self.assertTrue(credit.uuid)
        self.assertEqual(len(credit.transaction_ids), 1)
        self.assertEqual(credit.transaction_ids.txn_type, "issue")
        audits = self.Audit.search([("credit_id", "=", credit.id), ("action", "=", "issue")])
        self.assertTrue(audits)

    def test_partial_and_full_redemption(self):
        credit = self._issue(1000.0)
        credit._redeem_credit(400.0)
        self.assertEqual(credit.state, "partially_used")
        self.assertAlmostEqual(credit.amount_remaining, 600.0)
        credit._redeem_credit(600.0)
        self.assertEqual(credit.state, "used")
        self.assertAlmostEqual(credit.amount_remaining, 0.0)
        self.assertEqual(len(credit.transaction_ids.filtered(lambda t: t.txn_type == "redeem")), 2)

    def test_over_redemption_blocked(self):
        credit = self._issue(100.0)
        with self.assertRaises(ValidationError):
            credit._redeem_credit(150.0)

    def test_cancel_writes_off_remaining(self):
        credit = self._issue(800.0)
        credit._redeem_credit(200.0)
        credit._cancel_credit(reason="Customer requested cancel")
        self.assertEqual(credit.state, "cancelled")
        self.assertAlmostEqual(credit.amount_remaining, 0.0)
        self.assertTrue(credit.transaction_ids.filtered(lambda t: t.txn_type == "cancel"))

    def test_expire_on_due_credit(self):
        credit = self._issue(500.0)
        credit.expiry_date = fields.Datetime.now() - timedelta(days=1)
        self.assertTrue(credit._expire_credit())
        self.assertEqual(credit.state, "expired")
        self.assertAlmostEqual(credit.amount_remaining, 0.0)

    def test_adjust_increase_and_decrease(self):
        credit = self._issue(1000.0)
        credit._adjust_credit(200.0, increase=True, reason="Goodwill")
        self.assertAlmostEqual(credit.amount, 1200.0)
        self.assertAlmostEqual(credit.amount_remaining, 1200.0)
        credit._adjust_credit(300.0, increase=False, reason="Correction")
        self.assertAlmostEqual(credit.amount_remaining, 900.0)

    def test_transfer_moves_balance(self):
        source = self._issue(1000.0)
        target = self._issue(100.0)
        source._transfer_credit_to(target, 250.0, reason="Transfer test")
        self.assertAlmostEqual(source.amount_remaining, 750.0)
        self.assertAlmostEqual(target.amount_remaining, 350.0)
        self.assertTrue(source.transaction_ids.filtered(lambda t: t.txn_type == "transfer"))
        self.assertTrue(target.transaction_ids.filtered(lambda t: t.txn_type == "transfer"))

    def test_reverse_redeem_restores_balance(self):
        credit = self._issue(500.0)
        redeem = credit._redeem_credit(200.0)
        self.assertAlmostEqual(credit.amount_remaining, 300.0)
        credit._reverse_transaction(redeem, reason="Wrong redeem")
        self.assertAlmostEqual(credit.amount_remaining, 500.0)
        self.assertEqual(credit.state, "issued")

    def test_reissue_cancels_and_creates_new(self):
        credit = self._issue(700.0)
        credit._redeem_credit(200.0)
        new_credit = credit._reissue_credit(reason="Reprint")
        self.assertEqual(credit.state, "cancelled")
        self.assertEqual(new_credit.state, "issued")
        self.assertAlmostEqual(new_credit.amount, 500.0)
        self.assertNotEqual(new_credit.id, credit.id)

    def test_inactive_not_redeemable(self):
        credit = self._issue(100.0)
        credit.active = False
        with self.assertRaises(UserError):
            credit._redeem_credit(10.0)

    def test_posted_transaction_immutable(self):
        credit = self._issue(50.0)
        txn = credit.transaction_ids[:1]
        with self.assertRaises(UserError):
            txn.write({"amount": 1.0})
