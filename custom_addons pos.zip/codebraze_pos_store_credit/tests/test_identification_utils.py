# -*- coding: utf-8 -*-
"""Unit tests for barcode / UUID / QR utilities (no database required)."""

import unittest
import uuid

from odoo.addons.codebraze_pos_store_credit.utils.identification.barcode_format import (
    format_barcode,
    looks_like_barcode,
    normalize_prefix,
    parse_numeric_body,
)
from odoo.addons.codebraze_pos_store_credit.utils.identification.exceptions import (
    DuplicateError,
    IdentificationValidationError,
)
from odoo.addons.codebraze_pos_store_credit.utils.identification.qr_payload import (
    build_qr_payload,
)
from odoo.addons.codebraze_pos_store_credit.services.identification.validators.uuid_validators import (
    UUIDValidators,
)
from odoo.addons.codebraze_pos_store_credit.services.identification.validators.barcode_validators import (
    BarcodeValidators,
)
from odoo.addons.codebraze_pos_store_credit.services.identification.validators.sequence_validators import (
    SequenceValidators,
)


class TestBarcodeFormatUtils(unittest.TestCase):
    """Pure utility coverage for barcode formatting helpers."""

    def test_format_barcode_zfill(self):
        self.assertEqual(format_barcode("SC", "12", 5), "SC00012")
        self.assertEqual(format_barcode("RV", 1, 9), "RV000000001")

    def test_normalize_and_parse(self):
        self.assertEqual(normalize_prefix("  CBRV  "), "CBRV")
        self.assertEqual(parse_numeric_body("RV000000015", expected_prefix="RV"), "000000015")
        self.assertEqual(parse_numeric_body("SC123", expected_prefix="GV"), "")

    def test_looks_like_barcode(self):
        self.assertTrue(looks_like_barcode("SC000000001", prefix="SC", numeric_length=9))
        self.assertFalse(looks_like_barcode("SC1", prefix="SC", numeric_length=9))
        self.assertFalse(looks_like_barcode("", prefix="SC"))

    def test_format_rejects_bad_padding(self):
        with self.assertRaises(ValueError):
            format_barcode("SC", "1", 0)


class TestQRPayloadUtils(unittest.TestCase):
    def test_build_qr_payload(self):
        payload = build_qr_payload(
            voucher_number="RV/2026/00001",
            uuid="11111111-1111-4111-8111-111111111111",
            verification_url="https://example.com/v/1",
            extra_payload={"company": 1},
        )
        self.assertIn('"v":"RV/2026/00001"', payload)
        self.assertIn('"u":"11111111-1111-4111-8111-111111111111"', payload)
        self.assertIn('"url":"https://example.com/v/1"', payload)
        self.assertIn('"company":1', payload)

    def test_build_qr_payload_requires_fields(self):
        with self.assertRaises(ValueError):
            build_qr_payload(voucher_number="", uuid="x")
        with self.assertRaises(ValueError):
            build_qr_payload(voucher_number="A", uuid="")


class TestIdentificationValidators(unittest.TestCase):
    def test_uuid_validator(self):
        validators = UUIDValidators()
        good = str(uuid.uuid4())
        validators.validate_uuid(good)
        with self.assertRaises(IdentificationValidationError):
            validators.validate_uuid("not-a-uuid")

    def test_barcode_prefix_validator(self):
        validators = BarcodeValidators()
        validators.validate_prefix("SC0001", "SC")
        with self.assertRaises(IdentificationValidationError):
            validators.validate_prefix("RV0001", "SC")

    def test_sequence_code_validator(self):
        validators = SequenceValidators()
        validators.validate_sequence_code("store.credit")
        with self.assertRaises(IdentificationValidationError):
            validators.validate_sequence_code("")

    def test_duplicate_error_is_user_error_subclass(self):
        from odoo.exceptions import UserError

        self.assertTrue(issubclass(DuplicateError, UserError))
