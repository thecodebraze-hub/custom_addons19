# -*- coding: utf-8 -*-
"""Configuration resolution and settings parameter tests."""

from odoo.tests import tagged
from odoo.tests.common import TransactionCase

from odoo.addons.codebraze_pos_store_credit.models.store_credit_config_utils import (
    company_param_key,
    to_bool,
    to_float,
    to_int,
)


@tagged("post_install", "-at_install", "codebraze_store_credit")
class TestStoreCreditConfig(TransactionCase):
    """Validate config utilities and runtime settings resolution."""

    def test_config_utils_parsing(self):
        self.assertTrue(to_bool("true"))
        self.assertFalse(to_bool("0"))
        self.assertEqual(to_int("42", 0), 42)
        self.assertEqual(to_float("12.5", 0.0), 12.5)
        self.assertTrue(company_param_key(1, "barcode_prefix").endswith(".barcode_prefix"))

    def test_get_settings_defaults(self):
        settings = self.env["store.credit.settings"]._get_settings(company=self.env.company)
        self.assertTrue(settings)
        self.assertTrue(getattr(settings, "barcode_prefix", None))
        self.assertGreater(getattr(settings, "barcode_padding", 0), 0)
        self.assertTrue(hasattr(settings, "allow_partial_usage"))
        self.assertTrue(hasattr(settings, "enable_store_credit"))

    def test_settings_from_ir_config_parameter(self):
        company = self.env.company
        key = company_param_key(company.id, "barcode_prefix")
        self.env["ir.config_parameter"].sudo().set_param(key, "TSTPRE")
        settings = self.env["store.credit.settings"]._get_settings(company=company)
        self.assertEqual(settings.barcode_prefix, "TSTPRE")

    def test_business_methods_use_settings_partial_flag(self):
        company = self.env.company
        ICP = self.env["ir.config_parameter"].sudo()
        ICP.set_param(company_param_key(company.id, "allow_partial_redemption"), "False")
        partner = self.env["res.partner"].create({"name": "CFG Partner"})
        credit = self.env["store.credit"]._create_credit(
            {
                "credit_type": "manual",
                "partner_id": partner.id,
                "company_id": company.id,
                "currency_id": company.currency_id.id,
                "amount": 100.0,
            }
        )
        from odoo.exceptions import UserError

        with self.assertRaises(UserError):
            credit._redeem_credit(40.0)
        # cleanup: full redeem allowed if remaining equals face
        credit._redeem_credit(100.0)
        self.assertEqual(credit.state, "used")
