# -*- coding: utf-8 -*-
"""Identification framework exceptions.

These exceptions are shared across barcode, UUID, sequence and QR services.
"""

from odoo.exceptions import UserError, ValidationError


class DuplicateError(UserError):
    """Raised when a value (barcode / UUID / sequence number) already exists."""


class OfflineError(UserError):
    """Raised when an offline strategy is requested but not available."""


class IdentificationValidationError(ValidationError):
    """Raised for input validation errors within the identification framework."""

