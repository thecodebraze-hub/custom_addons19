# -*- coding: utf-8 -*-
"""Barcode formatting and parsing utilities."""

import re


_DIGITS_RE = re.compile(r"\d+")


def normalize_prefix(prefix):
    """Normalize a barcode prefix.

    :param prefix: string prefix
    :return: cleaned prefix
    """
    prefix = (prefix or "").strip()
    return prefix


def parse_numeric_body(barcode, expected_prefix=None):
    """Extract numeric body from barcode.

    If ``expected_prefix`` is provided, prefix must match.
    """
    if not barcode:
        return ""
    if expected_prefix:
        expected_prefix = normalize_prefix(expected_prefix)
        if not barcode.startswith(expected_prefix):
            return ""
        rest = barcode[len(expected_prefix) :]
    else:
        rest = barcode
    digits = "".join(_DIGITS_RE.findall(rest))
    return digits


def format_barcode(prefix, numeric_body, padding):
    """Format a barcode string.

    - ``numeric_body`` is left-padded with zeros to match ``padding``.
    - ``prefix`` is used as-is after trimming.
    """
    prefix = normalize_prefix(prefix)
    if padding <= 0:
        raise ValueError("padding must be > 0")
    digits = "".join(_DIGITS_RE.findall(str(numeric_body)))
    digits = digits or "0"
    return f"{prefix}{digits.zfill(padding)}"


def looks_like_barcode(barcode, prefix=None, numeric_length=None):
    """Best-effort format check for a barcode."""
    if not barcode:
        return False
    if prefix:
        prefix = normalize_prefix(prefix)
        if not barcode.startswith(prefix):
            return False
    digits = "".join(_DIGITS_RE.findall(barcode))
    if numeric_length is not None and len(digits) != numeric_length:
        return False
    return True

