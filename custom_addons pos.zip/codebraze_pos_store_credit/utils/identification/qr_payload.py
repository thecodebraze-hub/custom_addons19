# -*- coding: utf-8 -*-
"""QR payload building utilities."""

import json


def build_qr_payload(voucher_number, uuid, verification_url=None, extra_payload=None):
    """Build a stable QR payload.

    The payload is intentionally a JSON string to allow future extension
    without breaking client parsing.
    """
    if not voucher_number:
        raise ValueError("voucher_number is required")
    if not uuid:
        raise ValueError("uuid is required")
    payload = {
        "v": str(voucher_number),
        "u": str(uuid),
    }
    if verification_url:
        payload["url"] = verification_url
    if extra_payload:
        payload.update(extra_payload)
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False)

