/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/services/pos_store";
import { PosStoreCreditRedemptionService } from "./pos_store_credit_redemption_service";

patch(PosStore.prototype, {
    async setup(...args) {
        await super.setup(...args);
        this.storeCreditRedemption = new PosStoreCreditRedemptionService(this);
    },

    async posBackOnline() {
        await super.posBackOnline(...arguments);
        await this.storeCreditRedemption?.processOfflineRedemptionQueue();
    },
});
