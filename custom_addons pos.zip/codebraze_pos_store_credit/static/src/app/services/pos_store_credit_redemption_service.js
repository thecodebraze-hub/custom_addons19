/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { formatCurrency } from "@point_of_sale/app/models/utils/currency";

const OFFLINE_REDEMPTION_KEY_PREFIX = "codebraze.store_credit.redemption.cache.";
const OFFLINE_REDEMPTION_QUEUE_PREFIX = "codebraze.store_credit.redemption.queue.";

/**
 * Store credit redemption service for the POS payment screen.
 */
export class PosStoreCreditRedemptionService {
    constructor(pos) {
        this.pos = pos;
        this._settings = null;
    }

    get isOffline() {
        const network = this.pos.data?.network?.unsyncData;
        if (network && typeof network.hasConnection === "function") {
            return !network.hasConnection();
        }
        return typeof navigator !== "undefined" ? !navigator.onLine : false;
    }

    formatMoney(amount) {
        return formatCurrency(amount || 0, this.pos.currency);
    }

    getStoreCreditPaymentMethod() {
        return this.pos.config.payment_method_ids.find((pm) => pm.is_store_credit);
    }

    getExistingStoreCreditPaymentLine(order) {
        const scMethod = this.getStoreCreditPaymentMethod();
        if (!scMethod) {
            return null;
        }
        return order.payment_ids.find(
            (line) => line.payment_method_id?.id === scMethod.id
        );
    }

    parseRedemptionData(paymentLine) {
        if (!paymentLine?.store_credit_redemption_data) {
            return { redemptions: [] };
        }
        try {
            const data =
                typeof paymentLine.store_credit_redemption_data === "string"
                    ? JSON.parse(paymentLine.store_credit_redemption_data)
                    : paymentLine.store_credit_redemption_data;
            return { redemptions: data.redemptions || [] };
        } catch {
            return { redemptions: [] };
        }
    }

    getAppliedRedemptions(order) {
        const line = this.getExistingStoreCreditPaymentLine(order);
        return this.parseRedemptionData(line).redemptions;
    }

    getTotalAppliedCredit(order) {
        return this.getAppliedRedemptions(order).reduce(
            (sum, r) => sum + (Number(r.amount) || 0),
            0
        );
    }

    async loadSettings() {
        if (this._settings) {
            return this._settings;
        }
        if (this.isOffline) {
            this._settings = this._getOfflineSettings();
            return this._settings;
        }
        try {
            const result = await this.pos.data.call(
                "store.credit",
                "pos_get_redemption_settings",
                [this.pos.config.id]
            );
            this._settings = result?.success ? result : this._getOfflineSettings();
        } catch {
            this._settings = this._getOfflineSettings();
        }
        return this._settings;
    }

    async lookupStoreCredit({ query, lookupType, partnerId }) {
        if (this.isOffline) {
            return this._lookupOffline(query, lookupType, partnerId);
        }
        try {
            const result = await this.pos.data.call(
                "store.credit",
                "pos_lookup_store_credit",
                [
                    query,
                    lookupType,
                    this.pos.config.id,
                    this.pos.session?.id || false,
                    partnerId || false,
                ]
            );
            if (result?.success && result.credits?.length) {
                this._cacheCredits(result.credits);
            }
            return result;
        } catch (error) {
            return {
                success: false,
                error: error?.message || _t("Lookup failed."),
            };
        }
    }

    async precheckRedemption(payload) {
        if (this.isOffline) {
            return this._precheckOffline(payload);
        }
        try {
            return await this.pos.data.call(
                "store.credit",
                "pos_precheck_redemption",
                [payload, this.pos.config.id, this.pos.session?.id || false]
            );
        } catch (error) {
            return { valid: false, error: error?.message || _t("Validation failed.") };
        }
    }

    async calculateRedemptionBreakdown({ dueAmount, creditIds, partnerId, amounts }) {
        if (this.isOffline) {
            return this._calculateBreakdownOffline(dueAmount, creditIds, amounts);
        }
        try {
            return await this.pos.data.call(
                "store.credit",
                "pos_calculate_redemption_breakdown",
                [
                    {
                        due_amount: dueAmount,
                        credit_ids: creditIds,
                        partner_id: partnerId || false,
                        amounts: amounts || {},
                    },
                    this.pos.config.id,
                ]
            );
        } catch (error) {
            return { success: false, error: error?.message || _t("Calculation failed.") };
        }
    }

    async allocateStoreCredits({ dueAmount, creditIds, partnerId, amounts }) {
        if (this.isOffline) {
            return this._calculateBreakdownOffline(dueAmount, creditIds, amounts);
        }
        try {
            return await this.pos.data.call(
                "store.credit",
                "pos_allocate_store_credits",
                [
                    {
                        due_amount: dueAmount,
                        credit_ids: creditIds,
                        partner_id: partnerId || false,
                        amounts: amounts || {},
                    },
                    this.pos.config.id,
                    this.pos.session?.id || false,
                ]
            );
        } catch (error) {
            return { success: false, error: error?.message || _t("Allocation failed.") };
        }
    }

    computeApplicableAmount(order, credit, requestedAmount) {
        const due = Math.max(order.remainingDue ?? 0, 0);
        const remaining = Number(credit.amount_remaining) || 0;
        const requested = Number(requestedAmount) || 0;
        return Math.min(due, remaining, requested > 0 ? requested : due);
    }

    computeLocalBreakdown(order, credit, amount) {
        const due = Math.max(order.remainingDue ?? 0, 0);
        const applicable = this.computeApplicableAmount(order, credit, amount);
        const remainingBefore = Number(credit.amount_remaining) || 0;
        const remainingAfter = Math.max(remainingBefore - applicable, 0);
        const customerPayment = Math.max(due - applicable, 0);
        const settings = this._settings || {};
        return {
            creditUsed: applicable,
            remainingCredit: remainingAfter,
            customerPayment,
            isPartial: applicable < remainingBefore,
            strategy: settings.remaining_credit_strategy || "issue_new",
            willIssueNew:
                (settings.remaining_credit_strategy || "issue_new") === "issue_new" &&
                remainingAfter > 0,
        };
    }

    buildRedemptionPayload(credit, amount, order, extra = {}) {
        return {
            redemption_uuid: crypto.randomUUID(),
            credit_id: credit.credit_id,
            voucher_id: credit.voucher_id || false,
            voucher_number: credit.voucher_number || credit.name,
            barcode: credit.barcode,
            amount,
            due_amount: Math.max(order.remainingDue ?? 0, 0),
            order_uuid: order.uuid,
            existing_redemptions: this.getAppliedRedemptions(order),
            partner_id: order.getPartner()?.id || false,
            manager_approved: extra.managerApproved || false,
        };
    }

    applyRedemptionToOrder(order, credit, amount, extra = {}) {
        const scMethod = this.getStoreCreditPaymentMethod();
        if (!scMethod) {
            return { success: false, error: _t("Store Credit payment method is not configured.") };
        }

        const redemption = {
            redemption_uuid: crypto.randomUUID(),
            credit_id: credit.credit_id,
            voucher_id: credit.voucher_id || false,
            voucher_number: credit.voucher_number || credit.name,
            barcode: credit.barcode,
            amount,
            manager_approved: extra.managerApproved || false,
        };

        let paymentLine = this.getExistingStoreCreditPaymentLine(order);
        if (!paymentLine) {
            const result = order.addPaymentline(scMethod);
            if (!result.status) {
                return { success: false, error: result.data };
            }
            paymentLine = result.data;
        }

        const data = this.parseRedemptionData(paymentLine);
        const existing = data.redemptions.filter(
            (r) => r.credit_id !== redemption.credit_id
        );
        if (
            existing.length &&
            this._settings &&
            !this._settings.allow_multiple_voucher_usage
        ) {
            return {
                success: false,
                error: _t("Multiple store credits on one order are not allowed."),
            };
        }
        existing.push(redemption);
        paymentLine.store_credit_redemption_data = JSON.stringify({
            redemptions: existing,
        });
        const total = existing.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
        paymentLine.setAmount(total);
        order.selectPaymentline(paymentLine);

        if (this.isOffline) {
            this._queueOfflineRedemption(order, redemption);
        }

        return {
            success: true,
            paymentLine,
            redemption,
            totalApplied: total,
            breakdown: this.computeLocalBreakdown(order, credit, amount),
        };
    }

    async applyAutoAllocatedCredits(order, credits) {
        const due = Math.max(order.remainingDue ?? 0, 0);
        const creditIds = credits.map((c) => c.credit_id);
        const allocation = await this.allocateStoreCredits({
            dueAmount: due,
            creditIds,
            partnerId: order.getPartner()?.id || false,
        });
        if (!allocation?.success) {
            return allocation;
        }
        const results = [];
        for (const line of allocation.allocations || []) {
            const credit = credits.find((c) => c.credit_id === line.credit_id);
            if (!credit) {
                continue;
            }
            const result = this.applyRedemptionToOrder(order, credit, line.amount);
            if (!result.success) {
                return result;
            }
            results.push(result);
        }
        return {
            success: true,
            results,
            allocation,
        };
    }

    removeRedemptionFromOrder(order, redemptionUuid) {
        const paymentLine = this.getExistingStoreCreditPaymentLine(order);
        if (!paymentLine) {
            return;
        }
        const data = this.parseRedemptionData(paymentLine);
        const remaining = data.redemptions.filter(
            (r) => r.redemption_uuid !== redemptionUuid
        );
        if (!remaining.length) {
            order.removePaymentline(paymentLine);
            return;
        }
        paymentLine.store_credit_redemption_data = JSON.stringify({
            redemptions: remaining,
        });
        const total = remaining.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
        paymentLine.setAmount(total);
    }

    processRemainderPrintJobs(order) {
        const raw = order.store_credit_remainder_data;
        if (!raw) {
            return [];
        }
        try {
            const data = typeof raw === "string" ? JSON.parse(raw) : raw;
            const jobs = (data.remainder_jobs || []).filter(
                (job) => job.print?.printed && job.new_voucher_id
            );
            if (jobs.length && this.pos.voucherPrint?.printRemainderVouchers) {
                this.pos.voucherPrint.printRemainderVouchers(jobs);
            }
            return jobs;
        } catch {
            return [];
        }
    }

    logRedemptionCancelled(payload) {
        if (this.isOffline) {
            return;
        }
        this.pos.data
            .call("store.credit", "pos_log_redemption_cancelled", [
                this.pos.config.id,
                this.pos.session?.id || false,
                payload || {},
            ])
            .catch(() => {});
    }

    async processOfflineRedemptionQueue() {
        if (this.isOffline) {
            return;
        }
        const storageKey = `${OFFLINE_REDEMPTION_QUEUE_PREFIX}${this.pos.config.id}`;
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(storageKey) || "[]");
        } catch {
            return;
        }
        const remaining = [];
        for (const entry of queue) {
            try {
                const result = await this.precheckRedemption(entry);
                if (!result?.valid) {
                    remaining.push(entry);
                }
            } catch {
                remaining.push(entry);
            }
        }
        localStorage.setItem(storageKey, JSON.stringify(remaining));
    }

    _getOfflineSettings() {
        return {
            success: true,
            enable_store_credit: true,
            allow_partial_redemption: true,
            allow_multiple_voucher_usage: true,
            allow_split_payment: true,
            minimum_redemption_amount: 0,
            maximum_redemption_amount: 0,
            credit_redemption_order: "oldest_first",
            remaining_credit_strategy: "issue_new",
            auto_print_remainder_voucher: true,
            require_manager_approval_partial: false,
            offline_enabled: true,
        };
    }

    _calculateBreakdownOffline(dueAmount, creditIds, amounts = {}) {
        const due = Math.max(Number(dueAmount) || 0, 0);
        let dueLeft = due;
        let creditUsed = 0;
        const allocations = [];
        for (const creditId of creditIds || []) {
            const cached = this._getCachedCredit(creditId);
            if (!cached) {
                continue;
            }
            const remaining = Number(cached.amount_remaining) || 0;
            const requested =
                amounts[creditId] !== undefined
                    ? Number(amounts[creditId])
                    : Math.min(remaining, dueLeft);
            const applicable = Math.min(requested, remaining, dueLeft);
            if (applicable <= 0) {
                continue;
            }
            allocations.push({
                credit_id: creditId,
                amount: applicable,
                amount_remaining_before: remaining,
                amount_remaining_after: remaining - applicable,
            });
            creditUsed += applicable;
            dueLeft -= applicable;
        }
        return {
            success: true,
            due_amount: due,
            credit_used: creditUsed,
            customer_payment: Math.max(due - creditUsed, 0),
            remaining_credit: allocations.reduce(
                (sum, a) => sum + Math.max(a.amount_remaining_after, 0),
                0
            ),
            allocations,
        };
    }

    _getCachedCredit(creditId) {
        try {
            const credits = JSON.parse(localStorage.getItem(this._cacheKey()) || "[]");
            return credits.find((c) => c.credit_id === creditId);
        } catch {
            return null;
        }
    }

    _cacheKey() {
        return `${OFFLINE_REDEMPTION_KEY_PREFIX}${this.pos.config.id}`;
    }

    _cacheCredits(credits) {
        try {
            const key = this._cacheKey();
            const existing = JSON.parse(localStorage.getItem(key) || "[]");
            const merged = [...existing];
            for (const credit of credits) {
                if (!merged.some((c) => c.credit_id === credit.credit_id)) {
                    merged.push(credit);
                }
            }
            localStorage.setItem(key, JSON.stringify(merged.slice(-100)));
        } catch {
            // Non-blocking cache
        }
    }

    _lookupOffline(query, lookupType, partnerId) {
        let credits = [];
        try {
            credits = JSON.parse(localStorage.getItem(this._cacheKey()) || "[]");
        } catch {
            credits = [];
        }
        const q = (query || "").toLowerCase();
        const filtered = credits.filter((credit) => {
            if (lookupType === "customer" && partnerId) {
                return credit.partner_id === partnerId;
            }
            if (lookupType === "barcode") {
                return (credit.barcode || "").toLowerCase() === q;
            }
            if (lookupType === "voucher_number") {
                return (
                    (credit.voucher_number || "").toLowerCase() === q ||
                    (credit.name || "").toLowerCase() === q
                );
            }
            if (lookupType === "uuid") {
                return (credit.uuid || "").toLowerCase() === q;
            }
            return (
                (credit.barcode || "").toLowerCase().includes(q) ||
                (credit.voucher_number || "").toLowerCase().includes(q) ||
                (credit.name || "").toLowerCase().includes(q)
            );
        });
        if (!filtered.length) {
            return {
                success: false,
                error: _t("No cached store credit found. Connect to validate."),
            };
        }
        return { success: true, credits: filtered, offline: true };
    }

    _precheckOffline(payload) {
        if (!payload?.credit_id || !payload?.amount) {
            return { valid: false, error: _t("Invalid redemption payload.") };
        }
        return { valid: true, applicable_amount: payload.amount };
    }

    _queueOfflineRedemption(order, redemption) {
        const storageKey = `${OFFLINE_REDEMPTION_QUEUE_PREFIX}${this.pos.config.id}`;
        const entry = {
            ...redemption,
            order_uuid: order.uuid,
            queued_at: new Date().toISOString(),
        };
        let queue = [];
        try {
            queue = JSON.parse(localStorage.getItem(storageKey) || "[]");
        } catch {
            queue = [];
        }
        const duplicate = queue.some(
            (q) =>
                q.redemption_uuid === entry.redemption_uuid ||
                (q.credit_id === entry.credit_id && q.order_uuid === entry.order_uuid)
        );
        if (!duplicate) {
            queue.push(entry);
        }
        localStorage.setItem(storageKey, JSON.stringify(queue));
    }
}
