/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import OrderPaymentValidation from "@point_of_sale/app/utils/order_payment_validation";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { _t } from "@web/core/l10n/translation";

patch(OrderPaymentValidation.prototype, {
    async validateOrder(isForceValidate) {
        const order = this.order;
        const redemptionUi = this.pos.storeCreditRedemption;
        if (redemptionUi) {
            const scLine = redemptionUi.getExistingStoreCreditPaymentLine(order);
            if (scLine) {
                const data = redemptionUi.parseRedemptionData(scLine);
                if (!data.redemptions.length) {
                    this.pos.dialog.add(AlertDialog, {
                        title: _t("Store Credit"),
                        body: _t("Store credit payment is missing voucher redemption data."),
                    });
                    return false;
                }
                if (redemptionUi.isOffline) {
                    for (const redemption of data.redemptions) {
                        const precheck = await redemptionUi.precheckRedemption({
                            ...redemption,
                            partner_id: order.getPartner()?.id || false,
                            existing_redemptions: data.redemptions,
                        });
                        if (!precheck?.valid) {
                            this.pos.dialog.add(AlertDialog, {
                                title: _t("Store Credit"),
                                body:
                                    precheck?.error ||
                                    _t("Store credit validation failed in offline mode."),
                            });
                            return false;
                        }
                    }
                }
            }
        }
        return super.validateOrder(...arguments);
    },
});
