/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PosPayment } from "@point_of_sale/app/models/pos_payment";

patch(PosPayment.prototype, {
    setup(vals) {
        super.setup(...arguments);
        this.store_credit_redemption_data = vals.store_credit_redemption_data || "";
    },

    getStoreCreditLabel() {
        if (!this.store_credit_redemption_data) {
            return "";
        }
        try {
            const data =
                typeof this.store_credit_redemption_data === "string"
                    ? JSON.parse(this.store_credit_redemption_data)
                    : this.store_credit_redemption_data;
            const count = (data.redemptions || []).length;
            return count === 1
                ? data.redemptions[0].voucher_number
                : `${count} credits`;
        } catch {
            return "";
        }
    },
});
