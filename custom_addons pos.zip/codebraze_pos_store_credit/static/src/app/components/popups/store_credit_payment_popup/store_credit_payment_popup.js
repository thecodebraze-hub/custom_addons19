/** @odoo-module **/

import { Component, useState, onMounted } from "@odoo/owl";
import { Dialog } from "@web/core/dialog/dialog";
import { _t } from "@web/core/l10n/translation";
import { useService } from "@web/core/utils/hooks";

export class StoreCreditPaymentPopup extends Component {
    static template = "codebraze_pos_store_credit.StoreCreditPaymentPopup";
    static components = { Dialog };
    static props = {
        pos: { type: Object },
        order: { type: Object },
        getPayload: { type: Function },
        close: { type: Function },
    };

    setup() {
        this.pos = this.props.pos;
        this.order = this.props.order;
        this.redemptionUi = this.pos.storeCreditRedemption;
        this.notification = useService("notification");
        this.state = useState({
            loading: false,
            error: "",
            warning: "",
            lookupType: "barcode",
            query: "",
            credits: [],
            selectedCredit: null,
            applyAmount: 0,
            settings: null,
            breakdown: null,
            managerApproved: false,
        });

        onMounted(async () => {
            this.state.settings = await this.redemptionUi.loadSettings();
            if (this.order.getPartner()) {
                await this.lookupCustomerCredits();
            }
        });
    }

    get dueAmount() {
        return Math.max(this.order.remainingDue ?? 0, 0);
    }

    get formattedDue() {
        return this.redemptionUi.formatMoney(this.dueAmount);
    }

    get canApply() {
        return (
            this.state.selectedCredit &&
            this.state.applyAmount > 0 &&
            !this.state.loading &&
            !this.state.error &&
            (!this.needsManagerApproval || this.state.managerApproved)
        );
    }

    get canApplyAll() {
        return (
            this.state.credits.length > 1 &&
            this.state.settings?.allow_multiple_voucher_usage &&
            this.state.settings?.credit_redemption_order !== "manual" &&
            !this.state.loading
        );
    }

    get needsManagerApproval() {
        if (!this.state.settings?.require_manager_approval_partial) {
            return false;
        }
        const credit = this.state.selectedCredit;
        if (!credit || !this.state.applyAmount) {
            return false;
        }
        return this.state.applyAmount < (credit.amount_remaining || 0);
    }

    get lookupTypes() {
        return [
            { id: "barcode", label: _t("Barcode") },
            { id: "voucher_number", label: _t("Voucher Number") },
            { id: "manual", label: _t("Manual Search") },
            { id: "customer", label: _t("Customer Credits") },
        ];
    }

    onLookupTypeChange(ev) {
        this.state.lookupType = ev.target.value;
        this.state.credits = [];
        this.state.selectedCredit = null;
        this.state.breakdown = null;
        this.state.error = "";
        if (this.state.lookupType === "customer") {
            this.lookupCustomerCredits();
        }
    }

    async lookupCustomerCredits() {
        const partner = this.order.getPartner();
        if (!partner) {
            this.state.error = _t("Select a customer to list store credits.");
            return;
        }
        await this.runLookup("", "customer", partner.id);
    }

    isSelectedCredit(credit) {
        return (
            this.state.selectedCredit &&
            this.state.selectedCredit.credit_id === credit.credit_id
        );
    }

    onSearchKeydown(ev) {
        if (ev.key === "Enter") {
            this.search();
        }
    }

    async search() {
        if (this.state.lookupType === "customer") {
            await this.lookupCustomerCredits();
            return;
        }
        if (!this.state.query.trim()) {
            this.state.error = _t("Enter a search value.");
            return;
        }
        const lookupType =
            this.state.lookupType === "manual" ? "manual" : this.state.lookupType;
        await this.runLookup(this.state.query.trim(), lookupType);
    }

    async runLookup(query, lookupType, partnerId = false) {
        this.state.loading = true;
        this.state.error = "";
        this.state.warning = "";
        const result = await this.redemptionUi.lookupStoreCredit({
            query,
            lookupType,
            partnerId: partnerId || this.order.getPartner()?.id || false,
        });
        this.state.loading = false;
        if (!result?.success) {
            this.state.credits = result?.credits || [];
            this.state.error = result?.error || _t("No store credit found.");
            return;
        }
        if (result.offline) {
            this.state.warning = _t("Offline mode — using cached credits.");
        }
        this.state.credits = result.credits || [];
        if (this.state.credits.length === 1) {
            await this.selectCredit(this.state.credits[0]);
        }
    }

    async selectCredit(credit) {
        this.state.selectedCredit = credit;
        const amount = this.redemptionUi.computeApplicableAmount(
            this.order,
            credit,
            credit.amount_remaining
        );
        this.state.applyAmount = amount;
        this.state.error = "";
        this.state.managerApproved = false;
        await this.refreshBreakdown();
    }

    async onApplyAmountChange() {
        this.state.managerApproved = false;
        await this.refreshBreakdown();
    }

    async refreshBreakdown() {
        const credit = this.state.selectedCredit;
        if (!credit) {
            this.state.breakdown = null;
            return;
        }
        const serverBreakdown = await this.redemptionUi.calculateRedemptionBreakdown({
            dueAmount: this.dueAmount,
            creditIds: [credit.credit_id],
            partnerId: this.order.getPartner()?.id || false,
            amounts: { [credit.credit_id]: this.state.applyAmount },
        });
        if (serverBreakdown?.success) {
            this.state.breakdown = {
                creditUsed: serverBreakdown.credit_used,
                remainingCredit: serverBreakdown.remaining_credit,
                customerPayment: serverBreakdown.customer_payment,
                strategy: serverBreakdown.remaining_credit_strategy,
                willIssueNew: (serverBreakdown.remainder_lines || []).some(
                    (line) => line.will_issue_new
                ),
            };
            return;
        }
        this.state.breakdown = this.redemptionUi.computeLocalBreakdown(
            this.order,
            credit,
            this.state.applyAmount
        );
    }

    toggleManagerApproval() {
        this.state.managerApproved = !this.state.managerApproved;
    }

    cancel() {
        this.redemptionUi.logRedemptionCancelled({
            order_uuid: this.order.uuid,
        });
        this.props.close();
    }

    async applyAll() {
        this.state.loading = true;
        this.state.error = "";
        try {
            const result = await this.redemptionUi.applyAutoAllocatedCredits(
                this.order,
                this.state.credits
            );
            if (!result?.success) {
                this.state.error = result?.error || _t("Unable to apply store credits.");
                return;
            }
            this.props.getPayload({
                action: "credit_applied",
                result,
                remainingDue: Math.max(
                    this.dueAmount - (result.allocation?.credit_used || 0),
                    0
                ),
            });
            this.props.close();
        } finally {
            this.state.loading = false;
        }
    }

    async apply() {
        const credit = this.state.selectedCredit;
        if (!credit) {
            return;
        }
        this.state.loading = true;
        this.state.error = "";
        try {
            const payload = this.redemptionUi.buildRedemptionPayload(
                credit,
                this.state.applyAmount,
                this.order,
                { managerApproved: this.state.managerApproved }
            );
            const precheck = await this.redemptionUi.precheckRedemption(payload);
            if (!precheck?.valid) {
                this.state.error = precheck?.error || _t("Validation failed.");
                return;
            }
            const amount = precheck.applicable_amount ?? this.state.applyAmount;
            const result = this.redemptionUi.applyRedemptionToOrder(
                this.order,
                credit,
                amount,
                { managerApproved: this.state.managerApproved }
            );
            if (!result.success) {
                this.state.error = result.error || _t("Unable to apply store credit.");
                return;
            }
            this.props.getPayload({
                action: "credit_applied",
                result,
                remainingDue: Math.max(this.dueAmount - amount, 0),
            });
            this.props.close();
        } finally {
            this.state.loading = false;
        }
    }
}
