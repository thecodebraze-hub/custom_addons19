/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";
import { makeAwaitable } from "@point_of_sale/app/utils/make_awaitable_dialog";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { StoreCreditPaymentPopup } from "../components/popups/store_credit_payment_popup/store_credit_payment_popup";
import { _t } from "@web/core/l10n/translation";

patch(PaymentScreen.prototype, {
    async addNewPaymentLine(paymentMethod) {
        if (paymentMethod.is_store_credit) {
            return this.openStoreCreditPaymentPopup(paymentMethod);
        }
        return super.addNewPaymentLine(...arguments);
    },

    async openStoreCreditPaymentPopup(paymentMethod) {
        const settings = await this.pos.storeCreditRedemption.loadSettings();
        if (!settings?.enable_store_credit) {
            this.dialog.add(AlertDialog, {
                title: _t("Store Credit"),
                body: _t("Store credit redemption is disabled."),
            });
            return false;
        }
        if (this.pos.cashier?._role === "minimal") {
            this.notification.add(_t("Permission Denied"), { type: "danger" });
            return false;
        }

        const result = await makeAwaitable(this.dialog, StoreCreditPaymentPopup, {
            pos: this.pos,
            order: this.currentOrder,
        });

        if (!result || result.action !== "credit_applied") {
            return false;
        }

        this.numberBuffer.reset();
        if (result.result?.paymentLine) {
            this.numberBuffer.set(result.result.paymentLine.amount.toString());
        }
        return true;
    },
});
