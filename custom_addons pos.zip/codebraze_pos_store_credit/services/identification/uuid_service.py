# -*- coding: utf-8 -*-
"""UUID service for store credit and future credit instruments."""

import uuid as py_uuid

from .validators.uuid_validators import UUIDValidators


class UUIDService:
    """Reusable UUID operations (generation, validation, duplicate detection)."""

    def __init__(self, env):
        self.env = env
        self.validators = UUIDValidators()

    def generate_uuid(self):
        """Generate a UUID4 string."""
        return str(py_uuid.uuid4())

    def validate_uuid(self, uuid_str):
        """Validate uuid string format."""
        self.validators.validate_uuid(uuid_str)
        return True

    def check_duplicate_uuid(self, uuid_str, model="store.credit"):
        """Raise DuplicateError if uuid already exists in the target model."""
        return self.validators.check_duplicate_uuid(self.env, uuid_str, model=model)

    def validate_and_check_duplicate(self, uuid_str, model="store.credit"):
        """Validate uuid and check duplicates."""
        self.validate_uuid(uuid_str)
        self.check_duplicate_uuid(uuid_str, model=model)
        return True

