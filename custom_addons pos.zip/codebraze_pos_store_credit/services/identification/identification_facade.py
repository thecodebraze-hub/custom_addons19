# -*- coding: utf-8 -*-
"""Facade service for reusable identification operations.

This class provides a single entry point for other modules to generate and
validate UUIDs, barcodes and QR payloads while centralizing configuration
resolution and validation behavior.
"""

from .barcode_service import BarcodeService
from .qr_service import QRService
from .sequence_service import SequenceService
from .uuid_service import UUIDService


class IdentificationFacadeService:
    """Facade combining barcode, UUID, sequence and QR services."""

    def __init__(self, env):
        self.env = env
        self.barcode_service = BarcodeService(env)
        self.uuid_service = UUIDService(env)
        self.sequence_service = SequenceService(env)
        self.qr_service = QRService(env)

    # Utility pass-throughs
    def generate_uuid(self):
        return self.uuid_service.generate_uuid()

    def validate_uuid(self, uuid_str):
        return self.uuid_service.validate_uuid(uuid_str)

    def validate_and_check_uuid_duplicate(self, uuid_str, model="store.credit"):
        return self.uuid_service.validate_and_check_duplicate(
            uuid_str, model=model
        )

    def generate_barcode(self, **kwargs):
        return self.barcode_service.generate_barcode(**kwargs)

    def validate_barcode(self, barcode, **kwargs):
        return self.barcode_service.validate_barcode(barcode, **kwargs)

    def parse_barcode(self, barcode, **kwargs):
        return self.barcode_service.parse_barcode(barcode, **kwargs)

    def generate_sequence(self, sequence_code, company_id=None, sequence_date=None):
        return self.sequence_service.next_by_code(
            sequence_code=sequence_code,
            company_id=company_id,
            sequence_date=sequence_date,
        )

    def build_qr_payload(self, **kwargs):
        return self.qr_service.build_qr_payload(**kwargs)

