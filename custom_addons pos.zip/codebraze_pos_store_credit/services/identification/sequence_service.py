# -*- coding: utf-8 -*-
"""Sequence service wrapper around ir.sequence."""

from odoo.exceptions import UserError


class SequenceService:
    """Reusable sequence operations."""

    def __init__(self, env):
        self.env = env

    def next_by_code(self, sequence_code, company_id=None, sequence_date=None):
        """Get next sequence value using ir.sequence.

        :param sequence_code: ir.sequence code (e.g. 'store.credit.transaction')
        :param company_id: res.company id (optional)
        :param sequence_date: optional date/datetime for sequence (unused here)
        """
        sequence = self.env["ir.sequence"]
        if company_id:
            sequence = sequence.with_company(self.env["res.company"].browse(company_id))
        value = sequence.next_by_code(
            sequence_code, sequence_date=sequence_date
        )
        if not value:
            raise UserError(
                self.env._("Sequence '%(code)s' is not configured.", code=sequence_code)
            )
        return value

