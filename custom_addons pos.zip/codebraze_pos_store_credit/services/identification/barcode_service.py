# -*- coding: utf-8 -*-
"""Barcode service for generating, validating and parsing barcodes."""

from odoo.exceptions import UserError

from ...utils.identification.barcode_format import (
    format_barcode,
    normalize_prefix,
    parse_numeric_body,
)
from .sequence_service import SequenceService
from .uuid_service import UUIDService
from .validators.barcode_validators import BarcodeValidators


class BarcodeService:
    """Reusable barcode operations.

    This service is designed to be consumed by Store Credit, Return Voucher,
    Gift Voucher and future credit instruments.
    """

    def __init__(self, env):
        self.env = env
        self.validators = BarcodeValidators()
        self.sequence_service = SequenceService(env)
        self.uuid_service = UUIDService(env)

    def _resolve_prefix_padding(self, company_id=None, config=None, prefix=None, padding=None):
        settings_model = self.env["store.credit.settings"]
        settings = settings_model._get_settings(company=company_id or self.env.company, config=config)
        resolved_prefix = normalize_prefix(prefix or getattr(settings, "barcode_prefix", "") or getattr(settings, "voucher_prefix", ""))
        if not resolved_prefix:
            raise UserError(self.env._("Barcode prefix is not configured."))
        resolved_padding = int(padding or getattr(settings, "barcode_padding", 10) or 10)
        if resolved_padding <= 0:
            raise UserError(self.env._("Barcode padding must be > 0."))
        return resolved_prefix, resolved_padding

    def generate_barcode(
        self,
        company_id=None,
        config=None,
        *,
        prefix=None,
        padding=None,
        sequence_code="store.credit.barcode",
        offline=False,
        uuid_str=None,
        check_duplicate=True,
    ):
        """Generate a barcode string.

        Online generation uses ir.sequence and uniqueness checks.
        Offline generation uses UUID-derived numeric body (uuid_only strategy).
        """
        prefix, padding = self._resolve_prefix_padding(
            company_id=company_id, config=config, prefix=prefix, padding=padding
        )

        if offline:
            uuid_str = uuid_str or self.uuid_service.generate_uuid()
            # Validate UUID before generating barcode
            self.uuid_service.validate_uuid(uuid_str)
            digits = "".join(ch for ch in uuid_str.replace("-", "") if ch.isdigit())
            if not digits:
                # Deterministic fallback (still derived from UUID)
                digits = "0"
            numeric_body = digits[-padding:]  # keep last digits stable across sync
            barcode = format_barcode(prefix=prefix, numeric_body=numeric_body, padding=padding)
        else:
            seq_value = self.sequence_service.next_by_code(
                sequence_code, company_id=company_id
            )
            numeric_body = parse_numeric_body(str(seq_value))
            if not numeric_body:
                numeric_body = str(seq_value)
            barcode = format_barcode(prefix=prefix, numeric_body=numeric_body, padding=padding)

        if check_duplicate:
            self.validators.check_duplicate_barcode(self.env, barcode, model="store.credit")
        return barcode

    def validate_barcode(
        self,
        barcode,
        *,
        expected_prefix=None,
        expected_numeric_length=None,
        check_duplicate=False,
    ):
        """Validate barcode structure and optionally check existence/duplicate."""
        if not barcode:
            raise UserError(self.env._("Barcode is required."))
        if expected_prefix:
            self.validators.validate_prefix(barcode, expected_prefix)
        self.validators.validate_format(
            barcode,
            expected_prefix=expected_prefix,
            expected_numeric_length=expected_numeric_length,
        )
        if check_duplicate:
            self.validators.check_duplicate_barcode(
                self.env, barcode, model="store.credit"
            )
        return True

    def parse_barcode(self, barcode, expected_prefix=None):
        """Parse barcode and return components (best-effort)."""
        expected_prefix = normalize_prefix(expected_prefix) if expected_prefix else None
        numeric = parse_numeric_body(barcode, expected_prefix=expected_prefix)
        return {
            "prefix": expected_prefix or (barcode.split(str(numeric))[0] if numeric else ""),
            "numeric_body": numeric,
        }

    def validate_uuid_for_offline_barcode(self, uuid_str):
        """Ensure UUID is valid so offline barcode generation is deterministic."""
        self.uuid_service.validate_uuid(uuid_str)
        return True

