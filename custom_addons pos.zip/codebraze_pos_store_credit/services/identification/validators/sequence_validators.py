# -*- coding: utf-8 -*-
"""Sequence validation helpers for the identification framework."""

from ....utils.identification.exceptions import IdentificationValidationError


class SequenceValidators:
    """Reusable validators for sequences."""

    def validate_sequence_code(self, sequence_code):
        if not sequence_code or not str(sequence_code).strip():
            raise IdentificationValidationError("Sequence code is required.")

