# -*- coding: utf-8 -*-
"""Barcode validation helpers for the identification framework."""

from ....utils.identification.barcode_format import (
    looks_like_barcode,
    normalize_prefix,
)
from ....utils.identification.exceptions import DuplicateError, IdentificationValidationError


class BarcodeValidators:
    """Reusable validators for barcode operations."""

    def validate_prefix(self, barcode, expected_prefix):
        """Validate that barcode prefix matches expected_prefix."""
        expected_prefix = normalize_prefix(expected_prefix)
        if expected_prefix and not barcode.startswith(expected_prefix):
            raise IdentificationValidationError(
                f"Barcode prefix '{expected_prefix}' is required."
            )

    def validate_format(self, barcode, expected_prefix=None, expected_numeric_length=None):
        """Validate best-effort barcode structure."""
        if not looks_like_barcode(
            barcode, prefix=expected_prefix, numeric_length=expected_numeric_length
        ):
            raise IdentificationValidationError("Invalid barcode format.")

    def check_duplicate_barcode(self, env, barcode, model="store.credit"):
        """Raise DuplicateError when barcode already exists."""
        if not barcode:
            return
        exists = env[model].sudo().with_context(active_test=False).search_count(
            [("barcode", "=", barcode)]
        )
        if exists:
            raise DuplicateError(
                env._("Barcode %(barcode)s is already used.", barcode=barcode)
            )

    def validate_non_empty(self, barcode):
        if not barcode:
            raise IdentificationValidationError("Barcode is required.")
