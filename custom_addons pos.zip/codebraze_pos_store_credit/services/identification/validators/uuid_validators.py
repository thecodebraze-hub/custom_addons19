# -*- coding: utf-8 -*-
"""UUID validation helpers for the identification framework."""

import re

from ....utils.identification.exceptions import DuplicateError, IdentificationValidationError


_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


class UUIDValidators:
    """Reusable validators for UUID operations."""

    def validate_uuid(self, uuid):
        """Validate UUID format (UUID4 string expected)."""
        if not uuid or not _UUID_RE.match(str(uuid).strip()):
            raise IdentificationValidationError("Invalid UUID format.")

    def check_duplicate_uuid(self, env, uuid, model="store.credit"):
        """Raise DuplicateError when UUID already exists."""
        if not uuid:
            return
        exists = env[model].sudo().search_count([("uuid", "=", uuid)])
        if exists:
            raise DuplicateError(env._("UUID %(uuid)s already exists.", uuid=uuid))

