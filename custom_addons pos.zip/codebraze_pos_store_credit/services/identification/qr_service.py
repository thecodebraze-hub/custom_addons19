# -*- coding: utf-8 -*-
"""QR payload service for store credit instruments."""

from ...utils.identification.qr_payload import build_qr_payload


class QRService:
    """QR code payload builder.

    Rendering a QR image is intentionally left to later phases or to client
    side libraries. This service provides a stable payload.
    """

    def __init__(self, env):
        self.env = env

    def build_qr_payload(
        self,
        *,
        voucher_number,
        uuid,
        verification_url=None,
        extra_payload=None,
    ):
        """Build a JSON payload suitable for QR encoding."""
        return build_qr_payload(
            voucher_number=voucher_number,
            uuid=uuid,
            verification_url=verification_url,
            extra_payload=extra_payload,
        )

