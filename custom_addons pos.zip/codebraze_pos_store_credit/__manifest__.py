# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Store Credit",
    "version": "19.0.1.2.0",
    "category": "Sales/Point of Sale",
    "summary": "Core store credit engine for POS returns, vouchers and future wallets",
    "description": """
CodeBraze Store Credit Framework
================================
Generic store credit ledger supporting Return, Gift, Manual, Compensation,
Promotion, Loyalty, Wallet, Employee Credit and future credit programs.
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "point_of_sale",
        "stock",
        "mail",
    ],
    "data": [
        "security/ir.model.access.csv",
        "data/ir_sequence_data.xml",
        "data/store_credit_settings_data.xml",
        "data/pos_payment_method_data.xml",
    ],
    "assets": {
        "point_of_sale._assets_pos": [
            "codebraze_pos_store_credit/static/src/**/*",
        ],
    },
    "application": False,
    "installable": True,
    "auto_install": False,
}
