# -*- coding: utf-8 -*-
"""Partial redemption engine — remaining balance strategies and multi-credit allocation."""

import json
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare, float_is_zero

_logger = logging.getLogger(__name__)

REMAINING_STRATEGY_UPDATE_EXISTING = "update_existing"
REMAINING_STRATEGY_ISSUE_NEW = "issue_new"


class StoreCreditPartialRedemptionService(models.Model):
    _inherit = "store.credit"

    # -------------------------------------------------------------------------
    # POS RPC
    # -------------------------------------------------------------------------

    @api.model
    def pos_calculate_redemption_breakdown(self, payload, config_id):
        """Return credit used, remainder, and customer payment for a redemption plan."""
        config = self.env["pos.config"].browse(config_id).exists()
        if not config:
            return {"success": False, "error": self.env._("POS configuration not found.")}

        due_amount = float((payload or {}).get("due_amount") or 0.0)
        credit_ids = (payload or {}).get("credit_ids") or []
        explicit_amounts = (payload or {}).get("amounts") or {}

        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        )

        if credit_ids:
            credits = self.browse(credit_ids).exists()
            credits = self._sort_credits_for_allocation(
                credits.filtered(lambda c: c._is_redeemable()),
                getattr(settings, "credit_redemption_order", "oldest_first"),
            )
        elif payload.get("partner_id"):
            credits = self._pos_search_partner_credits(payload["partner_id"], config)
        else:
            credit = self.browse((payload or {}).get("credit_id")).exists()
            credits = credit if credit else self.env["store.credit"]

        if not credits:
            return {
                "success": False,
                "error": self.env._("No redeemable store credit found."),
            }

        allocations = self._allocate_credits_to_due(
            credits,
            due_amount,
            settings,
            explicit_amounts=explicit_amounts,
        )
        credit_used = sum(a["amount"] for a in allocations)
        customer_payment = max(due_amount - credit_used, 0.0)
        remaining_credit_total = sum(
            max(a["amount_remaining_before"] - a["amount"], 0.0) for a in allocations
        )

        strategy = getattr(
            settings, "remaining_credit_strategy", REMAINING_STRATEGY_ISSUE_NEW
        )
        remainder_lines = []
        for line in allocations:
            remainder = max(line["amount_remaining_before"] - line["amount"], 0.0)
            if float_is_zero(remainder, precision_rounding=credits[:1].currency_id.rounding if credits else 0.01):
                continue
            remainder_lines.append(
                {
                    "credit_id": line["credit_id"],
                    "remainder": remainder,
                    "strategy": strategy,
                    "will_issue_new": strategy == REMAINING_STRATEGY_ISSUE_NEW,
                }
            )

        return {
            "success": True,
            "due_amount": due_amount,
            "credit_used": credit_used,
            "customer_payment": customer_payment,
            "remaining_credit": remaining_credit_total,
            "allocations": allocations,
            "remainder_lines": remainder_lines,
            "remaining_credit_strategy": strategy,
        }

    @api.model
    def pos_allocate_store_credits(self, payload, config_id, session_id=False):
        """Allocate multiple store credits against an order due amount."""
        breakdown = self.pos_calculate_redemption_breakdown(payload, config_id)
        if not breakdown.get("success"):
            return breakdown

        config = self.env["pos.config"].browse(config_id).exists()
        session = (
            self.env["pos.session"].browse(session_id).exists() if session_id else False
        )
        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        )

        allocations = breakdown.get("allocations") or []
        if len(allocations) > 1 and not getattr(settings, "allow_multiple_voucher", True):
            return {
                "success": False,
                "error": self.env._("Multiple store credits on one order are not allowed."),
            }

        for line in allocations:
            credit = self.browse(line["credit_id"]).exists()
            validation = self._pos_validate_credit_for_redemption(
                credit,
                config,
                session=session,
                partner_id=(payload or {}).get("partner_id"),
                amount=line["amount"],
            )
            if not validation.get("valid"):
                return {
                    "success": False,
                    "error": validation.get("error"),
                    "error_code": "validation_failure",
                }
            partial_check = self._validate_partial_redemption_policy(
                credit,
                line["amount"],
                settings,
                payload or {},
            )
            if not partial_check.get("valid"):
                return partial_check

        return {
            "success": True,
            "allocations": allocations,
            **{k: breakdown[k] for k in (
                "due_amount",
                "credit_used",
                "customer_payment",
                "remaining_credit",
                "remainder_lines",
                "remaining_credit_strategy",
            )},
        }

    # -------------------------------------------------------------------------
    # Remaining balance strategy (post-redeem)
    # -------------------------------------------------------------------------

    def _handle_partial_redemption_remainder(
        self,
        redeemed_amount,
        pos_order,
        config,
        session,
        voucher=None,
        sc_payment=None,
        manager_approved=False,
    ):
        """
        Apply the configured remaining-balance strategy after a redeem transaction.

        Mode 01 (update_existing): keep balance on the same credit (no-op).
        Mode 02 (issue_new): transfer remainder to a new credit / voucher and mark
        the original as fully used.
        """
        self.ensure_one()
        settings = self._get_settings()
        precision = self.currency_id.rounding
        remaining = self.amount_remaining

        if float_is_zero(remaining, precision_rounding=precision):
            return {"strategy": "none", "remainder": 0.0}

        is_partial = float_compare(redeemed_amount, 0.0, precision_rounding=precision) > 0
        if not is_partial:
            return {"strategy": "none", "remainder": remaining}

        partial_check = self._validate_partial_redemption_policy(
            self,
            redeemed_amount,
            settings,
            {"manager_approved": manager_approved},
            balance_before=redeemed_amount + remaining,
        )
        if not partial_check.get("valid"):
            raise UserError(
                partial_check.get("error")
                or self.env._("Partial redemption is not allowed.")
            )

        strategy = getattr(
            settings, "remaining_credit_strategy", REMAINING_STRATEGY_ISSUE_NEW
        )

        self._log_partial_redemption_audit(
            redeemed_amount=redeemed_amount,
            remaining=remaining,
            strategy=strategy,
            config=config,
            session=session,
            pos_order=pos_order,
            voucher=voucher,
        )

        if strategy == REMAINING_STRATEGY_UPDATE_EXISTING:
            return {
                "strategy": REMAINING_STRATEGY_UPDATE_EXISTING,
                "remainder": remaining,
                "credit_id": self.id,
                "voucher_id": voucher.id if voucher else False,
                "state": self.state,
                "barcode": self.barcode,
                "voucher_number": voucher.voucher_number if voucher else self.name,
            }

        return self._issue_remainder_credit(
            amount=remaining,
            pos_order=pos_order,
            config=config,
            session=session,
            parent_voucher=voucher,
            sc_payment=sc_payment,
        )

    def _issue_remainder_credit(
        self,
        amount,
        pos_order,
        config,
        session,
        parent_voucher=None,
        sc_payment=None,
        user=None,
    ):
        """Transfer remainder to a new store credit (and voucher when applicable)."""
        self.ensure_one()
        user = user or self.env.user
        precision = self.currency_id.rounding
        remaining = self.amount_remaining

        if float_compare(amount, remaining, precision_rounding=precision) > 0:
            amount = remaining
        if float_is_zero(amount, precision_rounding=precision):
            return {"strategy": "none", "remainder": 0.0}

        new_credit_vals = {
            "credit_type": self.credit_type,
            "partner_id": self.partner_id.id or False,
            "company_id": self.company_id.id,
            "currency_id": self.currency_id.id,
            "config_id": (pos_order.config_id.id if pos_order else self.config_id.id)
            or False,
            "session_id": session.id if session else False,
            "cashier_id": user.id,
            "amount": 0.0,
            "state": "issued",
            "issue_date": fields.Datetime.now(),
            "expiry_date": self.expiry_date,
            "original_order_id": self.original_order_id.id or False,
            "origin_model": "store.credit",
            "origin_res_id": self.id,
            "note": self.env._(
                "Remainder issued from partial redemption of %(name)s",
                name=self.name,
            ),
        }
        new_credit = self.create(new_credit_vals)
        self._transfer_credit_to(
            new_credit,
            amount,
            reason=self.env._("Partial redemption remainder transfer"),
            user=user,
        )

        new_voucher = False
        voucher_model = self.env.get("pos.return.voucher")
        if voucher_model is not None:
            new_voucher = voucher_model._create_remainder_voucher(
                parent_voucher=parent_voucher,
                credit=new_credit,
                pos_order=pos_order,
                session=session,
                user=user,
            )

        print_payload = self._trigger_remainder_voucher_print(
            new_voucher or new_credit,
            config=config,
            session=session,
            user=user,
        )

        self._log_remainder_issued_audit(
            amount=amount,
            new_credit=new_credit,
            new_voucher=new_voucher,
            config=config,
            session=session,
            pos_order=pos_order,
            sc_payment=sc_payment,
        )

        return {
            "strategy": REMAINING_STRATEGY_ISSUE_NEW,
            "remainder": amount,
            "original_credit_id": self.id,
            "original_state": self.state,
            "new_credit_id": new_credit.id,
            "new_credit_name": new_credit.name,
            "new_barcode": new_credit.barcode,
            "new_voucher_id": new_voucher.id if new_voucher else False,
            "new_voucher_number": new_voucher.voucher_number if new_voucher else False,
            "print": print_payload,
        }

    def _trigger_remainder_voucher_print(self, voucher_or_credit, config, session, user=None):
        """Delegate to the voucher printing framework when installed."""
        user = user or self.env.user
        PrintService = self.env.get("pos.voucher.print.service")
        if PrintService is not None and hasattr(PrintService, "print_remainder_voucher"):
            return PrintService.print_remainder_voucher(
                voucher_or_credit,
                config=config,
                session=session,
                user=user,
            )

        voucher = voucher_or_credit
        if voucher._name == "store.credit":
            voucher_model = self.env.get("pos.return.voucher")
            if voucher_model is not None:
                voucher = voucher_model.search(
                    [("credit_id", "=", voucher_or_credit.id)], limit=1
                )
        if voucher and voucher._name == "pos.return.voucher":
            settings = self.env["store.credit.settings"]._get_settings(
                company=config.company_id, config=config
            )
            if getattr(settings, "auto_print_remainder_voucher", True):
                voucher._register_print(user=user)
                return {
                    "printed": True,
                    "voucher_id": voucher.id,
                    "voucher_number": voucher.voucher_number,
                    "trigger": "remainder",
                }
        return {"printed": False}

    # -------------------------------------------------------------------------
    # Allocation helpers
    # -------------------------------------------------------------------------

    @api.model
    def _sort_credits_for_allocation(self, credits, order_strategy):
        """Sort redeemable credits according to redemption order policy."""
        credits = credits.filtered(lambda c: c._is_redeemable())
        if order_strategy == "newest_first":
            return credits.sorted(
                key=lambda c: (c.issue_date or c.create_date, c.id), reverse=True
            )
        if order_strategy == "highest_amount_first":
            return credits.sorted(key=lambda c: (-c.amount_remaining, c.id))
        if order_strategy == "manual":
            return credits
        # oldest_first (default automatic)
        return credits.sorted(key=lambda c: (c.issue_date or c.create_date, c.id))

    @api.model
    def _allocate_credits_to_due(
        self, credits, due_amount, settings, explicit_amounts=None
    ):
        """
        Allocate credit amounts against an order due balance.

        When explicit_amounts is provided (manual mode), those amounts are honoured
        after validation; otherwise credits are consumed in sort order until due is met.
        """
        explicit_amounts = explicit_amounts or {}
        precision = credits[:1].currency_id.rounding if credits else 0.01
        due_left = max(float(due_amount or 0.0), 0.0)
        allocations = []
        order_strategy = getattr(settings, "credit_redemption_order", "oldest_first")

        sorted_credits = credits
        if order_strategy != "manual":
            sorted_credits = self._sort_credits_for_allocation(credits, order_strategy)

        for credit in sorted_credits:
            if float_is_zero(due_left, precision_rounding=precision):
                break
            remaining_before = credit.amount_remaining
            if credit.id in explicit_amounts:
                requested = float(explicit_amounts[credit.id])
            else:
                requested = min(remaining_before, due_left)

            if float_compare(requested, 0.0, precision_rounding=precision) <= 0:
                continue

            applicable = min(requested, remaining_before, due_left)
            allocations.append(
                {
                    "credit_id": credit.id,
                    "name": credit.name,
                    "barcode": credit.barcode,
                    "amount": applicable,
                    "amount_remaining_before": remaining_before,
                    "amount_remaining_after": max(remaining_before - applicable, 0.0),
                }
            )
            due_left = max(due_left - applicable, 0.0)

        return allocations

    @api.model
    def _validate_partial_redemption_policy(
        self, credit, amount, settings, payload, balance_before=None
    ):
        """Validate partial redemption rules including manager approval."""
        precision = credit.currency_id.rounding
        balance_before = (
            balance_before if balance_before is not None else credit.amount_remaining
        )
        is_partial = float_compare(amount, balance_before, precision_rounding=precision) < 0

        if is_partial and not getattr(settings, "allow_partial_usage", True):
            return {
                "valid": False,
                "error": self.env._("Partial redemption is not allowed."),
                "error_code": "partial_not_allowed",
            }

        if is_partial and getattr(
            settings, "require_manager_approval_partial", False
        ):
            if not payload.get("manager_approved"):
                return {
                    "valid": False,
                    "error": self.env._(
                        "Manager approval is required for partial redemption."
                    ),
                    "error_code": "manager_approval_required",
                }

        return {"valid": True, "is_partial": is_partial}

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    def _log_partial_redemption_audit(
        self,
        redeemed_amount,
        remaining,
        strategy,
        config,
        session,
        pos_order,
        voucher=None,
    ):
        self.ensure_one()
        payload = {
            "redeemed_amount": redeemed_amount,
            "remaining": remaining,
            "strategy": strategy,
            "credit_id": self.id,
            "voucher_id": voucher.id if voucher else False,
        }
        vals = {
            "credit_id": self.id,
            "action": "partial_redeem",
            "message": self.env._(
                "Partial redemption: %(redeemed)s used, %(remaining)s remaining "
                "(strategy=%(strategy)s)",
                redeemed=redeemed_amount,
                remaining=remaining,
                strategy=strategy,
            ),
            "amount": redeemed_amount,
            "company_id": self.company_id.id,
            "currency_id": self.currency_id.id,
            "config_id": config.id if config else False,
            "session_id": session.id if session else False,
            "cashier_id": self.env.user.id,
            "pos_order_id": pos_order.id if pos_order else False,
            "after_data": json.dumps(payload, default=str),
            "state": "done",
        }
        if voucher:
            vals["voucher_id"] = voucher.id
        return self.env["store.credit.audit"].create(vals)

    def _log_remainder_issued_audit(
        self,
        amount,
        new_credit,
        new_voucher,
        config,
        session,
        pos_order,
        sc_payment=None,
    ):
        self.ensure_one()
        payload = {
            "remainder_amount": amount,
            "original_credit_id": self.id,
            "new_credit_id": new_credit.id,
            "new_voucher_id": new_voucher.id if new_voucher else False,
            "sc_payment_id": sc_payment.id if sc_payment else False,
        }
        vals = {
            "credit_id": new_credit.id,
            "action": "remainder_issue",
            "message": self.env._(
                "Issued remainder credit %(name)s for %(amount)s after partial redemption",
                name=new_credit.name,
                amount=amount,
            ),
            "amount": amount,
            "company_id": new_credit.company_id.id,
            "currency_id": new_credit.currency_id.id,
            "config_id": config.id if config else False,
            "session_id": session.id if session else False,
            "cashier_id": self.env.user.id,
            "pos_order_id": pos_order.id if pos_order else False,
            "after_data": json.dumps(payload, default=str),
            "state": "done",
        }
        if new_voucher:
            vals["voucher_id"] = new_voucher.id
        return self.env["store.credit.audit"].create(vals)
