# -*- coding: utf-8 -*-
"""POS payment extension for store credit redemption metadata."""

from odoo import api, fields, models
from odoo.tools import float_is_zero


class PosPayment(models.Model):
    _inherit = "pos.payment"

    store_credit_redemption_data = fields.Text(
        string="Store Credit Redemptions",
        help="JSON payload of store credit / voucher redemptions applied to this payment.",
    )
    store_credit_payment_ids = fields.One2many(
        comodel_name="store.credit.payment",
        inverse_name="payment_id",
        string="Store Credit Payments",
        readonly=True,
    )

    @api.model
    def _load_pos_data_fields(self, config):
        fields_list = super()._load_pos_data_fields(config)
        return fields_list + ["store_credit_redemption_data"]

    def _create_payment_moves(self, is_reverse=False):
        """Store credit liability is cleared via store.credit accounting, not POS moves."""
        store_credit = self.filtered(
            lambda p: p.payment_method_id.is_store_credit
        )
        regular = self - store_credit
        result = self.env["account.move"]
        if regular:
            result = super(PosPayment, regular)._create_payment_moves(is_reverse=is_reverse)
        return result
