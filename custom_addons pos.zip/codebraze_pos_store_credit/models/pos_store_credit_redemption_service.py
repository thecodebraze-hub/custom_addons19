# -*- coding: utf-8 -*-
"""POS store credit redemption RPC and business orchestration."""

import json
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare

_logger = logging.getLogger(__name__)


class StoreCreditRedemptionService(models.Model):
    _inherit = "store.credit"

    # -------------------------------------------------------------------------
    # POS RPC
    # -------------------------------------------------------------------------

    @api.model
    def pos_get_redemption_settings(self, config_id):
        """Return redemption policy flags for the POS payment screen."""
        config = self.env["pos.config"].browse(config_id).exists()
        if not config:
            return {"success": False, "error": self.env._("POS configuration not found.")}
        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        )
        return {
            "success": True,
            "enable_store_credit": getattr(settings, "enable_store_credit", True),
            "allow_partial_redemption": getattr(settings, "allow_partial_usage", True),
            "allow_multiple_voucher_usage": getattr(
                settings, "allow_multiple_voucher", True
            ),
            "allow_split_payment": getattr(settings, "allow_split_payment", True),
            "minimum_redemption_amount": getattr(
                settings, "minimum_redemption_amount", 0.0
            ),
            "maximum_redemption_amount": getattr(
                settings, "maximum_redemption_amount", 0.0
            ),
            "credit_redemption_order": getattr(
                settings, "credit_redemption_order", "oldest_first"
            ),
            "remaining_credit_strategy": getattr(
                settings, "remaining_credit_strategy", "issue_new"
            ),
            "auto_print_remainder_voucher": getattr(
                settings, "auto_print_remainder_voucher", True
            ),
            "require_manager_approval_partial": getattr(
                settings, "require_manager_approval_partial", False
            ),
            "cross_branch_usage": getattr(settings, "cross_branch_usage", True),
            "offline_enabled": getattr(settings, "offline_enabled", False),
        }

    @api.model
    def pos_lookup_store_credit(
        self, query, lookup_type, config_id, session_id=False, partner_id=False
    ):
        """Find redeemable store credits by barcode, voucher number, uuid or customer."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        query = (query or "").strip()
        if not query and lookup_type != "customer":
            return {"success": False, "error": self.env._("Search value is required.")}
        if not config:
            return {"success": False, "error": self.env._("POS configuration not found.")}

        credits = self.env["store.credit"]
        voucher_model = self.env.get("pos.return.voucher")

        self._pos_log_audit_event(
            "lookup",
            self.env._("Store credit lookup: %(type)s", type=lookup_type),
            config=config,
            session=session,
            payload={"query": query, "lookup_type": lookup_type},
        )

        if lookup_type == "barcode":
            credits = credits.search(
                [("barcode", "=", query), ("active", "=", True)], limit=5
            )
        elif lookup_type == "voucher_number":
            if voucher_model is not None:
                vouchers = voucher_model.search(
                    [("voucher_number", "=", query)], limit=5
                )
                credits = vouchers.mapped("credit_id")
            if not credits:
                credits = credits.search(
                    [("name", "=", query), ("active", "=", True)], limit=5
                )
        elif lookup_type == "uuid":
            credits = credits.search([("uuid", "=", query)], limit=5)
        elif lookup_type == "customer":
            pid = partner_id or False
            if not pid:
                return {
                    "success": False,
                    "error": self.env._("Customer is required for customer lookup."),
                }
            credits = self._pos_search_partner_credits(pid, config)
        else:
            credits = self._pos_fuzzy_lookup(query, config, voucher_model)

        if not credits:
            return {
                "success": False,
                "error_code": "not_found",
                "error": self.env._("No store credit found."),
            }

        serialized = []
        for credit in credits:
            item = self._serialize_credit_for_pos(credit, config, voucher_model)
            validation = self._pos_validate_credit_for_redemption(
                credit, config, session=session, partner_id=partner_id
            )
            item["valid"] = validation.get("valid")
            item["validation_error"] = validation.get("error")
            serialized.append(item)

        valid_items = [c for c in serialized if c.get("valid")]
        if not valid_items:
            return {
                "success": False,
                "error_code": "validation_failure",
                "error": serialized[0].get("validation_error")
                if serialized
                else self.env._("Store credit is not redeemable."),
                "credits": serialized,
            }

        return {
            "success": True,
            "credits": valid_items if lookup_type != "customer" else serialized,
            "lookup_type": lookup_type,
        }

    @api.model
    def pos_precheck_redemption(self, payload, config_id, session_id=False):
        """Validate a redemption before applying it on the payment screen."""
        return self._pos_validate_redemption_payload(payload, config_id, session_id)

    @api.model
    def pos_log_redemption_cancelled(self, config_id, session_id=False, payload=None):
        """Audit hook when cashier closes the redemption popup without applying."""
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        self._pos_log_audit_event(
            "validation",
            self.env._("Store credit redemption cancelled"),
            config=config,
            session=session,
            payload=payload or {},
            success=False,
        )
        return {"success": True}

    # -------------------------------------------------------------------------
    # Redemption execution (server-side on order paid)
    # -------------------------------------------------------------------------

    @api.model
    def _pos_execute_redemption(self, line, pos_order, payment, config, session):
        """Execute a single redemption line idempotently."""
        redemption_uuid = (line or {}).get("redemption_uuid")
        if redemption_uuid:
            existing = self.env["store.credit.payment"].search(
                [("uuid", "=", redemption_uuid)], limit=1
            )
            if existing:
                return existing, {"strategy": "none"}

        credit = self.browse(line.get("credit_id")).exists()
        if not credit:
            raise UserError(self.env._("Store credit not found."))

        amount = float(line.get("amount") or 0.0)
        validation = self._pos_validate_redemption_payload(
            {
                "credit_id": credit.id,
                "amount": amount,
                "partner_id": pos_order.partner_id.id or False,
                "redemption_uuid": redemption_uuid,
                "order_uuid": pos_order.uuid,
                "existing_redemptions": line.get("existing_redemptions") or [],
                "manager_approved": line.get("manager_approved"),
            },
            config.id,
            session.id if session else False,
            skip_audit=True,
        )
        if not validation.get("valid"):
            raise UserError(validation.get("error") or self.env._("Redemption validation failed."))

        voucher = False
        voucher_model = self.env.get("pos.return.voucher")
        if voucher_model is not None and line.get("voucher_id"):
            voucher = voucher_model.browse(line["voucher_id"]).exists()

        if voucher:
            sc_payment = voucher._redeem_voucher(
                amount=amount,
                pos_order=pos_order,
                payment=payment,
                user=self.env.user,
            )
        else:
            txn = credit._redeem_credit(
                amount=amount,
                pos_order=pos_order,
                user=self.env.user,
                reference=redemption_uuid or credit.barcode,
            )
            sc_payment = self.env["store.credit.payment"].create(
                {
                    "credit_id": credit.id,
                    "pos_order_id": pos_order.id,
                    "payment_id": payment.id,
                    "payment_method_id": payment.payment_method_id.id,
                    "amount": amount,
                    "company_id": credit.company_id.id,
                    "currency_id": credit.currency_id.id,
                    "config_id": config.id,
                    "session_id": session.id if session else False,
                    "transaction_id": txn.id,
                    "cashier_id": self.env.user.id,
                    "uuid": redemption_uuid or False,
                }
            )

        if redemption_uuid and not sc_payment.uuid:
            sc_payment.uuid = redemption_uuid

        remainder_result = credit._handle_partial_redemption_remainder(
            redeemed_amount=amount,
            pos_order=pos_order,
            config=config,
            session=session,
            voucher=voucher,
            sc_payment=sc_payment,
            manager_approved=bool(line.get("manager_approved")),
        )
        if remainder_result and remainder_result.get("strategy") not in (None, "none"):
            sc_payment.note = json.dumps(
                {"remainder_result": remainder_result}, default=str
            )

        self._pos_log_audit_event(
            "redeem",
            self.env._(
                "Redeemed %(amount)s from %(name)s on order %(order)s",
                amount=amount,
                name=credit.name,
                order=pos_order.name,
            ),
            credit=credit,
            amount=amount,
            config=config,
            session=session,
            pos_order=pos_order,
            payload=line,
        )
        return sc_payment, remainder_result if remainder_result else {"strategy": "none"}

    # -------------------------------------------------------------------------
    # Lookup helpers
    # -------------------------------------------------------------------------

    @api.model
    def _pos_search_partner_credits(self, partner_id, config):
        settings = self.env["store.credit.settings"]._get_settings(
            company=config.company_id, config=config
        )
        domain = [
            ("partner_id", "=", partner_id),
            ("state", "in", ("issued", "partially_used")),
            ("active", "=", True),
            ("company_id", "=", config.company_id.id),
        ]
        credits = self.search(domain)
        redeemable = credits.filtered(lambda c: c._is_redeemable())
        order = getattr(settings, "credit_redemption_order", "oldest_first")
        return self._sort_credits_for_allocation(redeemable, order)

    @api.model
    def _sort_credits_for_allocation(self, credits, order_strategy):
        """Delegate to partial redemption engine for consistent sort order."""
        return self.env["store.credit"]._sort_credits_for_allocation(
            credits, order_strategy
        )

    @api.model
    def _pos_fuzzy_lookup(self, query, config, voucher_model):
        credits = self.search(
            [
                "|",
                ("barcode", "=", query),
                ("name", "=", query),
                ("active", "=", True),
            ],
            limit=5,
        )
        if not credits and voucher_model is not None:
            vouchers = voucher_model.search([("voucher_number", "ilike", query)], limit=5)
            credits = vouchers.mapped("credit_id")
        return credits

    @api.model
    def _serialize_credit_for_pos(self, credit, config, voucher_model=None):
        voucher = False
        voucher_number = False
        if voucher_model is not None:
            voucher = voucher_model.search([("credit_id", "=", credit.id)], limit=1)
            voucher_number = voucher.voucher_number if voucher else False
        return {
            "credit_id": credit.id,
            "voucher_id": voucher.id if voucher else False,
            "name": credit.name,
            "barcode": credit.barcode,
            "voucher_number": voucher_number or credit.name,
            "partner_id": credit.partner_id.id or False,
            "partner_name": credit.partner_id.name or "",
            "amount": credit.amount,
            "amount_remaining": credit.amount_remaining,
            "state": credit.state,
            "expiry_date": fields.Datetime.to_string(credit.expiry_date)
            if credit.expiry_date
            else False,
            "issue_date": fields.Datetime.to_string(credit.issue_date)
            if credit.issue_date
            else False,
            "config_id": credit.config_id.id or False,
            "config_name": credit.config_id.name or "",
            "credit_type": credit.credit_type,
        }

    # -------------------------------------------------------------------------
    # Validation
    # -------------------------------------------------------------------------

    @api.model
    def _pos_validate_credit_for_redemption(
        self, credit, config, session=False, partner_id=False, amount=None
    ):
        try:
            settings = credit._get_settings()
            if settings and not getattr(settings, "enable_store_credit", True):
                raise UserError(self.env._("Store credit redemption is disabled."))

            if not getattr(settings, "allow_cross_company_redemption", False):
                if credit.company_id != config.company_id:
                    raise UserError(
                        self.env._("Store credit belongs to another company.")
                    )

            if not getattr(settings, "cross_branch_usage", True):
                if credit.config_id and credit.config_id != config:
                    raise UserError(
                        self.env._("Store credit cannot be redeemed at this branch.")
                    )

            if partner_id and credit.partner_id and credit.partner_id.id != partner_id:
                raise UserError(
                    self.env._(
                        "Store credit belongs to another customer."
                    )
                )

            credit._validate_credit(amount=amount, for_redeem=bool(amount))
            if amount is not None:
                self._validate_redemption_amount_policy(credit, amount, settings)
            return {"valid": True}
        except (UserError, ValidationError) as exc:
            return {"valid": False, "error": str(exc)}

    @api.model
    def _pos_validate_redemption_payload(self, payload, config_id, session_id, skip_audit=False):
        config = self.env["pos.config"].browse(config_id).exists()
        session = self.env["pos.session"].browse(session_id).exists() if session_id else False
        credit = self.browse((payload or {}).get("credit_id")).exists()
        amount = float((payload or {}).get("amount") or 0.0)

        if not credit:
            return {
                "valid": False,
                "error_code": "not_found",
                "error": self.env._("Store credit not found."),
            }

        precision = credit.currency_id.rounding
        if float_compare(amount, 0.0, precision_rounding=precision) <= 0:
            return {
                "valid": False,
                "error_code": "invalid_amount",
                "error": self.env._("Redemption amount must be greater than zero."),
            }

        validation = self._pos_validate_credit_for_redemption(
            credit,
            config,
            session=session,
            partner_id=payload.get("partner_id"),
            amount=amount,
        )
        if not validation.get("valid"):
            if not skip_audit:
                self._pos_log_audit_event(
                    "validation",
                    validation.get("error"),
                    credit=credit,
                    config=config,
                    session=session,
                    payload=payload,
                    success=False,
                )
            return {
                "valid": False,
                "error_code": "validation_failure",
                "error": validation.get("error"),
            }

        settings = credit._get_settings()
        try:
            self._validate_redemption_amount_policy(credit, amount, settings)
        except (UserError, ValidationError) as exc:
            if not skip_audit:
                self._pos_log_audit_event(
                    "validation",
                    str(exc),
                    credit=credit,
                    config=config,
                    session=session,
                    payload=payload,
                    success=False,
                )
            return {
                "valid": False,
                "error_code": "policy_violation",
                "error": str(exc),
            }

        partial_check = self._validate_partial_redemption_policy(
            credit, amount, settings, payload
        )
        if not partial_check.get("valid"):
            if not skip_audit:
                self._pos_log_audit_event(
                    "validation",
                    partial_check.get("error"),
                    credit=credit,
                    config=config,
                    session=session,
                    payload=payload,
                    success=False,
                )
            return {
                "valid": False,
                "error_code": partial_check.get("error_code", "partial_policy"),
                "error": partial_check.get("error"),
            }

        existing = payload.get("existing_redemptions") or []
        credit_id = credit.id
        if any(
            r.get("credit_id") == credit_id and r.get("redemption_uuid") != payload.get("redemption_uuid")
            for r in existing
        ):
            if settings and not getattr(settings, "allow_multiple_voucher", True):
                return {
                    "valid": False,
                    "error_code": "duplicate_credit",
                    "error": self.env._("This store credit is already applied to the order."),
                }

        if not skip_audit:
            self._pos_log_audit_event(
                "validation",
                self.env._("Store credit validation passed for %(name)s", name=credit.name),
                credit=credit,
                amount=amount,
                config=config,
                session=session,
                payload=payload,
            )

        applicable = min(amount, credit.amount_remaining)
        due_amount = float((payload or {}).get("due_amount") or 0.0)
        customer_payment = max(due_amount - applicable, 0.0) if due_amount else 0.0
        return {
            "valid": True,
            "credit_id": credit.id,
            "amount": amount,
            "applicable_amount": applicable,
            "amount_remaining_after": max(credit.amount_remaining - applicable, 0.0),
            "is_partial": partial_check.get("is_partial"),
            "credit_used": applicable,
            "customer_payment": customer_payment,
            "remaining_credit_strategy": getattr(
                settings, "remaining_credit_strategy", "issue_new"
            ),
        }

    @api.model
    def _validate_redemption_amount_policy(self, credit, amount, settings):
        """Return error message or None."""
        precision = credit.currency_id.rounding
        minimum = getattr(settings, "minimum_redemption_amount", 0.0) or 0.0
        maximum = getattr(settings, "maximum_redemption_amount", 0.0) or 0.0

        if minimum > 0 and float_compare(amount, minimum, precision_rounding=precision) < 0:
            raise ValidationError(
                self.env._(
                    "Redemption amount must be at least %(min)s.",
                    min=minimum,
                )
            )
        if maximum > 0 and float_compare(amount, maximum, precision_rounding=precision) > 0:
            raise ValidationError(
                self.env._(
                    "Redemption amount cannot exceed %(max)s.",
                    max=maximum,
                )
            )
        if float_compare(amount, credit.amount_remaining, precision_rounding=precision) > 0:
            raise ValidationError(
                self.env._("Redemption amount exceeds remaining balance.")
            )
        if (
            settings
            and not getattr(settings, "allow_partial_usage", True)
            and float_compare(amount, credit.amount_remaining, precision_rounding=precision) != 0
        ):
            raise UserError(
                self.env._("Partial redemption is not allowed for this store credit.")
            )
        return None

    # -------------------------------------------------------------------------
    # Audit
    # -------------------------------------------------------------------------

    @api.model
    def _pos_log_audit_event(
        self,
        action,
        message,
        credit=None,
        amount=0.0,
        config=None,
        session=None,
        pos_order=None,
        payload=None,
        success=True,
    ):
        vals = {
            "action": action,
            "message": message,
            "amount": amount,
            "company_id": (config.company_id.id if config else self.env.company.id),
            "currency_id": (
                config.company_id.currency_id.id
                if config
                else self.env.company.currency_id.id
            ),
            "config_id": config.id if config else False,
            "session_id": session.id if session else False,
            "cashier_id": self.env.user.id,
            "pos_order_id": pos_order.id if pos_order else False,
            "state": "done" if success else "cancelled",
        }
        if credit:
            vals["credit_id"] = credit.id
            if payload:
                vals["after_data"] = json.dumps(payload, default=str)
            return self.env["store.credit.audit"].create(vals)
        Audit = self.env["store.credit.audit"]
        if payload:
            vals["after_data"] = json.dumps(payload, default=str)
        return Audit.create(vals)
