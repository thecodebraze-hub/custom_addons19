# -*- coding: utf-8 -*-
"""Structured audit trail for store credit lifecycle events."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class StoreCreditAudit(models.Model):
    """
    Store credit audit log.

    Technical name: store.credit.audit

    Tracks Issue, Redeem, Cancel, Expire, Approval and Print actions.
    """

    _name = "store.credit.audit"
    _description = "Store Credit Audit"
    _inherit = ["store.credit.uuid.mixin", "store.credit.sync.mixin"]
    _order = "create_date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
    )
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("done", "Done"),
            ("cancelled", "Cancelled"),
        ],
        string="Status",
        default="done",
        required=True,
        index=True,
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        ondelete="cascade",
        index=True,
        check_company=True,
    )
    action = fields.Selection(
        selection=[
            ("issue", "Issue"),
            ("redeem", "Redeem"),
            ("cancel", "Cancel"),
            ("expire", "Expire"),
            ("approval", "Approval"),
            ("print", "Print"),
            ("adjustment", "Adjustment"),
            ("transfer", "Transfer"),
            ("sync_conflict", "Sync Conflict"),
            ("lookup", "Voucher Lookup"),
            ("validation", "Voucher Validation"),
            ("partial_redeem", "Partial Redemption"),
            ("remainder_issue", "Remainder Credit Issued"),
        ],
        string="Action",
        required=True,
        index=True,
    )
    message = fields.Text(string="Message")
    amount = fields.Monetary(
        string="Amount",
        currency_field="currency_id",
        default=0.0,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.company.currency_id,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )
    cashier_id = fields.Many2one(
        comodel_name="res.users",
        string="Cashier",
        default=lambda self: self.env.user,
        index=True,
    )
    manager_id = fields.Many2one(
        comodel_name="res.users",
        string="Manager",
        index=True,
    )
    pos_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="POS Order",
        index=True,
        check_company=True,
    )
    before_data = fields.Text(
        string="Before Data",
        help="Optional JSON snapshot before the action.",
    )
    after_data = fields.Text(
        string="After Data",
        help="Optional JSON snapshot after the action.",
    )

    _sql_constraints = [
        (
            "store_credit_audit_uuid_uniq",
            "unique(uuid)",
            "Store credit audit UUID must be unique.",
        ),
    ]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
            if vals.get("name", "New") == "New":
                company = self.env["res.company"].browse(
                    vals.get("company_id") or self.env.company.id
                )
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("store.credit.audit")
                )
                if not seq:
                    raise UserError(
                        self.env._("Sequence 'store.credit.audit' is not configured.")
                    )
                vals["name"] = seq
        records = super().create(vals_list)
        for audit in records:
            _logger.info(
                "Store credit audit %s action=%s credit=%s",
                audit.name,
                audit.action,
                audit.credit_id.name if audit.credit_id else "-",
            )
        return records
