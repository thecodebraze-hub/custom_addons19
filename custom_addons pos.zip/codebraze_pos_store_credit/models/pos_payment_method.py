# -*- coding: utf-8 -*-
"""POS payment method extension for Store Credit redemption."""

from odoo import api, fields, models


class PosPaymentMethod(models.Model):
    _inherit = "pos.payment.method"

    is_store_credit = fields.Boolean(
        string="Store Credit",
        default=False,
        help="When enabled, this payment method redeems store credit / return vouchers.",
    )

    @api.model
    def _load_pos_data_fields(self, config):
        fields_list = super()._load_pos_data_fields(config)
        return fields_list + ["is_store_credit"]
