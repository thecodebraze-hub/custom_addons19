# -*- coding: utf-8 -*-
"""Reusable mixins for Store Credit, Return and Voucher documents."""

import logging
import uuid

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class StoreCreditSyncMixin(models.AbstractModel):
    """Offline / multi-device synchronization fields shared by credit documents."""

    _name = "store.credit.sync.mixin"
    _description = "Store Credit Sync Mixin"

    is_offline = fields.Boolean(
        string="Created Offline",
        default=False,
        index=True,
        help="True when the document was created while the POS was offline.",
    )
    needs_sync = fields.Boolean(
        string="Needs Sync",
        default=False,
        index=True,
        help="Queued for server synchronization.",
    )
    sync_status = fields.Selection(
        selection=[
            ("pending", "Pending"),
            ("synced", "Synced"),
            ("conflict", "Conflict"),
            ("failed", "Failed"),
        ],
        string="Sync Status",
        default="synced",
        index=True,
        required=True,
    )
    sync_datetime = fields.Datetime(
        string="Last Sync Time",
        readonly=True,
        help="Timestamp of the last successful synchronization.",
    )
    conflict_status = fields.Selection(
        selection=[
            ("none", "None"),
            ("residual_mismatch", "Residual Mismatch"),
            ("duplicate_code", "Duplicate Barcode"),
            ("duplicate_uuid", "Duplicate UUID"),
            ("superseded", "Superseded"),
        ],
        string="Conflict Status",
        default="none",
        index=True,
        required=True,
    )
    sync_retry_count = fields.Integer(
        string="Sync Retry Count",
        default=0,
        help="Number of synchronization attempts performed.",
    )
    device_id = fields.Char(
        string="Device ID",
        index=True,
        help="POS terminal / device identifier used when the record was created.",
    )


class StoreCreditUuidMixin(models.AbstractModel):
    """UUID generation helpers for offline-safe identity."""

    _name = "store.credit.uuid.mixin"
    _description = "Store Credit UUID Mixin"

    uuid = fields.Char(
        string="UUID",
        required=True,
        copy=False,
        index=True,
        readonly=True,
        default=lambda self: self._generate_uuid(),
        help="Globally unique identifier used for offline sync and idempotency.",
    )

    @api.model
    def _generate_uuid(self):
        """Return a new UUID4 string (lowercase)."""
        return str(uuid.uuid4())

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
        return super().create(vals_list)
