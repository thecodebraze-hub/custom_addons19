# -*- coding: utf-8 -*-
"""Immutable ledger lines for store.credit movements."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare

_logger = logging.getLogger(__name__)


class StoreCreditTransaction(models.Model):
    """
    Store credit ledger transaction.

    Technical name: store.credit.transaction

    Every monetary movement (issue, redeem, cancel, expire, adjustment,
    transfer) is recorded here. The parent store.credit residual is derived
    from posted transactions.
    """

    _name = "store.credit.transaction"
    _description = "Store Credit Transaction"
    _inherit = ["store.credit.uuid.mixin", "store.credit.sync.mixin"]
    _order = "date desc, id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
    )
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("posted", "Posted"),
            ("cancelled", "Cancelled"),
        ],
        string="Status",
        default="posted",
        required=True,
        index=True,
        copy=False,
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Credit",
        required=True,
        ondelete="cascade",
        index=True,
        check_company=True,
    )
    txn_type = fields.Selection(
        selection=[
            ("issue", "Issue"),
            ("redeem", "Redeem"),
            ("cancel", "Cancel"),
            ("expire", "Expire"),
            ("adjustment", "Adjustment"),
            ("transfer", "Transfer"),
        ],
        string="Transaction Type",
        required=True,
        index=True,
    )
    amount = fields.Monetary(
        string="Amount",
        currency_field="currency_id",
        required=True,
        help="Absolute amount of the movement (always >= 0).",
    )
    signed_amount = fields.Monetary(
        string="Signed Amount",
        currency_field="currency_id",
        compute="_compute_signed_amount",
        store=True,
        help="Positive increases available credit; negative decreases it.",
    )
    remaining = fields.Monetary(
        string="Remaining After",
        currency_field="currency_id",
        readonly=True,
        help="Snapshot of remaining balance on the credit after this transaction.",
    )
    reference = fields.Char(
        string="Reference",
        help="External or operational reference for this movement.",
    )
    pos_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="POS Order",
        index=True,
        check_company=True,
    )
    user_id = fields.Many2one(
        comodel_name="res.users",
        string="User",
        required=True,
        default=lambda self: self.env.user,
        index=True,
    )
    date = fields.Datetime(
        string="Date",
        required=True,
        default=fields.Datetime.now,
        index=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        related="credit_id.company_id",
        store=True,
        index=True,
        readonly=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        related="credit_id.currency_id",
        store=True,
        readonly=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        related="credit_id.config_id",
        store=True,
        index=True,
        readonly=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Customer",
        related="credit_id.partner_id",
        store=True,
        index=True,
        readonly=True,
    )
    parent_txn_id = fields.Many2one(
        comodel_name="store.credit.transaction",
        string="Parent Transaction",
        index=True,
        help="Links reverse / void movements to the original transaction.",
    )
    note = fields.Text(string="Notes")
    # Accounting hook (filled by accounting module)
    move_id = fields.Many2one(
        comodel_name="account.move",
        string="Journal Entry",
        index=True,
        copy=False,
        help="Accounting move posted for this transaction (if any).",
    )
    is_accounted = fields.Boolean(
        string="Accounted",
        default=False,
        index=True,
        copy=False,
    )

    _sql_constraints = [
        (
            "store_credit_txn_uuid_uniq",
            "unique(uuid)",
            "Store credit transaction UUID must be unique.",
        ),
        (
            "store_credit_txn_name_company_uniq",
            "unique(company_id, name)",
            "Store credit transaction reference must be unique per company.",
        ),
        (
            "store_credit_txn_amount_positive",
            "CHECK(amount >= 0)",
            "Transaction amount must be greater than or equal to zero.",
        ),
    ]

    @api.depends("txn_type", "amount")
    def _compute_signed_amount(self):
        increase_types = {"issue"}
        decrease_types = {"redeem", "cancel", "expire"}
        for txn in self:
            if txn.txn_type in increase_types:
                txn.signed_amount = txn.amount
            elif txn.txn_type in decrease_types:
                txn.signed_amount = -txn.amount
            elif txn.txn_type == "adjustment":
                # Explicit sign via context; default increases available credit
                sign = self.env.context.get("adjustment_sign", 1)
                txn.signed_amount = txn.amount * (1 if sign >= 0 else -1)
            elif txn.txn_type == "transfer":
                # Outbound transfers decrease residual; inbound increase it.
                sign = self.env.context.get("transfer_sign", 1)
                txn.signed_amount = txn.amount * (1 if sign >= 0 else -1)
            else:
                txn.signed_amount = 0.0

    @api.constrains("amount")
    def _check_amount(self):
        precision = self.env["decimal.precision"].precision_get("Product Price")
        for txn in self:
            if float_compare(txn.amount, 0.0, precision_digits=precision) < 0:
                raise ValidationError(self.env._("Transaction amount cannot be negative."))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            company_id = vals.get("company_id")
            if not company_id and vals.get("credit_id"):
                credit = self.env["store.credit"].browse(vals["credit_id"])
                company_id = credit.company_id.id
                vals.setdefault("company_id", company_id)
                vals.setdefault("currency_id", credit.currency_id.id)
            company = self.env["res.company"].browse(company_id or self.env.company.id)
            if vals.get("name", "New") == "New":
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("store.credit.transaction")
                )
                if not seq:
                    raise UserError(
                        self.env._(
                            "Sequence 'store.credit.transaction' is not configured."
                        )
                    )
                vals["name"] = seq
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
        records = super().create(vals_list)
        for txn in records:
            _logger.debug(
                "Posted store credit txn %s type=%s amount=%s credit=%s",
                txn.name,
                txn.txn_type,
                txn.amount,
                txn.credit_id.name,
            )
        return records

    def write(self, vals):
        if not self.env.su and self.filtered(lambda t: t.state == "posted"):
            locked = {"txn_type", "amount", "credit_id", "signed_amount", "uuid", "name"}
            if locked.intersection(vals):
                raise UserError(
                    self.env._("Posted store credit transactions cannot be modified.")
                )
        return super().write(vals)

    def unlink(self):
        if not self.env.su and self.filtered(lambda t: t.state == "posted"):
            raise UserError(
                self.env._("Posted store credit transactions cannot be deleted.")
            )
        return super().unlink()
