# -*- coding: utf-8 -*-
"""Store Credit configuration UI (res.config.settings).

This module is *configuration only*: it stores parameters in
ir.config_parameter. No business logic is implemented here.
"""

from odoo import api, fields, models
from odoo.exceptions import ValidationError

from .store_credit_config_utils import (
    company_param_key,
    config_param_key,
    to_bool,
    to_float,
    to_int,
)


class StoreCreditConfigSettings(models.TransientModel):
    """Store Credit configuration framework.

    The fields are written to ir.config_parameter and later resolved by
    ``store.credit.settings._get_settings()``.
    """

    _inherit = "res.config.settings"

    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="company_id.currency_id",
        readonly=True,
    )

    # ------------------------------------------------------------------
    # Enablements (credit types)
    # ------------------------------------------------------------------
    enable_store_credit = fields.Boolean(string="Enable Store Credit", default=True)
    enable_return_voucher = fields.Boolean(string="Enable Return Voucher", default=True)
    enable_gift_voucher = fields.Boolean(string="Enable Gift Voucher", default=False)
    enable_customer_wallet = fields.Boolean(string="Enable Customer Wallet", default=False)
    enable_loyalty_credit = fields.Boolean(string="Enable Loyalty Credit", default=False)
    enable_manual_credit = fields.Boolean(string="Enable Manual Credit", default=True)
    enable_compensation_credit = fields.Boolean(
        string="Enable Compensation Credit",
        default=True,
    )

    # ------------------------------------------------------------------
    # Voucher settings
    # ------------------------------------------------------------------
    voucher_prefix = fields.Char(string="Voucher Prefix", default="CBRV")
    voucher_sequence_code = fields.Char(string="Voucher Sequence Code", default="pos.return.voucher")
    barcode_prefix = fields.Char(string="Barcode Prefix", default="CBRV")
    qr_code_enabled = fields.Boolean(string="QR Code Enabled", default=False)
    voucher_expiry_enabled = fields.Boolean(string="Voucher Expiry Enabled", default=True)
    default_expiry_days = fields.Integer(string="Default Expiry Days", default=90)
    auto_expire = fields.Boolean(string="Auto Expire", default=True)
    allow_permanent_voucher = fields.Boolean(string="Allow Permanent Voucher", default=False)
    voucher_print_copies = fields.Integer(string="Voucher Print Copies", default=1)

    # ------------------------------------------------------------------
    # Redemption settings
    # ------------------------------------------------------------------
    allow_partial_redemption = fields.Boolean(
        string="Allow Partial Redemption", default=True
    )
    allow_multiple_voucher_usage = fields.Boolean(
        string="Allow Multiple Voucher Usage", default=True
    )
    allow_split_payment = fields.Boolean(string="Allow Split Payment", default=True)
    minimum_redemption_amount = fields.Monetary(
        string="Minimum Redemption Amount",
        currency_field="currency_id",
        default=0.0,
    )
    maximum_redemption_amount = fields.Monetary(
        string="Maximum Redemption Amount",
        currency_field="currency_id",
        default=0.0,
        help="0 means no max.",
    )
    allow_cross_branch_redemption = fields.Boolean(
        string="Allow Cross Branch Redemption", default=True
    )
    allow_cross_company_redemption = fields.Boolean(
        string="Allow Cross Company Redemption", default=False
    )
    credit_redemption_order = fields.Selection(
        selection=[
            ("oldest_first", "Oldest First"),
            ("newest_first", "Newest First"),
            ("highest_amount_first", "Highest Amount First"),
            ("manual", "Manual Selection"),
        ],
        string="Credit Redemption Order",
        default="oldest_first",
        help="When multiple store credits are available, apply oldest first, newest "
             "first, highest balance first, or let the cashier choose manually.",
    )
    remaining_credit_strategy = fields.Selection(
        selection=[
            ("update_existing", "Update Existing Store Credit"),
            ("issue_new", "Issue New Store Credit"),
        ],
        string="Remaining Credit Strategy",
        default="issue_new",
        help="When a voucher is partially redeemed, keep the balance on the same "
             "instrument or issue a new voucher for the remainder.",
    )
    auto_print_remainder_voucher = fields.Boolean(
        string="Auto Print Remainder Voucher",
        default=True,
        help="Automatically print a new voucher when remainder credit is issued.",
    )
    require_manager_approval_partial = fields.Boolean(
        string="Require Manager Approval (Partial Redemption)",
        default=False,
        help="Cashier must obtain manager approval before applying a partial redemption.",
    )

    # ------------------------------------------------------------------
    # Return settings
    # ------------------------------------------------------------------
    maximum_return_days = fields.Integer(string="Maximum Return Days", default=14)
    allow_return_without_customer = fields.Boolean(
        string="Allow Return Without Customer", default=True
    )
    allow_return_without_invoice = fields.Boolean(
        string="Allow Return Without Invoice", default=False
    )
    require_original_invoice = fields.Boolean(
        string="Require Original Invoice", default=True
    )
    require_manager_approval = fields.Boolean(
        string="Require Manager Approval", default=False
    )
    maximum_return_amount = fields.Monetary(
        string="Maximum Return Amount",
        currency_field="currency_id",
        default=0.0,
        help="0 means no max amount limit (beyond approval rules).",
    )

    # ------------------------------------------------------------------
    # Approval settings
    # ------------------------------------------------------------------
    manager_approval_required = fields.Boolean(
        string="Manager Approval Required", default=False
    )
    approval_amount_limit = fields.Monetary(
        string="Approval Amount Limit",
        currency_field="currency_id",
        default=0.0,
    )
    approval_for_expired_voucher = fields.Boolean(
        string="Approval For Expired Voucher", default=False
    )
    approval_for_cancel_voucher = fields.Boolean(
        string="Approval For Cancel Voucher", default=False
    )
    approval_for_manual_adjustment = fields.Boolean(
        string="Approval For Manual Adjustment", default=False
    )
    approval_for_return_without_invoice = fields.Boolean(
        string="Approval For Return Without Invoice", default=False
    )

    # ------------------------------------------------------------------
    # Barcode settings
    # ------------------------------------------------------------------
    barcode_length = fields.Integer(string="Barcode Length (Numeric Padding)", default=10)
    barcode_format = fields.Char(string="Barcode Format", default="PREFIX+SEQUENCE_ZPAD")
    barcode_validation = fields.Boolean(string="Barcode Validation", default=True)
    offline_barcode_strategy = fields.Selection(
        selection=[
            ("uuid_only", "UUID Only (UUID primary sync)"),
            ("sequence_pool", "Sequence Pool (offline barcode pre-allocation)"),
        ],
        string="Offline Barcode Strategy",
        default="uuid_only",
    )
    duplicate_prevention = fields.Selection(
        selection=[
            ("strict_unique", "Strict DB uniqueness (uuid primary, barcode secondary)"),
            ("partitioned_pool", "Partitioned offline pool ranges"),
        ],
        string="Duplicate Prevention",
        default="strict_unique",
    )

    # ------------------------------------------------------------------
    # Offline settings
    # ------------------------------------------------------------------
    offline_enabled = fields.Boolean(string="Offline Enabled", default=False)
    offline_queue_size = fields.Integer(string="Offline Queue Size", default=500)
    offline_retry_count = fields.Integer(string="Offline Retry Count", default=5)
    offline_retry_interval_seconds = fields.Integer(
        string="Offline Retry Interval (Seconds)", default=30
    )
    conflict_resolution_strategy = fields.Selection(
        selection=[
            ("server_residual_wins", "Server residual wins"),
            ("first_write_wins", "First write wins"),
        ],
        string="Conflict Resolution Strategy",
        default="server_residual_wins",
    )

    # ------------------------------------------------------------------
    # Print settings
    # ------------------------------------------------------------------
    auto_print_voucher = fields.Boolean(string="Auto Print Voucher", default=True)
    auto_print_return_receipt = fields.Boolean(
        string="Auto Print Return Receipt", default=True
    )
    print_qr = fields.Boolean(string="Print QR", default=False)
    print_barcode = fields.Boolean(string="Print Barcode", default=True)
    print_company_logo = fields.Boolean(string="Print Company Logo", default=True)
    print_remaining_balance = fields.Boolean(string="Print Remaining Balance", default=True)
    print_terms_conditions = fields.Boolean(
        string="Print Terms & Conditions", default=False
    )

    # ------------------------------------------------------------------
    # Notification settings
    # ------------------------------------------------------------------
    notify_customer = fields.Boolean(string="Notify Customer", default=False)
    email_notification = fields.Boolean(string="Email Notification", default=False)
    sms_notification = fields.Boolean(string="SMS Notification", default=False)
    whatsapp_notification = fields.Boolean(string="WhatsApp Notification", default=False)
    manager_notification = fields.Boolean(string="Manager Notification", default=False)

    # ------------------------------------------------------------------
    # Multi-company settings
    # ------------------------------------------------------------------
    separate_sequence_per_company = fields.Boolean(
        string="Separate Sequence Per Company", default=True
    )
    separate_voucher_prefix = fields.Boolean(
        string="Separate Voucher Prefix", default=True
    )
    separate_approval_rules = fields.Boolean(string="Separate Approval Rules", default=True)
    separate_expiry_rules = fields.Boolean(string="Separate Expiry Rules", default=True)

    # ------------------------------------------------------------------
    # Multi-branch settings
    # ------------------------------------------------------------------
    branch_specific_voucher = fields.Boolean(string="Branch Specific Voucher", default=True)
    branch_redemption_rules = fields.Boolean(string="Branch Redemption Rules", default=True)
    branch_approval_rules = fields.Boolean(string="Branch Approval Rules", default=True)

    # ------------------------------------------------------------------
    # Validation settings
    # ------------------------------------------------------------------
    negative_balance_allowed = fields.Boolean(
        string="Negative Balance Allowed", default=False
    )
    over_redemption_allowed = fields.Boolean(string="Over Redemption Allowed", default=False)
    future_date_allowed = fields.Boolean(string="Future Date Allowed", default=False)
    expired_voucher_allowed = fields.Boolean(string="Expired Voucher Allowed", default=False)
    cancelled_voucher_allowed = fields.Boolean(string="Cancelled Voucher Allowed", default=False)

    # ------------------------------------------------------------------
    # Developer settings
    # ------------------------------------------------------------------
    enable_debug_logs = fields.Boolean(string="Enable Debug Logs", default=False)
    enable_audit_logs = fields.Boolean(string="Enable Audit Logs", default=True)
    enable_api_logs = fields.Boolean(string="Enable API Logs", default=False)
    enable_performance_logs = fields.Boolean(string="Enable Performance Logs", default=False)

    # ------------------------------------------------------------------
    # Security settings (configuration only; ACL is implemented later)
    # ------------------------------------------------------------------
    permission_cashier = fields.Selection(
        selection=[
            ("read_only", "Read Only"),
            ("limited", "Limited"),
            ("full", "Full"),
        ],
        string="Cashier Permissions (Config)",
        default="limited",
    )
    permission_supervisor = fields.Selection(
        selection=[
            ("read_only", "Read Only"),
            ("limited", "Limited"),
            ("full", "Full"),
        ],
        string="Supervisor Permissions (Config)",
        default="full",
    )
    permission_manager = fields.Selection(
        selection=[
            ("read_only", "Read Only"),
            ("limited", "Limited"),
            ("full", "Full"),
        ],
        string="Manager Permissions (Config)",
        default="full",
    )
    permission_administrator = fields.Selection(
        selection=[
            ("read_only", "Read Only"),
            ("limited", "Limited"),
            ("full", "Full"),
        ],
        string="Administrator Permissions (Config)",
        default="full",
    )

    # ------------------------------------------------------------------
    # Parameter mapping
    # ------------------------------------------------------------------
    def _param_scope_ids(self):
        """Return (company_id, config_id) for the settings write/read."""
        company_id = (
            self.company_id.id
            if hasattr(self, "company_id") and self.company_id
            else self.env.company.id
        )
        config_id = (
            self.pos_config_id.id
            if hasattr(self, "pos_config_id") and self.pos_config_id
            else False
        )
        return company_id, config_id

    def _param_map(self):
        """Map transient fields to param keys."""
        return {
            # Enablements
            "enable_store_credit": self.enable_store_credit,
            "enable_return_voucher": self.enable_return_voucher,
            "enable_gift_voucher": self.enable_gift_voucher,
            "enable_customer_wallet": self.enable_customer_wallet,
            "enable_loyalty_credit": self.enable_loyalty_credit,
            "enable_manual_credit": self.enable_manual_credit,
            "enable_compensation_credit": self.enable_compensation_credit,
            # Voucher
            "voucher_prefix": self.voucher_prefix,
            "voucher_sequence_code": self.voucher_sequence_code,
            "barcode_prefix": self.barcode_prefix,
            "qr_code_enabled": self.qr_code_enabled,
            "voucher_expiry_enabled": self.voucher_expiry_enabled,
            "default_expiry_days": self.default_expiry_days,
            "auto_expire": self.auto_expire,
            "allow_permanent_voucher": self.allow_permanent_voucher,
            "voucher_print_copies": self.voucher_print_copies,
            # Redemption
            "allow_partial_redemption": self.allow_partial_redemption,
            "allow_multiple_voucher_usage": self.allow_multiple_voucher_usage,
            "allow_split_payment": self.allow_split_payment,
            "minimum_redemption_amount": self.minimum_redemption_amount,
            "maximum_redemption_amount": self.maximum_redemption_amount,
            "allow_cross_branch_redemption": self.allow_cross_branch_redemption,
            "allow_cross_company_redemption": self.allow_cross_company_redemption,
            "credit_redemption_order": self.credit_redemption_order,
            "remaining_credit_strategy": self.remaining_credit_strategy,
            "auto_print_remainder_voucher": self.auto_print_remainder_voucher,
            "require_manager_approval_partial": self.require_manager_approval_partial,
            # Return
            "maximum_return_days": self.maximum_return_days,
            "allow_return_without_customer": self.allow_return_without_customer,
            "allow_return_without_invoice": self.allow_return_without_invoice,
            "require_original_invoice": self.require_original_invoice,
            "require_manager_approval": self.require_manager_approval,
            "maximum_return_amount": self.maximum_return_amount,
            # Approval
            "manager_approval_required": self.manager_approval_required,
            "approval_amount_limit": self.approval_amount_limit,
            "approval_for_expired_voucher": self.approval_for_expired_voucher,
            "approval_for_cancel_voucher": self.approval_for_cancel_voucher,
            "approval_for_manual_adjustment": self.approval_for_manual_adjustment,
            "approval_for_return_without_invoice": self.approval_for_return_without_invoice,
            # Barcode
            "barcode_length": self.barcode_length,
            "barcode_format": self.barcode_format,
            "barcode_validation": self.barcode_validation,
            "offline_barcode_strategy": self.offline_barcode_strategy,
            "duplicate_prevention": self.duplicate_prevention,
            # Offline
            "offline_enabled": self.offline_enabled,
            "offline_queue_size": self.offline_queue_size,
            "offline_retry_count": self.offline_retry_count,
            "offline_retry_interval_seconds": self.offline_retry_interval_seconds,
            "conflict_resolution_strategy": self.conflict_resolution_strategy,
            # Print
            "auto_print_voucher": self.auto_print_voucher,
            "auto_print_return_receipt": self.auto_print_return_receipt,
            "print_qr": self.print_qr,
            "print_barcode": self.print_barcode,
            "print_company_logo": self.print_company_logo,
            "print_remaining_balance": self.print_remaining_balance,
            "print_terms_conditions": self.print_terms_conditions,
            # Notifications
            "notify_customer": self.notify_customer,
            "email_notification": self.email_notification,
            "sms_notification": self.sms_notification,
            "whatsapp_notification": self.whatsapp_notification,
            "manager_notification": self.manager_notification,
            # Multi-company
            "separate_sequence_per_company": self.separate_sequence_per_company,
            "separate_voucher_prefix": self.separate_voucher_prefix,
            "separate_approval_rules": self.separate_approval_rules,
            "separate_expiry_rules": self.separate_expiry_rules,
            # Multi-branch
            "branch_specific_voucher": self.branch_specific_voucher,
            "branch_redemption_rules": self.branch_redemption_rules,
            "branch_approval_rules": self.branch_approval_rules,
            # Validation
            "negative_balance_allowed": self.negative_balance_allowed,
            "over_redemption_allowed": self.over_redemption_allowed,
            "future_date_allowed": self.future_date_allowed,
            "expired_voucher_allowed": self.expired_voucher_allowed,
            "cancelled_voucher_allowed": self.cancelled_voucher_allowed,
            # Developer
            "enable_debug_logs": self.enable_debug_logs,
            "enable_audit_logs": self.enable_audit_logs,
            "enable_api_logs": self.enable_api_logs,
            "enable_performance_logs": self.enable_performance_logs,
            # Security config
            "permission_cashier": self.permission_cashier,
            "permission_supervisor": self.permission_supervisor,
            "permission_manager": self.permission_manager,
            "permission_administrator": self.permission_administrator,
        }

    @api.model
    def get_values(self):
        """Load config values from ir.config_parameter."""
        res = super().get_values() if hasattr(super(), "get_values") else {}
        company_id, config_id = self._param_scope_ids()
        params = self.env["ir.config_parameter"].sudo()

        def read(key, default):
            if config_id:
                raw = params.get_param(config_param_key(config_id, key), default=None)
                if raw is not None:
                    return raw
            raw = params.get_param(company_param_key(company_id, key), default=None)
            return raw if raw is not None else default

        # Populate only fields that exist on this transient model.
        # Conversion is handled by Odoo for primitives, but we normalize
        # booleans/ints for reliability.
        values = {
            "enable_store_credit": to_bool(read("enable_store_credit", True), True),
            "enable_return_voucher": to_bool(read("enable_return_voucher", True), True),
            "enable_gift_voucher": to_bool(read("enable_gift_voucher", False), False),
            "enable_customer_wallet": to_bool(read("enable_customer_wallet", False), False),
            "enable_loyalty_credit": to_bool(read("enable_loyalty_credit", False), False),
            "enable_manual_credit": to_bool(read("enable_manual_credit", True), True),
            "enable_compensation_credit": to_bool(
                read("enable_compensation_credit", True), True
            ),
            "voucher_prefix": str(read("voucher_prefix", "CBRV") or "CBRV"),
            "voucher_sequence_code": str(
                read("voucher_sequence_code", "pos.return.voucher") or "pos.return.voucher"
            ),
            "barcode_prefix": str(read("barcode_prefix", "CBRV") or "CBRV"),
            "qr_code_enabled": to_bool(read("qr_code_enabled", False), False),
            "voucher_expiry_enabled": to_bool(read("voucher_expiry_enabled", True), True),
            "default_expiry_days": to_int(read("default_expiry_days", 90), 90),
            "auto_expire": to_bool(read("auto_expire", True), True),
            "allow_permanent_voucher": to_bool(read("allow_permanent_voucher", False), False),
            "voucher_print_copies": to_int(read("voucher_print_copies", 1), 1),
            "allow_partial_redemption": to_bool(
                read("allow_partial_redemption", True), True
            ),
            "allow_multiple_voucher_usage": to_bool(
                read("allow_multiple_voucher_usage", True), True
            ),
            "allow_split_payment": to_bool(read("allow_split_payment", True), True),
            "minimum_redemption_amount": to_float(
                read("minimum_redemption_amount", 0.0), 0.0
            ),
            "maximum_redemption_amount": to_float(
                read("maximum_redemption_amount", 0.0), 0.0
            ),
            "allow_cross_branch_redemption": to_bool(
                read("allow_cross_branch_redemption", True), True
            ),
            "allow_cross_company_redemption": to_bool(
                read("allow_cross_company_redemption", False), False
            ),
            "credit_redemption_order": str(
                read("credit_redemption_order", "oldest_first") or "oldest_first"
            ),
            "remaining_credit_strategy": str(
                read("remaining_credit_strategy", "issue_new") or "issue_new"
            ),
            "auto_print_remainder_voucher": to_bool(
                read("auto_print_remainder_voucher", True), True
            ),
            "require_manager_approval_partial": to_bool(
                read("require_manager_approval_partial", False), False
            ),
            "maximum_return_days": to_int(read("maximum_return_days", 14), 14),
            "allow_return_without_customer": to_bool(
                read("allow_return_without_customer", True), True
            ),
            "allow_return_without_invoice": to_bool(
                read("allow_return_without_invoice", False), False
            ),
            "require_original_invoice": to_bool(
                read("require_original_invoice", True), True
            ),
            "require_manager_approval": to_bool(
                read("require_manager_approval", False), False
            ),
            "maximum_return_amount": to_float(
                read("maximum_return_amount", 0.0), 0.0
            ),
            "manager_approval_required": to_bool(
                read("manager_approval_required", False), False
            ),
            "approval_amount_limit": to_float(read("approval_amount_limit", 0.0), 0.0),
            "approval_for_expired_voucher": to_bool(
                read("approval_for_expired_voucher", False), False
            ),
            "approval_for_cancel_voucher": to_bool(
                read("approval_for_cancel_voucher", False), False
            ),
            "approval_for_manual_adjustment": to_bool(
                read("approval_for_manual_adjustment", False), False
            ),
            "approval_for_return_without_invoice": to_bool(
                read("approval_for_return_without_invoice", False), False
            ),
            "barcode_length": to_int(read("barcode_length", 10), 10),
            "barcode_format": str(read("barcode_format", "PREFIX+SEQUENCE_ZPAD") or "PREFIX+SEQUENCE_ZPAD"),
            "barcode_validation": to_bool(read("barcode_validation", True), True),
            "offline_barcode_strategy": str(
                read("offline_barcode_strategy", "uuid_only") or "uuid_only"
            ),
            "duplicate_prevention": str(
                read("duplicate_prevention", "strict_unique") or "strict_unique"
            ),
            "offline_enabled": to_bool(read("offline_enabled", False), False),
            "offline_queue_size": to_int(read("offline_queue_size", 500), 500),
            "offline_retry_count": to_int(read("offline_retry_count", 5), 5),
            "offline_retry_interval_seconds": to_int(
                read("offline_retry_interval_seconds", 30), 30
            ),
            "conflict_resolution_strategy": str(
                read("conflict_resolution_strategy", "server_residual_wins")
                or "server_residual_wins"
            ),
            "auto_print_voucher": to_bool(read("auto_print_voucher", True), True),
            "auto_print_return_receipt": to_bool(
                read("auto_print_return_receipt", True), True
            ),
            "print_qr": to_bool(read("print_qr", False), False),
            "print_barcode": to_bool(read("print_barcode", True), True),
            "print_company_logo": to_bool(read("print_company_logo", True), True),
            "print_remaining_balance": to_bool(
                read("print_remaining_balance", True), True
            ),
            "print_terms_conditions": to_bool(
                read("print_terms_conditions", False), False
            ),
            "notify_customer": to_bool(read("notify_customer", False), False),
            "email_notification": to_bool(read("email_notification", False), False),
            "sms_notification": to_bool(read("sms_notification", False), False),
            "whatsapp_notification": to_bool(
                read("whatsapp_notification", False), False
            ),
            "manager_notification": to_bool(read("manager_notification", False), False),
            "separate_sequence_per_company": to_bool(
                read("separate_sequence_per_company", True), True
            ),
            "separate_voucher_prefix": to_bool(
                read("separate_voucher_prefix", True), True
            ),
            "separate_approval_rules": to_bool(
                read("separate_approval_rules", True), True
            ),
            "separate_expiry_rules": to_bool(
                read("separate_expiry_rules", True), True
            ),
            "branch_specific_voucher": to_bool(
                read("branch_specific_voucher", True), True
            ),
            "branch_redemption_rules": to_bool(
                read("branch_redemption_rules", True), True
            ),
            "branch_approval_rules": to_bool(
                read("branch_approval_rules", True), True
            ),
            "negative_balance_allowed": to_bool(
                read("negative_balance_allowed", False), False
            ),
            "over_redemption_allowed": to_bool(
                read("over_redemption_allowed", False), False
            ),
            "future_date_allowed": to_bool(read("future_date_allowed", False), False),
            "expired_voucher_allowed": to_bool(
                read("expired_voucher_allowed", False), False
            ),
            "cancelled_voucher_allowed": to_bool(
                read("cancelled_voucher_allowed", False), False
            ),
            "enable_debug_logs": to_bool(read("enable_debug_logs", False), False),
            "enable_audit_logs": to_bool(read("enable_audit_logs", True), True),
            "enable_api_logs": to_bool(read("enable_api_logs", False), False),
            "enable_performance_logs": to_bool(
                read("enable_performance_logs", False), False
            ),
            "permission_cashier": str(read("permission_cashier", "limited") or "limited"),
            "permission_supervisor": str(
                read("permission_supervisor", "full") or "full"
            ),
            "permission_manager": str(read("permission_manager", "full") or "full"),
            "permission_administrator": str(
                read("permission_administrator", "full") or "full"
            ),
        }
        res.update(values)
        return res

    def set_values(self):
        """Persist all config values in ir.config_parameter."""
        company_id, config_id = self._param_scope_ids()
        params = self.env["ir.config_parameter"].sudo()

        def write_param(key, value):
            params.set_param(company_param_key(company_id, key), value)
            if config_id:
                params.set_param(config_param_key(config_id, key), value)

        # Basic validation (avoid invalid configs early)
        if not (self.barcode_prefix or "").strip():
            raise ValidationError("Barcode prefix cannot be empty.")
        if len((self.barcode_prefix or "").strip()) > 10:
            raise ValidationError("Barcode prefix must be at most 10 characters.")
        if self.barcode_length <= 0:
            raise ValidationError("Barcode length must be > 0.")
        if self.voucher_print_copies <= 0:
            raise ValidationError("Voucher print copies must be > 0.")
        if self.default_expiry_days < 0:
            raise ValidationError("Default expiry days cannot be negative.")
        if self.offline_queue_size < 0 or self.offline_retry_count < 0:
            raise ValidationError("Offline retry queue/count cannot be negative.")
        if self.offline_retry_interval_seconds < 0:
            raise ValidationError("Offline retry interval cannot be negative.")

        for param_key, value in self._param_map().items():
            write_param(param_key, value)

        return True

