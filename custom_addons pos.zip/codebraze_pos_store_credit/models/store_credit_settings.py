# -*- coding: utf-8 -*-
"""Company-level Store Credit & Return configuration.

This model still exists for backward compatibility and for installations that
may have used DB-stored settings in Phase 01.

In Phase 02+, the business layer must consume configuration values exclusively.
Therefore, ``_get_settings()`` now resolves settings from ``ir.config_parameter``
(with company and optional pos.config override), and falls back to DB values
when parameters are not present yet.
"""

import logging
from types import SimpleNamespace

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError

from .store_credit_config_utils import (
    company_param_key,
    config_param_key,
    to_bool,
    to_float,
    to_int,
)

_logger = logging.getLogger(__name__)


class StoreCreditSettings(models.Model):
    """
    Configuration for store credit, vouchers and return policies.

    One active settings record per company (optional POS config override).
    """

    _name = "store.credit.settings"
    _description = "Store Credit Settings"
    _check_company_auto = True

    name = fields.Char(
        string="Name",
        required=True,
        default="Store Credit Settings",
    )
    active = fields.Boolean(default=True)
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        related="company_id.currency_id",
        store=True,
        readonly=True,
    )
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("active", "Active"),
            ("archived", "Archived"),
        ],
        string="Status",
        default="active",
        required=True,
        index=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="POS Config Override",
        check_company=True,
        index=True,
        help="Leave empty for company-wide defaults. Set to override per branch.",
    )

    # Voucher / barcode
    voucher_expiry_days = fields.Integer(
        string="Voucher Expiry (Days)",
        default=90,
        help="Default number of days before a store credit / voucher expires. "
             "0 means never expires.",
    )
    barcode_prefix = fields.Char(
        string="Barcode Prefix",
        required=True,
        default="CBRV",
        help="Prefix used when generating store credit / voucher barcodes.",
    )
    barcode_padding = fields.Integer(
        string="Barcode Padding",
        default=10,
        required=True,
        help="Zero-pad width for the numeric part of the barcode.",
    )

    # Approvals & returns
    manager_approval = fields.Boolean(
        string="Require Manager Approval",
        default=False,
        help="When enabled, returns above thresholds require manager approval.",
    )
    maximum_refund_days = fields.Integer(
        string="Maximum Refund Days",
        default=14,
        help="Maximum days after the original sale during which a return is allowed.",
    )
    approval_amount = fields.Monetary(
        string="Approval Amount Threshold",
        currency_field="currency_id",
        default=0.0,
        help="Return totals at or above this amount require supervisor/manager approval.",
    )

    # Usage rules
    allow_partial_usage = fields.Boolean(
        string="Allow Partial Usage",
        default=True,
        help="Allow redeeming only part of a store credit balance.",
    )
    allow_multiple_voucher = fields.Boolean(
        string="Allow Multiple Vouchers",
        default=True,
        help="Allow paying a single POS order with more than one voucher.",
    )
    cross_branch_usage = fields.Boolean(
        string="Cross Branch Usage",
        default=True,
        help="Allow redeeming store credit issued at another POS branch "
             "within the same company.",
    )
    auto_print = fields.Boolean(
        string="Auto Print Voucher",
        default=True,
        help="Automatically print the voucher slip when credit is issued.",
    )
    allow_guest_credit = fields.Boolean(
        string="Allow Guest Credit",
        default=True,
        help="Allow issuing store credit without a linked customer.",
    )
    enable_cash_refund = fields.Boolean(
        string="Enable Cash Refund",
        default=False,
        help="Allow cash refund as a return settlement method.",
    )
    cash_refund_limit = fields.Monetary(
        string="Cash Refund Limit",
        currency_field="currency_id",
        default=0.0,
        help="Cash refunds above this amount require manager approval.",
    )

    _sql_constraints = [
        (
            "settings_company_config_uniq",
            "unique(company_id, config_id)",
            "Only one Store Credit Settings record is allowed per company "
            "and POS configuration.",
        ),
        (
            "barcode_padding_positive",
            "CHECK(barcode_padding > 0)",
            "Barcode padding must be greater than zero.",
        ),
        (
            "voucher_expiry_non_negative",
            "CHECK(voucher_expiry_days >= 0)",
            "Voucher expiry days cannot be negative.",
        ),
        (
            "maximum_refund_days_non_negative",
            "CHECK(maximum_refund_days >= 0)",
            "Maximum refund days cannot be negative.",
        ),
    ]

    @api.constrains("barcode_prefix")
    def _check_barcode_prefix(self):
        for settings in self:
            prefix = (settings.barcode_prefix or "").strip()
            if not prefix:
                raise ValidationError(self.env._("Barcode prefix is required."))
            if len(prefix) > 10:
                raise ValidationError(
                    self.env._("Barcode prefix must be at most 10 characters.")
                )

    @api.model
    def _get_settings(self, company=None, config=None):
        """
        Resolve settings for a company, optionally overridden by POS config.

        :param company: res.company record / id
        :param config: pos.config record / id
        :return: an object with configuration attributes used by business logic
                 (SimpleNamespace; not a recordset on purpose).
        """
        company = company or self.env.company
        company_id = company.id if hasattr(company, "id") else int(company)
        config_id = False
        if config:
            config_id = config.id if hasattr(config, "id") else int(config)

        # Fallback to DB-stored values (Phase 01 installations)
        domain = [
            ("company_id", "=", company_id),
            ("active", "=", True),
            ("state", "=", "active"),
        ]
        db_settings = self.env["store.credit.settings"]
        fallback = None
        if config_id:
            fallback = db_settings.search(domain + [("config_id", "=", config_id)], limit=1)
        if not fallback:
            fallback = db_settings.search(domain + [("config_id", "=", False)], limit=1)

        # Prepare default fallbacks
        def _fallback_attr(attr, default=None):
            if fallback and hasattr(fallback, attr):
                return getattr(fallback, attr)
            return default

        params = self.env["ir.config_parameter"].sudo()

        def _read_param(key, default):
            # Prefer pos.config override when available
            if config_id:
                raw = params.get_param(config_param_key(config_id, key), default=None)
                if raw is not None:
                    return raw
            raw = params.get_param(company_param_key(company_id, key), default=None)
            return raw if raw is not None else default

        # Voucher expiry handling: expiry disabled OR permanent vouchers => 0 days
        voucher_expiry_enabled = to_bool(
            _read_param("voucher_expiry_enabled", _fallback_attr("voucher_expiry_days", 90) > 0),
            True,
        )
        allow_permanent_voucher = to_bool(
            _read_param("allow_permanent_voucher", False), False
        )
        default_expiry_days = to_int(
            _read_param(
                "default_expiry_days",
                _fallback_attr("voucher_expiry_days", 90),
            ),
            _fallback_attr("voucher_expiry_days", 90) or 90,
        )
        voucher_expiry_days = 0 if (not voucher_expiry_enabled or allow_permanent_voucher) else default_expiry_days

        barcode_prefix = str(_read_param("barcode_prefix", _fallback_attr("barcode_prefix", "CBRV")) or "CBRV")
        barcode_padding = to_int(
            _read_param("barcode_length", _fallback_attr("barcode_padding", 10)),
            _fallback_attr("barcode_padding", 10) or 10,
        )

        # Build a config object with the attribute names expected by the
        # existing business layer.
        settings_obj = SimpleNamespace(
            # Enablement flags
            enable_store_credit=to_bool(
                _read_param("enable_store_credit", True), True
            ),
            enable_return_voucher=to_bool(
                _read_param("enable_return_voucher", True), True
            ),
            enable_gift_voucher=to_bool(
                _read_param("enable_gift_voucher", False), False
            ),
            enable_customer_wallet=to_bool(
                _read_param("enable_customer_wallet", False), False
            ),
            enable_loyalty_credit=to_bool(
                _read_param("enable_loyalty_credit", False), False
            ),
            enable_manual_credit=to_bool(
                _read_param("enable_manual_credit", True), True
            ),
            enable_compensation_credit=to_bool(
                _read_param("enable_compensation_credit", True), True
            ),
            # Voucher settings
            voucher_prefix=str(_read_param("voucher_prefix", barcode_prefix) or barcode_prefix),
            voucher_sequence_code=str(_read_param("voucher_sequence_code", "pos.return.voucher") or "pos.return.voucher"),
            qr_code_enabled=to_bool(_read_param("qr_code_enabled", False), False),
            voucher_expiry_enabled=voucher_expiry_enabled,
            auto_expire=to_bool(_read_param("auto_expire", True), True),
            allow_permanent_voucher=allow_permanent_voucher,
            voucher_print_copies=to_int(_read_param("voucher_print_copies", 1), 1),
            # Business-layer-required names
            voucher_expiry_days=voucher_expiry_days,
            barcode_prefix=barcode_prefix,
            barcode_padding=barcode_padding,
            auto_print=to_bool(_read_param("auto_print_voucher", _fallback_attr("auto_print", True)), True),
            allow_partial_usage=to_bool(_read_param("allow_partial_redemption", _fallback_attr("allow_partial_usage", True)), True),
            allow_multiple_voucher=to_bool(_read_param("allow_multiple_voucher_usage", _fallback_attr("allow_multiple_voucher", True)), True),
            cross_branch_usage=to_bool(_read_param("allow_cross_branch_redemption", _fallback_attr("cross_branch_usage", True)), True),
            allow_guest_credit=to_bool(
                _read_param("allow_return_without_customer", _fallback_attr("allow_guest_credit", True)),
                True,
            ),
            enable_cash_refund=to_bool(
                _read_param("enable_cash_refund", _fallback_attr("enable_cash_refund", False)),
                _fallback_attr("enable_cash_refund", False) or False,
            ),
            cash_refund_limit=to_float(
                _read_param("cash_refund_limit", _fallback_attr("cash_refund_limit", 0.0)),
                _fallback_attr("cash_refund_limit", 0.0) or 0.0,
            ),
            # Return / approval business-layer required names
            maximum_refund_days=to_int(
                _read_param("maximum_return_days", _fallback_attr("maximum_refund_days", 14)),
                _fallback_attr("maximum_refund_days", 14) or 14,
            ),
            manager_approval=to_bool(
                _read_param("manager_approval_required", _fallback_attr("manager_approval", False)),
                _fallback_attr("manager_approval", False) or False,
            ),
            approval_amount=to_float(
                _read_param("approval_amount_limit", _fallback_attr("approval_amount", 0.0)),
                _fallback_attr("approval_amount", 0.0) or 0.0,
            ),
            # Additional config (for future validators/services)
            allow_multiple_voucher_usage=to_bool(
                _read_param("allow_multiple_voucher_usage", True), True
            ),
            allow_split_payment=to_bool(_read_param("allow_split_payment", True), True),
            allow_cross_branch_redemption=to_bool(
                _read_param("allow_cross_branch_redemption", True), True
            ),
            allow_cross_company_redemption=to_bool(
                _read_param("allow_cross_company_redemption", False), False
            ),
            minimum_redemption_amount=to_float(
                _read_param("minimum_redemption_amount", 0.0), 0.0
            ),
            maximum_redemption_amount=to_float(
                _read_param("maximum_redemption_amount", 0.0), 0.0
            ),
            credit_redemption_order=str(
                _read_param("credit_redemption_order", "oldest_first")
                or "oldest_first"
            ),
            remaining_credit_strategy=str(
                _read_param("remaining_credit_strategy", "issue_new") or "issue_new"
            ),
            auto_print_remainder_voucher=to_bool(
                _read_param("auto_print_remainder_voucher", True), True
            ),
            require_manager_approval_partial=to_bool(
                _read_param("require_manager_approval_partial", False), False
            ),
            maximum_return_amount=to_float(
                _read_param("maximum_return_amount", _fallback_attr("maximum_return_amount", 0.0) or 0.0),
                0.0,
            ),
            require_manager_approval=to_bool(
                _read_param("require_manager_approval", False), False
            ),
            require_original_invoice=to_bool(
                _read_param("require_original_invoice", True), True
            ),
            allow_return_without_invoice=to_bool(
                _read_param("allow_return_without_invoice", False), False
            ),
            offline_enabled=to_bool(_read_param("offline_enabled", False), False),
            offline_queue_size=to_int(_read_param("offline_queue_size", 500), 500),
            offline_retry_count=to_int(_read_param("offline_retry_count", 5), 5),
            offline_retry_interval_seconds=to_int(_read_param("offline_retry_interval_seconds", 30), 30),
            conflict_resolution_strategy=str(
                _read_param(
                    "conflict_resolution_strategy",
                    "server_residual_wins",
                )
                or "server_residual_wins"
            ),
        )

        # Normalize values for safety
        if not barcode_prefix or not barcode_prefix.strip():
            raise UserError(self.env._("Invalid Store Credit configuration: barcode prefix is empty."))
        if not barcode_padding or barcode_padding <= 0:
            raise UserError(self.env._("Invalid Store Credit configuration: barcode length must be > 0."))

        return settings_obj
