# -*- coding: utf-8 -*-
"""Store Credit configuration helpers.

This file centralizes:
- ir.config_parameter key naming conventions
- parsing helpers for booleans / numbers stored as Text

It is used by both the settings UI layer (res.config.settings) and the
runtime configuration resolver (store.credit.settings._get_settings()).
"""

from odoo import _


PARAM_KEY_ROOT = "codebraze.store_credit"


def company_param_key(company_id, param_key):
    """Build the ir.config_parameter key for a company-scoped setting."""
    return f"{PARAM_KEY_ROOT}.company.{int(company_id)}.{param_key}"


def config_param_key(pos_config_id, param_key):
    """Build the ir.config_parameter key for a pos.config-scoped override."""
    return f"{PARAM_KEY_ROOT}.pos_config.{int(pos_config_id)}.{param_key}"


def to_bool(raw, default=False):
    """Parse ir.config_parameter Text values into booleans."""
    if raw is None:
        return default
    s = str(raw).strip().lower()
    if s in ("1", "true", "t", "yes", "y", "on"):
        return True
    if s in ("0", "false", "f", "no", "n", "off"):
        return False
    return default


def to_int(raw, default=0):
    """Parse integer values stored as Text."""
    if raw is None:
        return default
    try:
        return int(float(raw))
    except (TypeError, ValueError):
        return default


def to_float(raw, default=0.0):
    """Parse float/decimal values stored as Text."""
    if raw is None:
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


def to_str(raw, default=""):
    """Normalize Text values."""
    if raw is None:
        return default
    s = str(raw)
    return s

