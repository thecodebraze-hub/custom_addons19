# -*- coding: utf-8 -*-
"""Link between store credit redemption and POS payments."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare

_logger = logging.getLogger(__name__)


class StoreCreditPayment(models.Model):
    """
    Store credit payment mapping / redemption payment line.

    Technical name: store.credit.payment

    Tracks each POS payment that consumes (or issues against) a store credit
    instrument. Supports partial redemption, multi-voucher and split tender.
    """

    _name = "store.credit.payment"
    _description = "Store Credit Payment"
    _inherit = ["store.credit.uuid.mixin", "store.credit.sync.mixin"]
    _order = "id desc"
    _check_company_auto = True

    name = fields.Char(
        string="Reference",
        required=True,
        copy=False,
        readonly=True,
        default="New",
        index=True,
    )
    active = fields.Boolean(default=True)
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("posted", "Posted"),
            ("reversed", "Reversed"),
            ("cancelled", "Cancelled"),
        ],
        string="Status",
        default="posted",
        required=True,
        index=True,
    )
    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        required=True,
        ondelete="restrict",
        index=True,
        check_company=True,
    )
    payment_id = fields.Many2one(
        comodel_name="pos.payment",
        string="POS Payment",
        index=True,
        ondelete="set null",
        help="POS payment line that applied this store credit.",
    )
    payment_method_id = fields.Many2one(
        comodel_name="pos.payment.method",
        string="Payment Method",
        index=True,
        check_company=True,
    )
    pos_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="POS Order",
        required=True,
        index=True,
        check_company=True,
    )
    transaction_id = fields.Many2one(
        comodel_name="store.credit.transaction",
        string="Credit Transaction",
        index=True,
        copy=False,
        help="Ledger redeem/issue transaction linked to this payment.",
    )
    amount = fields.Monetary(
        string="Amount",
        currency_field="currency_id",
        required=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        default=lambda self: self.env.company,
        index=True,
    )
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        string="Currency",
        required=True,
        default=lambda self: self.env.company.currency_id,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Customer",
        related="credit_id.partner_id",
        store=True,
        index=True,
        readonly=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        index=True,
        check_company=True,
    )
    session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        check_company=True,
    )
    cashier_id = fields.Many2one(
        comodel_name="res.users",
        string="Cashier",
        default=lambda self: self.env.user,
        index=True,
    )
    note = fields.Text(string="Notes")

    _sql_constraints = [
        (
            "store_credit_payment_uuid_uniq",
            "unique(uuid)",
            "Store credit payment UUID must be unique.",
        ),
        (
            "store_credit_payment_amount_positive",
            "CHECK(amount >= 0)",
            "Payment amount must be greater than or equal to zero.",
        ),
    ]

    @api.constrains("amount", "credit_id")
    def _check_amount(self):
        precision = self.env["decimal.precision"].precision_get("Product Price")
        for line in self:
            if float_compare(line.amount, 0.0, precision_digits=precision) <= 0:
                raise ValidationError(
                    self.env._("Store credit payment amount must be greater than zero.")
                )

    @api.constrains("credit_id", "pos_order_id", "company_id")
    def _check_company_consistency(self):
        for line in self:
            if line.credit_id.company_id != line.company_id:
                raise ValidationError(
                    self.env._("Store credit and payment must belong to the same company.")
                )
            if line.pos_order_id and line.pos_order_id.company_id != line.company_id:
                raise ValidationError(
                    self.env._("POS order and payment must belong to the same company.")
                )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("uuid"):
                vals["uuid"] = self._generate_uuid()
            if vals.get("name", "New") == "New":
                company = self.env["res.company"].browse(
                    vals.get("company_id") or self.env.company.id
                )
                # Reuse transaction sequence family for payment refs if dedicated missing
                seq = (
                    self.env["ir.sequence"]
                    .with_company(company)
                    .next_by_code("store.credit.payment")
                )
                if not seq:
                    seq = (
                        self.env["ir.sequence"]
                        .with_company(company)
                        .next_by_code("store.credit.transaction")
                    )
                if not seq:
                    raise UserError(
                        self.env._("Sequence for store credit payment is not configured.")
                    )
                vals["name"] = seq
            if vals.get("credit_id") and not vals.get("currency_id"):
                credit = self.env["store.credit"].browse(vals["credit_id"])
                vals["currency_id"] = credit.currency_id.id
                vals.setdefault("company_id", credit.company_id.id)
        return super().create(vals_list)
