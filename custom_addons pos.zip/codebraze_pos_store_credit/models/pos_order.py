# -*- coding: utf-8 -*-
"""POS order hooks for store credit redemption on payment."""

import json
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class PosOrder(models.Model):
    _inherit = "pos.order"

    store_credit_remainder_data = fields.Text(
        string="Store Credit Remainder Data",
        help="JSON payload of remainder vouchers issued after partial redemptions.",
        copy=False,
    )

    def _process_saved_order(self, draft):
        if not draft and self.state != "cancel":
            self._redeem_store_credit_payments()
        return super()._process_saved_order(draft)

    def _redeem_store_credit_payments(self):
        """Redeem store credits linked to store-credit payment lines."""
        for order in self:
            sc_payments = order.payment_ids.filtered(
                lambda p: p.payment_method_id.is_store_credit
            )
            if not sc_payments:
                continue
            remainder_jobs = []
            for payment in sc_payments:
                remainder_jobs.extend(order._process_store_credit_payment_line(payment))
            if remainder_jobs:
                order.store_credit_remainder_data = json.dumps(
                    {"remainder_jobs": remainder_jobs}, default=str
                )

    def _process_store_credit_payment_line(self, payment):
        self.ensure_one()
        if not payment.store_credit_redemption_data:
            raise UserError(
                self.env._(
                    "Store credit payment on order %(order)s is missing redemption data.",
                    order=self.name,
                )
            )
        try:
            payload = json.loads(payment.store_credit_redemption_data)
        except (TypeError, ValueError) as exc:
            raise UserError(
                self.env._("Invalid store credit redemption payload on order %(order)s.", order=self.name)
            ) from exc

        redemptions = payload.get("redemptions") or []
        if not redemptions:
            raise UserError(
                self.env._(
                    "Store credit payment on order %(order)s has no redemption lines.",
                    order=self.name,
                )
            )

        Credit = self.env["store.credit"]
        remainder_jobs = []
        for line in redemptions:
            _sc_payment, remainder = Credit._pos_execute_redemption(
                line,
                pos_order=self,
                payment=payment,
                config=self.config_id,
                session=self.session_id,
            )
            if remainder and remainder.get("strategy") not in (None, "none"):
                remainder_jobs.append(remainder)
        return remainder_jobs

    @api.model
    def _load_pos_data_fields(self, config):
        fields_list = super()._load_pos_data_fields(config)
        return fields_list + ["store_credit_remainder_data"]
