# -*- coding: utf-8 -*-
"""Upgrade migration: preserve historical mappings on config expansion."""


def migrate(cr, version):
    """Copy legacy expense_account_id into sales_returns_account_id when empty."""
    cr.execute(
        """
        UPDATE store_credit_settings
           SET sales_returns_account_id = expense_account_id
         WHERE sales_returns_account_id IS NULL
           AND expense_account_id IS NOT NULL
        """
    )
    cr.execute(
        """
        UPDATE store_credit_settings
           SET redemption_clearing_account_id = expense_account_id
         WHERE redemption_clearing_account_id IS NULL
           AND expense_account_id IS NOT NULL
        """
    )
    cr.execute(
        """
        UPDATE store_credit_settings
           SET refund_journal_id = journal_id
         WHERE refund_journal_id IS NULL
           AND journal_id IS NOT NULL
        """
    )
    cr.execute(
        """
        UPDATE store_credit_settings
           SET sales_return_journal_id = journal_id
         WHERE sales_return_journal_id IS NULL
           AND journal_id IS NOT NULL
        """
    )
