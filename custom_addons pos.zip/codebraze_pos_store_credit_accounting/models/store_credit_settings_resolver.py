# -*- coding: utf-8 -*-
"""Inject accounting configuration into runtime settings namespace."""

from types import SimpleNamespace

from odoo import api, models


class StoreCreditSettingsAccountingResolver(models.Model):
    _inherit = "store.credit.settings"

    @api.model
    def _get_settings(self, company=None, config=None):
        settings_obj = super()._get_settings(company=company, config=config)
        company = company or self.env.company
        company_id = company.id if hasattr(company, "id") else int(company)
        config_id = False
        if config:
            config_id = config.id if hasattr(config, "id") else int(config)

        domain = [
            ("company_id", "=", company_id),
            ("active", "=", True),
            ("state", "=", "active"),
        ]
        fallback = self.env["store.credit.settings"]
        record = None
        if config_id:
            record = fallback.search(domain + [("config_id", "=", config_id)], limit=1)
        if not record:
            record = fallback.search(domain + [("config_id", "=", False)], limit=1)

        def _rec_attr(attr, default=None):
            if record and hasattr(record, attr):
                val = getattr(record, attr)
                return val if val else default
            return default

        accounting_attrs = {
            "enable_accounting": _rec_attr("enable_accounting", True),
            "accounting_config_version": _rec_attr("accounting_config_version", 1),
            # Journals
            "journal_id": _rec_attr("journal_id", False),
            "refund_journal_id": _rec_attr("refund_journal_id", False),
            "sales_return_journal_id": _rec_attr("sales_return_journal_id", False),
            "cash_refund_journal_id": _rec_attr("cash_refund_journal_id", False),
            "bank_refund_journal_id": _rec_attr("bank_refund_journal_id", False),
            "adjustment_journal_id": _rec_attr("adjustment_journal_id", False),
            "reversal_journal_id": _rec_attr("reversal_journal_id", False),
            # Accounts
            "liability_account_id": _rec_attr("liability_account_id", False),
            "sales_returns_account_id": _rec_attr("sales_returns_account_id", False)
            or _rec_attr("expense_account_id", False),
            "gift_voucher_liability_account_id": _rec_attr(
                "gift_voucher_liability_account_id", False
            ),
            "wallet_liability_account_id": _rec_attr(
                "wallet_liability_account_id", False
            ),
            "loyalty_liability_account_id": _rec_attr(
                "loyalty_liability_account_id", False
            ),
            "redemption_clearing_account_id": _rec_attr(
                "redemption_clearing_account_id", False
            )
            or _rec_attr("expense_account_id", False),
            "refund_clearing_account_id": _rec_attr("refund_clearing_account_id", False),
            "inventory_account_id": _rec_attr("inventory_account_id", False),
            "cogs_account_id": _rec_attr("cogs_account_id", False),
            "revenue_account_id": _rec_attr("revenue_account_id", False),
            "tax_account_id": _rec_attr("tax_account_id", False),
            "adjustment_account_id": _rec_attr("adjustment_account_id", False),
            "writeoff_account_id": _rec_attr("writeoff_account_id", False),
            "breakage_revenue_account_id": _rec_attr("breakage_revenue_account_id", False),
            "expense_account_id": _rec_attr("expense_account_id", False)
            or _rec_attr("sales_returns_account_id", False),
            "cash_account_id": _rec_attr("cash_account_id", False),
            "bank_account_id": _rec_attr("bank_account_id", False),
            # Fiscal & behaviour
            "fiscal_position_id": _rec_attr("fiscal_position_id", False),
            "auto_post_entries": _rec_attr("auto_post_entries", True),
            "accounting_strict_mode": _rec_attr("accounting_strict_mode", False),
            "post_on_issue": _rec_attr("post_on_issue", True),
            "post_on_redeem": _rec_attr("post_on_redeem", True),
            "post_on_cancel": _rec_attr("post_on_cancel", True),
            "post_on_expire": _rec_attr("post_on_expire", True),
            "reconcile_refund_clearing": _rec_attr("reconcile_refund_clearing", True),
            "invoiced_return_mode": _rec_attr(
                "invoiced_return_mode", "credit_note_and_liability"
            ),
            "uninvoiced_return_mode": _rec_attr(
                "uninvoiced_return_mode", "session_and_liability"
            ),
        }

        if config_id:
            pos_config = self.env["pos.config"].browse(config_id)
            if pos_config.pos_store_credit_journal_id:
                accounting_attrs["journal_id"] = pos_config.pos_store_credit_journal_id
            if pos_config.pos_refund_journal_id:
                accounting_attrs["refund_journal_id"] = pos_config.pos_refund_journal_id
            if pos_config.pos_liability_account_id:
                accounting_attrs["liability_account_id"] = (
                    pos_config.pos_liability_account_id
                )
            if pos_config.pos_return_fiscal_position_id:
                accounting_attrs["fiscal_position_id"] = (
                    pos_config.pos_return_fiscal_position_id
                )
            if pos_config.pos_accounting_strict_mode:
                accounting_attrs["accounting_strict_mode"] = True

        if isinstance(settings_obj, SimpleNamespace):
            for key, value in accounting_attrs.items():
                setattr(settings_obj, key, value)
            if config_id:
                pos_config = self.env["pos.config"].browse(config_id)
                if pos_config.pos_manager_approval:
                    settings_obj.manager_approval = True
                if pos_config.pos_approval_amount:
                    settings_obj.approval_amount = pos_config.pos_approval_amount
        return settings_obj
