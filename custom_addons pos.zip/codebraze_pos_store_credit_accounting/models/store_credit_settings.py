# -*- coding: utf-8 -*-
"""Accounting configuration fields on store credit / return settings."""

from odoo import api, fields, models
from odoo.exceptions import ValidationError

# Account fields validated by return.accounting.config.service
ACCOUNTING_ACCOUNT_FIELDS = (
    "liability_account_id",
    "sales_returns_account_id",
    "redemption_clearing_account_id",
    "refund_clearing_account_id",
    "breakage_revenue_account_id",
    "gift_voucher_liability_account_id",
    "wallet_liability_account_id",
    "loyalty_liability_account_id",
    "inventory_account_id",
    "cogs_account_id",
    "revenue_account_id",
    "tax_account_id",
    "adjustment_account_id",
    "writeoff_account_id",
    "cash_account_id",
    "bank_account_id",
    "expense_account_id",
)

ACCOUNTING_JOURNAL_FIELDS = (
    "journal_id",
    "refund_journal_id",
    "sales_return_journal_id",
    "cash_refund_journal_id",
    "bank_refund_journal_id",
    "adjustment_journal_id",
    "reversal_journal_id",
)

ACCOUNTING_TRACKED_FIELDS = ACCOUNTING_ACCOUNT_FIELDS + ACCOUNTING_JOURNAL_FIELDS + (
    "enable_accounting",
    "fiscal_position_id",
    "accounting_strict_mode",
    "auto_post_entries",
    "post_on_issue",
    "post_on_redeem",
    "post_on_cancel",
    "post_on_expire",
    "reconcile_refund_clearing",
    "invoiced_return_mode",
    "uninvoiced_return_mode",
    "manager_approval",
    "approval_amount",
    "cash_refund_limit",
)


class StoreCreditSettingsAccounting(models.Model):
    _inherit = "store.credit.settings"

    # -------------------------------------------------------------------------
    # Enablement & versioning (migration-safe)
    # -------------------------------------------------------------------------

    enable_accounting = fields.Boolean(
        string="Enable Accounting Integration",
        default=True,
    )
    accounting_config_version = fields.Integer(
        string="Accounting Config Version",
        default=1,
        copy=False,
        help="Incremented when accounting mapping changes. Historical moves "
        "retain their original journal entries.",
    )

    # -------------------------------------------------------------------------
    # Journals
    # -------------------------------------------------------------------------

    journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Store Credit Journal",
        check_company=True,
        domain="[('company_id', '=', company_id), ('type', 'in', ('general', 'sale'))]",
        help="Journal for store credit liability and redemption entries.",
    )
    refund_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Refund / Clearing Journal",
        check_company=True,
        domain="[('company_id', '=', company_id)]",
        help="Default journal for refund clearing entries.",
    )
    sales_return_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Sales Return Journal",
        check_company=True,
        domain="[('company_id', '=', company_id), ('type', 'in', ('general', 'sale'))]",
        help="Journal for sales return and contra-revenue entries.",
    )
    cash_refund_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Cash Refund Journal",
        check_company=True,
        domain="[('company_id', '=', company_id), ('type', 'in', ('cash', 'general'))]",
        help="Journal for cash refund disbursements.",
    )
    bank_refund_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Bank Refund Journal",
        check_company=True,
        domain="[('company_id', '=', company_id), ('type', 'in', ('bank', 'general'))]",
        help="Journal for card / bank refund disbursements.",
    )
    adjustment_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Manual Adjustment Journal",
        check_company=True,
        domain="[('company_id', '=', company_id), ('type', '=', 'general')]",
        help="Journal for manual store credit adjustments.",
    )
    reversal_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Reversal Journal",
        check_company=True,
        domain="[('company_id', '=', company_id)]",
        help="Journal used for accounting reversals when different from source.",
    )

    # -------------------------------------------------------------------------
    # Account mapping
    # -------------------------------------------------------------------------

    liability_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Store Credit Liability Account",
        check_company=True,
        help="Balance-sheet liability for outstanding store credit.",
    )
    sales_returns_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Sales Return Account",
        check_company=True,
        help="Contra-revenue account when issuing store credit from returns.",
    )
    gift_voucher_liability_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Gift Voucher Liability Account",
        check_company=True,
        help="Reserved for future gift voucher liability postings.",
    )
    wallet_liability_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Customer Wallet Liability Account",
        check_company=True,
        help="Reserved for future customer wallet liability postings.",
    )
    loyalty_liability_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Loyalty Liability Account",
        check_company=True,
        help="Reserved for future loyalty credit liability postings.",
    )
    redemption_clearing_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Redemption Clearing Account",
        check_company=True,
        help="Bridge account when store credit is redeemed on a POS sale.",
    )
    refund_clearing_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Refund Clearing Account",
        check_company=True,
        help="Suspense/clearing for technical return-order payments.",
    )
    inventory_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Inventory Account",
        check_company=True,
        help="Override inventory account for return stock valuation traceability.",
    )
    cogs_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Cost of Goods Sold Account",
        check_company=True,
        help="Override COGS account for return stock valuation traceability.",
    )
    revenue_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Revenue Account",
        check_company=True,
        help="Override revenue account for manual return accounting entries.",
    )
    tax_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Tax Account Override",
        check_company=True,
        help="Optional override when fiscal position tax mapping is insufficient.",
    )
    adjustment_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Adjustment Account",
        check_company=True,
        help="Account for manual store credit balance adjustments.",
    )
    writeoff_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Write-off Account",
        check_company=True,
        help="Account for voucher write-offs and breakage not covered elsewhere.",
    )
    breakage_revenue_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Voucher Breakage Revenue",
        check_company=True,
        help="Income account for expired unredeemed store credit.",
    )
    expense_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Legacy Issuance Counterpart",
        check_company=True,
        help="Deprecated: use Sales Return Account. Kept for upgrades.",
    )
    cash_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Cash Account Override",
        check_company=True,
    )
    bank_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Bank Account Override",
        check_company=True,
    )

    # -------------------------------------------------------------------------
    # Fiscal position & posting behaviour
    # -------------------------------------------------------------------------

    fiscal_position_id = fields.Many2one(
        comodel_name="account.fiscal.position",
        string="Default Return Fiscal Position",
        check_company=True,
        help="Default fiscal position for return tax mapping when not inherited "
        "from the original sale.",
    )
    auto_post_entries = fields.Boolean(string="Auto-Post Entries", default=True)
    accounting_strict_mode = fields.Boolean(
        string="Strict Accounting Mode",
        default=False,
        help="Block posting when required accounts or journals are missing.",
    )
    post_on_issue = fields.Boolean(string="Post on Issue", default=True)
    post_on_redeem = fields.Boolean(string="Post on Redeem", default=True)
    post_on_cancel = fields.Boolean(string="Post on Cancel", default=True)
    post_on_expire = fields.Boolean(string="Post on Expire", default=True)
    reconcile_refund_clearing = fields.Boolean(
        string="Auto-Reconcile Refund Clearing",
        default=True,
    )
    invoiced_return_mode = fields.Selection(
        selection=[
            ("credit_note_only", "Credit Note Only"),
            ("credit_note_and_liability", "Credit Note and Liability"),
        ],
        string="Invoiced Return Mode",
        default="credit_note_and_liability",
    )
    uninvoiced_return_mode = fields.Selection(
        selection=[
            ("session_only", "POS Session Only"),
            ("session_and_liability", "Session and Liability"),
        ],
        string="Uninvoiced Return Mode",
        default="session_and_liability",
    )

    config_audit_ids = fields.One2many(
        comodel_name="store.credit.settings.audit",
        inverse_name="settings_id",
        string="Configuration Audit",
        readonly=True,
    )

    @api.constrains("company_id", "fiscal_position_id", *ACCOUNTING_ACCOUNT_FIELDS, *ACCOUNTING_JOURNAL_FIELDS)
    def _check_accounting_company_consistency(self):
        ConfigService = self.env["return.accounting.config.service"]
        for settings in self:
            if not settings.enable_accounting:
                continue
            company = settings.company_id
            if settings.fiscal_position_id and settings.fiscal_position_id.company_id != company:
                raise ValidationError(
                    self.env._(
                        "Fiscal position must belong to company %(company)s.",
                        company=company.display_name,
                    )
                )
            for field_name in ACCOUNTING_ACCOUNT_FIELDS:
                account = settings[field_name]
                if account:
                    ConfigService._validate_account_record(
                        account, company, field_name, raise_error=True
                    )
            for field_name in ACCOUNTING_JOURNAL_FIELDS:
                journal = settings[field_name]
                if journal:
                    ConfigService._validate_journal_record(
                        journal, company, field_name, raise_error=True
                    )

    def write(self, vals):
        tracked = {k for k in vals if k in ACCOUNTING_TRACKED_FIELDS}
        before = {}
        if tracked:
            for record in self:
                before[record.id] = {
                    field: record[field] for field in tracked if field in record._fields
                }
        bump_version = bool(
            tracked.intersection(ACCOUNTING_ACCOUNT_FIELDS + ACCOUNTING_JOURNAL_FIELDS)
        )
        result = super().write(vals)
        if tracked:
            for record in self:
                record._log_accounting_config_changes(before.get(record.id, {}), vals)
                if bump_version and record.enable_accounting:
                    record.accounting_config_version += 1
        return result

    def _log_accounting_config_changes(self, before_vals, new_vals):
        """Write audit rows for accounting configuration changes."""
        Audit = self.env["store.credit.settings.audit"]
        for field_name, new_value in new_vals.items():
            if field_name not in ACCOUNTING_TRACKED_FIELDS:
                continue
            old_value = before_vals.get(field_name)
            if old_value == new_value:
                continue
            change_type = "account_change"
            if field_name in ACCOUNTING_JOURNAL_FIELDS:
                change_type = "journal_change"
            elif field_name in (
                "manager_approval",
                "approval_amount",
                "cash_refund_limit",
            ):
                change_type = "approval_policy_change"
            elif field_name == "fiscal_position_id":
                change_type = "fiscal_position_change"
            else:
                change_type = "configuration_change"
            Audit.create(
                {
                    "settings_id": self.id,
                    "company_id": self.company_id.id,
                    "config_id": self.config_id.id or False,
                    "change_type": change_type,
                    "field_name": field_name,
                    "old_value": self._format_audit_value(field_name, old_value),
                    "new_value": self._format_audit_value(field_name, new_value),
                    "user_id": self.env.user.id,
                }
            )

    def _format_audit_value(self, field_name, value):
        if not value and value is not False:
            return ""
        field = self._fields.get(field_name)
        if field and field.type == "many2one" and value:
            if hasattr(value, "display_name"):
                return value.display_name
            return self.env[field.comodel_name].browse(value).display_name
        if field and field.type == "selection":
            return dict(field.selection).get(value, str(value))
        return str(value)
