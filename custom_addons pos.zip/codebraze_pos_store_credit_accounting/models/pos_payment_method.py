# -*- coding: utf-8 -*-
"""Sync store credit payment method accounts from accounting settings."""

from odoo import api, models


class PosPaymentMethodAccounting(models.Model):
    _inherit = "pos.payment.method"

    @api.model
    def _load_pos_data_fields(self, config):
        fields_list = super()._load_pos_data_fields(config)
        return fields_list + ["receivable_account_id"]
