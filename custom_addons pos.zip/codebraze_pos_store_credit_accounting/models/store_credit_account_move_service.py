# -*- coding: utf-8 -*-
"""Central accounting orchestration for store credit and POS returns."""

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_is_zero

_logger = logging.getLogger(__name__)


class StoreCreditAccountMoveService(models.AbstractModel):
    """Post and reconcile journal entries using standard Odoo account.move APIs."""

    _name = "store.credit.account.move.service"
    _description = "Store Credit Accounting Service"

    # -------------------------------------------------------------------------
    # Configuration
    # -------------------------------------------------------------------------

    @api.model
    def _resolve_accounting_settings(self, company=None, config=None):
        """Return enriched settings namespace including accounting fields."""
        return self.env["return.accounting.config.service"].get_resolved_config(
            company=company, config=config
        )

    @api.model
    def validate_accounting_configuration(self, company=None, config=None, strict=False):
        """Validate journals and accounts required for automated posting."""
        return self.env["return.accounting.config.service"].validate_for_posting(
            company=company,
            config=config,
            operation="store_credit",
            strict=strict,
        )

    def _sales_returns_account(self, settings):
        return getattr(settings, "sales_returns_account_id", False) or getattr(
            settings, "expense_account_id", False
        )

    def _redemption_clearing_account(self, settings):
        return getattr(settings, "redemption_clearing_account_id", False) or getattr(
            settings, "expense_account_id", False
        )

    def _breakage_account(self, settings):
        return (
            getattr(settings, "breakage_revenue_account_id", False)
            or getattr(settings, "writeoff_account_id", False)
            or self._sales_returns_account(settings)
        )

    def _refund_clearing_account(self, settings):
        return getattr(settings, "refund_clearing_account_id", False)

    # -------------------------------------------------------------------------
    # Store credit transaction posting
    # -------------------------------------------------------------------------

    @api.model
    def post_credit_transaction(self, txn):
        """Create and post account.move for a store.credit.transaction."""
        txn.ensure_one()
        if txn.is_accounted or txn.move_id:
            return txn.move_id
        if txn.state != "posted":
            return self.env["account.move"]

        settings = txn.credit_id._get_accounting_settings()
        ConfigService = self.env["return.accounting.config.service"]
        operation = txn.txn_type if txn.txn_type in ("issue", "redeem", "cancel", "expire", "adjustment") else "store_credit"
        try:
            ConfigService.validate_for_posting(
                company=txn.company_id,
                config=txn.config_id,
                operation=operation,
                strict=getattr(settings, "accounting_strict_mode", False),
                currency=txn.currency_id,
            )
        except ValidationError:
            if getattr(settings, "accounting_strict_mode", False):
                raise
            txn.accounting_state = "skipped"
            return self.env["account.move"]

        if not getattr(settings, "enable_accounting", True):
            txn.accounting_state = "skipped"
            return self.env["account.move"]
        if not getattr(settings, "auto_post_entries", True):
            txn.accounting_state = "skipped"
            return self.env["account.move"]

        post_flags = {
            "issue": getattr(settings, "post_on_issue", True),
            "redeem": getattr(settings, "post_on_redeem", True),
            "cancel": getattr(settings, "post_on_cancel", True),
            "expire": getattr(settings, "post_on_expire", True),
            "adjustment": True,
        }
        if not post_flags.get(txn.txn_type, False):
            txn.accounting_state = "skipped"
            return self.env["account.move"]

        if txn.txn_type == "issue":
            ret = self._find_return_for_credit(txn.credit_id)
            if ret and not self._should_post_liability_on_return(
                ret, settings
            ):
                txn.accounting_state = "skipped"
                return self.env["account.move"]

        debit_acc, credit_acc, label = self._get_accounts_for_txn(txn, settings)
        if not debit_acc or not credit_acc:
            txn.accounting_state = "skipped"
            return self.env["account.move"]
        if float_is_zero(txn.amount, precision_rounding=txn.currency_id.rounding):
            txn.accounting_state = "skipped"
            return self.env["account.move"]

        move = self._create_balanced_move(
            company=txn.company_id,
            journal=self.env["return.accounting.config.service"].resolve_journal(
                settings,
                operation="adjustment" if txn.txn_type == "adjustment" else "store_credit",
            ),
            date=txn.date,
            currency=txn.currency_id,
            amount=txn.amount,
            debit_account=debit_acc,
            credit_account=credit_acc,
            label=f"{label} - {txn.credit_id.name}",
            partner=txn.partner_id,
            ref=f"{txn.credit_id.name} / {txn.name}",
            link_vals=self._credit_txn_move_links(txn),
        )
        txn.write(
            {
                "move_id": move.id,
                "is_accounted": True,
                "accounting_state": "posted",
            }
        )
        self._sync_voucher_accounting_state(txn.credit_id)
        self._log_accounting_audit(
            txn.credit_id,
            action=self._audit_action_for_txn(txn),
            message=_("Posted accounting move %(move)s for %(txn)s", move=move.name, txn=txn.name),
            amount=txn.amount,
            move=move,
            txn=txn,
        )
        return move

    def _get_accounts_for_txn(self, txn, settings):
        liability = settings.liability_account_id
        sales_returns = self._sales_returns_account(settings)
        redeem_clearing = self._redemption_clearing_account(settings)
        breakage = self._breakage_account(settings)

        if txn.txn_type == "issue":
            return sales_returns, liability, _("Store credit issued")
        if txn.txn_type == "redeem":
            return liability, redeem_clearing, _("Store credit redeemed")
        if txn.txn_type == "cancel":
            return liability, sales_returns, _("Store credit cancelled")
        if txn.txn_type == "expire":
            return liability, breakage, _("Store credit expired")
        if txn.txn_type == "adjustment":
            adj_account = (
                getattr(settings, "adjustment_account_id", False)
                or sales_returns
            )
            if txn.signed_amount >= 0:
                return adj_account, liability, _("Store credit adjustment (+)")
            return liability, adj_account, _("Store credit adjustment (-)")
        return False, False, False

    def _credit_txn_move_links(self, txn):
        voucher = self.env["pos.return.voucher"].search(
            [("credit_id", "=", txn.credit_id.id)], limit=1
        )
        vals = {
            "store_credit_id": txn.credit_id.id,
            "store_credit_transaction_id": txn.id,
            "pos_order_id": txn.pos_order_id.id or False,
            "pos_session_id": txn.session_id.id or False,
        }
        if voucher:
            vals["return_voucher_id"] = voucher.id
        ret = self._find_return_for_credit(txn.credit_id)
        if ret:
            vals["pos_return_transaction_id"] = ret.id
        return vals

    @api.model
    def reverse_credit_transaction(self, txn, reason=None):
        """Reverse a posted credit transaction using account.move.reversal."""
        txn.ensure_one()
        if not txn.move_id or txn.move_id.state != "posted":
            raise UserError(_("No posted move to reverse for this transaction."))
        reversal = self.env["account.move.reversal"].with_context(
            active_model="account.move",
            active_ids=txn.move_id.ids,
        ).create(
            {
                "journal_id": (
                    self.env["return.accounting.config.service"].resolve_journal(
                        txn.credit_id._get_accounting_settings(),
                        operation="reversal",
                        fallback=txn.move_id.journal_id,
                    ).id
                ),
                "reason": reason or _("Store credit transaction reversal"),
            }
        )
        action = reversal.reverse_moves()
        reverse_move = self.env["account.move"].browse(action.get("res_id"))
        if reverse_move:
            txn.accounting_state = "reversed"
            self._log_accounting_audit(
                txn.credit_id,
                action="accounting_reverse",
                message=_("Reversed move %(move)s", move=txn.move_id.name),
                amount=txn.amount,
                move=reverse_move,
                txn=txn,
            )
        return reverse_move

    # -------------------------------------------------------------------------
    # Return / settlement accounting
    # -------------------------------------------------------------------------

    @api.model
    def accounting_on_return_confirmed(self, return_txn):
        """Generate credit note for invoiced returns; validate configuration."""
        return_txn.ensure_one()
        settings = self._resolve_accounting_settings(
            company=return_txn.company_id, config=return_txn.config_id
        )
        if not getattr(settings, "enable_accounting", True):
            return_txn.write({"accounting_state": "skipped"})
            return True

        self.validate_accounting_configuration(
            company=return_txn.company_id,
            config=return_txn.config_id,
            strict=getattr(settings, "accounting_strict_mode", False),
        )

        refund_order = return_txn.return_order_id
        original = return_txn.original_order_id
        if original and original.account_move and refund_order:
            self._generate_return_credit_note(return_txn, refund_order, original)

        return_txn.write({"accounting_state": "pending_settlement"})
        return True

    @api.model
    def accounting_on_settlement(self, return_txn):
        """Post settlement-specific accounting (clearing reconciliation)."""
        return_txn.ensure_one()
        settings = self._resolve_accounting_settings(
            company=return_txn.company_id, config=return_txn.config_id
        )
        if not getattr(settings, "enable_accounting", True):
            return True

        method = return_txn.settlement_method or return_txn.refund_method
        if method == "cash":
            self._accounting_cash_settlement(return_txn, settings)
        elif method == "voucher":
            self._accounting_voucher_settlement(return_txn, settings)
        elif method == "original_payment":
            self._accounting_original_payment_settlement(return_txn, settings)

        if getattr(settings, "reconcile_refund_clearing", True):
            method = return_txn.settlement_method or return_txn.refund_method
            if method == "voucher":
                self._reconcile_refund_clearing(return_txn, settings)

        if return_txn.accounting_state != "reconciled":
            return_txn.write({"accounting_state": "posted"})
        return True

    def _generate_return_credit_note(self, return_txn, refund_order, original):
        """Use standard Odoo POS credit note generation for invoiced returns."""
        if refund_order.account_move:
            return refund_order.account_move
        if not original.account_move:
            return self.env["account.move"]

        refund_order = refund_order.with_context(
            codebraze_return_transaction_id=return_txn.id,
        )
        move = refund_order._generate_pos_order_invoice()
        if move:
            move.write(
                {
                    "pos_return_transaction_id": return_txn.id,
                    "pos_order_id": refund_order.id,
                }
            )
            return_txn.write({"refund_move_id": move.id})
            self._log_return_accounting_audit(
                return_txn,
                "accounting_post",
                _("Credit note %(name)s created for return %(ret)s", name=move.name, ret=return_txn.name),
                move=move,
            )
        return move

    def _accounting_cash_settlement(self, return_txn, settings):
        """Cash refund: defer clearing reconciliation until session close."""
        payment = return_txn.settlement_payment_id
        if payment:
            payment.write({"pos_return_transaction_id": return_txn.id})
            self._log_return_accounting_audit(
                return_txn,
                "payment_created",
                _("Cash settlement payment %(id)s recorded", id=payment.id),
                payment=payment,
            )
        return True

    def _accounting_voucher_settlement(self, return_txn, settings):
        """Voucher: liability is posted when store credit is issued (ledger txn)."""
        if not self._should_post_liability_on_return(return_txn, settings):
            return_txn.write({"accounting_state": "posted"})
            self._log_return_accounting_audit(
                return_txn,
                "accounting_post",
                _("Liability posting skipped per return accounting mode."),
            )
            return True
        credit = return_txn.credit_id
        if not credit and return_txn.voucher_id:
            credit = return_txn.voucher_id.credit_id
        if credit:
            issue_txns = credit.transaction_ids.filtered(
                lambda t: t.txn_type == "issue" and t.state == "posted"
            )
            for txn in issue_txns.filtered(lambda t: not t.is_accounted):
                self.post_credit_transaction(txn)
        self._log_return_accounting_audit(
            return_txn,
            "liability_created",
            _("Store credit liability recorded for voucher settlement"),
            credit=credit,
        )
        return True

    def _accounting_original_payment_settlement(self, return_txn, settings):
        """Original payment refund — defer reconciliation until session close."""
        payment = return_txn.settlement_payment_id
        if payment and not payment.pos_return_transaction_id:
            payment.write({"pos_return_transaction_id": return_txn.id})
        self._log_return_accounting_audit(
            return_txn,
            "payment_created",
            _("Original payment method settlement linked"),
            payment=payment,
        )
        return True

    def _reconcile_refund_clearing(self, return_txn, settings):
        """Reconcile refund clearing with sales-returns or liability lines."""
        clearing_account = self._refund_clearing_account(settings)
        sales_returns = self._sales_returns_account(settings)
        if not clearing_account:
            return False

        clearing_lines = self.env["account.move.line"]
        refund_order = return_txn.return_order_id
        if refund_order and refund_order.session_id and refund_order.session_id.move_id:
            clearing_lines = refund_order.session_id.move_id.line_ids.filtered(
                lambda l: l.account_id == clearing_account
                and not l.reconciled
                and (
                    not return_txn.partner_id
                    or not l.partner_id
                    or l.partner_id == return_txn.partner_id
                )
            )

        counterpart_lines = self.env["account.move.line"]
        if return_txn.credit_id and sales_returns:
            issue_moves = return_txn.credit_id.transaction_ids.filtered(
                lambda t: t.txn_type == "issue" and t.move_id
            ).mapped("move_id")
            counterpart_lines = issue_moves.line_ids.filtered(
                lambda l: l.account_id == sales_returns and not l.reconciled
            )
        elif settings.liability_account_id and return_txn.credit_id:
            issue_moves = return_txn.credit_id.transaction_ids.mapped("move_id").filtered(
                lambda m: m.state == "posted"
            )
            counterpart_lines = issue_moves.line_ids.filtered(
                lambda l: l.account_id == settings.liability_account_id and not l.reconciled
            )

        lines_to_reconcile = clearing_lines + counterpart_lines
        return self._safe_reconcile(
            lines_to_reconcile,
            return_txn,
            _("Refund clearing reconciliation"),
        )

    def _reconcile_cash_refund_clearing(self, return_txn, settings, payment):
        """Reconcile session refund clearing with cash settlement payment."""
        clearing_account = self._refund_clearing_account(settings)
        if not clearing_account:
            return False
        refund_order = return_txn.return_order_id
        if not refund_order or not refund_order.session_id or not refund_order.session_id.move_id:
            return False

        clearing_lines = refund_order.session_id.move_id.line_ids.filtered(
            lambda l: l.account_id == clearing_account and not l.reconciled
        )
        cash_lines = self.env["account.move.line"]
        if payment and hasattr(payment, "account_move_id") and payment.account_move_id:
            cash_lines = payment.account_move_id.line_ids.filtered(
                lambda l: not l.reconciled and l.credit > 0
            )
        return self._safe_reconcile(
            clearing_lines + cash_lines,
            return_txn,
            _("Cash refund clearing reconciliation"),
        )

    def _safe_reconcile(self, lines, return_txn, label):
        lines = lines.filtered(lambda l: not l.reconciled)
        if len(lines) < 2:
            return False
        try:
            lines.reconcile()
            self._log_return_accounting_audit(
                return_txn,
                "accounting_post",
                label,
            )
            return True
        except Exception as err:  # noqa: BLE001
            _logger.warning(
                "Reconciliation failed for %s (%s): %s",
                return_txn.name,
                label,
                err,
            )
            self._log_return_accounting_audit(
                return_txn,
                "accounting_error",
                str(err),
            )
            return False

    # -------------------------------------------------------------------------
    # Redemption & session reconciliation
    # -------------------------------------------------------------------------

    @api.model
    def accounting_on_redemption(self, pos_order):
        """Attempt to reconcile redemption clearing after store credit payment."""
        pos_order.ensure_one()
        settings = self._resolve_accounting_settings(
            company=pos_order.company_id, config=pos_order.config_id
        )
        if not getattr(settings, "enable_accounting", True):
            return False
        clearing = self._redemption_clearing_account(settings)
        if not clearing:
            return False

        redeem_txns = self.env["store.credit.transaction"].search(
            [
                ("pos_order_id", "=", pos_order.id),
                ("txn_type", "=", "redeem"),
                ("state", "=", "posted"),
            ]
        )
        if not redeem_txns:
            return False

        clearing_lines = redeem_txns.mapped("move_id").line_ids.filtered(
            lambda l: l.account_id == clearing and not l.reconciled and l.credit > 0
        )
        session = pos_order.session_id
        if not session or not session.move_id:
            return False

        partner = pos_order.partner_id
        receivable = partner.property_account_receivable_id if partner else False
        if not receivable:
            return False

        recv_lines = session.move_id.line_ids.filtered(
            lambda l: l.account_id == receivable
            and not l.reconciled
            and l.debit > 0
            and (not partner or l.partner_id == partner)
        )
        return self._safe_reconcile_lines(
            clearing_lines,
            recv_lines,
            pos_order=pos_order,
        )

    @api.model
    def accounting_on_session_closed(self, session):
        """Reconcile store credit redemption clearing for all orders in session."""
        settings = self._resolve_accounting_settings(
            company=session.company_id, config=session.config_id
        )
        if not getattr(settings, "enable_accounting", True):
            return False

        orders = session.order_ids.filtered(
            lambda o: o.state in ("paid", "done", "invoiced")
            and o.payment_ids.filtered(lambda p: p.payment_method_id.is_store_credit)
        )
        for order in orders:
            try:
                self.accounting_on_redemption(order)
            except Exception as err:  # noqa: BLE001
                _logger.warning(
                    "Session redemption reconciliation failed for %s: %s",
                    order.name,
                    err,
                )
        return True

    def _safe_reconcile_lines(self, debit_candidates, credit_candidates, pos_order=None):
        """Match clearing credits against receivable debits by amount."""
        reconciled = False
        for cl in credit_candidates.filtered(lambda l: not l.reconciled):
            match = debit_candidates.filtered(
                lambda l: not l.reconciled
                and float_is_zero(
                    l.debit - cl.credit,
                    precision_rounding=l.company_currency_id.rounding,
                )
            )[:1]
            if match:
                try:
                    (cl + match).reconcile()
                    reconciled = True
                except Exception as err:  # noqa: BLE001
                    _logger.warning("Redemption reconcile failed: %s", err)
        if reconciled and pos_order:
            credit = pos_order.payment_ids.filtered(
                lambda p: p.payment_method_id.is_store_credit
            ).mapped("store_credit_payment_ids.credit_id")[:1]
            if credit:
                self._log_accounting_audit(
                    credit,
                    action="liability_reduced",
                    message=_(
                        "Redemption clearing reconciled for order %(order)s",
                        order=pos_order.name,
                    ),
                    amount=sum(
                        pos_order.payment_ids.filtered(
                            lambda p: p.payment_method_id.is_store_credit
                        ).mapped("amount")
                    ),
                    pos_order=pos_order,
                )
        return reconciled

    def _should_post_liability_on_return(self, return_txn, settings):
        original = return_txn.original_order_id
        if original and original.account_move:
            return getattr(settings, "invoiced_return_mode", "credit_note_and_liability") != (
                "credit_note_only"
            )
        return getattr(settings, "uninvoiced_return_mode", "session_and_liability") != (
            "session_only"
        )

    # -------------------------------------------------------------------------
    # Move builders
    # -------------------------------------------------------------------------

    @api.model
    def _create_balanced_move(
        self,
        company,
        journal,
        date,
        currency,
        amount,
        debit_account,
        credit_account,
        label,
        partner=False,
        ref=False,
        link_vals=None,
    ):
        if not journal:
            raise UserError(_("Accounting journal is not configured."))
        move_date = date
        if move_date and hasattr(move_date, "date"):
            move_date = move_date.date()
        move_date = move_date or fields.Date.context_today(self)

        company_currency = company.currency_id
        if currency != company_currency:
            debit_balance = currency._convert(
                amount, company_currency, company, move_date
            )
            credit_balance = debit_balance
            amount_currency = amount
        else:
            debit_balance = amount
            credit_balance = amount
            amount_currency = 0.0

        line_base = {
            "name": label,
            "partner_id": partner.id if partner else False,
            "currency_id": currency.id if currency != company_currency else False,
        }
        if currency != company_currency:
            line_base["amount_currency"] = amount_currency

        move_vals = {
            "ref": ref or label,
            "journal_id": journal.id,
            "company_id": company.id,
            "date": move_date,
            "move_type": "entry",
            "line_ids": [
                (
                    0,
                    0,
                    {
                        **line_base,
                        "account_id": debit_account.id,
                        "debit": debit_balance,
                        "credit": 0.0,
                    },
                ),
                (
                    0,
                    0,
                    {
                        **line_base,
                        "account_id": credit_account.id,
                        "debit": 0.0,
                        "credit": credit_balance,
                    },
                ),
            ],
        }
        if link_vals:
            move_vals.update(link_vals)

        move = self.env["account.move"].create(move_vals)
        try:
            move.action_post()
        except Exception as err:
            move.unlink()
            raise UserError(
                _("Failed to post accounting entry: %(error)s", error=str(err))
            ) from err
        return move

    # -------------------------------------------------------------------------
    # Helpers & audit
    # -------------------------------------------------------------------------

    @api.model
    def _find_return_for_credit(self, credit):
        return self.env["pos.return.transaction"].search(
            [("credit_id", "=", credit.id)], limit=1
        )

    def _sync_voucher_accounting_state(self, credit):
        voucher = self.env["pos.return.voucher"].search(
            [("credit_id", "=", credit.id)], limit=1
        )
        if voucher and hasattr(voucher, "_sync_accounting_state"):
            voucher._sync_accounting_state()

    def _audit_action_for_txn(self, txn):
        mapping = {
            "issue": "liability_created",
            "redeem": "liability_reduced",
            "cancel": "liability_reduced",
            "expire": "liability_reduced",
            "adjustment": "accounting_post",
        }
        return mapping.get(txn.txn_type, "accounting_post")

    @api.model
    def _log_accounting_audit(self, credit, action, message, amount=0.0, move=None, txn=None):
        if not credit:
            return
        extra = {}
        if move:
            extra["after_data"] = f'{{"move_id": {move.id}, "move_name": "{move.name}"}}'
        credit._log_audit(
            action=action,
            message=message,
            amount=amount,
            pos_order=move.pos_order_id if move and hasattr(move, "pos_order_id") else None,
            extra=extra,
        )

    @api.model
    def _log_return_accounting_audit(
        self, return_txn, event_type, message, move=None, payment=None, credit=None
    ):
        payload = {"return_id": return_txn.id, "message": message}
        if move:
            payload["move_id"] = move.id
        if payment:
            payload["payment_id"] = payment.id
        if credit:
            payload["credit_id"] = credit.id
        self.env["pos.return.audit"]._log_pos_event(
            event_type if event_type in dict(
                self.env["pos.return.audit"]._fields["event_type"].selection
            ) else "settlement_confirmed",
            message=message,
            success=event_type != "accounting_error",
            config=return_txn.config_id,
            session=return_txn.session_id,
            order=return_txn.original_order_id,
            payload=payload,
        )
