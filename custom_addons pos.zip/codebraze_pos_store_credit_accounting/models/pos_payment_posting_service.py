# -*- coding: utf-8 -*-
"""POS payment posting, validation, and accounting reconciliation."""

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare, float_is_zero

_logger = logging.getLogger(__name__)


class PosPaymentPostingService(models.AbstractModel):
    """Orchestrate POS payment posting and reconciliation with standard Odoo APIs."""

    _name = "pos.payment.posting.service"
    _description = "POS Payment Posting Service"

    # -------------------------------------------------------------------------
    # Validation
    # -------------------------------------------------------------------------

    @api.model
    def validate_payment_posting(self, payment):
        """Validate a single payment before accounting processing."""
        payment.ensure_one()
        errors = []
        order = payment.pos_order_id
        if not payment.payment_method_id:
            errors.append(_("Payment method is required."))
        if float_is_zero(payment.amount, precision_rounding=order.currency_id.rounding):
            errors.append(_("Payment amount cannot be zero."))
        if payment.payment_method_id.is_store_credit and not payment.store_credit_redemption_data:
            errors.append(_("Store credit payment is missing redemption data."))
        if payment.accounting_state == "posted" and payment.is_accounting_reconciled:
            errors.append(_("Payment is already posted and reconciled."))
        if errors:
            raise ValidationError("\n".join(errors))
        return True

    @api.model
    def validate_order_payments(self, order):
        """Ensure payment lines sum to the order total (supports split tender)."""
        order.ensure_one()
        if order.state in ("draft", "cancel"):
            return True
        if self.env["pos.return.transaction"].search_count(
            [("return_order_id", "=", order.id)]
        ):
            return True
        payments = order.payment_ids.filtered(
            lambda p: not float_is_zero(
                p.amount, precision_rounding=order.currency_id.rounding
            )
        )
        paid = sum(payments.mapped("amount"))
        rounding = order.currency_id.rounding
        if float_compare(paid, order.amount_total, precision_rounding=rounding) != 0:
            raise ValidationError(
                _(
                    "Payment total %(paid)s does not match order total %(total)s on %(order)s.",
                    paid=paid,
                    total=order.amount_total,
                    order=order.name,
                )
            )
        return True

    # -------------------------------------------------------------------------
    # Payment lifecycle hooks
    # -------------------------------------------------------------------------

    @api.model
    def accounting_on_payment_created(self, payments):
        """Audit and prepare payments for deferred session reconciliation."""
        AccountMoveService = self.env["store.credit.account.move.service"]
        for payment in payments:
            try:
                self.validate_payment_posting(payment)
            except ValidationError as err:
                payment.accounting_state = "error"
                _logger.warning("Payment validation failed for %s: %s", payment.id, err)
                continue

            if payment.payment_method_id.is_store_credit:
                payment.accounting_state = "pending_reconcile"
                self._log_payment_audit(
                    payment,
                    "store_credit_applied",
                    _("Store credit payment recorded on order %(order)s", order=payment.pos_order_id.name),
                )
                continue

            if payment.pos_order_id.account_move:
                payment.accounting_state = "posted"
                self._log_payment_audit(
                    payment,
                    "payment_posted",
                    _("Invoiced payment move linked"),
                )
            else:
                payment.accounting_state = "pending_reconcile"
                self._log_payment_audit(
                    payment,
                    "payment_created",
                    _("Payment pending session reconciliation"),
                )

            if payment.pos_return_transaction_id:
                AccountMoveService._log_return_accounting_audit(
                    payment.pos_return_transaction_id,
                    "payment_created",
                    _("Settlement payment %(id)s created", id=payment.id),
                    payment=payment,
                )
        return True

    @api.model
    def accounting_on_order_paid(self, order):
        """Validate split/partial payments after order is saved."""
        order.ensure_one()
        if order.state == "cancel":
            return False
        settings = self._resolve_settings(order.company_id, order.config_id)
        if not getattr(settings, "enable_accounting", True):
            return False
        try:
            self.validate_order_payments(order)
        except ValidationError as err:
            _logger.warning("Order payment validation failed for %s: %s", order.name, err)
            raise
        self._ensure_store_credit_payment_method_accounts(order.config_id, settings)
        sc_payments = order.payment_ids.filtered(
            lambda p: p.payment_method_id.is_store_credit
        )
        if sc_payments:
            self._log_payment_audit(
                sc_payments[0],
                "store_credit_applied",
                _(
                    "Store credit applied: %(amount)s across %(count)s payment line(s)",
                    amount=sum(sc_payments.mapped("amount")),
                    count=len(sc_payments),
                ),
            )
        return True

    @api.model
    def accounting_on_session_closed(self, session):
        """Reconcile all POS payments after session accounting move exists."""
        settings = self._resolve_settings(session.company_id, session.config_id)
        if not getattr(settings, "enable_accounting", True):
            return False
        if not session.move_id:
            return False

        self._ensure_store_credit_payment_method_accounts(session.config_id, settings)

        AccountMoveService = self.env["store.credit.account.move.service"]
        AccountMoveService.accounting_on_session_closed(session)

        self._reconcile_session_return_settlements(session, settings)
        self._reconcile_session_store_credit_orders(session, settings)
        self._reconcile_session_invoiced_payments(session, settings)
        return True

    # -------------------------------------------------------------------------
    # Session reconciliation — returns
    # -------------------------------------------------------------------------

    def _reconcile_session_return_settlements(self, session, settings):
        """Reconcile refund clearing with cash, bank, or liability for settled returns."""
        ReturnTxn = self.env["pos.return.transaction"]
        returns = ReturnTxn.search(
            [
                ("session_id", "=", session.id),
                ("settlement_state", "=", "settled"),
                ("return_order_id", "!=", False),
            ]
        )
        for ret in returns:
            if ret.accounting_state == "reconciled":
                continue
            method = ret.settlement_method or ret.refund_method
            try:
                if method == "cash":
                    self._reconcile_return_cash_settlement(session, ret, settings)
                elif method == "voucher":
                    self._reconcile_return_voucher_settlement(session, ret, settings)
                elif method == "original_payment":
                    self._reconcile_return_original_payment(session, ret, settings)
            except Exception as err:  # noqa: BLE001
                _logger.warning(
                    "Return settlement reconciliation failed for %s: %s",
                    ret.name,
                    err,
                )
                ret.write({"accounting_state": "error"})
        return True

    def _reconcile_return_cash_settlement(self, session, return_txn, settings):
        """Dr Refund Clearing / Cr Cash — match session lines after close."""
        clearing_account = self._refund_clearing_account(settings)
        if not clearing_account:
            return False

        clearing_lines = self._session_lines_for_account(
            session, clearing_account, return_txn.partner_id
        )
        cash_lines = self._session_cash_outflow_lines(
            session, return_txn, settings
        )
        bank_lines = self._session_bank_outflow_lines(
            session, return_txn, settings
        )
        payment_lines = cash_lines + bank_lines
        if not payment_lines and return_txn.settlement_payment_id:
            payment_lines = self._payment_move_lines(return_txn.settlement_payment_id)

        reconciled = self._reconcile_line_sets(
            clearing_lines,
            payment_lines,
            return_txn.amount_total,
        )
        if reconciled:
            self._mark_return_settlement_reconciled(return_txn, _("Cash refund reconciliation"))
            if return_txn.settlement_payment_id:
                return_txn.settlement_payment_id.write(
                    {"is_accounting_reconciled": True, "accounting_state": "reconciled"}
                )
        return reconciled

    def _reconcile_return_voucher_settlement(self, session, return_txn, settings):
        """Clear refund clearing against sales-returns / liability from voucher issue."""
        AccountMoveService = self.env["store.credit.account.move.service"]
        result = AccountMoveService._reconcile_refund_clearing(return_txn, settings)
        if result:
            self._mark_return_settlement_reconciled(
                return_txn, _("Voucher refund clearing reconciliation")
            )
        return result

    def _reconcile_return_original_payment(self, session, return_txn, settings):
        """Reconcile clearing with bank/card lines from original payment method."""
        clearing_account = self._refund_clearing_account(settings)
        if not clearing_account:
            return False

        clearing_lines = self._session_lines_for_account(
            session, clearing_account, return_txn.partner_id
        )
        bank_lines = self.env["account.move.line"]
        payment = return_txn.settlement_payment_id
        if payment:
            bank_lines = self._session_lines_for_payment_method(
                session, payment.payment_method_id, return_txn.partner_id
            )
            if not bank_lines:
                bank_lines = self._payment_move_lines(payment)

        reconciled = self._reconcile_line_sets(
            clearing_lines,
            bank_lines,
            return_txn.amount_total,
        )
        if reconciled:
            self._mark_return_settlement_reconciled(
                return_txn, _("Original payment method reconciliation")
            )
            if payment:
                payment.write(
                    {"is_accounting_reconciled": True, "accounting_state": "reconciled"}
                )
        return reconciled

    # -------------------------------------------------------------------------
    # Session reconciliation — store credit / split payments
    # -------------------------------------------------------------------------

    def _reconcile_session_store_credit_orders(self, session, settings):
        """Reconcile redemption clearing with session receivable per order."""
        clearing = self._redemption_clearing_account(settings)
        if not clearing:
            return False

        orders = session.order_ids.filtered(
            lambda o: o.state in ("paid", "done", "invoiced")
            and o.payment_ids.filtered(lambda p: p.payment_method_id.is_store_credit)
        )
        for order in orders:
            if order.payment_ids.filtered(
                lambda p: p.is_accounting_reconciled and p.payment_method_id.is_store_credit
            ):
                continue
            self._reconcile_order_store_credit(session, order, settings)
        return True

    def _reconcile_order_store_credit(self, session, order, settings):
        """Reconcile multiple voucher redemptions + partial cash/card on one order."""
        clearing = self._redemption_clearing_account(settings)
        sc_payments = order.payment_ids.filtered(
            lambda p: p.payment_method_id.is_store_credit
        )
        if not sc_payments:
            return False

        redeem_txns = self.env["store.credit.transaction"].search(
            [
                ("pos_order_id", "=", order.id),
                ("txn_type", "=", "redeem"),
                ("state", "=", "posted"),
            ]
        )
        clearing_credit_lines = redeem_txns.mapped("move_id").line_ids.filtered(
            lambda l: l.account_id == clearing
            and not l.reconciled
            and l.credit > 0
        )
        if not clearing_credit_lines:
            return False

        sc_amount = sum(sc_payments.mapped("amount"))
        recv_lines = self._session_receivable_lines_for_store_credit(
            session, order, settings, sc_amount
        )
        reconciled = self._reconcile_line_sets(
            recv_lines,
            clearing_credit_lines,
            sc_amount,
        )
        if reconciled:
            sc_payments.write(
                {"is_accounting_reconciled": True, "accounting_state": "reconciled"}
            )
            self._log_payment_audit(
                sc_payments[0],
                "reconciliation_completed",
                _(
                    "Store credit redemption reconciled for order %(order)s (%(count)s voucher(s))",
                    order=order.name,
                    count=len(redeem_txns.mapped("credit_id")),
                ),
            )
        return reconciled

    def _reconcile_session_invoiced_payments(self, session, settings):
        """Mark invoiced order payments whose moves are posted."""
        for order in session.order_ids.filtered(lambda o: o.account_move):
            for payment in order.payment_ids.filtered(
                lambda p: p.account_move_id and p.account_move_id.state == "posted"
            ):
                if payment.is_accounting_reconciled:
                    continue
                payment.write({"accounting_state": "posted"})
                if payment.account_move_id.line_ids.filtered("reconciled"):
                    payment.write(
                        {
                            "is_accounting_reconciled": True,
                            "accounting_state": "reconciled",
                        }
                    )
                    self._log_payment_audit(
                        payment,
                        "reconciliation_completed",
                        _("Invoiced payment reconciled with invoice"),
                    )
        return True

    # -------------------------------------------------------------------------
    # Reversal
    # -------------------------------------------------------------------------

    @api.model
    def reverse_payment_accounting(self, payment, reason=None):
        """Reverse accounting for a cancelled POS payment."""
        payment.ensure_one()
        if payment.is_accounting_reconciled:
            lines = payment.account_move_id.line_ids.filtered("reconciled")
            if lines:
                lines.remove_move_reconcile()
        move = payment.account_move_id
        if move and move.state == "posted":
            reversal = self.env["account.move.reversal"].with_context(
                active_model="account.move",
                active_ids=move.ids,
            ).create(
                {
                    "journal_id": move.journal_id.id,
                    "reason": reason or _("POS payment reversal"),
                }
            )
            reversal.reverse_moves()
        payment.write(
            {
                "accounting_state": "reversed",
                "is_accounting_reconciled": False,
            }
        )
        self._log_payment_audit(
            payment,
            "payment_reversed",
            reason or _("Payment accounting reversed"),
        )
        return True

    @api.model
    def reverse_order_payments_accounting(self, order, reason=None):
        """Reverse all posted payment accounting on a cancelled order."""
        for payment in order.payment_ids:
            if payment.accounting_state in ("posted", "reconciled"):
                self.reverse_payment_accounting(payment, reason=reason)
        return True

    # -------------------------------------------------------------------------
    # Line resolution helpers
    # -------------------------------------------------------------------------

    def _session_lines_for_account(self, session, account, partner=False):
        lines = self.env["account.move.line"]
        moves = session.move_id
        if moves:
            lines = moves.line_ids.filtered(
                lambda l: l.account_id == account
                and not l.reconciled
                and (not partner or not l.partner_id or l.partner_id == partner)
            )
        return lines

    def _session_lines_for_payment_method(self, session, payment_method, partner=False):
        receivable = session._get_receivable_account(payment_method)
        return self._session_lines_for_account(session, receivable, partner)

    def _session_receivable_lines_for_store_credit(self, session, order, settings, amount):
        """Match session receivable debits for store credit PM or POS default."""
        sc_pm = order.payment_ids.filtered(
            lambda p: p.payment_method_id.is_store_credit
        )[:1].payment_method_id
        accounts = []
        if sc_pm:
            accounts.append(session._get_receivable_account(sc_pm))
        clearing = self._redemption_clearing_account(settings)
        if clearing:
            accounts.append(clearing)
        pos_recv = order.company_id.account_default_pos_receivable_account_id
        if pos_recv:
            accounts.append(pos_recv)

        lines = self.env["account.move.line"]
        for account in accounts:
            candidates = session.move_id.line_ids.filtered(
                lambda l, acc=account: l.account_id == acc
                and not l.reconciled
                and l.debit > 0
                and (
                    not order.partner_id
                    or not l.partner_id
                    or l.partner_id == order.partner_id
                )
            )
            lines |= candidates
        return lines

    def _session_cash_outflow_lines(self, session, return_txn, settings):
        cash_account = getattr(settings, "cash_account_id", False)
        lines = self.env["account.move.line"]
        for stmt_line in session.statement_line_ids:
            move = stmt_line.move_id
            if not move:
                continue
            for line in move.line_ids.filtered(lambda l: not l.reconciled and l.credit > 0):
                if cash_account and line.account_id != cash_account:
                    continue
                lines |= line
        if session.move_id:
            cash_methods = session.config_id.payment_method_ids.filtered("is_cash_count")
            for pm in cash_methods:
                recv = session._get_receivable_account(pm)
                lines |= session.move_id.line_ids.filtered(
                    lambda l, r=recv: l.account_id == r
                    and not l.reconciled
                    and l.credit > 0
                )
        return lines

    def _session_bank_outflow_lines(self, session, return_txn, settings):
        bank_account = getattr(settings, "bank_account_id", False)
        lines = self.env["account.move.line"]
        for bank_payment in session.bank_payment_ids:
            move = bank_payment.move_id
            if not move:
                continue
            for line in move.line_ids.filtered(lambda l: not l.reconciled):
                if bank_account and line.account_id != bank_account:
                    continue
                if line.credit > 0:
                    lines |= line
        return lines

    def _payment_move_lines(self, payment):
        if not payment or not payment.account_move_id:
            return self.env["account.move.line"]
        return payment.account_move_id.line_ids.filtered(
            lambda l: not l.reconciled and (l.credit > 0 or l.debit > 0)
        )

    def _reconcile_line_sets(self, side_a, side_b, target_amount=None):
        """Reconcile lines by matching amounts; skip if already reconciled."""
        side_a = side_a.filtered(lambda l: not l.reconciled)
        side_b = side_b.filtered(lambda l: not l.reconciled)
        if not side_a or not side_b:
            return False

        rounding = side_a[:1].company_currency_id.rounding
        if target_amount is not None:
            target = abs(target_amount)
            side_a = side_a.filtered(
                lambda l: float_is_zero(
                    abs(l.balance) - target, precision_rounding=rounding
                )
                or float_is_zero(
                    abs(l.amount_currency) - target, precision_rounding=rounding
                )
            )[:1] or side_a[:1]
            side_b = side_b.filtered(
                lambda l: float_is_zero(
                    abs(l.balance) - target, precision_rounding=rounding
                )
                or float_is_zero(
                    abs(l.amount_currency) - target, precision_rounding=rounding
                )
            )[:1] or side_b[:1]

        lines = side_a + side_b
        if len(lines) < 2:
            return False
        try:
            lines.reconcile()
            return True
        except Exception as err:  # noqa: BLE001
            _logger.warning("Line reconciliation failed: %s", err)
            return False

    def _ensure_store_credit_payment_method_accounts(self, config, settings):
        """Map store credit PM receivable to redemption clearing account."""
        clearing = self._redemption_clearing_account(settings)
        if not clearing or not config:
            return False
        sc_methods = config.payment_method_ids.filtered("is_store_credit")
        for pm in sc_methods:
            if pm.receivable_account_id != clearing:
                pm.sudo().write({"receivable_account_id": clearing.id})
        clearing_pm = config.return_clearing_payment_method_id
        refund_clearing = self._refund_clearing_account(settings)
        if clearing_pm and refund_clearing and clearing_pm.receivable_account_id != refund_clearing:
            clearing_pm.sudo().write({"receivable_account_id": refund_clearing.id})
        return True

    def _mark_return_settlement_reconciled(self, return_txn, message):
        return_txn.write({"accounting_state": "reconciled"})
        self.env["pos.return.audit"]._log_pos_event(
            "reconciliation_completed",
            message=message,
            success=True,
            config=return_txn.config_id,
            session=return_txn.session_id,
            order=return_txn.original_order_id,
            payload={"return_id": return_txn.id},
        )

    def _resolve_settings(self, company, config):
        return self.env["return.accounting.config.service"].get_resolved_config(
            company=company, config=config
        )

    def _refund_clearing_account(self, settings):
        return self.env["store.credit.account.move.service"]._refund_clearing_account(
            settings
        )

    def _redemption_clearing_account(self, settings):
        return self.env[
            "store.credit.account.move.service"
        ]._redemption_clearing_account(settings)

    @api.model
    def _log_payment_audit(self, payment, action, message):
        order = payment.pos_order_id
        if payment.pos_return_transaction_id:
            self.env["pos.return.audit"]._log_pos_event(
                action
                if action
                in dict(self.env["pos.return.audit"]._fields["event_type"].selection)
                else "payment_created",
                message=message,
                success=True,
                config=order.config_id,
                session=order.session_id,
                order=order,
                payload={
                    "payment_id": payment.id,
                    "amount": payment.amount,
                    "payment_method": payment.payment_method_id.name,
                },
            )
        credits = payment.store_credit_payment_ids.mapped("credit_id")
        for credit in credits:
            credit._log_audit(action=action, message=message, amount=payment.amount)
