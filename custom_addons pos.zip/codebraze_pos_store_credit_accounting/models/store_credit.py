# -*- coding: utf-8 -*-
"""Accounting helpers on store.credit."""

from odoo import models
from odoo.exceptions import UserError


class StoreCredit(models.Model):
    _inherit = "store.credit"

    def _get_accounting_settings(self):
        """Return settings that must include journal / liability accounts."""
        self.ensure_one()
        settings = self._get_settings()
        if not settings:
            raise UserError(
                self.env._(
                    "Store credit settings are missing for company %(company)s.",
                    company=self.company_id.display_name,
                )
            )
        return settings
