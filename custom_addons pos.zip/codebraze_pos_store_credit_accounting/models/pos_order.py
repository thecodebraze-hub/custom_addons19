# -*- coding: utf-8 -*-
"""POS order hooks for payment validation and store credit reconciliation."""

import logging

from odoo import models

_logger = logging.getLogger(__name__)


class PosOrderStoreCreditAccounting(models.Model):
    _inherit = "pos.order"

    def _process_saved_order(self, draft):
        result = super()._process_saved_order(draft)
        if not draft and self.state != "cancel":
            Posting = self.env["pos.payment.posting.service"]
            for order in self:
                try:
                    Posting.accounting_on_order_paid(order)
                except Exception as err:  # noqa: BLE001
                    _logger.warning(
                        "Order payment accounting validation failed for %s: %s",
                        order.name,
                        err,
                    )
        return result

    def _redeem_store_credit_payments(self):
        result = super()._redeem_store_credit_payments()
        for order in self:
            try:
                self.env["store.credit.account.move.service"].accounting_on_redemption(
                    order
                )
            except Exception as err:  # noqa: BLE001
                _logger.warning(
                    "Store credit redemption accounting hook failed for %s: %s",
                    order.name,
                    err,
                )
        return result

    def action_pos_order_cancel(self):
        Posting = self.env["pos.payment.posting.service"]
        for order in self:
            try:
                Posting.reverse_order_payments_accounting(
                    order, reason=self.env._("POS order cancelled")
                )
            except Exception as err:  # noqa: BLE001
                _logger.warning(
                    "Payment reversal failed on cancel for %s: %s", order.name, err
                )
        return super().action_pos_order_cancel()

