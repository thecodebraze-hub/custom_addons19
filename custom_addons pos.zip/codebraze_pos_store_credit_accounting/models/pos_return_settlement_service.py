# -*- coding: utf-8 -*-
"""Settlement accounting and voucher issuance for refund disbursement."""

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class PosReturnTransactionSettlementAccounting(models.Model):
    _inherit = "pos.return.transaction"

    @api.model
    def pos_settle_return(self, payload, config_id, session_id=False):
        result = super().pos_settle_return(payload, config_id, session_id)
        if not result.get("success"):
            return result
        ret = self.browse(result.get("return_id")).exists()
        if not ret:
            return result
        try:
            self.env["store.credit.account.move.service"].accounting_on_settlement(ret)
        except UserError:
            raise
        except Exception as err:  # noqa: BLE001
            _logger.exception("Return accounting on settlement failed for %s", ret.name)
            ret.write({"accounting_state": "error"})
            self.env["pos.return.audit"]._log_pos_event(
                "accounting_error",
                message=str(err),
                success=False,
                config=ret.config_id,
                session=ret.session_id,
                order=ret.original_order_id,
                payload={"return_id": ret.id, "phase": "settlement"},
            )
        return result

    def _execute_voucher_settlement(self):
        """Issue voucher/credit when settling with return voucher refund method."""
        result = super()._execute_voucher_settlement()
        if self.credit_id:
            return {
                **result,
                "credit_id": self.credit_id.id,
                "voucher_id": self.voucher_id.id if self.voucher_id else False,
                "status": "issued",
            }
        Voucher = self.env.get("pos.return.voucher")
        if not Voucher or not hasattr(Voucher, "_create_from_return"):
            return result
        voucher = Voucher._create_from_return(self)
        self.write(
            {
                "voucher_id": voucher.id,
                "credit_id": voucher.credit_id.id,
            }
        )
        return {
            **result,
            "status": "issued",
            "voucher_id": voucher.id,
            "credit_id": voucher.credit_id.id,
            "voucher_number": voucher.voucher_number,
        }

    def _execute_cash_settlement(self):
        result = super()._execute_cash_settlement()
        if self.settlement_payment_id:
            self.settlement_payment_id.write(
                {"pos_return_transaction_id": self.id}
            )
        return result

    def _execute_original_payment_settlement(self):
        """Create refund payment on return order using original payment method."""
        self.ensure_one()
        order = self.return_order_id
        if not order:
            raise UserError(self.env._("Return POS order is missing."))
        original_payments = self.original_order_id.payment_ids
        if not original_payments:
            raise UserError(
                self.env._("Original invoice has no payment lines to reference.")
            )
        self.original_payment_ids = [(6, 0, original_payments.ids)]

        if self.settlement_payment_id:
            return {
                "original_payment_ids": original_payments.ids,
                "payment_id": self.settlement_payment_id.id,
                "payment_methods": ", ".join(
                    original_payments.mapped("payment_method_id.name")
                ),
            }

        orig_pm = original_payments[0].payment_method_id
        payment = self.env["pos.payment"].create(
            {
                "name": self.env._("Original payment refund"),
                "pos_order_id": order.id,
                "amount": order.amount_total,
                "payment_date": fields.Datetime.now(),
                "payment_method_id": orig_pm.id,
                "pos_return_transaction_id": self.id,
            }
        )
        self.settlement_payment_id = payment.id
        methods = ", ".join(original_payments.mapped("payment_method_id.name"))
        return {
            "original_payment_ids": original_payments.ids,
            "payment_id": payment.id,
            "payment_methods": methods,
        }
