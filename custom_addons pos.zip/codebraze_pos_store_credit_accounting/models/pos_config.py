# -*- coding: utf-8 -*-
"""POS-level accounting configuration overrides."""

from odoo import api, fields, models


class PosConfigStoreCreditAccounting(models.Model):
    _inherit = "pos.config"

    return_clearing_payment_method_id = fields.Many2one(
        comodel_name="pos.payment.method",
        string="Return Clearing Payment Method",
        check_company=True,
        domain="[('config_ids', 'in', id)]",
        help=(
            "Technical payment method for return POS order inventory settlement. "
            "Its receivable account should map to the refund clearing account."
        ),
    )
    pos_refund_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Default Refund Journal",
        check_company=True,
        domain="[('company_id', '=', company_id)]",
        help="Overrides company refund journal for this POS.",
    )
    pos_store_credit_journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Default Store Credit Journal",
        check_company=True,
        domain="[('company_id', '=', company_id), ('type', 'in', ('general', 'sale'))]",
        help="Overrides company store credit journal for this POS.",
    )
    pos_liability_account_id = fields.Many2one(
        comodel_name="account.account",
        string="Default Liability Account",
        check_company=True,
        help="Overrides company store credit liability account for this POS.",
    )
    pos_return_fiscal_position_id = fields.Many2one(
        comodel_name="account.fiscal.position",
        string="Return Fiscal Position",
        check_company=True,
        help="Default fiscal position for returns at this POS (tax mapping).",
    )
    pos_accounting_strict_mode = fields.Boolean(
        string="Strict Accounting (Branch)",
        help="When set, overrides company strict accounting for this POS.",
    )
    pos_manager_approval = fields.Boolean(
        string="Require Manager Approval (Branch)",
        help="Branch override for manager approval on returns.",
    )
    pos_approval_amount = fields.Monetary(
        string="Approval Threshold (Branch)",
        currency_field="currency_id",
        help="Branch override for return approval amount threshold.",
    )

    def write(self, vals):
        tracked = {
            k
            for k in vals
            if k
            in (
                "pos_refund_journal_id",
                "pos_store_credit_journal_id",
                "pos_liability_account_id",
                "pos_return_fiscal_position_id",
                "pos_accounting_strict_mode",
                "pos_manager_approval",
                "pos_approval_amount",
                "return_clearing_payment_method_id",
            )
        }
        before = {}
        if tracked:
            for record in self:
                before[record.id] = {f: record[f] for f in tracked}
        result = super().write(vals)
        if tracked:
            Audit = self.env["store.credit.settings.audit"]
            for record in self:
                settings = self.env["store.credit.settings"].search(
                    [
                        ("company_id", "=", record.company_id.id),
                        ("config_id", "=", record.id),
                        ("active", "=", True),
                    ],
                    limit=1,
                )
                if not settings:
                    settings = self.env["store.credit.settings"].search(
                        [
                            ("company_id", "=", record.company_id.id),
                            ("config_id", "=", False),
                            ("active", "=", True),
                        ],
                        limit=1,
                    )
                if not settings:
                    continue
                for field_name in tracked:
                    old_val = before[record.id].get(field_name)
                    new_val = record[field_name]
                    if old_val == new_val:
                        continue
                    change_type = "journal_change" if "journal" in field_name else (
                        "approval_policy_change"
                        if "approval" in field_name or "manager" in field_name
                        else "account_change"
                        if "account" in field_name or "liability" in field_name
                        else "fiscal_position_change"
                        if "fiscal" in field_name
                        else "configuration_change"
                    )
                    Audit.create(
                        {
                            "settings_id": settings.id,
                            "company_id": record.company_id.id,
                            "config_id": record.id,
                            "change_type": change_type,
                            "field_name": field_name,
                            "old_value": str(old_val) if old_val else "",
                            "new_value": str(new_val) if new_val else "",
                            "user_id": self.env.user.id,
                        }
                    )
        return result

    @api.model
    def _load_pos_data_fields(self, config):
        fields_list = super()._load_pos_data_fields(config)
        return fields_list + [
            "pos_manager_approval",
            "pos_approval_amount",
        ]
