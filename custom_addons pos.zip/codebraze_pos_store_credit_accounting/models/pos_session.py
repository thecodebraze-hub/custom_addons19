# -*- coding: utf-8 -*-
"""Reconcile store credit redemption clearing after POS session accounting."""

import logging

from odoo import models

_logger = logging.getLogger(__name__)


class PosSessionStoreCreditAccounting(models.Model):
    _inherit = "pos.session"

    def _create_account_move(self, balancing_account=False, amount_to_balance=0, bank_payment_method_diffs=None):
        move = super()._create_account_move(
            balancing_account=balancing_account,
            amount_to_balance=amount_to_balance,
            bank_payment_method_diffs=bank_payment_method_diffs,
        )
        if move:
            try:
                self.env["pos.payment.posting.service"].accounting_on_session_closed(
                    self
                )
            except Exception as err:  # noqa: BLE001
                _logger.warning(
                    "POS payment session reconciliation failed for %s: %s",
                    self.name,
                    err,
                )
        return move
