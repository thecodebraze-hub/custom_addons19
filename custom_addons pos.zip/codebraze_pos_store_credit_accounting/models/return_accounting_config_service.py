# -*- coding: utf-8 -*-
"""Configuration resolution and validation for return accounting."""

import logging

from odoo import _, api, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

# Expected account types per configuration field (Odoo 19 account_type values)
ACCOUNT_TYPE_RULES = {
    "liability_account_id": ("liability_current", "liability_non_current"),
    "gift_voucher_liability_account_id": ("liability_current", "liability_non_current"),
    "wallet_liability_account_id": ("liability_current", "liability_non_current"),
    "loyalty_liability_account_id": ("liability_current", "liability_non_current"),
    "sales_returns_account_id": (
        "income",
        "income_other",
        "expense",
        "expense_direct_cost",
    ),
    "redemption_clearing_account_id": (
        "asset_current",
        "asset_receivable",
        "liability_current",
        "income_other",
    ),
    "refund_clearing_account_id": (
        "asset_current",
        "asset_receivable",
        "liability_current",
        "income_other",
    ),
    "inventory_account_id": ("asset_current",),
    "cogs_account_id": ("expense_direct_cost", "expense"),
    "revenue_account_id": ("income", "income_other"),
    "tax_account_id": ("liability_current", "asset_current"),
    "adjustment_account_id": ("expense", "income_other", "income"),
    "writeoff_account_id": ("expense", "income_other"),
    "breakage_revenue_account_id": ("income", "income_other"),
    "cash_account_id": ("asset_cash", "asset_current"),
    "bank_account_id": ("asset_cash", "asset_current"),
    "expense_account_id": ("expense", "income_other", "income"),
}

JOURNAL_OPERATION_MAP = {
    "store_credit": "journal_id",
    "refund": "refund_journal_id",
    "sales_return": "sales_return_journal_id",
    "cash_refund": "cash_refund_journal_id",
    "bank_refund": "bank_refund_journal_id",
    "adjustment": "adjustment_journal_id",
    "reversal": "reversal_journal_id",
}

LIABILITY_ACCOUNT_MAP = {
    "return": "liability_account_id",
    "gift_voucher": "gift_voucher_liability_account_id",
    "wallet": "wallet_liability_account_id",
    "loyalty": "loyalty_liability_account_id",
}


class ReturnAccountingConfigService(models.AbstractModel):
    """Resolve and validate return / store credit accounting configuration."""

    _name = "return.accounting.config.service"
    _description = "Return Accounting Configuration Service"

    # -------------------------------------------------------------------------
    # Resolution
    # -------------------------------------------------------------------------

    @api.model
    def get_resolved_config(self, company=None, config=None):
        """Return settings namespace with POS-level overrides applied."""
        company = company or self.env.company
        settings = self.env["store.credit.settings"]._get_settings(
            company=company, config=config
        )
        if not config:
            return settings

        pos_config = config if hasattr(config, "id") else self.env["pos.config"].browse(config)
        if not pos_config:
            return settings

        overrides = {
            "journal_id": pos_config.pos_store_credit_journal_id or getattr(
                settings, "journal_id", False
            ),
            "refund_journal_id": pos_config.pos_refund_journal_id or getattr(
                settings, "refund_journal_id", False
            ),
            "liability_account_id": pos_config.pos_liability_account_id or getattr(
                settings, "liability_account_id", False
            ),
            "fiscal_position_id": pos_config.pos_return_fiscal_position_id or getattr(
                settings, "fiscal_position_id", False
            ),
        }
        for key, value in overrides.items():
            if value:
                setattr(settings, key, value)
        return settings

    @api.model
    def resolve_journal(self, settings, operation="store_credit", fallback=None):
        """Resolve journal by operation key; never hardcode."""
        field_name = JOURNAL_OPERATION_MAP.get(operation, "journal_id")
        journal = getattr(settings, field_name, False) or fallback
        if not journal and operation == "store_credit":
            journal = getattr(settings, "journal_id", False)
        if not journal and operation == "refund":
            journal = getattr(settings, "refund_journal_id", False)
        return journal

    @api.model
    def resolve_account(self, settings, account_key, fallback_keys=None):
        """Resolve account by field name with optional fallback keys."""
        account = getattr(settings, account_key, False)
        if account:
            return account
        for key in fallback_keys or ():
            account = getattr(settings, key, False)
            if account:
                return account
        return False

    @api.model
    def resolve_liability_account(self, settings, credit_type="return"):
        """Resolve liability account by credit instrument type."""
        field_name = LIABILITY_ACCOUNT_MAP.get(
            credit_type, "liability_account_id"
        )
        account = getattr(settings, field_name, False)
        if account:
            return account
        return getattr(settings, "liability_account_id", False)

    # -------------------------------------------------------------------------
    # Validation
    # -------------------------------------------------------------------------

    @api.model
    def validate_for_posting(
        self,
        company=None,
        config=None,
        operation="store_credit",
        strict=False,
        currency=None,
    ):
        """
        Validate journals and accounts exist before posting.

        :param operation: store_credit | refund | cash_refund | bank_refund |
                          adjustment | reversal | redeem | issue
        :returns: dict with valid, errors, warnings
        """
        settings = self.get_resolved_config(company=company, config=config)
        errors = []
        warnings = []

        if not getattr(settings, "enable_accounting", True):
            return {"valid": True, "enabled": False, "errors": [], "warnings": []}

        company = company or self.env.company
        if hasattr(company, "id"):
            company_rec = company
        else:
            company_rec = self.env["res.company"].browse(company)

        currency = currency or company_rec.currency_id
        if hasattr(currency, "id") is False and currency:
            currency = self.env["res.currency"].browse(currency)

        journal = self.resolve_journal(settings, operation=operation)
        if not journal:
            errors.append(
                _("Journal for operation '%(op)s' is not configured.", op=operation)
            )
        else:
            try:
                self._validate_journal_record(
                    journal, company_rec, operation, raise_error=True
                )
            except (ValidationError, UserError) as err:
                errors.append(str(err))

        required_accounts = self._required_accounts_for_operation(operation)
        for field_name in required_accounts:
            account = getattr(settings, field_name, False)
            if not account:
                errors.append(
                    _("Account '%(field)s' is not configured.", field=field_name)
                )
                continue
            try:
                self._validate_account_record(
                    account, company_rec, field_name, raise_error=True
                )
            except (ValidationError, UserError) as err:
                errors.append(str(err))

        fiscal_pos = getattr(settings, "fiscal_position_id", False)
        if fiscal_pos and fiscal_pos.company_id != company_rec:
            errors.append(_("Fiscal position company does not match."))

        if currency and company_rec.currency_id != currency:
            if not currency.active:
                errors.append(_("Currency is not active."))

        if strict and errors:
            raise ValidationError("\n".join(errors))

        return {
            "valid": not errors,
            "enabled": True,
            "errors": errors,
            "warnings": warnings,
            "config_version": getattr(settings, "accounting_config_version", 1),
        }

    @api.model
    def _required_accounts_for_operation(self, operation):
        common = ("liability_account_id", "sales_returns_account_id")
        mapping = {
            "store_credit": common + ("redemption_clearing_account_id",),
            "issue": common,
            "redeem": ("liability_account_id", "redemption_clearing_account_id"),
            "refund": ("refund_clearing_account_id",),
            "cash_refund": ("refund_clearing_account_id",),
            "bank_refund": ("refund_clearing_account_id",),
            "adjustment": ("liability_account_id", "adjustment_account_id"),
            "reversal": (),
            "expire": ("liability_account_id", "breakage_revenue_account_id"),
            "cancel": common,
        }
        return mapping.get(operation, common)

    @api.model
    def _validate_journal_record(self, journal, company, label, raise_error=False):
        errors = []
        if not journal:
            errors.append(_("Journal '%(label)s' is missing.", label=label))
        elif journal.company_id != company:
            errors.append(
                _(
                    "Journal '%(journal)s' must belong to company %(company)s.",
                    journal=journal.display_name,
                    company=company.display_name,
                )
            )
        if errors and raise_error:
            raise ValidationError("\n".join(errors))
        return not errors

    @api.model
    def _validate_account_record(self, account, company, field_name, raise_error=False):
        errors = []
        if not account:
            errors.append(_("Account for '%(field)s' is missing.", field=field_name))
        elif account.company_id != company:
            errors.append(
                _(
                    "Account '%(account)s' (%(field)s) must belong to company %(company)s.",
                    account=account.display_name,
                    field=field_name,
                    company=company.display_name,
                )
            )
        else:
            allowed = ACCOUNT_TYPE_RULES.get(field_name)
            if allowed and account.account_type not in allowed:
                errors.append(
                    _(
                        "Account '%(account)s' has type '%(type)s' but '%(field)s' "
                        "requires one of: %(allowed)s.",
                        account=account.display_name,
                        type=account.account_type,
                        field=field_name,
                        allowed=", ".join(allowed),
                    )
                )
        if errors and raise_error:
            raise ValidationError("\n".join(errors))
        return not errors

    @api.model
    def validate_accounting_configuration(self, company=None, config=None, strict=False):
        """Backward-compatible wrapper used by account move service."""
        return self.validate_for_posting(
            company=company,
            config=config,
            operation="store_credit",
            strict=strict,
        )
