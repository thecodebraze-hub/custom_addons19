# -*- coding: utf-8 -*-
"""Accounting fields and hooks on POS return transactions."""

from odoo import fields, models


class PosReturnTransactionAccounting(models.Model):
    _inherit = "pos.return.transaction"

    accounting_state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("pending_settlement", "Pending Settlement"),
            ("posted", "Posted"),
            ("reconciled", "Reconciled"),
            ("skipped", "Skipped"),
            ("error", "Error"),
        ],
        string="Accounting Status",
        default="draft",
        index=True,
        copy=False,
    )
    refund_move_id = fields.Many2one(
        comodel_name="account.move",
        string="Refund Journal Entry",
        copy=False,
        index=True,
        check_company=True,
        help="Credit note or refund move generated for invoiced returns.",
    )
    accounting_move_ids = fields.One2many(
        comodel_name="account.move",
        inverse_name="pos_return_transaction_id",
        string="Accounting Entries",
        copy=False,
    )
