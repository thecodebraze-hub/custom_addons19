# -*- coding: utf-8 -*-
"""Accounting-related audit events for POS returns."""

from odoo import fields, models


class PosReturnAuditAccounting(models.Model):
    _inherit = "pos.return.audit"

    event_type = fields.Selection(
        selection_add=[
            ("accounting_post", "Accounting Posted"),
            ("accounting_reverse", "Accounting Reversed"),
            ("liability_created", "Store Credit Liability Created"),
            ("liability_reduced", "Store Credit Liability Reduced"),
            ("payment_created", "Payment Created"),
            ("payment_posted", "Payment Posted"),
            ("payment_reversed", "Payment Reversed"),
            ("reconciliation_completed", "Reconciliation Completed"),
            ("store_credit_applied", "Store Credit Applied"),
            ("accounting_error", "Accounting Error"),
        ],
        ondelete={
            "accounting_post": "cascade",
            "accounting_reverse": "cascade",
            "liability_created": "cascade",
            "liability_reduced": "cascade",
            "payment_created": "cascade",
            "payment_posted": "cascade",
            "payment_reversed": "cascade",
            "reconciliation_completed": "cascade",
            "store_credit_applied": "cascade",
            "accounting_error": "cascade",
        },
    )
