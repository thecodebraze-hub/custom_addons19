# -*- coding: utf-8 -*-
"""Link account.move to store credit and POS return documents."""

from odoo import fields, models


class AccountMove(models.Model):
    _inherit = "account.move"

    store_credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        index=True,
        copy=False,
        check_company=True,
        help="Store credit instrument related to this journal entry.",
    )
    store_credit_transaction_id = fields.Many2one(
        comodel_name="store.credit.transaction",
        string="Store Credit Transaction",
        index=True,
        copy=False,
        check_company=True,
    )
    return_voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Return Voucher",
        index=True,
        copy=False,
        check_company=True,
    )
    pos_return_transaction_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return Transaction",
        index=True,
        copy=False,
        check_company=True,
    )
    pos_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="POS Order",
        index=True,
        copy=False,
        check_company=True,
    )
    pos_session_id = fields.Many2one(
        comodel_name="pos.session",
        string="POS Session",
        index=True,
        copy=False,
        check_company=True,
    )
