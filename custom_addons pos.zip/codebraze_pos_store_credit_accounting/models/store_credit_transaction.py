# -*- coding: utf-8 -*-
"""Post journal entries from store credit transactions via accounting service."""

import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class StoreCreditTransaction(models.Model):
    _inherit = "store.credit.transaction"

    accounting_state = fields.Selection(
        selection=[
            ("to_post", "To Post"),
            ("posted", "Posted"),
            ("skipped", "Skipped"),
            ("reversed", "Reversed"),
        ],
        string="Accounting Status",
        default="to_post",
        index=True,
        copy=False,
    )

    def _should_post_accounting(self):
        self.ensure_one()
        if self.is_accounted or self.move_id:
            return False
        if self.state != "posted":
            return False
        if self.txn_type not in ("issue", "redeem", "cancel", "expire", "adjustment"):
            return False
        settings = self.credit_id._get_settings()
        if not getattr(settings, "enable_accounting", True):
            return False
        if not getattr(settings, "auto_post_entries", True):
            return False
        if not getattr(settings, "journal_id", False) or not getattr(
            settings, "liability_account_id", False
        ):
            return False
        return True

    def _post_accounting(self):
        """Delegate to the central accounting service."""
        Accounting = self.env["store.credit.account.move.service"]
        for txn in self:
            if not txn._should_post_accounting():
                if not txn.move_id:
                    txn.accounting_state = "skipped"
                continue
            try:
                Accounting.post_credit_transaction(txn)
            except UserError as err:
                _logger.warning(
                    "Store credit accounting failed for %s: %s",
                    txn.name,
                    err,
                )
                txn.accounting_state = "skipped"
                raise
        return True

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        to_post = records.filtered(lambda t: t.state == "posted")
        if to_post:
            try:
                to_post._post_accounting()
            except UserError as err:
                _logger.warning("Store credit accounting skipped: %s", err)
                to_post.filtered(lambda t: not t.move_id).write(
                    {"accounting_state": "skipped"}
                )
        return records
