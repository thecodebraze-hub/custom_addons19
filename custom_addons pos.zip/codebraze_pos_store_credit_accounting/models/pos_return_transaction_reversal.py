# -*- coding: utf-8 -*-
"""Reverse payment accounting when returns are cancelled."""

import logging

from odoo import models

_logger = logging.getLogger(__name__)


class PosReturnTransactionPaymentReversal(models.Model):
    _inherit = "pos.return.transaction"

    def action_cancel(self):
        Posting = self.env["pos.payment.posting.service"]
        for ret in self:
            order = ret.return_order_id
            if order:
                try:
                    Posting.reverse_order_payments_accounting(
                        order,
                        reason=self.env._(
                            "Return %(name)s cancelled", name=ret.name
                        ),
                    )
                except Exception as err:  # noqa: BLE001
                    _logger.warning(
                        "Payment reversal on return cancel failed for %s: %s",
                        ret.name,
                        err,
                    )
            if ret.credit_id:
                for txn in ret.credit_id.transaction_ids.filtered(
                    lambda t: t.is_accounted and t.move_id
                ):
                    try:
                        self.env[
                            "store.credit.account.move.service"
                        ].reverse_credit_transaction(
                            txn,
                            reason=self.env._(
                                "Return %(name)s cancelled", name=ret.name
                            ),
                        )
                    except Exception as err:  # noqa: BLE001
                        _logger.warning(
                            "Credit reversal on return cancel failed: %s", err
                        )
        return super().action_cancel()
