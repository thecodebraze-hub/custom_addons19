# -*- coding: utf-8 -*-
"""Accounting audit actions on store credit audit log."""

from odoo import fields, models


class StoreCreditAuditAccounting(models.Model):
    _inherit = "store.credit.audit"

    action = fields.Selection(
        selection_add=[
            ("liability_created", "Liability Created"),
            ("liability_reduced", "Liability Reduced"),
            ("accounting_post", "Accounting Posted"),
            ("accounting_reverse", "Accounting Reversed"),
            ("payment_created", "Payment Created"),
            ("payment_posted", "Payment Posted"),
            ("payment_reversed", "Payment Reversed"),
            ("reconciliation_completed", "Reconciliation Completed"),
            ("store_credit_applied", "Store Credit Applied"),
        ],
        ondelete={
            "liability_created": "cascade",
            "liability_reduced": "cascade",
            "accounting_post": "cascade",
            "accounting_reverse": "cascade",
            "payment_created": "cascade",
            "payment_posted": "cascade",
            "payment_reversed": "cascade",
            "reconciliation_completed": "cascade",
            "store_credit_applied": "cascade",
        },
    )
