# -*- coding: utf-8 -*-
"""POS payment accounting fields, posting hooks, and document links."""

import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class PosPaymentAccounting(models.Model):
    _inherit = "pos.payment"

    pos_return_transaction_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return Transaction",
        index=True,
        copy=False,
        check_company=True,
        help="Return settlement that created this payment line.",
    )
    accounting_state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("pending_reconcile", "Pending Reconciliation"),
            ("posted", "Posted"),
            ("reconciled", "Reconciled"),
            ("reversed", "Reversed"),
            ("skipped", "Skipped"),
            ("error", "Error"),
        ],
        string="Accounting Status",
        default="draft",
        index=True,
        copy=False,
    )
    is_accounting_reconciled = fields.Boolean(
        string="Accounting Reconciled",
        default=False,
        index=True,
        copy=False,
    )

    def _cb_payment_move_link_vals(self):
        self.ensure_one()
        order = self.pos_order_id
        vals = {
            "pos_order_id": order.id,
            "pos_session_id": order.session_id.id if order.session_id else False,
        }
        if self.pos_return_transaction_id:
            vals["pos_return_transaction_id"] = self.pos_return_transaction_id.id
        return vals

    @api.model_create_multi
    def create(self, vals_list):
        payments = super().create(vals_list)
        try:
            self.env["pos.payment.posting.service"].accounting_on_payment_created(
                payments
            )
        except Exception as err:  # noqa: BLE001
            _logger.warning("Payment accounting hook failed: %s", err)
        return payments

    def _create_payment_moves(self, is_reverse=False):
        """Extend standard invoiced payment moves with CodeBraze document links."""
        store_credit = self.filtered(
            lambda p: p.payment_method_id.is_store_credit
        )
        regular = self - store_credit
        result = self.env["account.move"]
        if regular:
            result = super(PosPaymentAccounting, regular)._create_payment_moves(
                is_reverse=is_reverse
            )
            Posting = self.env["pos.payment.posting.service"]
            for payment in regular:
                if payment.account_move_id:
                    payment.account_move_id.write(payment._cb_payment_move_link_vals())
                    payment.write({"accounting_state": "posted"})
                    Posting._log_payment_audit(
                        payment,
                        "payment_posted",
                        self.env._(
                            "Payment move %(move)s posted for invoiced order",
                            move=payment.account_move_id.name,
                        ),
                    )
        return result

    def unlink(self):
        Posting = self.env["pos.payment.posting.service"]
        for payment in self.filtered(
            lambda p: p.accounting_state in ("posted", "reconciled")
        ):
            try:
                Posting.reverse_payment_accounting(
                    payment, reason=self.env._("Payment line removed")
                )
            except Exception as err:  # noqa: BLE001
                _logger.warning(
                    "Could not reverse payment accounting for %s: %s",
                    payment.id,
                    err,
                )
        return super().unlink()
