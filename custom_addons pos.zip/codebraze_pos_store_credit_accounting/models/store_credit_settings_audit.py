# -*- coding: utf-8 -*-
"""Audit trail for store credit / return accounting configuration changes."""

from odoo import fields, models


class StoreCreditSettingsAudit(models.Model):
    _name = "store.credit.settings.audit"
    _description = "Store Credit Settings Audit"
    _order = "create_date desc, id desc"

    settings_id = fields.Many2one(
        comodel_name="store.credit.settings",
        string="Settings",
        required=True,
        ondelete="cascade",
        index=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        string="Company",
        required=True,
        index=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="POS Config",
        index=True,
    )
    change_type = fields.Selection(
        selection=[
            ("configuration_change", "Configuration Change"),
            ("journal_change", "Journal Change"),
            ("account_change", "Account Change"),
            ("approval_policy_change", "Approval Policy Change"),
            ("fiscal_position_change", "Fiscal Position Change"),
        ],
        required=True,
        index=True,
    )
    field_name = fields.Char(string="Field", required=True, index=True)
    old_value = fields.Char(string="Previous Value")
    new_value = fields.Char(string="New Value")
    user_id = fields.Many2one(
        comodel_name="res.users",
        string="Changed By",
        required=True,
        default=lambda self: self.env.user,
        index=True,
    )
