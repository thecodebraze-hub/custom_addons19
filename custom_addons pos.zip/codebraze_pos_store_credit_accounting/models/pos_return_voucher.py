# -*- coding: utf-8 -*-
"""Accounting status fields on return vouchers."""

from odoo import fields, models


class PosReturnVoucher(models.Model):
    _inherit = "pos.return.voucher"

    accounting_state = fields.Selection(
        selection=[
            ("to_post", "To Post"),
            ("posted", "Posted"),
            ("reversed", "Reversed"),
            ("skipped", "Skipped"),
        ],
        string="Accounting Status",
        default="to_post",
        index=True,
        copy=False,
        help="Aggregated accounting state derived from linked credit transactions.",
    )
    move_ids = fields.One2many(
        comodel_name="account.move",
        inverse_name="return_voucher_id",
        string="Journal Entries",
        copy=False,
    )

    def _sync_accounting_state(self):
        for voucher in self:
            txns = voucher.credit_id.transaction_ids
            if not txns:
                voucher.accounting_state = "to_post"
                continue
            accounted = txns.filtered(lambda t: t.is_accounted)
            if accounted and len(accounted) == len(txns.filtered(lambda t: t.state == "posted")):
                voucher.accounting_state = "posted"
            elif accounted:
                voucher.accounting_state = "posted"
            else:
                skipped = all(
                    t.accounting_state == "skipped"
                    for t in txns
                    if hasattr(t, "accounting_state")
                )
                voucher.accounting_state = "skipped" if skipped else "to_post"
        return True
