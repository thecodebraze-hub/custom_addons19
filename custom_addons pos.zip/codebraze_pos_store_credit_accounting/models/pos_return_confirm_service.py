# -*- coding: utf-8 -*-
"""Trigger return accounting when a return is confirmed from POS."""

import logging

from odoo import api, models

_logger = logging.getLogger(__name__)


class PosReturnTransactionConfirmAccounting(models.Model):
    _inherit = "pos.return.transaction"

    @api.model
    def pos_confirm_return(self, payload, config_id, session_id):
        result = super().pos_confirm_return(payload, config_id, session_id)
        if result.get("success") and result.get("return_id"):
            ret = self.browse(result["return_id"]).exists()
            if ret:
                try:
                    self.env["store.credit.account.move.service"].accounting_on_return_confirmed(
                        ret
                    )
                except Exception as err:  # noqa: BLE001 — audit and continue
                    _logger.exception(
                        "Return accounting on confirm failed for %s", ret.name
                    )
                    ret.write({"accounting_state": "error"})
                    self.env["pos.return.audit"]._log_pos_event(
                        "accounting_error",
                        message=str(err),
                        success=False,
                        config=ret.config_id,
                        session=ret.session_id,
                        order=ret.original_order_id,
                        payload={"return_id": ret.id, "phase": "confirm"},
                    )
        return result

    def _settle_return_order_for_inventory(self, refund_order):
        result = super()._settle_return_order_for_inventory(refund_order)
        for payment in refund_order.payment_ids.filtered(
            lambda p: not p.pos_return_transaction_id
        ):
            payment.write({"pos_return_transaction_id": self.id})
        return result

    def _select_settlement_payment_method(self):
        if self.config_id.return_clearing_payment_method_id:
            return self.config_id.return_clearing_payment_method_id
        return super()._select_settlement_payment_method()
