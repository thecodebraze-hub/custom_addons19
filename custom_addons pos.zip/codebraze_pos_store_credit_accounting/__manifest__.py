# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Store Credit Accounting",
    "version": "19.0.1.3.0",
    "category": "Accounting/Accounting",
    "summary": "Accounting integration for store credit liability and credit notes",
    "description": """
CodeBraze Store Credit Accounting
=================================
Links store credit ledger movements to journal entries, liability accounts
and optional credit notes.
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "account",
        "account_accountant",
        "point_of_sale",
        "codebraze_pos_store_credit",
        "codebraze_pos_return",
        "codebraze_pos_return_voucher",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/store_credit_settings_accounting_views.xml",
        "views/pos_config_accounting_views.xml",
    ],
    "application": False,
    "installable": True,
    "auto_install": False,
}
