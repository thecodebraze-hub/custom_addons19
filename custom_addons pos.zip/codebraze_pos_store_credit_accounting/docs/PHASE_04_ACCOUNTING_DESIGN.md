# Phase 04 — Accounting Integration Design Blueprint

**Version:** 1.0  
**Date:** 2026-07-09  
**Status:** Design only (no implementation)  
**Modules:** `codebraze_pos_return`, `codebraze_pos_return_voucher`, `codebraze_pos_store_credit`, `codebraze_pos_store_credit_accounting`  
**Odoo baseline:** 19.0 Enterprise — `account`, `account_accountant`, `point_of_sale`

---

## 1. Design Principles

### 1.1 Non-negotiable rules

| Rule | Rationale |
|------|-----------|
| **Never bypass Odoo Accounting** | All monetary effects must land in `account.move` / `account.move.line` using standard posting, reconciliation, and reversal APIs. |
| **Reuse standard POS flows** | Return orders are native `pos.order` refunds; session closing, stock valuation, and invoiced credit notes must use Odoo core mechanics. |
| **Store Credit = Liability** | Outstanding voucher balance is a balance-sheet liability (`Current Liabilities`), not a discount, coupon, negative product, or price reduction. |
| **Single source of revenue reversal** | Sales revenue is reversed **once** — either via POS session aggregation or via `out_refund` credit note, never both for the same return line. |
| **Single source of refund disbursement** | Cash/bank outflow is recorded **once** at settlement; liability issuance is recorded **once** at store credit issue. |
| **Ledger drives liability accounting** | Every accounting entry for store credit originates from a posted `store.credit.transaction` (existing hook in accounting module). |
| **Idempotency** | Accounting posts are tied to immutable transaction UUIDs; reposting is blocked when `move_id` / `is_accounted` is set. |

### 1.2 What Odoo already does (do not reimplement)

| Event | Odoo standard mechanism |
|-------|-------------------------|
| Uninvoiced sale | `pos.session._create_account_move` on session close — aggregates sales, taxes, receivables, stock |
| Uninvoiced return order | Negative order lines reduce sales/stock in the **same session entry** |
| Invoiced sale | `pos.order._create_invoice` → `account.move` (`out_invoice`) |
| Invoiced return | `pos.order._prepare_invoice_vals` → `out_refund`, linked via `reversed_entry_id` / `pos_refunded_invoice_ids` |
| Stock return | `pos.order._create_order_picking` → stock moves → session stock valuation lines |
| Payment method moves | `pos.payment._create_payment_moves` per payment (except store credit — already excluded) |

### 1.3 What CodeBraze must add

| Gap | Solution |
|-----|----------|
| Voucher liability not in standard POS | Dedicated liability journal entries on `store.credit.transaction` |
| Voucher redemption not a payment method move | Liability reduction entry + POS receivable clearing (not sales discount) |
| Return settlement vs technical return payment | Clearing account bridge to avoid duplicate cash/refund entries |
| Traceability | Extend `account.move` links to return, voucher, POS order |
| Invoiced + voucher returns | Coordinate credit note receivable with liability issuance |

---

## 2. Accounting Architecture

### 2.1 Layered model

```
┌─────────────────────────────────────────────────────────────────┐
│                     PRESENTATION (POS UI)                        │
│  Refund Popup → Return Confirm → Settlement → Redemption         │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                   OPERATIONAL LAYER (existing)                     │
│  pos.return.transaction │ pos.order (return) │ store.credit      │
│  pos.return.voucher     │ store.credit.transaction               │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│              ACCOUNTING ORCHESTRATION (to implement)               │
│  AccountMoveService — coordinates timing, accounts, reconciliation │
│  Hooks: session close │ credit note │ credit txn create           │
└────────────────────────────┬────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                   ODOO ACCOUNTING (standard)                     │
│  account.move │ account.move.line │ reconciliation │ reversal    │
│  pos.session.move_id │ pos.order.account_move                     │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Document relationships

```
pos.order (original sale)
    │
    ├── account.move (out_invoice)          [if invoiced]
    │
    └── pos.return.transaction
            │
            ├── pos.order (return / refund)  → session.move_id (uninvoiced)
            │       └── account.move (out_refund)  [if invoiced]
            │
            ├── pos.return.voucher
            │       └── store.credit
            │               └── store.credit.transaction*
            │                       └── account.move (liability entries)
            │
            └── pos.exchange.transaction (future accounting extension)
```

### 2.3 Account roles (conceptual)

| Account role | Typical type | Purpose |
|--------------|--------------|---------|
| **Sales Revenue** | Income | Original sale (Odoo product/category accounts) |
| **Sales Returns** | Income (contra) or dedicated returns account | Revenue reversal on return |
| **Output Tax** | Liability | Tax reversal on return |
| **POS Receivable** | Asset | Session interim receivable (company default POS receivable) |
| **Cash / Bank** | Asset | Actual refund disbursement |
| **Inventory** | Asset | Stock return at cost |
| **COGS / Stock Output** | Expense / Asset | Cost reversal via session stock lines |
| **Store Credit Liability** | Current Liability | Money owed to customer via voucher |
| **Refund Clearing (Suspense)** | Current Asset/Liability | Bridge between return order technical payment and settlement |
| **Voucher Breakage Revenue** | Income (optional) | Expired unredeemed liability (configurable) |

---

## 3. Configuration Design

### 3.1 Settings scope

Extend `store.credit.settings` (and `res.config.settings` / `ir.config_parameter` bridge) with an **Accounting** section. Settings resolve per `company_id` with optional `pos.config` override (same pattern as Phase 02).

### 3.2 Configuration fields

| Field | Model | Required | Description |
|-------|-------|----------|-------------|
| `enable_accounting` | settings | Yes | Master switch; when False, operational layer only (dev/test) |
| `auto_post_entries` | settings | Yes | Auto-post on transaction create (exists) |
| `refund_journal_id` | settings | Yes | Journal for return/refund entries not handled by POS session (invoiced credit notes use `invoice_journal_id` from POS config) |
| `store_credit_journal_id` | settings | Yes | Journal for liability issue/redeem/cancel/expire (exists as `journal_id`) |
| `liability_account_id` | settings | Yes | Store Credit Liability (exists) |
| `sales_returns_account_id` | settings | Yes | Counterpart on issue — credit note / returns contra revenue (replaces generic `expense_account_id`) |
| `redemption_clearing_account_id` | settings | Yes | Counterpart on redeem — bridges to POS receivable, not sales discount |
| `refund_clearing_account_id` | settings | Recommended | Technical return-order payment clearing until settlement |
| `cash_account_id` | settings | Optional | Override; default from payment method / journal |
| `bank_account_id` | settings | Optional | Override for card refunds |
| `breakage_revenue_account_id` | settings | Optional | Voucher expiry — income on unredeemed balance |
| `tax_account_id` | settings | Optional | Only if manual tax adjustment entries needed outside credit note |
| `post_on_issue` | settings | Yes | Post liability on `txn_type=issue` |
| `post_on_redeem` | settings | Yes | Post liability reduction on redeem |
| `post_on_expire` | settings | Yes | Post expiry to breakage or returns |
| `post_on_cancel` | settings | Yes | Post cancel reversal |
| `invoiced_return_mode` | settings | Yes | `credit_note_only` \| `credit_note_and_liability` |
| `uninvoiced_return_mode` | settings | Yes | `session_only` \| `session_and_liability` |
| `reconcile_refund_clearing` | settings | Yes | Auto-reconcile clearing with settlement move |

### 3.3 POS config additions

| Field | Model | Description |
|-------|-------|-------------|
| `return_clearing_payment_method_id` | `pos.config` | Internal payment method mapped to `refund_clearing_account_id` for technical return-order payment (inventory-only) |
| `store_credit_payment_method_id` | `pos.config` | Already exists — must map to clearing, not cash |

### 3.4 Default chart mapping (per company)

On module install / accounting wizard:

| Credit type | Issue counterpart default |
|-------------|---------------------------|
| Return voucher | Sales Returns account |
| Exchange difference | Sales Returns account |
| Manual / compensation | Configurable GL account |
| Gift / loyalty (future) | Deferred revenue or liability sub-account |

### 3.5 Multi-company

- Every `account.journal` and `account.account` has `check_company=True`.
- Settings record per company (and optional branch override).
- Sequences for `account.move` refs include company prefix.
- No cross-company store credit transfers in accounting (operational layer already blocks).

### 3.6 Multi-currency

| Concept | Design |
|---------|--------|
| Voucher currency | `store.credit.currency_id` — face value currency |
| Company currency | `res.company.currency_id` — reporting |
| Transaction amount | Stored in voucher currency on `store.credit.transaction` |
| `account.move` | `currency_id` = transaction currency; `company_currency_id` on lines with `amount_currency` + `balance` |
| Exchange rate | `date` of transaction; use Odoo `res.currency._convert` at post time |
| Redemption on POS order in different currency | Block or convert at redemption using order session date rate (config: `redemption_fx_policy`) |
| Rounding | Apply `currency.rounding` before posting; write-off differences to dedicated rounding account if needed |

---

## 4. End-to-End Journal Flow

### 4.1 Master flow

```
ORIGINAL SALE
    │
    ├─[Uninvoiced]─► Session close ─► Dr Receivable/Cash  Cr Sales+Tax
    │                                      (pos.session.move_id)
    │
    └─[Invoiced]───► out_invoice ───► Dr Receivable  Cr Sales+Tax
                                           (pos.order.account_move)

CUSTOMER RETURN
    │
    ├─ Return transaction created (pos.return.transaction)
    ├─ Return POS order created (negative lines, is_refund=True)
    ├─ Stock picking (customer → stock)
    │
    ├─[Uninvoiced]─► Session close includes return order
    │                 Dr Sales+Tax (reduced)  Cr Receivable/Clearing
    │                 Dr Inventory  Cr COGS/Stock output (stock lines)
    │
    └─[Invoiced]───► out_refund (credit note)
                      Dr Sales+Tax  Cr Receivable
                      Linked: reversed_entry_id → original invoice

REFUND SETTLEMENT (customer disbursement — separate from stock technical payment)
    │
    ├─ CASH ─────────► Dr Receivable/Clearing  Cr Cash
    │                 (pos.payment move or session line)
    │
    ├─ ORIGINAL PM ──► Dr Receivable/Clearing  Cr Bank/Card receivable
    │                 + payment refund workflow per method
    │
    └─ VOUCHER ──────► store.credit.issue transaction
                       Dr Sales Returns  Cr Store Credit Liability
                       (store.credit.transaction → account.move)

VOUCHER REDEMPTION (new sale)
    │
    ├─ POS order paid with store credit payment method
    ├─ store.credit.redeem transaction
    │      Dr Store Credit Liability  Cr Redemption Clearing
    ├─ Session close on sale order
    │      Dr Redemption Clearing  Cr Receivable (net with other payments)
    └─ Never post store credit as negative sale line

VOUCHER EXPIRY / CANCEL
    │
    ├─ EXPIRE ─► Dr Store Credit Liability  Cr Breakage Revenue (or Sales Returns)
    └─ CANCEL ► Dr Store Credit Liability  Cr Sales Returns (restore)
```

### 4.2 Scenario A — Uninvoiced return → Voucher (Rs. 5,000)

| Step | Operational event | Accounting entry | Journal |
|------|-------------------|------------------|---------|
| 1 | Original sale Rs. 10,000 | (prior session) Dr Cash 10,000 / Cr Sales 10,000 | POS Session |
| 2 | Return order −5,000 (technical clearing pm) | (session close) Dr Sales 5,000 / Cr Refund Clearing 5,000 | POS Session |
| 3 | Settlement = Voucher | — | — |
| 4 | `store.credit` issue Rs. 5,000 | Dr Sales Returns 5,000 / Cr SC Liability 5,000 | Store Credit Journal |
| 5 | Reconcile clearing ↔ issue | Clear Refund Clearing against Sales Returns (or auto-match) | — |

**Net P&L:** Sales reduced by 5,000 (step 2) — issue entry moves amount to liability (balance sheet), no second revenue hit.

### 4.3 Scenario B — Uninvoiced return → Cash refund

| Step | Event | Entry |
|------|-------|-------|
| 1 | Return order −5,000 | Dr Sales 5,000 / Cr Refund Clearing 5,000 (session) |
| 2 | Cash settlement | Dr Refund Clearing 5,000 / Cr Cash 5,000 |

**No liability entry.**

### 4.4 Scenario C — Invoiced return → Credit note + Voucher

| Step | Event | Entry |
|------|-------|-------|
| 1 | Credit note `out_refund` | Dr Sales 5,000 / Cr AR 5,000 |
| 2 | Voucher issue | Dr Sales Returns 5,000 / Cr SC Liability 5,000 |
| 3 | Reconcile | AR credit note balance ↔ optional clearing; liability independent |

**Rule:** Credit note handles revenue/tax reversal; liability entry records customer obligation. Do **not** also negative-post sales in session for the same return.

### 4.5 Scenario D — Voucher redemption on Rs. 3,500 sale (voucher Rs. 5,000, partial)

| Step | Event | Entry |
|------|-------|-------|
| 1 | New sale Rs. 3,500 (cash Rs. 0) | Session: Dr SC Clearing 3,500 / Cr Sales 3,500 (+ tax) |
| 2 | Redeem Rs. 3,500 | Dr SC Liability 3,500 / Cr SC Clearing 3,500 |
| 3 | Remainder Rs. 1,500 | Liability stays on balance sheet (or new voucher per strategy) |

**Sales is never discounted** — full sales amount is recognized; liability clearing acts as payment.

### 4.6 Scenario E — Voucher expiry (Rs. 1,500 remaining)

| Step | Event | Entry |
|------|-------|-------|
| 1 | `store.credit.expire` txn | Dr SC Liability 1,500 / Cr Breakage Revenue 1,500 |

### 4.7 Scenario F — Manual adjustment (+/−)

| Direction | Entry |
|-----------|-------|
| Increase liability | Dr Sales Returns (or configured adj. account) / Cr SC Liability |
| Decrease liability | Dr SC Liability / Cr Sales Returns |

Requires manager approval in operational layer; accounting mirrors `txn_type=adjustment`.

### 4.8 Scenario G — Exchange (store owes customer)

| Step | Event | Entry |
|------|-------|-------|
| 1 | Return leg (via return txn) | Standard return entries |
| 2 | Replacement sale | Standard POS sale |
| 3 | Difference < 0 (credit to customer) | `store.credit.issue` for abs(difference) — same as voucher issue |

---

## 5. Accounting Mapping

### 5.1 `store.credit.transaction` → Journal entry

| txn_type | signed_amount | Debit | Credit | move_type |
|----------|---------------|-------|--------|-----------|
| `issue` | + | `sales_returns_account_id` | `liability_account_id` | `entry` |
| `redeem` | − | `liability_account_id` | `redemption_clearing_account_id` | `entry` |
| `cancel` | − | `liability_account_id` | `sales_returns_account_id` | `entry` |
| `expire` | − | `liability_account_id` | `breakage_revenue_account_id` | `entry` |
| `adjustment` | + | `sales_returns_account_id` | `liability_account_id` | `entry` |
| `adjustment` | − | `liability_account_id` | `sales_returns_account_id` | `entry` |
| `transfer` | − (source) | `liability_account_id` | `liability_account_id` (inter-company only if allowed) | `entry` |
| `transfer` | + (target) | mirror of source | paired move or net-zero internal | `entry` |

**Note:** Refine `expense_account_id` → split into `sales_returns_account_id` and `redemption_clearing_account_id` in implementation.

### 5.2 `pos.return.transaction` → Accounting touchpoints

| refund_method | Settlement | Accounting path |
|---------------|------------|-----------------|
| `voucher` | Voucher issue | `action_complete` → `_issue_store_credit` → issue txn → liability move |
| `cash` | Cash payment | `pos.payment` → session cash lines; clear refund clearing |
| `original_payment` | Link original PM | Payment refund per method + receivable reconciliation |
| `exchange` | Exchange txn | Return + sale entries; difference via issue txn |

### 5.3 `pos.order` linkage

| Order type | Primary accounting document |
|------------|----------------------------|
| Original sale (uninvoiced) | `session_id.move_id` |
| Original sale (invoiced) | `account_move` (`out_invoice`) |
| Return order (uninvoiced) | Included in session `move_id` |
| Return order (invoiced) | `account_move` (`out_refund`) |
| Redemption sale | Session `move_id` + redeem liability entry |

### 5.4 `account.move` extension fields (existing + proposed)

| Field | Links to |
|-------|----------|
| `store_credit_id` | `store.credit` (exists) |
| `store_credit_transaction_id` | `store.credit.transaction` (exists) |
| `return_voucher_id` | `pos.return.voucher` (exists) |
| `pos_return_transaction_id` | `pos.return.transaction` (to add) |
| `pos_order_id` | `pos.order` (to add) |
| `pos_session_id` | `pos.session` (to add) |

---

## 6. Business Rules

### 6.1 Revenue integrity

| ID | Rule |
|----|------|
| BR-REV-01 | A return line shall reverse revenue exactly once across session entry OR credit note. |
| BR-REV-02 | Store credit redemption shall not create a negative `pos.order.line` or invoice line. |
| BR-REV-03 | Store credit shall not use `account.move` `discount` or `%` price reduction patterns. |
| BR-REV-04 | Tax reversal on returns follows Odoo tax engine on credit note or session tax lines. |

### 6.2 Liability integrity

| ID | Rule |
|----|------|
| BR-LIA-01 | Sum of posted liability credits minus debits = outstanding `store.credit.amount_remaining` per credit (reconciled periodically). |
| BR-LIA-02 | Issue entry amount = `store.credit.transaction.amount` for `txn_type=issue`. |
| BR-LIA-03 | Redeem entry amount = redeem transaction amount; must not exceed remaining liability. |
| BR-LIA-04 | Expire/cancel entries only for remaining balance. |
| BR-LIA-05 | Partial redemption remainder (new voucher strategy) issues new liability entry; original fully debited. |

### 6.3 Refund / settlement integrity

| ID | Rule |
|----|------|
| BR-REF-01 | `settlement_state=settled` requires accounting completion OR explicit `skipped` with reason. |
| BR-REF-02 | Cash settlement amount = `pos.return.transaction.amount_total` (± rounding). |
| BR-REF-03 | Voucher settlement shall not create duplicate `issue` if credit already linked. |
| BR-REF-04 | Technical return-order payment must use clearing payment method, not customer cash, when `refund_clearing_account_id` is configured. |

### 6.4 Posting timing

| Event | When to post |
|-------|--------------|
| Uninvoiced sale/return revenue | `pos.session.action_pos_session_close` |
| Invoiced credit note | `pos.order._generate_pos_order_invoice` or manual invoice wizard |
| Store credit issue | On `store.credit.transaction` create (posted state) — after settlement confirms voucher |
| Store credit redeem | On redeem transaction create — after `pos.order` paid sync |
| Expire | Cron / manual — on expire transaction |
| Cancel | On cancel transaction |

### 6.5 Posting guards

| Guard | Action |
|-------|--------|
| Missing journal/accounts | `accounting_state=skipped`; block settlement completion if `enable_accounting` and strict mode |
| Duplicate `move_id` | Skip; log audit |
| Fiscal lock date | Respect `account.move` lock dates; queue for later post |
| Unbalanced move | Raise `UserError`; do not partial post |

---

## 7. Integration Design

### 7.1 Module structure (implementation target)

```
codebraze_pos_store_credit_accounting/
├── models/
│   ├── account_move.py              # extend links
│   ├── store_credit_settings.py     # extend config (exists)
│   ├── store_credit_transaction.py  # posting engine (exists, refine)
│   ├── store_credit.py              # orchestration hooks
│   ├── pos_return_transaction.py    # return → accounting bridge
│   ├── pos_order.py                 # invoiced credit note coordination
│   ├── pos_session.py               # clearing reconciliation on close
│   ├── pos_payment.py               # cash settlement moves
│   └── pos_return_voucher.py        # aggregate state (exists)
├── services/
│   └── account_move_service.py      # NEW — single posting orchestrator
├── data/
│   ├── account_account_data.xml       # optional default accounts
│   └── payment_method_clearing.xml    # refund clearing PM
└── views/
    └── res_config_settings_views.xml
```

### 7.2 Service: `AccountMoveService`

Central orchestrator (Python, next phase). Responsibilities:

| Method | Purpose |
|--------|---------|
| `post_credit_transaction(txn)` | Build & post move from txn; set `move_id`, `is_accounted` |
| `reverse_credit_transaction(txn, reason)` | Standard `account.move.reversal` |
| `link_return_settlement(ret, method)` | Coordinate settlement with clearing |
| `reconcile_clearing_for_return(ret)` | Match refund clearing to issue/cash |
| `validate_configuration(company, config)` | Pre-flight before go-live |
| `get_accounting_audit_trail(document)` | Return all linked moves |

**Delegation:** Call `account.move.create` + `action_post()` — never raw SQL.

### 7.3 Integration hooks

| Hook location | Trigger | Action |
|---------------|---------|--------|
| `store.credit.transaction.create` | posted txn | `AccountMoveService.post_credit_transaction` (exists, refine accounts) |
| `pos.return.transaction` settlement | `pos_settle_return` success | Trigger issue txn if voucher; cash move if cash |
| `pos.return.confirm` | return order paid | Assign clearing payment method |
| `pos.session._create_account_move` | session close | Reconcile SC clearing lines with redeem/issue entries |
| `pos.order._create_invoice` | invoiced return | Ensure credit note; skip duplicate session revenue for invoiced orders |
| `pos.payment._create_payment_moves` | cash refund | Standard — already bypasses store credit |
| `store.credit.transaction` reverse | reversal txn | `account.move.reversal` linked via `parent_txn_id` |

### 7.4 Duplication prevention matrix

| Risk | Prevention |
|------|------------|
| Revenue reversed twice (session + credit note) | `order.is_invoiced` flag routes to single path |
| Cash refunded twice (technical + settlement) | Reuse existing payment in `_execute_cash_settlement`; clearing PM design |
| Liability issued twice | `credit_id` unique per return; idempotent `issue` txn check |
| Redemption reduces sales AND liability | Store credit PM excluded from `_create_payment_moves`; redeem via liability only |
| Session receivable mismatch | Redemption clearing account nets in session close |

### 7.5 Reconciliation design

| Pair | Method |
|------|--------|
| Credit note AR ↔ original invoice AR | Odoo standard `reversed_entry_id` reconciliation |
| Refund clearing ↔ liability issue | `account.partial.reconcile` on clearing and sales returns lines |
| Redemption clearing ↔ session receivable | Session close matching by partner + reference |
| Cash settlement ↔ refund clearing | On settlement confirm |

---

## 8. Audit & Traceability

### 8.1 Required links on every `account.move`

| Document type | Required fields populated |
|---------------|-------------------------|
| Liability issue/redeem | `store_credit_id`, `store_credit_transaction_id`, `return_voucher_id` (if any), `pos_order_id`, `pos_return_transaction_id` |
| Credit note | `pos_order_ids`, `pos_refunded_invoice_ids` (Odoo standard) + `pos_return_transaction_id` |
| Cash refund | `pos_order_id`, `pos_return_transaction_id`, `pos_payment_ids` |

### 8.2 Audit log alignment

| Operational audit | Accounting counterpart |
|-------------------|------------------------|
| `pos.return.audit` settlement_confirmed | `account.move` posted/ref |
| `store.credit.audit` issue/redeem | `store.credit.transaction.move_id` |
| `store.credit.audit` print | no move (non-financial) |

### 8.3 Reporting views (future, not this phase)

- Store Credit Liability aging (by issue date, expiry)
- Return → Credit Note → Voucher chain report
- Unreconciled refund clearing dashboard

---

## 9. Implementation Phases (for subsequent prompts)

| Prompt | Scope |
|--------|-------|
| **04a** | Configuration model + settings UI + default accounts wizard |
| **04b** | Refine `store.credit.transaction` posting (split accounts, multi-currency) |
| **04c** | Return settlement bridge + refund clearing payment method |
| **04d** | Invoiced return credit note integration + `pos_return_transaction_id` on moves |
| **04e** | Session close reconciliation for redemption clearing |
| **04f** | Reversal engine + fiscal lock handling |
| **04g** | Accounting tests + reconciliation assertions |
| **04h** | Exchange accounting (difference issue) |

---

## 10. Open Design Decisions (resolve before coding)

| # | Decision | Recommendation |
|---|----------|----------------|
| 1 | Rename `expense_account_id` → split accounts | **Yes** — `sales_returns_account_id` + `redemption_clearing_account_id` |
| 2 | Technical return payment method | **Dedicated clearing PM** per POS config (avoid false cash outflow) |
| 3 | Invoiced + voucher: issue entry counterpart | **Sales Returns** aligned with credit note contra account |
| 4 | Expiry: breakage vs returns | **Configurable** — default breakage revenue |
| 5 | Strict accounting mode | Block settlement if accounts missing when `enable_accounting=True` |
| 6 | Transfer accounting | Net-zero internal liability transfer (single paired entry or two mirrored entries) |

---

## 11. Compliance Checklist (design validation)

- [x] Every product return creates proper accounting records (session or credit note)
- [x] Every store credit issue creates liability entry
- [x] Voucher redemption reduces liability (not discount)
- [x] Sales revenue never duplicated (routing rules defined)
- [x] Refund entries never duplicated (clearing + idempotency)
- [x] Configurable accounts and journals
- [x] Multi-company support
- [x] Multi-currency support
- [x] Every journal entry linked to source documents
- [x] Reuses Odoo standard POS session and credit note flows
- [x] Builds on existing `codebraze_pos_store_credit_accounting` scaffold

---

*This document is the implementation blueprint for Phase 04. No Python code is included by design.*
