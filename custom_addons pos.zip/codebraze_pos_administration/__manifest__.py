# -*- coding: utf-8 -*-
{
    "name": "CodeBraze POS Return & Store Credit Administration",
    "version": "19.0.2.0.0",
    "category": "Sales/Point of Sale",
    "summary": "Backend administration for returns, store credits and vouchers",
    "description": """
Return & Store Credit Administration
====================================
Manager and administrator backend screens for returns, exchanges,
store credits, vouchers, redemptions, approvals and audit logs.
    """,
    "author": "CodeBraze",
    "website": "https://www.codebraze.com",
    "license": "LGPL-3",
    "depends": [
        "point_of_sale",
        "mail",
        "codebraze_pos_store_credit",
        "codebraze_pos_return",
        "codebraze_pos_return_voucher",
        "codebraze_pos_store_credit_accounting",
        "codebraze_pos_approval",
    ],
    "data": [
        "security/return_admin_security.xml",
        "security/ir.model.access.csv",
        "security/ir_rule.xml",
        "views/store_credit_views.xml",
        "views/store_credit_timeline_views.xml",
        "views/res_partner_store_credit_views.xml",
        "views/store_credit_transaction_views.xml",
        "views/store_credit_payment_views.xml",
        "views/store_credit_audit_views.xml",
        "views/pos_return_voucher_views.xml",
        "views/pos_return_transaction_views.xml",
        "views/pos_exchange_transaction_views.xml",
        "views/pos_return_audit_views.xml",
        "views/store_credit_settings_views.xml",
        "views/return_admin_menus.xml",
        "wizards/store_credit_wizard_views.xml",
        "data/ir_cron_data.xml",
        "data/server_actions.xml",
    ],
    "application": False,
    "installable": True,
    "auto_install": False,
}
