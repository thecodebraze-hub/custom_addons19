# -*- coding: utf-8 -*-
"""Backend administration actions and smart-button helpers on store.credit."""

from odoo import _, api, fields, models
from odoo.exceptions import UserError


class StoreCreditAdmin(models.Model):
    _inherit = "store.credit"

    is_frozen = fields.Boolean(
        string="Frozen",
        default=False,
        tracking=True,
        help="When frozen, the credit cannot be redeemed until unfrozen.",
    )
    return_voucher_ids = fields.One2many(
        comodel_name="pos.return.voucher",
        inverse_name="credit_id",
        string="Vouchers",
    )
    return_transaction_ids = fields.One2many(
        comodel_name="pos.return.transaction",
        inverse_name="credit_id",
        string="Return Transactions",
    )
    voucher_id = fields.Many2one(
        comodel_name="pos.return.voucher",
        string="Return Voucher",
        compute="_compute_admin_links",
        store=True,
    )
    voucher_number = fields.Char(
        related="voucher_id.voucher_number",
        string="Voucher Number",
        store=True,
    )
    return_transaction_id = fields.Many2one(
        comodel_name="pos.return.transaction",
        string="Return Transaction",
        compute="_compute_admin_links",
        store=True,
    )
    return_order_id = fields.Many2one(
        comodel_name="pos.order",
        string="Return Invoice",
        related="return_transaction_id.return_order_id",
        store=True,
    )
    redemption_count = fields.Integer(compute="_compute_admin_counts")
    audit_count = fields.Integer(compute="_compute_admin_counts")
    approval_count = fields.Integer(compute="_compute_admin_counts")
    account_move_count = fields.Integer(compute="_compute_admin_counts")
    print_count = fields.Integer(
        related="voucher_id.print_count",
        string="Print Count",
    )
    partner_mobile = fields.Char(related="partner_id.mobile", string="Customer Mobile")
    partner_phone = fields.Char(related="partner_id.phone", string="Customer Phone")
    return_number = fields.Char(
        related="return_transaction_id.name",
        string="Return Number",
        store=True,
    )
    original_invoice_name = fields.Char(
        related="original_order_id.name",
        string="Original Invoice",
        store=True,
    )

    def _log_admin_audit(
        self,
        action,
        message=None,
        amount=0.0,
        old_value=None,
        new_value=None,
        before_data=None,
        after_data=None,
        manager=None,
        reason=None,
    ):
        """Structured audit for manual administration actions."""
        self.ensure_one()
        extra = {
            "manager_id": (manager or self.env.user).id,
            "old_value": old_value,
            "new_value": new_value,
            "before_data": before_data,
            "after_data": after_data,
        }
        audit = self._log_audit(
            action=action,
            message=message or reason,
            amount=amount,
            extra={k: v for k, v in extra.items() if v is not None},
        )
        if audit and reason:
            audit.message = "%s — %s" % (audit.message or action, reason)
        self._rebuild_timeline()
        return audit

    @api.depends("return_voucher_ids", "return_transaction_ids", "origin_model", "origin_res_id")
    def _compute_admin_links(self):
        ReturnTxn = self.env["pos.return.transaction"]
        for credit in self:
            voucher = credit.return_voucher_ids[:1]
            ret = credit.return_transaction_ids[:1]
            if not ret and credit.origin_model == "pos.return.transaction" and credit.origin_res_id:
                ret = ReturnTxn.browse(credit.origin_res_id).exists()
            credit.voucher_id = voucher.id if voucher else False
            credit.return_transaction_id = ret.id if ret else False

    @api.depends("transaction_ids", "payment_ids", "audit_ids")
    def _compute_admin_counts(self):
        Move = self.env["account.move"]
        Approval = self.env["pos.approval.history"]
        for credit in self:
            credit.redemption_count = len(credit.payment_ids)
            credit.audit_count = len(credit.audit_ids)
            credit.approval_count = Approval.search_count(
                [("credit_id", "=", credit.id)]
            )
            credit.account_move_count = Move.search_count(
                [("store_credit_id", "=", credit.id)]
            )

    def _validate_credit(self, amount=None, for_redeem=False):
        for credit in self:
            if credit.is_frozen:
                raise UserError(
                    self.env._(
                        "Store credit %(name)s is frozen. Unfreeze before proceeding.",
                        name=credit.name,
                    )
                )
        return super()._validate_credit(amount=amount, for_redeem=for_redeem)

    # -------------------------------------------------------------------------
    # Manager actions
    # -------------------------------------------------------------------------

    def action_cancel_credit(self):
        self._check_admin_access("manager")
        service = self.env["store.credit.admin.service"]
        service.validate_admin_action(
            self, "cancel", reason=self.env.context.get("cancel_reason")
        )
        for credit in self:
            old_state = credit.state
            old_remaining = credit.amount_remaining
            credit._cancel_credit(
                reason=self.env.context.get("cancel_reason"),
                user=self.env.user,
            )
            credit._log_admin_audit(
                action="cancel",
                message=self.env._("Store credit cancelled"),
                amount=-old_remaining,
                old_value="%s / %s" % (old_state, old_remaining),
                new_value="cancelled / 0",
                reason=self.env.context.get("cancel_reason"),
            )
        return True

    def action_expire_credit(self):
        self._check_admin_access("manager")
        self.env["store.credit.admin.service"].validate_admin_action(self, "expire")
        for credit in self:
            old_state = credit.state
            old_remaining = credit.amount_remaining
            credit._expire_credit(user=self.env.user)
            credit._log_admin_audit(
                action="expire",
                message=self.env._("Store credit expired"),
                amount=-old_remaining,
                old_value="%s / %s" % (old_state, old_remaining),
                new_value="expired / 0",
            )
        return True

    def action_freeze_credit(self):
        self._check_admin_access("manager")
        self.env["store.credit.admin.service"].validate_admin_action(self, "freeze")
        for credit in self.filtered(lambda c: not c.is_frozen):
            credit.write({"is_frozen": True})
            credit._log_admin_audit(
                action="adjustment",
                message=self.env._("Store credit frozen by administrator"),
                old_value="unfrozen",
                new_value="frozen",
            )
        return True

    def action_unfreeze_credit(self):
        self._check_admin_access("manager")
        self.env["store.credit.admin.service"].validate_admin_action(self, "unfreeze")
        for credit in self.filtered(lambda c: c.is_frozen):
            credit.write({"is_frozen": False})
            credit._log_admin_audit(
                action="adjustment",
                message=self.env._("Store credit unfrozen by administrator"),
                old_value="frozen",
                new_value="unfrozen",
            )
        return True

    def action_deactivate_credit(self):
        self._check_admin_access("manager")
        self.write({"active": False})
        return True

    def action_reactivate_credit(self):
        self._check_admin_access("administrator")
        self.write({"active": True})
        return True

    def action_open_transfer_wizard(self):
        self._check_admin_access("manager")
        if len(self) != 1:
            raise UserError(self.env._("Select a single store credit to transfer."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Transfer Store Credit"),
            "res_model": "store.credit.transfer.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_source_credit_id": self.id},
        }

    def action_open_merge_wizard(self):
        self._check_admin_access("administrator")
        return {
            "type": "ir.actions.act_window",
            "name": _("Merge Store Credits"),
            "res_model": "store.credit.merge.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_credit_ids": self.ids},
        }

    def action_open_split_wizard(self):
        self._check_admin_access("administrator")
        if len(self) != 1:
            raise UserError(self.env._("Select a single store credit to split."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Split Store Credit"),
            "res_model": "store.credit.split.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_credit_id": self.id},
        }

    def action_open_adjust_wizard(self):
        self._check_admin_access("manager")
        return {
            "type": "ir.actions.act_window",
            "name": _("Adjust Store Credit"),
            "res_model": "store.credit.adjust.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_credit_ids": self.ids},
        }

    def action_open_extend_expiry_wizard(self):
        self._check_admin_access("manager")
        return {
            "type": "ir.actions.act_window",
            "name": _("Extend Expiry"),
            "res_model": "store.credit.extend.expiry.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_credit_ids": self.ids},
        }

    def action_open_manual_redeem_wizard(self):
        self._check_admin_access("manager")
        return {
            "type": "ir.actions.act_window",
            "name": _("Manual Redemption"),
            "res_model": "store.credit.manual.redeem.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {"default_credit_id": self[:1].id},
        }

    def action_reprint_voucher(self):
        self._check_admin_access("supervisor")
        for credit in self:
            voucher = credit.voucher_id
            if not voucher:
                raise UserError(
                    self.env._(
                        "No return voucher linked to store credit %(name)s.",
                        name=credit.name,
                    )
                )
            voucher.action_reprint_voucher()
        return True

    # -------------------------------------------------------------------------
    # Smart buttons
    # -------------------------------------------------------------------------

    def action_view_transactions(self):
        self.ensure_one()
        return self._admin_action_window(
            _("Transactions"),
            "store.credit.transaction",
            [("credit_id", "=", self.id)],
        )

    def action_view_redemptions(self):
        self.ensure_one()
        return self._admin_action_window(
            _("Redemptions"),
            "store.credit.payment",
            [("credit_id", "=", self.id)],
        )

    def action_view_audit_logs(self):
        self.ensure_one()
        return self._admin_action_window(
            _("Audit Logs"),
            "store.credit.audit",
            [("credit_id", "=", self.id)],
        )

    def action_view_approvals(self):
        self.ensure_one()
        return self._admin_action_window(
            _("Approvals"),
            "pos.approval.history",
            [("credit_id", "=", self.id)],
        )

    def action_view_return_order(self):
        self.ensure_one()
        if not self.return_transaction_id:
            raise UserError(self.env._("No return transaction linked."))
        return {
            "type": "ir.actions.act_window",
            "name": _("Return"),
            "res_model": "pos.return.transaction",
            "view_mode": "form",
            "res_id": self.return_transaction_id.id,
        }

    def action_view_pos_order(self):
        self.ensure_one()
        order = self.original_order_id or self.return_order_id
        if not order:
            raise UserError(self.env._("No POS order linked."))
        return {
            "type": "ir.actions.act_window",
            "name": _("POS Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": order.id,
        }

    def action_view_account_moves(self):
        self.ensure_one()
        return self._admin_action_window(
            _("Accounting Entries"),
            "account.move",
            [("store_credit_id", "=", self.id)],
            view_mode="list,form",
        )

    def action_view_print_history(self):
        self.ensure_one()
        return self.action_view_audit_logs()


    def _admin_action_window(self, name, model, domain, view_mode="list,form"):
        return {
            "type": "ir.actions.act_window",
            "name": name,
            "res_model": model,
            "view_mode": view_mode,
            "domain": domain,
            "context": dict(self.env.context),
        }

    def _check_admin_access(self, level="supervisor"):
        """Enforce CodeBraze administration security groups."""
        user = self.env.user
        mapping = {
            "cashier": "codebraze_pos_administration.group_sc_cashier",
            "supervisor": "codebraze_pos_administration.group_sc_supervisor",
            "manager": "codebraze_pos_administration.group_sc_manager",
            "administrator": "codebraze_pos_administration.group_sc_administrator",
        }
        group_xmlid = mapping.get(level, mapping["manager"])
        if not user.has_group(group_xmlid):
            raise UserError(
                self.env._("You do not have permission to perform this action.")
            )
