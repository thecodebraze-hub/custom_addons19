# -*- coding: utf-8 -*-
"""Customer store credit profile and history aggregates."""

from odoo import api, fields, models


class ResPartnerStoreCredit(models.Model):
    _inherit = "res.partner"

    store_credit_ids = fields.One2many(
        comodel_name="store.credit",
        inverse_name="partner_id",
        string="Store Credits",
    )
    sc_total_issued = fields.Monetary(
        string="Total Credit Issued",
        compute="_compute_store_credit_stats",
        currency_field="sc_currency_id",
    )
    sc_total_redeemed = fields.Monetary(
        string="Total Credit Redeemed",
        compute="_compute_store_credit_stats",
        currency_field="sc_currency_id",
    )
    sc_available_balance = fields.Monetary(
        string="Available Balance",
        compute="_compute_store_credit_stats",
        currency_field="sc_currency_id",
    )
    sc_active_count = fields.Integer(
        string="Active Credits",
        compute="_compute_store_credit_stats",
    )
    sc_expired_count = fields.Integer(
        string="Expired Credits",
        compute="_compute_store_credit_stats",
    )
    sc_used_count = fields.Integer(
        string="Used Credits",
        compute="_compute_store_credit_stats",
    )
    sc_cancelled_count = fields.Integer(
        string="Cancelled Credits",
        compute="_compute_store_credit_stats",
    )
    sc_currency_id = fields.Many2one(
        comodel_name="res.currency",
        compute="_compute_store_credit_stats",
    )
    sc_return_count = fields.Integer(compute="_compute_store_credit_history_counts")
    sc_redemption_count = fields.Integer(compute="_compute_store_credit_history_counts")
    sc_adjustment_count = fields.Integer(compute="_compute_store_credit_history_counts")

    @api.depends("store_credit_ids", "store_credit_ids.amount", "store_credit_ids.amount_used", "store_credit_ids.amount_remaining", "store_credit_ids.state", "store_credit_ids.currency_id")
    def _compute_store_credit_stats(self):
        for partner in self:
            credits = partner.store_credit_ids
            partner.sc_currency_id = (
                credits[:1].currency_id if credits else partner.company_id.currency_id
            )
            partner.sc_total_issued = sum(credits.mapped("amount"))
            partner.sc_total_redeemed = sum(credits.mapped("amount_used"))
            active = credits.filtered(
                lambda c: c.state in ("issued", "partially_used") and c.amount_remaining > 0
            )
            partner.sc_available_balance = sum(active.mapped("amount_remaining"))
            partner.sc_active_count = len(active)
            partner.sc_expired_count = len(credits.filtered(lambda c: c.state == "expired"))
            partner.sc_used_count = len(credits.filtered(lambda c: c.state == "used"))
            partner.sc_cancelled_count = len(credits.filtered(lambda c: c.state == "cancelled"))

    def _compute_store_credit_history_counts(self):
        Return = self.env["pos.return.transaction"]
        Payment = self.env["store.credit.payment"]
        Audit = self.env["store.credit.audit"]
        for partner in self:
            credit_ids = partner.store_credit_ids.ids
            partner.sc_return_count = Return.search_count(
                [("partner_id", "=", partner.id)]
            )
            partner.sc_redemption_count = Payment.search_count(
                [("credit_id", "in", credit_ids)]
            ) if credit_ids else 0
            partner.sc_adjustment_count = Audit.search_count(
                [
                    ("credit_id", "in", credit_ids),
                    ("action", "=", "adjustment"),
                ]
            ) if credit_ids else 0

    def action_view_store_credit_profile(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Store Credit Profile"),
            "res_model": "res.partner",
            "view_mode": "form",
            "res_id": self.id,
            "views": [
                (
                    self.env.ref(
                        "codebraze_pos_administration.view_partner_store_credit_profile_form"
                    ).id,
                    "form",
                )
            ],
            "target": "current",
        }

    def action_view_active_store_credits(self):
        return self._partner_credit_action(
            self.env._("Active Store Credits"),
            [("state", "in", ("issued", "partially_used")), ("amount_remaining", ">", 0)],
        )

    def action_view_expired_store_credits(self):
        return self._partner_credit_action(
            self.env._("Expired Store Credits"),
            [("state", "=", "expired")],
        )

    def action_view_used_store_credits(self):
        return self._partner_credit_action(
            self.env._("Used Store Credits"),
            [("state", "=", "used")],
        )

    def action_view_cancelled_store_credits(self):
        return self._partner_credit_action(
            self.env._("Cancelled Store Credits"),
            [("state", "=", "cancelled")],
        )

    def action_view_customer_returns(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Returns"),
            "res_model": "pos.return.transaction",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
        }

    def action_view_customer_redemptions(self):
        self.ensure_one()
        credit_ids = self.store_credit_ids.ids
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Redemptions"),
            "res_model": "store.credit.payment",
            "view_mode": "list,form",
            "domain": [("credit_id", "in", credit_ids or [0])],
        }

    def action_view_customer_adjustments(self):
        self.ensure_one()
        credit_ids = self.store_credit_ids.ids
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Manual Adjustments"),
            "res_model": "store.credit.audit",
            "view_mode": "list,form",
            "domain": [
                ("credit_id", "in", credit_ids or [0]),
                ("action", "=", "adjustment"),
            ],
        }

    def _partner_credit_action(self, name, extra_domain):
        self.ensure_one()
        domain = [("partner_id", "=", self.id)] + extra_domain
        return {
            "type": "ir.actions.act_window",
            "name": name,
            "res_model": "store.credit",
            "view_mode": "list,form",
            "domain": domain,
            "context": {"default_partner_id": self.id},
        }
