# -*- coding: utf-8 -*-
"""Administration helpers on return transactions."""

from odoo import _, fields, models


class PosReturnTransactionAdmin(models.Model):
    _inherit = "pos.return.transaction"

    voucher_count = fields.Integer(compute="_compute_admin_counts")
    payment_count = fields.Integer(compute="_compute_admin_counts")

    def _compute_admin_counts(self):
        for ret in self:
            ret.voucher_count = 1 if ret.voucher_id or ret.credit_id else 0
            ret.payment_count = 1 if ret.settlement_payment_id else 0

    def action_view_return_order(self):
        self.ensure_one()
        if not self.return_order_id:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": _("Return Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": self.return_order_id.id,
        }

    def action_view_original_order(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Original Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": self.original_order_id.id,
        }

    def action_view_store_credit(self):
        self.ensure_one()
        if not self.credit_id:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": _("Store Credit"),
            "res_model": "store.credit",
            "view_mode": "form",
            "res_id": self.credit_id.id,
        }

    def action_view_audit_logs(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Audit Logs"),
            "res_model": "pos.return.audit",
            "view_mode": "list,form",
            "domain": [("payload", "ilike", str(self.id))],
        }
