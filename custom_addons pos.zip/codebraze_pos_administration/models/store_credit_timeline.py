# -*- coding: utf-8 -*-
"""Unified lifecycle timeline for store credits."""

from odoo import api, fields, models


class StoreCreditTimeline(models.Model):
    _name = "store.credit.timeline"
    _description = "Store Credit Timeline"
    _order = "event_date desc, id desc"
    _check_company_auto = True

    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        required=True,
        ondelete="cascade",
        index=True,
    )
    partner_id = fields.Many2one(
        comodel_name="res.partner",
        string="Customer",
        related="credit_id.partner_id",
        store=True,
        index=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        related="credit_id.company_id",
        store=True,
    )
    event_type = fields.Selection(
        selection=[
            ("issue", "Issue"),
            ("print", "Print"),
            ("redeem", "Redeem"),
            ("partial_redeem", "Partial Redeem"),
            ("expiry_extension", "Expiry Extension"),
            ("adjustment", "Adjustment"),
            ("freeze", "Freeze"),
            ("unfreeze", "Unfreeze"),
            ("transfer", "Transfer"),
            ("cancellation", "Cancellation"),
            ("expire", "Expire"),
            ("approval", "Approval"),
        ],
        required=True,
        index=True,
    )
    event_date = fields.Datetime(string="Date", required=True, index=True)
    description = fields.Text(string="Description")
    amount = fields.Monetary(currency_field="currency_id")
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="credit_id.currency_id",
    )
    user_id = fields.Many2one(comodel_name="res.users", string="User")
    manager_id = fields.Many2one(comodel_name="res.users", string="Manager")
    old_value = fields.Char(string="Old Value")
    new_value = fields.Char(string="New Value")
    reason = fields.Char(string="Reason")
    res_model = fields.Char(string="Source Model")
    res_id = fields.Integer(string="Source ID")

    @api.model
    def _map_audit_action(self, action):
        mapping = {
            "issue": "issue",
            "redeem": "redeem",
            "partial_redeem": "partial_redeem",
            "cancel": "cancellation",
            "expire": "expire",
            "print": "print",
            "adjustment": "adjustment",
            "transfer": "transfer",
            "approval": "approval",
        }
        return mapping.get(action, "adjustment")

    @api.model
    def _map_txn_type(self, txn_type):
        mapping = {
            "issue": "issue",
            "redeem": "redeem",
            "cancel": "cancellation",
            "expire": "expire",
            "adjustment": "adjustment",
            "transfer": "transfer",
        }
        return mapping.get(txn_type, "adjustment")


class StoreCreditTimelineMixin(models.Model):
    _inherit = "store.credit"

    timeline_ids = fields.One2many(
        comodel_name="store.credit.timeline",
        inverse_name="credit_id",
        string="Timeline",
    )
    timeline_count = fields.Integer(compute="_compute_timeline_count")

    @api.depends("timeline_ids")
    def _compute_timeline_count(self):
        for credit in self:
            credit.timeline_count = len(credit.timeline_ids)

    def action_rebuild_timeline(self):
        self._rebuild_timeline()
        return True

    def action_view_timeline(self):
        self.ensure_one()
        self._rebuild_timeline()
        return {
            "type": "ir.actions.act_window",
            "name": self.env._("Timeline"),
            "res_model": "store.credit.timeline",
            "view_mode": "list",
            "domain": [("credit_id", "=", self.id)],
            "context": dict(self.env.context),
        }

    def _rebuild_timeline(self):
        Timeline = self.env["store.credit.timeline"]
        for credit in self:
            Timeline.search([("credit_id", "=", credit.id)]).unlink()
            entries = []
            seen_keys = set()

            def _add(entry):
                key = (
                    entry.get("event_type"),
                    entry.get("event_date"),
                    entry.get("res_model"),
                    entry.get("res_id"),
                )
                if key in seen_keys:
                    return
                seen_keys.add(key)
                entry["credit_id"] = credit.id
                entries.append(entry)

            for txn in credit.transaction_ids.filtered(lambda t: t.state == "posted"):
                _add(
                    {
                        "event_type": Timeline._map_txn_type(txn.txn_type),
                        "event_date": txn.date or txn.create_date,
                        "description": txn.note or txn.name,
                        "amount": txn.signed_amount,
                        "user_id": txn.user_id.id,
                        "res_model": "store.credit.transaction",
                        "res_id": txn.id,
                    }
                )

            for payment in credit.payment_ids:
                _add(
                    {
                        "event_type": "redeem",
                        "event_date": payment.create_date,
                        "description": payment.name,
                        "amount": -abs(payment.amount),
                        "user_id": payment.cashier_id.id,
                        "res_model": "store.credit.payment",
                        "res_id": payment.id,
                    }
                )

            for audit in credit.audit_ids:
                event_type = Timeline._map_audit_action(audit.action)
                if audit.message and "frozen" in (audit.message or "").lower():
                    event_type = "freeze"
                elif audit.message and "unfrozen" in (audit.message or "").lower():
                    event_type = "unfreeze"
                elif audit.message and "expiry extended" in (audit.message or "").lower():
                    event_type = "expiry_extension"
                _add(
                    {
                        "event_type": event_type,
                        "event_date": audit.create_date,
                        "description": audit.message,
                        "amount": audit.amount,
                        "user_id": audit.cashier_id.id,
                        "manager_id": audit.manager_id.id,
                        "old_value": audit.old_value,
                        "new_value": audit.new_value,
                        "res_model": "store.credit.audit",
                        "res_id": audit.id,
                    }
                )

            Approval = self.env["pos.approval.history"]
            for approval in Approval.search([("credit_id", "=", credit.id)]):
                _add(
                    {
                        "event_type": "approval",
                        "event_date": approval.approve_datetime or approval.create_date,
                        "description": "%s — %s" % (approval.approval_type, approval.state),
                        "amount": approval.amount,
                        "user_id": approval.requester_id.id,
                        "manager_id": approval.approver_id.id,
                        "reason": approval.reason,
                        "res_model": "pos.approval.history",
                        "res_id": approval.id,
                    }
                )

            if entries:
                Timeline.create(entries)
