# -*- coding: utf-8 -*-
"""Administration actions on return vouchers."""

from odoo import _, models
from odoo.exceptions import UserError


class PosReturnVoucherAdmin(models.Model):
    _inherit = "pos.return.voucher"

    def action_reprint_voucher(self):
        for voucher in self:
            voucher._register_print(user=self.env.user)
        return True

    def action_print_voucher(self):
        return self.action_reprint_voucher()

    def action_cancel_voucher(self):
        if not self.env.user.has_group(
            "codebraze_pos_administration.group_sc_manager"
        ):
            raise UserError(_("You do not have permission to cancel vouchers."))
        for voucher in self:
            voucher._cancel_voucher(
                reason=self.env.context.get("cancel_reason"),
                user=self.env.user,
            )
        return True

    def action_expire_voucher(self):
        if not self.env.user.has_group(
            "codebraze_pos_administration.group_sc_manager"
        ):
            raise UserError(_("You do not have permission to expire vouchers."))
        for voucher in self:
            voucher._expire_voucher(user=self.env.user)
        return True

    def action_open_store_credit(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": _("Store Credit"),
            "res_model": "store.credit",
            "view_mode": "form",
            "res_id": self.credit_id.id,
        }
