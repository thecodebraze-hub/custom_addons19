# -*- coding: utf-8 -*-
"""Read-only audit display helpers."""

from odoo import fields, models


class StoreCreditAuditAdmin(models.Model):
    _inherit = "store.credit.audit"

    branch_id = fields.Many2one(
        related="config_id",
        string="Branch",
        store=True,
    )
    old_value = fields.Char(string="Old Value")
    new_value = fields.Char(string="New Value")
