# -*- coding: utf-8 -*-
"""Validation service for backend store credit administration actions."""

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools import float_compare


class StoreCreditAdminService(models.AbstractModel):
    _name = "store.credit.admin.service"
    _description = "Store Credit Administration Service"

    ACTIVE_STATES = ("issued", "partially_used")
    ADJUSTABLE_STATES = ("issued", "partially_used", "draft")

    @api.model
    def validate_admin_action(self, credits, action, **kwargs):
        """Validate credits before a backend administration action."""
        errors = []
        amount = float(kwargs.get("amount") or 0.0)
        user = self.env.user
        required_level = kwargs.get("required_level", "manager")
        credits._check_admin_access(required_level)

        for credit in credits:
            credit_errors = self._validate_single_credit(
                credit, action, amount=amount, **kwargs
            )
            errors.extend(credit_errors)

        if errors:
            raise UserError("\n".join(errors))
        return True

    @api.model
    def _validate_single_credit(self, credit, action, amount=0.0, **kwargs):
        errors = []
        precision = credit.currency_id.rounding
        label = credit.name

        if not credit.active and action not in ("reactivate", "export"):
            errors.append(
                self.env._("%(name)s is archived.", name=label)
            )

        if action in ("redeem", "transfer", "decrease") and credit.is_frozen:
            errors.append(
                self.env._("%(name)s is frozen.", name=label)
            )

        if action in ("redeem", "transfer", "decrease", "cancel", "expire", "extend_expiry"):
            if action == "cancel":
                if credit.state not in self.ACTIVE_STATES + ("draft",):
                    errors.append(
                        self.env._(
                            "%(name)s cannot be cancelled in status %(state)s.",
                            name=label,
                            state=credit.state,
                        )
                    )
            elif action in ("transfer", "decrease", "extend_expiry", "redeem", "expire"):
                if credit.state in ("cancelled", "used", "expired"):
                    errors.append(
                        self.env._(
                            "%(name)s has status %(state)s and cannot be modified.",
                            name=label,
                            state=credit.state,
                        )
                    )
                elif action in ("transfer", "decrease", "redeem") and credit.state not in self.ACTIVE_STATES:
                    errors.append(
                        self.env._("%(name)s is not active.", name=label)
                    )

        if action in ("transfer", "decrease", "redeem") and amount:
            if float_compare(amount, credit.amount_remaining, precision_rounding=precision) > 0:
                errors.append(
                    self.env._(
                        "Amount exceeds remaining balance on %(name)s.",
                        name=label,
                    )
                )

        if action in ("redeem", "transfer") and credit.expiry_date:
            if credit.expiry_date < fields.Datetime.now() and credit.state != "expired":
                errors.append(
                    self.env._("%(name)s has expired.", name=label)
                )

        target_partner = kwargs.get("target_partner_id")
        if action == "transfer" and target_partner and credit.partner_id:
            if credit.partner_id.id != target_partner:
                pass  # cross-customer transfer allowed for managers

        target_company = kwargs.get("target_company_id")
        if target_company and credit.company_id.id != target_company:
            errors.append(
                self.env._("%(name)s belongs to another company.", name=label)
            )

        target_config = kwargs.get("target_config_id")
        settings = self.env["store.credit.settings"]._get_settings(
            company=credit.company_id,
            config=credit.config_id,
        )
        if (
            target_config
            and settings
            and getattr(settings, "branch_specific_voucher", True)
            and credit.config_id
            and credit.config_id.id != target_config
            and action in ("redeem", "transfer")
        ):
            errors.append(
                self.env._("%(name)s belongs to another branch.", name=label)
            )

        if action in ("adjust", "decrease", "increase") and not kwargs.get("reason"):
            errors.append(
                self.env._("A reason is required for adjustments on %(name)s.", name=label)
            )

        return errors

    @api.model
    def check_adjustment_approval(self, credit, amount, increase=True):
        """Return whether manager approval is required for an adjustment."""
        service = self.env["pos.approval.service"]
        signed_amount = amount if increase else -amount
        evaluation = service.evaluate(
            {
                "approval_type": "manual_adjustment",
                "amount": signed_amount,
                "currency_id": credit.currency_id.id,
                "company_id": credit.company_id.id,
                "config_id": credit.config_id.id if credit.config_id else False,
                "exception_codes": ["negative_adjustment"] if signed_amount < 0 else [],
            }
        )
        if not evaluation.get("required"):
            return {"required": False}
        user = self.env.user
        if user.has_group("codebraze_pos_administration.group_sc_manager"):
            return {
                "required": True,
                "auto_approved": True,
                "manager_id": user.id,
                "reasons": evaluation.get("reasons", []),
            }
        return {
            "required": True,
            "auto_approved": False,
            "reasons": evaluation.get("reasons", []),
            "min_level": evaluation.get("min_level", "store_manager"),
        }
