# -*- coding: utf-8 -*-
"""Administration helpers on exchange transactions."""

from odoo import _, models


class PosExchangeTransactionAdmin(models.Model):
    _inherit = "pos.exchange.transaction"

    def action_view_return(self):
        self.ensure_one()
        if not self.return_id:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": _("Return"),
            "res_model": "pos.return.transaction",
            "view_mode": "form",
            "res_id": self.return_id.id,
        }

    def action_view_replacement_order(self):
        self.ensure_one()
        if not self.replacement_order_id:
            return False
        return {
            "type": "ir.actions.act_window",
            "name": _("Replacement Order"),
            "res_model": "pos.order",
            "view_mode": "form",
            "res_id": self.replacement_order_id.id,
        }
