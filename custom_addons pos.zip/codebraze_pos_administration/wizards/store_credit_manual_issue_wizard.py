# -*- coding: utf-8 -*-
"""Manual store credit issuance from backend."""

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class StoreCreditManualIssueWizard(models.TransientModel):
    _name = "store.credit.manual.issue.wizard"
    _description = "Manual Store Credit Issue"

    partner_id = fields.Many2one("res.partner", string="Customer")
    credit_type = fields.Selection(
        selection=[
            ("return", "Return"),
            ("manual", "Manual"),
            ("compensation", "Compensation"),
            ("promotion", "Promotion"),
            ("gift", "Gift"),
        ],
        required=True,
        default="manual",
    )
    amount = fields.Monetary(currency_field="currency_id", required=True)
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        default=lambda self: self.env.company.currency_id,
        required=True,
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        default=lambda self: self.env.company,
        required=True,
    )
    config_id = fields.Many2one(
        comodel_name="pos.config",
        string="Branch",
        check_company=True,
        domain="[('company_id', '=', company_id)]",
    )
    expiry_date = fields.Datetime(string="Expiry Date")
    note = fields.Text(string="Notes")

    def action_issue(self):
        self.ensure_one()
        if self.amount <= 0:
            raise ValidationError(_("Amount must be positive."))
        credit = self.env["store.credit"]._create_credit(
            {
                "partner_id": self.partner_id.id or False,
                "credit_type": self.credit_type,
                "amount": self.amount,
                "currency_id": self.currency_id.id,
                "company_id": self.company_id.id,
                "config_id": self.config_id.id or False,
                "expiry_date": self.expiry_date or False,
                "note": self.note,
                "manager_id": self.env.user.id,
            }
        )
        return {
            "type": "ir.actions.act_window",
            "name": _("Store Credit"),
            "res_model": "store.credit",
            "view_mode": "form",
            "res_id": credit.id,
        }
