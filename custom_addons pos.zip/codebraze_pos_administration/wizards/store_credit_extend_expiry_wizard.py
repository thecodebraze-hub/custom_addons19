# -*- coding: utf-8 -*-
"""Extend store credit expiry date with full audit."""

import json

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class StoreCreditExtendExpiryWizard(models.TransientModel):
    _name = "store.credit.extend.expiry.wizard"
    _description = "Extend Store Credit Expiry"

    credit_ids = fields.Many2many(
        comodel_name="store.credit",
        string="Store Credits",
        required=True,
    )
    new_expiry_date = fields.Datetime(string="New Expiry Date", required=True)
    reason = fields.Text(string="Reason", required=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        active_ids = self.env.context.get("active_ids") or []
        if active_ids and "credit_ids" in fields_list:
            res["credit_ids"] = [(6, 0, active_ids)]
        return res

    def action_apply(self):
        self.ensure_one()
        if not self.new_expiry_date:
            raise ValidationError(_("Expiry date is required."))
        service = self.env["store.credit.admin.service"]
        service.validate_admin_action(
            self.credit_ids, "extend_expiry", reason=self.reason
        )
        for credit in self.credit_ids:
            old = credit.expiry_date
            credit.write({"expiry_date": self.new_expiry_date})
            credit._log_admin_audit(
                action="adjustment",
                message=self.env._(
                    "Expiry extended from %(old)s to %(new)s",
                    old=old,
                    new=self.new_expiry_date,
                ),
                old_value=str(old) if old else "",
                new_value=str(self.new_expiry_date),
                before_data=json.dumps({"expiry_date": str(old) if old else False}),
                after_data=json.dumps({"expiry_date": str(self.new_expiry_date)}),
                reason=self.reason,
            )
        return {"type": "ir.actions.act_window_close"}
