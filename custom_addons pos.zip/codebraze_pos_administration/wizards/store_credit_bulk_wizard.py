# -*- coding: utf-8 -*-
"""Bulk operations on store credits."""

import base64
import csv
import io
from datetime import datetime

from odoo import _, fields, models
from odoo.exceptions import UserError


class StoreCreditBulkWizard(models.TransientModel):
    _name = "store.credit.manual.bulk.wizard"
    _description = "Bulk Store Credit Operations"

    credit_ids = fields.Many2many(
        comodel_name="store.credit",
        string="Store Credits",
        required=True,
    )
    operation = fields.Selection(
        selection=[
            ("expire", "Expire"),
            ("cancel", "Cancel"),
            ("freeze", "Freeze"),
            ("unfreeze", "Unfreeze"),
            ("extend_expiry", "Extend Expiry"),
            ("activate", "Activate"),
            ("deactivate", "Deactivate"),
            ("print", "Reprint Vouchers"),
            ("export", "Export CSV"),
        ],
        required=True,
    )
    reason = fields.Text(string="Reason")
    new_expiry_date = fields.Datetime(string="New Expiry Date")

    def action_apply(self):
        self.ensure_one()
        credits = self.credit_ids
        if not credits:
            raise UserError(_("No store credits selected."))

        if self.operation == "expire":
            credits.action_expire_credit()
        elif self.operation == "cancel":
            if not self.reason:
                raise UserError(_("A reason is required for bulk cancellation."))
            credits.with_context(cancel_reason=self.reason).action_cancel_credit()
        elif self.operation == "freeze":
            credits.action_freeze_credit()
        elif self.operation == "unfreeze":
            credits.action_unfreeze_credit()
        elif self.operation == "extend_expiry":
            if not self.new_expiry_date:
                raise UserError(_("New expiry date is required."))
            self.env["store.credit.extend.expiry.wizard"].create(
                {
                    "credit_ids": [(6, 0, credits.ids)],
                    "new_expiry_date": self.new_expiry_date,
                    "reason": self.reason or _("Bulk expiry extension"),
                }
            ).action_apply()
        elif self.operation == "activate":
            credits.action_reactivate_credit()
        elif self.operation == "deactivate":
            credits.action_deactivate_credit()
        elif self.operation == "print":
            credits.action_reprint_voucher()
        elif self.operation == "export":
            return self._action_export_csv(credits)

        return {"type": "ir.actions.act_window_close"}

    def _action_export_csv(self, credits):
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(
            [
                "Reference",
                "Voucher Number",
                "Barcode",
                "Customer",
                "Status",
                "Credit Amount",
                "Used",
                "Remaining",
                "Issue Date",
                "Expiry Date",
                "Branch",
                "Frozen",
            ]
        )
        for credit in credits:
            writer.writerow(
                [
                    credit.name,
                    credit.voucher_number or "",
                    credit.barcode or "",
                    credit.partner_id.name or "",
                    credit.state,
                    credit.amount,
                    credit.amount_used,
                    credit.amount_remaining,
                    credit.issue_date or "",
                    credit.expiry_date or "",
                    credit.config_id.name or "",
                    "Yes" if credit.is_frozen else "No",
                ]
            )
        data = base64.b64encode(buffer.getvalue().encode("utf-8"))
        filename = "store_credits_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M%S")
        attachment = self.env["ir.attachment"].create(
            {
                "name": filename,
                "type": "binary",
                "datas": data,
                "mimetype": "text/csv",
            }
        )
        return {
            "type": "ir.actions.act_url",
            "url": "/web/content/%s?download=true" % attachment.id,
            "target": "self",
        }
