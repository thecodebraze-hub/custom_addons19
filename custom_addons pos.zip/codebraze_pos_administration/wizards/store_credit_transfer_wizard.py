# -*- coding: utf-8 -*-
"""Transfer store credit balance to another instrument."""

import json

from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class StoreCreditTransferWizard(models.TransientModel):
    _name = "store.credit.transfer.wizard"
    _description = "Transfer Store Credit"

    source_credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Source Credit",
        required=True,
    )
    target_credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Target Credit",
        required=True,
        domain="[('id', '!=', source_credit_id), ('company_id', '=', company_id), ('state', 'in', ('issued', 'partially_used'))]",
    )
    amount = fields.Monetary(currency_field="currency_id", required=True)
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="source_credit_id.currency_id",
    )
    company_id = fields.Many2one(
        comodel_name="res.company",
        related="source_credit_id.company_id",
    )
    remaining_amount = fields.Monetary(
        related="source_credit_id.amount_remaining",
        string="Available Balance",
    )
    reason = fields.Text(string="Reason", required=True)

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        credit_id = self.env.context.get("default_source_credit_id")
        if credit_id and "amount" in fields_list:
            credit = self.env["store.credit"].browse(credit_id).exists()
            if credit:
                res["amount"] = credit.amount_remaining
        return res

    def action_apply(self):
        self.ensure_one()
        if self.amount <= 0:
            raise ValidationError(_("Transfer amount must be positive."))
        service = self.env["store.credit.admin.service"]
        service.validate_admin_action(
            self.source_credit_id,
            "transfer",
            amount=self.amount,
            reason=self.reason,
        )
        old_source = self.source_credit_id.amount_remaining
        old_target = self.target_credit_id.amount_remaining
        self.source_credit_id._transfer_credit_to(
            self.target_credit_id,
            self.amount,
            reason=self.reason,
            user=self.env.user,
        )
        self.source_credit_id._log_admin_audit(
            action="transfer",
            message=self.env._(
                "Transferred %(amount)s to %(target)s",
                amount=self.amount,
                target=self.target_credit_id.name,
            ),
            amount=-self.amount,
            old_value=str(old_source),
            new_value=str(self.source_credit_id.amount_remaining),
            before_data=json.dumps({"target": self.target_credit_id.name}),
            reason=self.reason,
        )
        self.target_credit_id._log_admin_audit(
            action="transfer",
            message=self.env._(
                "Received %(amount)s from %(source)s",
                amount=self.amount,
                source=self.source_credit_id.name,
            ),
            amount=self.amount,
            old_value=str(old_target),
            new_value=str(self.target_credit_id.amount_remaining),
            before_data=json.dumps({"source": self.source_credit_id.name}),
            reason=self.reason,
        )
        return {"type": "ir.actions.act_window_close"}
