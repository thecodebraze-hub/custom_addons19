# -*- coding: utf-8 -*-
"""Manual balance adjustment wizard with approval and audit."""

import json

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError


class StoreCreditAdjustWizard(models.TransientModel):
    _name = "store.credit.adjust.wizard"
    _description = "Store Credit Adjustment"

    credit_ids = fields.Many2many(
        comodel_name="store.credit",
        string="Store Credits",
        required=True,
    )
    adjustment_type = fields.Selection(
        selection=[
            ("increase", "Increase"),
            ("decrease", "Decrease"),
        ],
        required=True,
        default="increase",
    )
    amount = fields.Monetary(currency_field="currency_id", required=True)
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        default=lambda self: self.env.company.currency_id,
    )
    reason = fields.Text(string="Reason", required=True)
    manager_id = fields.Many2one(
        comodel_name="res.users",
        string="Approving Manager",
    )
    approval_required = fields.Boolean(compute="_compute_approval_required")
    approval_notes = fields.Text(string="Approval Notes")

    @api.depends("credit_ids", "amount", "adjustment_type")
    def _compute_approval_required(self):
        service = self.env["store.credit.admin.service"]
        for wizard in self:
            required = False
            increase = wizard.adjustment_type == "increase"
            for credit in wizard.credit_ids:
                result = service.check_adjustment_approval(
                    credit, wizard.amount or 0.0, increase=increase
                )
                if result.get("required") and not result.get("auto_approved"):
                    required = True
                    break
            wizard.approval_required = required

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        active_ids = self.env.context.get("active_ids") or self.env.context.get(
            "default_credit_ids"
        )
        if active_ids and "credit_ids" in fields_list:
            res["credit_ids"] = [(6, 0, active_ids)]
        return res

    def action_apply(self):
        self.ensure_one()
        if self.amount <= 0:
            raise ValidationError(_("Adjustment amount must be positive."))
        increase = self.adjustment_type == "increase"
        service = self.env["store.credit.admin.service"]
        approval_service = self.env["pos.approval.service"]

        for credit in self.credit_ids:
            service.validate_admin_action(
                credit,
                "increase" if increase else "decrease",
                amount=self.amount,
                reason=self.reason,
            )
            approval_check = service.check_adjustment_approval(
                credit, self.amount, increase=increase
            )
            manager = self.manager_id or self.env.user
            if approval_check.get("required"):
                signed = self.amount if increase else -self.amount
                approved = approval_service.ensure_approved(
                    {
                        "approval_type": "manual_adjustment",
                        "amount": signed,
                        "currency_id": credit.currency_id.id,
                        "company_id": credit.company_id.id,
                        "config_id": credit.config_id.id if credit.config_id else False,
                        "credit_id": credit.id,
                    },
                    {
                        "manager_approved": bool(
                            approval_check.get("auto_approved") or self.manager_id
                        ),
                        "manager_id": manager.id,
                    },
                )
                if not approved.get("valid"):
                    approval_service.create_request(
                        {
                            "approval_type": "manual_adjustment",
                            "credit_id": credit.id,
                            "amount": abs(signed),
                            "currency_id": credit.currency_id.id,
                            "company_id": credit.company_id.id,
                            "config_id": credit.config_id.id,
                            "reason": self.reason,
                            "exception_codes": ["negative_adjustment"]
                            if signed < 0
                            else [],
                        }
                    )
                    raise UserError(
                        _(
                            "Manager approval is required for this adjustment. "
                            "An approval request has been created."
                        )
                    )

            old_remaining = credit.amount_remaining
            old_face = credit.amount
            credit._adjust_credit(
                self.amount,
                reason=self.reason,
                user=manager,
                increase=increase,
            )
            credit._log_admin_audit(
                action="adjustment",
                message=self.env._(
                    "Manual adjustment (%(direction)s) by %(amount)s",
                    direction="increase" if increase else "decrease",
                    amount=self.amount,
                ),
                amount=self.amount if increase else -self.amount,
                old_value=json.dumps(
                    {"remaining": old_remaining, "face_amount": old_face}
                ),
                new_value=json.dumps(
                    {
                        "remaining": credit.amount_remaining,
                        "face_amount": credit.amount,
                    }
                ),
                manager=manager,
                reason=self.reason,
            )
        return {"type": "ir.actions.act_window_close"}
