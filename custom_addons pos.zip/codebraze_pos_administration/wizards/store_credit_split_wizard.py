# -*- coding: utf-8 -*-
"""Future-ready split credit wizard (stub)."""

from odoo import _, fields, models
from odoo.exceptions import UserError


class StoreCreditSplitWizard(models.TransientModel):
    _name = "store.credit.split.wizard"
    _description = "Split Store Credit (Future)"

    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        required=True,
    )
    split_amount = fields.Monetary(currency_field="currency_id")
    currency_id = fields.Many2one(
        comodel_name="res.currency",
        related="credit_id.currency_id",
    )
    reason = fields.Text(string="Reason")

    def action_apply(self):
        raise UserError(
            _(
                "Split credit is reserved for a future release. "
                "Use Transfer Credit to move part of a balance to a new instrument."
            )
        )
