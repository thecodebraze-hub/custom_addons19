# -*- coding: utf-8 -*-
"""Future-ready merge credits wizard (stub)."""

from odoo import _, fields, models
from odoo.exceptions import UserError


class StoreCreditMergeWizard(models.TransientModel):
    _name = "store.credit.merge.wizard"
    _description = "Merge Store Credits (Future)"

    credit_ids = fields.Many2many(
        comodel_name="store.credit",
        string="Store Credits",
        required=True,
    )
    reason = fields.Text(string="Reason")

    def action_apply(self):
        raise UserError(
            _(
                "Merge credits is reserved for a future release. "
                "Use Transfer Credit to move balances between instruments."
            )
        )
