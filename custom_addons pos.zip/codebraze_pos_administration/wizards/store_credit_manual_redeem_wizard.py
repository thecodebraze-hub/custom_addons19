# -*- coding: utf-8 -*-
"""Manual redemption from backend."""

from odoo import _, fields, models
from odoo.exceptions import ValidationError


class StoreCreditManualRedeemWizard(models.TransientModel):
    _name = "store.credit.manual.redeem.wizard"
    _description = "Manual Store Credit Redemption"

    credit_id = fields.Many2one(
        comodel_name="store.credit",
        string="Store Credit",
        required=True,
    )
    amount = fields.Monetary(currency_field="currency_id", required=True)
    currency_id = fields.Many2one(related="credit_id.currency_id")
    remaining_amount = fields.Monetary(
        related="credit_id.amount_remaining",
        string="Remaining",
    )
    pos_order_id = fields.Many2one("pos.order", string="POS Order")
    reason = fields.Text(string="Reason", required=True)

    def action_redeem(self):
        self.ensure_one()
        if self.amount <= 0:
            raise ValidationError(_("Redemption amount must be positive."))
        self.credit_id._validate_credit(amount=self.amount, for_redeem=True)
        self.credit_id._redeem_credit(
            self.amount,
            pos_order=self.pos_order_id,
            extra_vals={"note": self.reason},
        )
        return {"type": "ir.actions.act_window_close"}
